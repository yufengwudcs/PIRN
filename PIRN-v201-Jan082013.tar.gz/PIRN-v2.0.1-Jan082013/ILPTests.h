#ifndef ILP_TESTS_H
#define ILP_TESTS_H 1

// Contain code to test out ILP to see whether they work and on what data range
// TBD

void OutputMinCostAddTree( char *filename );


#endif



