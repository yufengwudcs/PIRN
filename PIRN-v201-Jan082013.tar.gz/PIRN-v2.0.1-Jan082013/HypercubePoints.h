#ifndef HYPERCUBE_POINTS_H
#define  HYPERCUBE_POINTS_H

#include <set>
#include <map>
#include <vector>
using namespace std;


// 
class HPPEntry
{
public:
	HPPEntry();
	void AddPairInfo( const pair<int,int> &pp, int count );
	// initialize by looking at a single bit
	static void FindCandiateAtSingleBit(int numPoints, vector<HPPEntry> &listCandidates);
	// merge the count of two records
	void MergeWith( const HPPEntry &entryToMerge );
	// no need to keep larger distance than the required dist (i.e. collapse distance >= bound)
	void ApplyBound(map< pair<int, int>, int > &mapDistPairwise);
	// is the distance satisfying the min requirements?
	bool IsCompatible( map< pair<int, int>, int > &mapDistPairwise );
	bool operator <(const HPPEntry &lc2) const
	{
		return mapNumDiffBits < lc2.mapNumDiffBits;
	}
	void Dump();

private:
	// for each pair of nodes <i,j>, the number of times the two take different bits (0 and 1)
	map< pair<int,int>, int> mapNumDiffBits;
};



// Test whether it is feasible to place a certain number of points
// in a fixed dimensional hypercube
class HypercubePointsPlacement
{
public:
	HypercubePointsPlacement( int numPoints, const map< pair<int, int>, int > &mapDistPairwise );
	HypercubePointsPlacement( const vector< vector<int> > &vecDistPairwise );

	// test whether it works for some m-dimensional 
	bool IsFeasibleFor(int dimHC);
	int GetNumPoints() { return numPoints; }

private:
	int numPoints;
	map< pair<int, int>, int > mapDistPairwise; 
	set< HPPEntry > setLastBuiltHPPEntries;
	int szLastBuildHPP;
};


#endif
