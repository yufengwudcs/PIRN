// *************************************************************************************************
// Include section

#include "GML2ExtNewick.h"
#include <sstream>

//**************************************************************************************************
graph gmlProcess(string filename);
void  printGML(graph rawG,graph G,string input_filename,string output_filename);
graph  deleteRedundantNodes(graph G);
graph  new_deleteRedundantNodes(graph G,bool fHVLines);
void OutputQuotString(ofstream &outFile, const char *buf);
vector<node> find_refined_neighbors(node startNode,graph G,vector<node> refinedNodes);
vector<node> find_refined_directed_neighbors(node startNode,graph G,vector<node> refinedNodes);
void  printDirectedGML(int rawNodeCount,graph refinedG,string input_filename,string output_filename);
phyTree network2Tree(graph topDownG, graph bottonUpG,bool fOrigHNum);
string printExtendedNewick(phyTree  T );
void visitTree(node root, phyTree T);

graph reverseDirection(graph G);
//Global Variable 
unsigned int nodeCountRawGraph=0;     //Global Variable for count node in raw graph
unsigned int nodeCountRefinedGraph=0; //Global Variable for count node in refined graph
string newickString;
bool leafFlag=false;  // If leafFlag is true, the program just processed a leaf before



// *************************************************************************************************
// @fn          convertGML2ExtNewick
// @brief       Function responsable to transfer the gml format to extended newick format 
// @param       file stream
// @return      none
// *************************************************************************************************
string convertGML2ExtNewick(string filename,bool fOrigHNum)
{
	//cout<<"convertGML2ExtNewick..."<<endl;
	graph bottomUpG;  // In rawG, the edges direction is bottom up
	bottomUpG=gmlProcess(filename);
	multimap<node, node>::iterator iter;
	
	phyTree  T;
	graph topDownG = reverseDirection(bottomUpG);// In topDownG, the edges direction is Top down
	T=network2Tree(topDownG,bottomUpG,fOrigHNum);
	string resultNewickString = printExtendedNewick(T);
	return resultNewickString;
	
}
// *************************************************************************************************
// @fn          network2Tree
// @brief       Cutting in-edge all but one of each reticulate node, which means the node�� indegree ��2 in topDown Graph
// @param       graph topDownG
// @return      phyTree  T
// *************************************************************************************************
phyTree network2Tree(graph topDownG, graph bottomUpG,bool fOrigHNum)
{
	phyTree  T;
	vector<node> reticulateNodes;
	typedef multimap<node,node>::iterator multi_iter_Type;
    // Initialize treeEdgeSet using oringinal topDown directed edge
	T.treeEdgeSet = topDownG.directedEdgeSet;
	T.rootID =  bottomUpG.rootID;

	map<int,int> nodeIdMap; // oringal id -> 1 2 3 ...id 
	int retiCount=1;
	//Label nodes
	for(int i=1; i<= bottomUpG.nodesCount; i++)
	{   
		// Find reticulate node: indegree ��2 in topDown Graph, also means outdegree ��2 in bottomUp Graph
		if( bottomUpG.directedEdgeSet.count(i)==2)
		{
		    // node i is reticulate node
			reticulateNodes.push_back(i);
			treeNode temp;

			stringstream ss;
			ss << i;
			string i_str = ss.str();


			stringstream sd;
			sd << retiCount;
			string retiCount_str = sd.str();
			if(fOrigHNum == true)
			{
			  temp.label="#H"+i_str;
			}
			else
			{
			  temp.label="#H"+retiCount_str;
			  nodeIdMap.insert(pair<int,int>(i,retiCount));
			}

			temp.nodeID= i;
			T.treeNodes.push_back(temp);

			retiCount++;
		}
		else if(topDownG.directedEdgeSet.count(i)==0)
		{
		    treeNode temp;
			string leafLabel=bottomUpG.labelSet[i];
			string rmQuoteLeafLabel = leafLabel.substr(1,leafLabel.length()-2);
			temp.label=rmQuoteLeafLabel;
			temp.nodeID= i;
			T.treeNodes.push_back(temp);
		}
		else
		{
		    treeNode temp;
			temp.label = "";
			temp.nodeID= i;
			T.treeNodes.push_back(temp);
		}
	}

	//Cutting in-edge all but one of each reticulate node
	vector<node>::iterator vec_iter;
	for(vec_iter =reticulateNodes.begin(); vec_iter != reticulateNodes.end(); vec_iter ++ )
	{
	    node rtNode = *vec_iter;

		// Find reticulate i's  parents, for all parent but one, create new edge to a new leaf labeled #Hi 
		// Delete the olde pareent--> rtNode edge
		
		pair<multi_iter_Type, multi_iter_Type> pairIterTemp = bottomUpG.directedEdgeSet.equal_range(rtNode);
		multi_iter_Type it1 = pairIterTemp.first;
		//We leave the first parent, so ++it1
		++it1;

		for (; it1 != pairIterTemp.second; ++it1)
		{
			//For each parent node 

			if((*it1).first ==  rtNode)
			{
				 node parentNode =(*it1).second;

				  //Insert new node
				 treeNode newNode;
				 newNode.nodeID= T.treeNodes.size()+1;
                                
				 stringstream ss;
				 ss << rtNode;
				 string rtNode_str = ss.str();

				if(fOrigHNum == true)
				{
				  newNode.label="#H"+rtNode_str;
				}
				else
				{
				  int new123ID= nodeIdMap[rtNode];
				  stringstream sd;
				  sd << new123ID;
				  string new_str = sd.str();
				  newNode.label="#H"+new_str;
				}
				retiCount++;
				 T.treeNodes.push_back(newNode);

				  //Insert Edge
				  T.treeEdgeSet.insert(pair<node,node>( parentNode, newNode.nodeID));

				  //Delete edge: parent --> rtNode
		          pair<multi_iter_Type, multi_iter_Type> parentPairIterTemp = T.treeEdgeSet.equal_range(parentNode);
		          multi_iter_Type parentIt = parentPairIterTemp.first;
				  for (; parentIt !=  parentPairIterTemp.second; ++parentIt)
				  { 
					  if((*parentIt).first == parentNode)
					  {
						  if ((*parentIt).second == rtNode)
						  {
							  T.treeEdgeSet.erase(parentIt);
							  break;
						  }
					  }
				  }

			}

				 
		}
	
	}

	//Test
	/*
	multimap<node, node>::iterator iterTree;
	for(iterTree = T.treeEdgeSet.begin();iterTree != T.treeEdgeSet.end(); iterTree++)
	{
		cout<<"node "<< (*iterTree).first << " => "<< (*iterTree).second <<endl;
	}

	vector<treeNode>::iterator tNiter;
	for(tNiter = T.treeNodes.begin(); tNiter != T.treeNodes.end(); tNiter++)
	{
		cout<<"node "<< (*tNiter).nodeID <<"label:"<< (*tNiter).label<<endl;
	}*/ 
		
	return T;
}


string printExtendedNewick(phyTree  T)
{
	//cout<<"printing Extended Newick"<<endl;
	visitTree(T.rootID,T);
	newickString+=";";
	return newickString;
}

void visitTree(node rootID, phyTree T)
{
	typedef multimap<node,node>::iterator multi_iter_Type;

	//Leaf
	if(T.treeEdgeSet.count(rootID) == 0 )
	{
	   //Find this node's label
		leafFlag=true;
		string nodeLabel;
		vector<treeNode>::iterator trIter;
		for(trIter = T.treeNodes.begin(); trIter != T.treeNodes.end(); trIter++)
		{
			if((*trIter).nodeID == rootID)
			{
				nodeLabel= (*trIter).label;
				break;
			}
		}
	    newickString = newickString + nodeLabel;

	}
	//Internal 
	else
	{    
		pair<multi_iter_Type, multi_iter_Type> pairIter = T.treeEdgeSet.equal_range(rootID);
		int childrenCount = T.treeEdgeSet.count(rootID);
		newickString += "(";
		multi_iter_Type Iter = pairIter.first;
		for (; Iter != pairIter.second; ++Iter)
		{   
			childrenCount--;
			if((*Iter).first == rootID)
			{   
			   visitTree((*Iter).second,T);
			   if(childrenCount>0)
			   {
			    newickString += ",";
			   }
			}
		}

		//Find this node's label
		string nodeLabel;
		vector<treeNode>::iterator trIter;
		for(trIter = T.treeNodes.begin(); trIter != T.treeNodes.end(); trIter++)
		{
			if((*trIter).nodeID == rootID)
			{
				nodeLabel= (*trIter).label;
				break;
			}
		}
		newickString += ")";
		newickString += nodeLabel;
	}
}
void  refineNetwork(string input_filename,string output_filename, bool fHVLines)
{  
	//cout<<"refineNetwork running..."<<endl;
	graph rawG,refinedG;
	rawG=gmlProcess(input_filename);
	refinedG=new_deleteRedundantNodes(rawG,fHVLines);
	//graph revG=reverseDirection(refinedG);
	printDirectedGML(rawG.nodesCount,refinedG,input_filename,output_filename);

	//cout<<"I am testing, ok?";
}

graph gmlProcess(string filename)
{
	graph G;
	multimap<node, node> edgeSet;
	multimap<node, node> directedEdgeSet;

	ifstream fin;
	fin.open(filename.c_str());

	// First process some header info
	string header;

	fin>>header;
	if(header != "graph")
	{
		cout<<"Please input right gml file";
	}
	string line;
	for(int i=0;i<5;i++)
	{
		getline(fin,line);
		//cout<<line<<"\n";
	}

	int nodeNumber=0;
	while(getline(fin,line))
	{
		//count node
		if(line=="node [")
		{   
			nodeNumber++;

			string temp;
			node  nodeID;
			string nodelabel;
			fin>>temp;
			//cout<<temp;
			fin>>nodeID;
			//cout<<"node:"<<nodeID<<endl;
			fin>>temp;
			fin>>nodelabel;
			G.nodesID.push_back(nodeID);
			G.labelSet.insert(pair<node,string>(nodeID,nodelabel));
		}
		//get X, Y, Z node
		if(line=="  center [")
		{   
			position p;
			string temp;
			fin>>temp;
			fin>>p.x;
			fin>>temp;
			fin>>p.y;
			fin>>temp;
			fin>>p.z;
			G.positionSet.insert(pair<node,position>(G.nodesID.back(),p));
		}
		//Read edge
		if(line=="edge [")
		{ 
			//cout<<"edge:";
			string temp;
			node sourceID, targetID;
			fin>>temp;
			fin>>sourceID;
			//cout<<sourceID<<" ";
			fin>>temp;
			fin>>targetID;
			//cout<<targetID<<"\n";
			edgeSet.insert(pair<node,node>(sourceID,targetID) );
			directedEdgeSet.insert(pair<node,node>(sourceID,targetID));
			edgeSet.insert(pair<node,node>(targetID,sourceID) );  

		}


	}

	G.edgeSet=edgeSet;
	G.nodesCount= nodeNumber;
	G.directedEdgeSet=directedEdgeSet;

	
	//First we need find the root, which indegree is 0. In PIRN, the direction of arrow is reversed,
	//which means the node who's outdegree is 0 is the root!
	for(unsigned int i=1; i<=nodeNumber;i++)
	{ 
		
		if(G.directedEdgeSet.count(i)==0)
		{
			//cout<<"node "<<i<<" is the root!"<<endl;
			G.rootID=i;
		}
		
	}

	fin.close();
	return G ;
}

void  printGML(graph rawG,graph refinedG,string input_filename,string output_filename)
{
	ifstream fin;
	ofstream fout;
	map<int,int> oldID_newID_map;
	//cout<<"printing..."<<endl;
	fin.open(input_filename.c_str());
	fout.open(output_filename.c_str());
	string l;
	//process header
	for(int i=0;i<5;i++)
	{
		getline(fin,l);
		fout<<l<<"\n";
	}


	for(unsigned int i=0; i< rawG.nodesCount; i++)
	{
		string temp,line;  // used for absove useless string
		node nodeID;
		getline(fin,line);
		bool vgjTag = false;
		if(line !="node [")
		{
			cout<<"wrong gml format! ";
		}
		fin>>temp;
		fin>>nodeID;   //get the node id of that node 
		//cout<<"nodeID"<<endl;

		//Judge if this node is in refinedG.nodesID or not
		unsigned int index=-1;
		for(unsigned int ii=0; ii< refinedG.nodesID.size();ii++)
		{

			if(refinedG.nodesID[ii] == nodeID)  
			{   
				index=ii;
				//cout<<refinedG.nodesID[ii] <<"="<<index+1<<endl;
				oldID_newID_map.insert(pair<int,int>(nodeID,index+1));
				break;
			}
			else
			{
				index=-1;
			}

			//cout<<"refinedNode:"<<refinedG.nodesID[i]<<endl;
		}

		if(index == -1) //Can not find the nodeID in refined.nodeID it means that the node we are processing now is redundant 
		{
			// proceed until the end of node, without output containt to output_file
			string temp;
			while(getline(fin,temp))
			{
				if(temp=="vgj [ ")
				{  
					vgjTag = true;

				}
				if(temp == "]" && vgjTag == true)  //comes to node's end line
				{  
					vgjTag=false;
					continue;
				}
				if(temp == "]" && vgjTag == false)
				{
					break;
				}
			} 
		}

		else{
			fout<<"node ["<<"\n";
			fout<<"id "<<index+1;
			// proceed until end of node, change id to index, other things unchanged
			while(getline(fin,line))
			{

				fout<<line<<"\n";

				if(line == "vgj [ ")
				{   
					//fout<<"I found you VGJ"<<endl;
					vgjTag = true;

				}
				if(vgjTag == true && line == "]" )  
				{  

					//fout<<"I found first ]"<<endl;
					vgjTag=false;
					continue;
				}
				if(vgjTag == false && line == "]") //comes to node's end line
				{
					//fout<<"Find second ]"<<endl;
					break;
				}


			} 



		}

		/*
		while(getline(fin,line))
		{

		if(line == "]")  //comes to node's end line
		{
		fout<<"]"<<"\n";
		break;
		}
		} */

	}

	//Process edges

	//cout<<"edge processing.."<<endl;

	multimap<node,node>::iterator multi_iter;
	multimap<node,node> printedPair;

	//multimap<node, node> tempEdgeSet=refinedG.edgeSet;

	/*
	for (multi_iter=refinedG.edgeSet.begin() ; multi_iter != refinedG.edgeSet.end(); multi_iter++ )
	{
		node sourceID, targetID;
		sourceID= oldID_newID_map[(*multi_iter).first];
	    targetID= oldID_newID_map[(*multi_iter).second];
		
		printedPair.insert(pair<node,node>(sourceID,targetID));
		bool exist_flag= false;

		//If (targetID,sourceID) pair already exist in printedPair , set exist_flag =true
		typedef multimap<node,node>::iterator multi_iter_Type;
		pair<multi_iter_Type, multi_iter_Type> pairIterTemp = printedPair.equal_range(targetID);
		multi_iter_Type it1 = pairIterTemp.first;
		for (; it1 != pairIterTemp.second; ++it1) {
			if ((*it1).second == sourceID) { 
				exist_flag= true;
				break;
			}
		}
		
		if(exist_flag != true)
		{
		   cout<<sourceID<<"=>"<<targetID<<endl;
		}
	}

	*/

	for (multi_iter=refinedG.edgeSet.begin() ; multi_iter != refinedG.edgeSet.end(); multi_iter++ )
	{
	node sourceID, targetID;
	sourceID= oldID_newID_map[(*multi_iter).first];
	targetID= oldID_newID_map[(*multi_iter).second];

	printedPair.insert(pair<node,node>(sourceID,targetID));
	bool exist_flag= false;

	//If (targetID,sourceID) pair already exist in printedPair , set exist_flag =true
	typedef multimap<node,node>::iterator multi_iter_Type;
	pair<multi_iter_Type, multi_iter_Type> pairIterTemp = printedPair.equal_range(targetID);
	multi_iter_Type it1 = pairIterTemp.first;
	for (; it1 != pairIterTemp.second; ++it1) {
			if ((*it1).second == sourceID) { 
				exist_flag= true;
				break;
			}
	}
		
	if(exist_flag != true)
	{
		fout << "edge [\n";
		fout<< "source " <<sourceID<< endl; 
		fout << "target  "<<targetID<< endl; 
		fout << "label " ;
		OutputQuotString(fout,  ""  ); 
		fout << "\n";
		fout << "]\n";
		//printedPair.insert ( pair<node,>((*multi_iter).first,(*multi_iter).second));
	}

   }

	fout<<"\n]\n";

	//cout<< "number of redundant nodes: "<<redundantNodes.size()<<endl;


}

void  printDirectedGML(int rawNodeCount,graph refinedG,string input_filename,string output_filename)
{
	ifstream fin;
	ofstream fout;
	map<int,int> oldID_newID_map;
	//cout<<"printing..."<<endl;
	fin.open(input_filename.c_str());
	fout.open(output_filename.c_str());
	string l;
	//process header
	for(int i=0;i<5;i++)
	{
		getline(fin,l);
		fout<<l<<"\n";
	}


	for(unsigned int i=0; i< rawNodeCount; i++)
	{
		string temp,line;  // used for absove useless string
		node nodeID;
		getline(fin,line);
		bool vgjTag = false;
		if(line !="node [")
		{
			cout<<"wrong gml format! ";
		}
		fin>>temp;
		fin>>nodeID;   //get the node id of that node 
		//cout<<"nodeID"<<endl;

		//Judge if this node is in refinedG.nodesID or not
		unsigned int index=-1;
		for(unsigned int ii=0; ii< refinedG.nodesID.size();ii++)
		{

			if(refinedG.nodesID[ii] == nodeID)  
			{   
				index=ii;
				//cout<<refinedG.nodesID[ii] <<"="<<index+1<<endl;
				oldID_newID_map.insert(pair<int,int>(nodeID,index+1));
				break;
			}
			else
			{
				index=-1;
			}

			//cout<<"refinedNode:"<<refinedG.nodesID[i]<<endl;
		}

		if(index == -1) //Can not find the nodeID in refined.nodeID it means that the node we are processing now is redundant 
		{
			// proceed until the end of node, without output containt to output_file
			string temp;
			while(getline(fin,temp))
			{
				if(temp=="vgj [ ")
				{  
					vgjTag = true;

				}
				if(temp == "]" && vgjTag == true)  //comes to node's end line
				{  
					vgjTag=false;
					continue;
				}
				if(temp == "]" && vgjTag == false)
				{
					break;
				}
			} 
		}

		else{
			fout<<"node ["<<"\n";
			fout<<"id "<<index+1;
			// proceed until end of node, change id to index, other things unchanged
			while(getline(fin,line))
			{

				fout<<line<<"\n";

				if(line == "vgj [ ")
				{   
					//fout<<"I found you VGJ"<<endl;
					vgjTag = true;

				}
				if(vgjTag == true && line == "]" )  
				{  

					//fout<<"I found first ]"<<endl;
					vgjTag=false;
					continue;
				}
				if(vgjTag == false && line == "]") //comes to node's end line
				{
					//fout<<"Find second ]"<<endl;
					break;
				}
			} 

		}
	}

	//Process edges

	//cout<<"edge processing.."<<endl;
	multimap<node,node>::iterator multi_iter;

	for (multi_iter=refinedG.directedEdgeSet.begin() ; multi_iter != refinedG.directedEdgeSet.end(); multi_iter++ )
	{
		node sourceID, targetID;
		sourceID= oldID_newID_map[(*multi_iter).first];
		targetID= oldID_newID_map[(*multi_iter).second];

		typedef multimap<node,node>::iterator multi_iter_Type;
		fout << "edge [\n";
		fout<< "source " <<sourceID<< endl; 
		fout << "target  "<<targetID<< endl; 
		fout << "label " ;
		OutputQuotString(fout,  ""  ); 
		fout << "\n";
		fout << "]\n";
   }

	fout<<"\n]\n";

	//cout<< "number of redundant nodes: "<<redundantNodes.size()<<endl;


}

graph  new_deleteRedundantNodes(graph G,bool fHVLines)
{
	graph refinedGraph;
	unsigned int raw_nodeNumber=G.nodesCount;
	vector<node> refinedNodes;
	multimap<node,node> new_edgeSet;
	multimap<node,node> new_directed_edgeSet;

	//First we need find the root, which indegree is 0. In PIRN, the direction of arrow is reversed,
	//which means the node who's outdegree is 0 is the root!
	for(unsigned int i=1; i<=raw_nodeNumber;i++)
	{ 
		
		if(G.directedEdgeSet.count(i)==0)
		{
			//cout<<"node "<<i<<" is the root!"<<endl;
			G.rootID=i;
		}
		
	}

	for(unsigned int i=1; i<=raw_nodeNumber;i++)
	{ 
		
		if((G.rootID != i)&&(G.edgeSet.count(i)!=2))
		{
			refinedNodes.push_back(i);
		}
		
	}

	//We also keep the node at the angle
	
	if(fHVLines == true)
	{
	    for(unsigned int i=1; i<=raw_nodeNumber;i++)
		{ 
			//find nodes who is redundant but at angle
			if((G.rootID != i)&&(G.edgeSet.count(i)==2))
			{   
				multimap<node, node> edgeSetTemp =G.edgeSet;
				multimap<node, node>::iterator iter;
				iter=edgeSetTemp.find(i);
				node a = (*iter).second;
				edgeSetTemp.erase(iter);
				iter=edgeSetTemp.find(i);
				node b = (*iter).second;
				position aPos = G.positionSet[a];
				position iPos = G.positionSet[i];
				position bPos = G.positionSet[b];
				//cout<<i <<"'s neighbor: "<<a<<"  "<<b<<endl;
				if((( iPos.x == aPos.x) &&( iPos.y== bPos.y)) || ((iPos.x == bPos.x )&&(iPos.y == aPos.y )))
				{
					refinedNodes.push_back(i);

				}

			}
		
		}
	}

    //Push the root into refinedNodes
	refinedNodes.push_back(G.rootID);

	//vector<node>::iterator vec;
	//for(vec =refinedNodes.begin(); vec != refinedNodes.end(); vec++)

	vector<node>::iterator iter;
	int edgeCountTemp=0;
	for(iter =refinedNodes.begin(); iter != refinedNodes.end(); iter++) //  refinedNodes.end()-1  here means we do not need to find neighbor for the root
	{
	    //For each node, find it's refined neighbor;
		node startNode = *iter;
		if(startNode == G.rootID)
			break;
		//vector<node> refinedNeighbors;  // find neighbor:  node --> neighbor AND  neighbor -->node
		vector<node> refinedDirectedNeighbors;  // find neighbor:  node --> neighbor, NOT  neighbor -->node
		
		//refinedNeighbors=find_refined_neighbors(startNode,G,refinedNodes);
		refinedDirectedNeighbors = find_refined_directed_neighbors(startNode,G,refinedNodes);

		
		//Insert it to a new_edgeSet
		/*
		vector<node>::iterator vec_iter;
		for(vec_iter = refinedNeighbors.begin(); vec_iter != refinedNeighbors.end(); vec_iter++)
		{
			// cout<<"Find "<<*vec_iter<<" for "<<startNode<<endl;
		     node targetNode = *vec_iter;
		     new_edgeSet.insert(pair<node,node>(startNode,targetNode));
		}
		*/ 
		//cout<<endl;
		//Insert it to a 
		
		vector<node>::iterator vec_iter2;
	
		for(vec_iter2 =  refinedDirectedNeighbors.begin(); vec_iter2 !=  refinedDirectedNeighbors.end(); vec_iter2++)
		{
			 //cout<<"Find "<<*vec_iter2<<" for "<<startNode<<endl;
		     node targetNode = *vec_iter2;
		     new_directed_edgeSet.insert(pair<node,node>(startNode,targetNode));
			 new_edgeSet.insert(pair<node,node>(startNode,targetNode));
			 new_edgeSet.insert(pair<node,node>(targetNode,startNode));
			 edgeCountTemp++;
		}
		
		//cout<<endl;
		//cout<<endl;
		//cout<<endl;
	} 
	//cout<<edgeCountTemp<<" edges"<<endl;
	refinedGraph.nodesCount=refinedNodes.size();
	refinedGraph.nodesID=refinedNodes;
	refinedGraph.edgeSet = new_edgeSet;
	refinedGraph.directedEdgeSet=new_directed_edgeSet;
	refinedGraph.rootID=G.rootID;

	return refinedGraph;

}

// *************************************************************************************************
// @fn          find_refined_neighbors
// @brief       Function responsable to find all the neigbor around it without consider edges' direction
// @param       node startNode,graph G
// @return      vector<node> foundNeighbors
// *************************************************************************************************
/*
vector<node> find_refined_neighbors(node startNode,graph G,vector<node> refinedNodes)
{
	vector<node> foundNeighbors;
	typedef multimap<node,node>::iterator multi_iter_Type;
	pair<multi_iter_Type, multi_iter_Type> pairIterTemp = G.edgeSet.equal_range(startNode);

	multi_iter_Type it1 = pairIterTemp.first;

	for (; it1 != pairIterTemp.second; ++it1)
	{   
		if((*it1).first == startNode)
		{
			unsigned int nowNode = (*it1).second;
			unsigned int prevNode = (*it1).first;

			while(1)
			{   
				//moveOn
				unsigned int CC =G.edgeSet.count(nowNode);
				if(CC !=2) { 
					//cout<<"Find refined neighbor node: "<<nowNode <<" for node:  "<<startNode<<endl;
					foundNeighbors.push_back(nowNode); //Find a refined node, make it as a neighbor
					break;
				}
				else     
				{   
				    //move forward
					pair<multi_iter_Type, multi_iter_Type> pairIterTempTemp = G.edgeSet.equal_range(nowNode);
	                multi_iter_Type it_temp = pairIterTempTemp.first;
					for (; it_temp!= pairIterTempTemp.second; ++it_temp)
					{    
						  if((*it_temp).first == nowNode)
						  {
							  if((*it_temp).second != prevNode)  //Let it do not look back 
							  {  
								  prevNode= nowNode;
					              nowNode = (*it_temp).second; 
							  }
						  }
					} 
				}
			}
		}

	}

	
	return foundNeighbors;
}
*/ 

// *************************************************************************************************
// @fn          find_refined_neighbors
// @brief       Function responsable to find all the neigbor around it with considering edges' direction
// @param       node startNode,graph G
// @return      vector<node> foundNeighbors
// *************************************************************************************************
vector<node> find_refined_directed_neighbors(node startNode,graph G, vector<node> refinedNodes)
{
	vector<node> foundDirectedNeighbors;
	typedef multimap<node,node>::iterator multi_iter_Type;
	if(G.directedEdgeSet.count(startNode) == 0)
	{ 
		// startNode is the root
		//cout<<"node "<<startNode<<" is the root !"<<endl;
	   
	}
	else if(G.directedEdgeSet.count(startNode) == 1)
	{  
	   node nextNode;
	   // startNode is a leaf or a angle node
	   nextNode=G.directedEdgeSet.find(startNode)->second;
	   while(1)  // Make sure that nextNode is not a redundant node
	   {   
		   if(nextNode == G.rootID)
		   {  
			  foundDirectedNeighbors.push_back(G.rootID);
		      break;
		   }
		   else if(find(refinedNodes.begin(), refinedNodes.end(), nextNode)!=refinedNodes.end() && nextNode != G.rootID) //(G.edgeSet.count(nextNode) !=2)
		   {
		      foundDirectedNeighbors.push_back(nextNode);
			  break;
		   }
		   nextNode=G.directedEdgeSet.find(nextNode)->second;
	   }

	}
	else
	{
		// startNode is a reticulate node     node ---> a    and  node ---> b   and so on

		pair<multi_iter_Type, multi_iter_Type> pairIterTemp = G.directedEdgeSet.equal_range(startNode);
	    multi_iter_Type it1 = pairIterTemp.first;

		for (; it1 != pairIterTemp.second; ++it1)
		{  
			if((*it1).first == startNode)
			{
				   node nextNode;
				   nextNode=(*it1).second;
				   while(1)  // If nextNode is  a redundant node, move on
				   {   
					   if(nextNode == G.rootID)
					   {  
						  foundDirectedNeighbors.push_back(G.rootID);
						  break;
					   }
					   else if(find(refinedNodes.begin(), refinedNodes.end(), nextNode)!=refinedNodes.end() && nextNode != G.rootID)
					   {
						  foundDirectedNeighbors.push_back(nextNode);
						  break;
					   }
					   nextNode=G.directedEdgeSet.find(nextNode)->second;
				   }
			}

		}

	}
	return foundDirectedNeighbors;
}

graph reverseDirection(graph G)
{   
   graph revG;
   typedef multimap<node,node>::iterator multi_iter_Type;
   multi_iter_Type iter;
   // reverse edges' direction
   for(iter = G.directedEdgeSet.begin(); iter != G.directedEdgeSet.end(); iter++)
   {
	   revG.directedEdgeSet.insert(pair<node,node>((*iter).second,(*iter).first) );;
   }
   revG.rootID = G.rootID;
   revG.edgeSet =G.edgeSet;
   revG.nodesCount= G.nodesCount;
   revG.nodesID=G.nodesID;

   return revG;

}

void OutputQuotString(ofstream &outFile, const char *buf)
{
	outFile << '"';
	outFile << buf;
	outFile << '"';
}
