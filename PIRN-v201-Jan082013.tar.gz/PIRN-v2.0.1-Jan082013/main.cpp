#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>

#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <cmath>
using namespace std;


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "Utils.h"
#include "Utils2.h"
#include "Utils3.h"
#include "ILPTests.h"
#include "MarginalTree.h"
#include "ReticulateILP.h"
#include "SprILP.h"
#include "ExactCfgExplorer.h"


// stub code
int minCutLB = 0;
bool fAcyclic = false;
bool fHeuistMode = false;
bool fTest = false;

// Global data
static int fileArgIndex = 1;
static bool fExhaustive = false;
static int maxReticulateEvts = 100;	// a fairly large number for reticulation
static TaxaMapper mapperTMapInfo;
static const char *VERSION_PIRN = "******************** PIRN Version 2.0.1 **********************\n******************** January 8, 2013  **********************\n";
//**************************************************************\n";


static void Usage()
{
    cout << "Usage: ./pirn <OPTIONS> <file-name>" << endl;
	cout << "Options:\n";
	cout << " -a: try more thorough search\n";
	cout << " -C: turn on exact configuraiton-based search mode (must also specify -r option\n";
	cout << " -r: set the maximum number of reticulations allowed (this goes with -C option)\n";
	cout << " -n: set the maximum number of configurations kept each level (this goes with -C option)\n";
    exit(1);
}


static bool CheckArguments(int argc, char **argv) 
{
    if( argc <= 1  )
    {
        return false;
    }
    if( argc == 2)
    {
        fileArgIndex = 1;
    }
    else 
    {
        // Check argument one by one
        for(int i = 1; i< argc; ++i)
        {
			if(strncmp ( argv[i], "-a", 2) == 0)
            {
                // not an option one. Right now the only one is file
                fExhaustive = true;
				cout << "Turn on the mode to compute for all order of derivation.\n";
            }
			else if(strncmp ( argv[i], "-h", 2) == 0)
			{
				fHeuistMode = true;
				cout << "Turn on heuristic mode\n";
			}
			else if(strncmp ( argv[i], "-C", 2) == 0)
			{
				fTest = true;
				cout << "Turn on configuration search mode\n";
			}
			else if( strncmp(argv[i], "-r", 2) == 0 )
			{
				i++;
				sscanf(argv[i], "%d", &maxReticulateEvts);
				cout << "Set the maximum allowed reticulation events to be " << maxReticulateEvts << endl;
			}
			else if( strncmp(argv[i], "-c", 2) == 0 )
			{
				i++;
				int numClassKept;
				sscanf(argv[i], "%d", &numClassKept);
				SetNumCfgClassKept(numClassKept);
				cout << "Set the number of configuraiton class kept to be " << numClassKept << endl;
			}
			else if( strncmp(argv[i], "-n", 2) == 0 )
			{
				i++;
				int numClassKept;
				sscanf(argv[i], "%d", &numClassKept);
				//SetNumCfgClassKept(numClassKept);
				//cout << "Set the number of configuraiton class kept to be " << numClassKept << endl;
				SetMaxNumCfgsKept(numClassKept);
				cout << "Set the maximum number of configuraitons kept at each stage to be " << numClassKept << endl;
			}
            else if( argv[i][0] != '-' )
            {
                // not an option one. Right now the only one is file
                fileArgIndex = i;
				//filenameGMLPrefix = argv[i];
            }
            else
            {
                return false;
            }
        }
    }
    return true;
}


static void TestILP()
{
	// test
	OutputMinCostAddTree("temp.lp");
}

static void TestSWDer()
{
	vector<MarginalTree> listTrees;
	// empty for now
	SWNetworkBuilder swnb( listTrees );
	swnb.Test();
}

static void ConsReticulateNet(vector<MarginalTree> &listTrees)
{
	// if all the trees are the same: notify user and stop
	bool fSameTrees = true;
	for(int i=1; i<(int)listTrees.size(); ++i)
	{
		if( listTrees[0].IsToplogicSame( listTrees[i] ) == false)
		{
			fSameTrees = false;
			break;
		}
	}
	if( fSameTrees == true )
	{
		cout << "All the input trees are the SAME.\n";
		cout << "Lower bound for the minimum number of reticulate nodes = 0" << endl;
		cout << "The minimum number of hybridization events = 0" << endl;
		cout << "This is the OPTIMAL solution.\n";
		return;
	}


	cout << "The number of leaves before reduction is " << listTrees[0].GetNumLeaves() << endl;
	vector<MarginalTree> listTreeReduced(listTrees.size());
	vector<MarginalTree *> listTreePtrsIn, listTreePtrsOut;
	for( int i=0; i<(int)listTrees.size(); ++i )
	{
	//	listTrees[i].SortByLeafId();
//cout << "ConsReticulateNet: tree " << i << ": " << listTrees[i].GetNewick() << endl;
//listTrees[i].Dump();
		listTreePtrsIn.push_back( &listTrees[i] );
		listTreePtrsOut.push_back( &listTreeReduced[i] );
	}
	vector< pair<int,int>  > listRemovedLeaves;
	vector<int> listRemoveLeavesSurvivors;
	ReduceListTreesMAF( listTreePtrsIn,  listTreePtrsOut, listRemovedLeaves, listRemoveLeavesSurvivors );
	//cout << "The number of leaves AFTER reduction is " << listTreePtrsOut[0]->GetNumLeaves() << endl;

	// fix redundent leaves
	for(int i=0; i<(int)listTrees.size(); ++i)
	{
//cout << "2: before fix dup: tree ";
//listTreeReduced[i].Dump();
		listTreeReduced[i].FixDupIds();
//cout << "2: after fix dup: tree ";
//listTreeReduced[i].Dump();
	}

//cout << "After simple data reduction (shrinking identical subtrees, the list of trees are output as rtree?.gml.\n";
//for(int i=0; i<(int)listTrees.size(); ++i)
//{
//cout << "ConsReticulateNet: tree " << i << ": " << listTreeReduced[i].GetNewick() << endl;
//listTreeReduced[i].Dump();
//char fname[100];
//sprintf(fname, "rtree%d.gml", i);
//listTrees[i].OutputGML( fname );
//listTreePtrsOut[i]->OutputGML( fname );
//}

	cout << "The number of leaves after reduction is " << listTreePtrsOut[0]->GetNumLeaves() << endl;
	cout << "In ConsReticulateNet: number of trees = " << listTrees.size() << endl;

	// now compute the lower bound
	ReticualteNetLB lber(listTreeReduced);
	int lbTrees = lber.Calculate();
	cout << "Lower bound for the minimum number of reticulate nodes = " << lbTrees << endl;
//exit(1);
	// if all the trees are the same, stop
	if( lbTrees == 0 )
	{
		cout << "The total number of hybridization events = 0" << endl;
		return;
	}

	// 
	SWNetworkBuilder swnb( listTreeReduced );
	swnb.SetOrigTreeInfo(listTrees[0].GetNumLeaves(), listRemovedLeaves, listRemoveLeavesSurvivors, &mapperTMapInfo  );
	swnb.SetLB(lbTrees);
	if( fExhaustive == false )
	{
cout << "Now running the coarse mode of the SIT bound...\n";
		//vector<int> vecOrder;
		//vecOrder.push_back(1);
		//vecOrder.push_back(0);
		//vecOrder.push_back(4);
		//vecOrder.push_back(2);
		//vecOrder.push_back(3);
		//swnb.CalcOneOrder( vecOrder );
		vector< vector<int> > resDists;
		vector<int> listNodeOrder;
		lber.GetPairwiseDists(resDists);
		int mstCost = swnb.FindMSTOrder( resDists, listNodeOrder );
		cout << "A quick estimate of minimum reticulation:  " << mstCost << endl;
		if( fHeuistMode == false )
		{
			swnb.CalcBest();
		}
		else
		{
			// turn on heuristic mode
//			swnb.SetLB(lbTrees);
//			cout << "MST approximation: " << mstCost << endl;
			swnb.CalcHeu(listNodeOrder);
		}
	}
	else
	{
cout << "Now running the full mode of the SIT bound...\n";
		vector< vector<int> > resDists;
		lber.GetPairwiseDists(resDists);
		vector<int> listNodeOrder;
		int mstCost = swnb.FindMSTOrder( resDists, listNodeOrder );
		cout << "A quick estimate of minimum reticulation:  " << mstCost << endl;
//		swnb.SetLB(lbTrees);
		swnb.CalcExhaustive();
	}

}


static void TestCfgExplorer( vector<MarginalTree> &listTrees )
//static void TestCfgExplorer(char *filename)
{
	//ifstream inFileST( filename );
	//if(!inFileST)
	//{
	//	cout << "Can not open species tree: "<< filename <<endl;
	//	exit(1);
	//}
//cout << "File read OK\n";
	// 
	//TaxaMapper mapperTaxaIds;
	//vector<MarginalTree> listTrees;
	//ReadinMarginalTreesNewick( inFileST, -1, listTrees, &mapperTaxaIds );
	//ReadinMarginalTreesNewick( inFileST, -1, listTrees, &mapperTaxaIds );


	bool fSameTrees = true;
	for(int i=1; i<(int)listTrees.size(); ++i)
	{
//cout << "Tree " << i << ": " << listTrees[i].GetNewick() << endl;
		if( listTrees[0].IsToplogicSame( listTrees[i] ) == false)
		{
//cout << "Tree " << i << " and tree 0 (the first tree) are not the same"  << endl;
//cout << "Tree " << i << ": " << listTrees[i].GetNewick() << endl;
//cout << "Tree 0 " << ": " << listTrees[0].GetNewick() << endl;
			fSameTrees = false;
			break;
		}
	}
	if( fSameTrees == true )
	{
		cout << "All the input trees are the SAME.\n";
		cout << "The minimum number of hybridization events = 0" << endl;
		return;
	}
	// maintain the set of original trees
	vector<PhylogenyTreeBasic *> listOrigInputTrees;
	for( int i=0; i<(int)listTrees.size(); ++i )
	{
		string strNW = listTrees[i].GetNewick();
		PhylogenyTreeBasic *ptrOrigTree = new PhylogenyTreeBasic;
		ptrOrigTree->ConsOnNewick(strNW);
		listOrigInputTrees.push_back( ptrOrigTree );
	}


	cout << "The number of leaves before reduction is " << listTrees[0].GetNumLeaves() << endl;
	vector<MarginalTree> listTreeReduced(listTrees.size());
	vector<MarginalTree *> listTreePtrsIn, listTreePtrsOut;
	for( int i=0; i<(int)listTrees.size(); ++i )
	{
		listTrees[i].SortByLeafId();
//cout << "TestCfgExplorer: tree " << i << ": " << listTrees[i].GetNewick() << endl;
//listTrees[i].Dump();
		listTreePtrsIn.push_back( &listTrees[i] );
		listTreePtrsOut.push_back( &listTreeReduced[i] );
	}
	vector< pair<int,int>  > listRemovedLeaves;
	vector<int> listRemoveLeavesSurvivors;
	ReduceListTreesMAF( listTreePtrsIn,  listTreePtrsOut, listRemovedLeaves, listRemoveLeavesSurvivors );
	//cout << "The number of leaves AFTER reduction is " << listTreePtrsOut[0]->GetNumLeaves() << endl;
// dump MAF results
//cout << "listRemovedLeaves: \n";
//for(int i=0; i<(int)listRemovedLeaves.size(); ++i  )
//{
//cout << "[" << listRemovedLeaves[i].first << ", " << listRemovedLeaves[i].second << "]  ";
//}
//cout << endl;
//cout << "listRemoveLeavesSurvivors: \n";
//DumpIntVec( listRemoveLeavesSurvivors );

cout << "After simple data reduction (shrinking identical subtrees, the list of trees are output as rtree?.gml.\n";
for(int i=0; i<(int)listTrees.size(); ++i)
{
char fname[100];
sprintf(fname, "rtree%d.gml", i);
//listTrees[i].OutputGML( fname );
listTreePtrsOut[i]->OutputGML( fname );
}

	//cout << "The number of leaves after reduction is " << listTreePtrsOut[0]->GetNumLeaves() << endl;
	cout << "In TestCfgExplorer: number of trees = " << listTrees.size() << endl;

	//vector<MarginalTree> listMargTreesMapCorrected;
	//for(int i=0; i<(int)listTreePtrsOut.size(); ++i)
	//{
	//}



	//TaxaMapper mapperTMapInfoDummy;

	vector<PhylogenyTreeBasic *> listPhyTrees;
	for(int t=0; t<(int)listTreePtrsOut.size(); ++t)
	{
		listTreePtrsOut[t]->InitDefaultEdgeLen();
		//listTrees[t].BuildDescendantInfo();
		string nwtr = listTreePtrsOut[t]->GetNewick();
//cout << "Tree " << t << ": " << nwtr << endl;

		MarginalTree mtreeMap;
		ReadinMarginalTreesNewickWLenString( nwtr, listTreePtrsOut[0]->GetNumLeaves(), mtreeMap, true );
		string nwtrMapped = mtreeMap.GetNewick();

		PhylogenyTreeBasic *ptrcur = new PhylogenyTreeBasic;
		ptrcur->ConsOnNewick(nwtrMapped);
//string nwtr2;
//ptrcur->ConsNewick(nwtr2);
//cout << "Reconstructed phytree: " << nwtr2 << endl;
		listPhyTrees.push_back(ptrcur);
	}
//#endif

	CfgExplorer cfgExp(listPhyTrees );
	cfgExp.SetMaxRetEvtAllowed( maxReticulateEvts );
	cfgExp.SetOrigTreeInfo(listRemovedLeaves, listRemoveLeavesSurvivors, &mapperTMapInfo );
	cfgExp.SetOrigInputTrees(listOrigInputTrees);
	SetCfgExplorerApproxMode(fHeuistMode);
	cfgExp.Explore();

	// delete trees
	for( int t=0; t<(int)listPhyTrees.size(); ++t )
	{
		delete listPhyTrees[t];
	}
	listPhyTrees.clear();
	for(int t=0; t<(int)listOrigInputTrees.size(); ++t)
	{
		delete listOrigInputTrees[t];
	}
	listOrigInputTrees.clear();
}


int main(int argc, char **argv)
{
	cout << VERSION_PIRN << endl;


    if( CheckArguments( argc, argv) == false)
    {
        Usage();
    }



	ifstream inFile(argv[fileArgIndex]);
	if(!inFile)
	{
		cout << "Can not open "<< argv[fileArgIndex] <<endl;
		exit(1);
	}

	// read in the Marginal trees
	vector<MarginalTree> listTrees;
	if( ReadinMarginalTreesNewick(  inFile, -1, listTrees, &mapperTMapInfo  ) == false )
	//if( ReadinMarginalTreesNewick(  inFile, -1, listTrees  ) == false )
	{
		cout << "CAUTION: PIRN assume leaf labels start from 0. Every leaf is automatically adjusted to let the lowest label from 0\n";
	}
	inFile.close();

	// before doing anything, add a leaf
	for(int i=0; i<(int)listTrees.size(); ++i)
	{
//cout << "Read in marginal tree " << i << ": ";
//listTrees[i].Dump();
		if( fTest == false)
		{
			AddRootAsLeafToTree( listTrees[i], true );
			// 01/31/12:  init default edge length
			listTrees[i].InitDefaultEdgeLen();
			// 
//cout << "1: before fix dup: tree ";
//listTrees[i].Dump();
			listTrees[i].FixDupIds();
//cout << "1: after fix dup: tree ";
//listTrees[i].Dump();

		}
		// also for the sake of traversal, build desc info
		listTrees[i].BuildDescendantInfo();
	}



//cout << "The list of trees:\n";
//for(int i=0; i<(int)listTrees.size(); ++i)
//{
//listTrees[i].Dump();
//}

	// keep time
    long tstart1 = GetCurrentTimeTick();
//cout << "Now test ILP:\n";
//TestILP();

//TestSWDer();
	if( fTest == false )
	{
		ConsReticulateNet(listTrees);
	    cout << "The best reticulate network found is output in rnbest.gml\n";
	}
	else
	{
		//int numTaxa = listTrees[0].GetNumLeaves();
//cout << "Number of taxa: " << numTaxa << endl;

#if 0
		ifstream inFile(argv[fileArgIndex]);
		if(!inFile)
		{
			cout << "Can not open "<< argv[fileArgIndex] <<endl;
			exit(1);
		}
		vector<PhylogenyTreeBasic> listPhyTrees;
		while( inFile.eof() == false )
		{
			string treeNewick;
			inFile >> treeNewick;
			if( treeNewick.size() == 0 )
			{
				break;
			}
cout << "newick tree = " << treeNewick << endl;

	//#if 0
			// update numleaves
			//multiset<string> setLabels;
			//NewickUtils :: RetrieveLabelSet( treeNewick, setLabels);
			//nLvs = setLabels.size();
	//#endif
			//
			PhylogenyTreeBasic phTree;
			phTree.ConsOnNewick(treeNewick, -1, false, NULL);
cout << "tree reconstructed\n";
			listPhyTrees.push_back( phTree );
cout << "After push back tree\n";
string nwtr2;
phTree.ConsNewick(nwtr2);
cout << "Reconstructed phytree: " << nwtr2 << endl;
		}
		inFile.close();


		// 
		vector<PhylogenyTreeBasic *> listPhyTreesPtr;
		ReadinPhyloTreesNewick(inFile, numTaxa-1, listPhyTreesPtr);
		inFile.close();
cout << "Number of tree read: " << listPhyTreesPtr.size() << endl;

		vector<PhylogenyTreeBasic> listPhyTrees;
		for(int t=0; t<(int)listPhyTreesPtr.size(); ++t)
		{
string strTr;
listPhyTreesPtr[t]->ConsNewick( strTr );
cout << "Ptr tree: " << strTr << endl;
			listPhyTrees.push_back( *listPhyTreesPtr[t] );
		}
		for(int t=0; t<(int)listPhyTreesPtr.size(); ++t)
		{
			 delete listPhyTreesPtr[t];
		}
		listPhyTreesPtr.clear();
		for(int t=0; t<(int)listPhyTrees.size(); ++t)
		{
			 string strTr;
			 listPhyTrees[t].ConsNewick( strTr );
			 cout << "Read in one tree: " << strTr << endl;
		}
#endif

#if 0
		vector<PhylogenyTreeBasic *> listPhyTrees;
		for(int t=0; t<(int)listTrees.size(); ++t)
		{
			//listTrees[t].InitDefaultEdgeLen();
			//listTrees[t].BuildDescendantInfo();
			string nwtr = listTrees[t].GetNewick();
cout << "Tree " << t << ": " << nwtr << endl;
			PhylogenyTreeBasic *ptrcur = new PhylogenyTreeBasic;
			ptrcur->ConsOnNewick(nwtr);
string nwtr2;
ptrcur->ConsNewick(nwtr2);
cout << "Reconstructed phytree: " << nwtr2 << endl;
			listPhyTrees.push_back(ptrcur);
		}

		CfgExplorer cfgExp(listPhyTrees );
		cfgExp.Explore();

		// delete trees
		for( int t=0; t<(int)listPhyTrees.size(); ++t )
		{
			delete listPhyTrees[t];
		}
		listPhyTrees.clear();
#endif

		// test config explorer
		TestCfgExplorer(listTrees);
		//TestCfgExplorer(argv[fileArgIndex]);
	}


    cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;

    // for now, do nothing
    return 0;
}
