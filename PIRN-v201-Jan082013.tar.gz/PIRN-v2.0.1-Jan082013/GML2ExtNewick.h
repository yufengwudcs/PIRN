
#ifndef GML2EXTNEWICK_H_
#define GML2EXTNEWICK_H_

#include<vector>
#include <map>
#include <algorithm>
#include<iostream>
#include<vector>
#include<fstream>
#include<string> 
using namespace std;

typedef unsigned int node ;

typedef struct position
{
	double x;
	double y;
	double z;
}position;

typedef struct graph{
unsigned int   nodesCount;
vector<node>   nodesID;
multimap<node, node> edgeSet;
multimap<node, node> directedEdgeSet;
node  rootID;
map<node,position> positionSet;
map<node,string> labelSet;
}graph;

typedef struct treeNode
{
 node nodeID;
 string label;
}treeNode;

typedef struct phyTree {
node rootID;
vector<treeNode> treeNodes;
multimap<node, node> treeEdgeSet; // node --> children 
}phyTree;


extern string  convertGML2ExtNewick(string filename, bool fOrigHNum);
extern void  refineNetwork(string input_filename,string output_filename, bool fHVLines);

#endif
