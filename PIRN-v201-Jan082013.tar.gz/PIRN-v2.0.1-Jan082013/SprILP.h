#ifndef TEST_CODE_H
#define TEST_CODE_H

#include <map>
#include "Utils.h"
#include "Utils2.h"
#include "MarginalTree.h"
#include "ILPSolver.h"
using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void OutputILPMaxAgreeForest(const char* filename, const MarginalTree &tree1, const MarginalTree &tree2 );
void OutputILPMaxAgreeForestVarReduced(const char* fileName, const MarginalTree &treeOrig1, 
                                       const MarginalTree &treeOrig2 );
void OutputILPMaxAgreeForestTest(const char* filename, const MarginalTree &tree1, const MarginalTree &tree2 );
void OutputILPMaxAgreeForestTest2(const char* filename, const MarginalTree &tree1, const MarginalTree &tree2 );
void OutputILPMaxGoodAgreeForest(const char* filename, const MarginalTree &tree1, const MarginalTree &tree2 );
void OutputILPMaxGoodAgreeForestTest(const char* filename, const MarginalTree &tree1, const MarginalTree &tree2 );
void ReducePairTreesMAF( const MarginalTree &tree1, const MarginalTree &tree2, 
                               MarginalTree &resTree1, MarginalTree &resTree2,
							   vector< pair<int,int>  > *pRemovedLeaves = NULL, 
							   vector<int> *pRemoveLeavesSurvivors = NULL );
void ReduceListTreesMAF( const vector<MarginalTree *> &listTreePtrsIn,  
                               vector<MarginalTree *> &resTreePtrsOut, 
							   vector< pair<int,int>   > &listRemovedLeaves , 
							   vector<int> &listRemoveLeavesSurvivors );
void RecoverContractedSubtree(int lvReduced, set<int> &reoveredSubtree, const vector< pair<int,int>  > &removedLeaves,
							  const vector<int> &removeLeavesSurvivors);
void RecoverOrigSubsetLeaves( const vector<int> &listNewLvs, const vector< pair<int,int>  > &removedLeaves,
							  const vector<int> &removeLeavesSurvivors, set<int> &lvsRecovered  );
int HeurisTreeCut(const MarginalTree &tree1, const MarginalTree &tree2);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class ILPSolverSPR
{
public:
	// One way to initialze is to sub-string of a row sequence in datamat
	ILPSolverSPR(const MarginalTree &tree1, const MarginalTree &tree2 );

	// Another way is to form sub-string of existing partialsequence
	~ILPSolverSPR();
    int ComputeILP();
    int ComputeILPSimple();
    int ComputeAcyclicrSPR(  );
    int ComputeHeuristic();
    void GetCutEdges( vector<int> &edgesRes ) { edgesRes = edgesCut; }
	void SetAcyclic(bool f) {fAcyclic = f;}

private:
    // 
    int GetCVarNum() const;
    int GetCVarPos(  int edgePos ) const; // require v1 < v2
//    int GetMVarNum() const;
    int GetMVarPos( int ni, int nj, const vector<pair<int,int> > &listNodePairs ) const; // require v1 < v2
    int GetGVarPos( int ni, int nj, int vstart) const; // require v1 < v2
    //int GetTotConstraintsNum() const;
    int ComputeHeuristicRun( const vector<set<int> > &hittingEdgeSetsInit, 
        const vector<int> &listEdgeMemberCountsInit, const vector< set<int> > &listEdgeMemberInSets );
    void FindCutEdges( const ILPSolution &solILP );

	const MarginalTree &tree1;
	const MarginalTree &tree2;
    vector<int> edgesCut;
	bool fAcyclic;
};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////



#endif  // TEST_CODE_H

