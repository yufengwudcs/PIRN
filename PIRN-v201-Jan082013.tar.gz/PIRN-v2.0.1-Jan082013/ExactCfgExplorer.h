#ifndef EXACT_CFG_EXPLORER_H
#define EXACT_CFG_EXPLORER_H

#include "Utils3.h"
#include "PhylogenyTreeBasic.h"
#include "ReticulateNet.h"

///////////////////////////////////////////////////////////////////////////////

#define RET_EVT_IMP 1


//void TestExactCfgExplorer( vector<PhylogenyTreeBasic *> &listGeneTrees );
void SetNumCfgClassKept(int numClassKept);
void SetCfgExplorerApproxMode(bool f);
void SetMaxNumCfgsKept(int maxn);


///////////////////////////////////////////////////////////////////////////////
// Event for reticulation (branching when looking backwards in time)


typedef int CfgRetEvt;

///////////////////////////////////////////////////////////////////////////////
// Lineage source of a lineage (i.e. which gene tree lineage it traces to)

class CfgLineageSrc
{
public:
	CfgLineageSrc() : nodeInGeneTree(-1)
#ifdef RET_EVT_IMP
		, idRetEvtSet(-1) 
#endif
	{}	// default: nothing is initialized
	CfgLineageSrc(int nodeId) : nodeInGeneTree(nodeId)
#ifdef RET_EVT_IMP
		, idRetEvtSet(-1) 
#endif
	{  }	// no event flags are attached
	void AddEvt(int evtId);
	bool IsEmptyRetEvtSet() const { 
#ifdef RET_EVT_IMP
		return idRetEvtSet < 0; 
#else
	return true;
#endif
	}
#ifdef RET_EVT_IMP
	int GetRetEvtSetId() const { return idRetEvtSet; }
	void SetEvtSetId(int id) { idRetEvtSet = id; }
#endif
	bool CoalesceWith(const CfgLineageSrc &lsrcOther, CfgLineageSrc &srcNew) const;
	bool IsNodeContained(int nodeId) const;
	bool operator <(const CfgLineageSrc &rhs) const
	{
		//return nodeInGeneTree < rhs.nodeInGeneTree || (nodeInGeneTree == rhs.nodeInGeneTree  && setRetEvtFlags < rhs.setRetEvtFlags);
		return nodeInGeneTree < rhs.nodeInGeneTree;
	}
	bool operator ==(const CfgLineageSrc &rhs) const
	{
		//return nodeInGeneTree == rhs.nodeInGeneTree && setRetEvtFlags == rhs.setRetEvtFlags;
		return nodeInGeneTree == rhs.nodeInGeneTree;
	}
	void SetNodeId(int id) { nodeInGeneTree = id; }
	int GetNodeId() const { return nodeInGeneTree; }
	void Dump() const;
	//bool HasCondition() const { return setRetEvtFlags.size() > 0; }
	bool IsBeaten(const CfgLineageSrc &other) const;
	//void GetSetEvts( set< CfgRetEvt > &setEvts) const { setEvts = setRetEvtFlags; }
	//void SetRetEvts( const set< CfgRetEvt > &setEvts ) { setRetEvtFlags = setEvts; }

private:
	int nodeInGeneTree;
#ifdef RET_EVT_IMP
	int idRetEvtSet;
#endif
	//set< CfgRetEvt > setRetEvtFlags;
	//set<int> setRetEvtIdsOnly;
};


///////////////////////////////////////////////////////////////////////////////
// Lineage in a configuration

class CfgLineage
{
	friend class CfgConfiguration;
public:
	CfgLineage();

	// add source
	//CfgLineage() { numCopies = 1; }
	//void AddSrc( const CfgLineageSrc &src, bool fAlways ) 
	void AddSrc( const CfgLineageSrc &src ) 
	{
		listLinsSrcCombined.insert(src);
		//if( fAlways == true)
		//{
		//	listLinsSrcAlways.insert( src );  
		//}
		//else
		//{
		//	listLinsSrcCondition.insert( src );  
		//}
	}
	void AddRetEvt(int evtId);
	bool CoalesceWith(const CfgLineage &linOther, CfgLineage &linNew) const;
	bool IsCoalRedundent(const CfgLineage &linOther, const CfgLineage &linNew) const;
	bool IsNodeContained(int nodeId) const;
	bool operator ==(const CfgLineage &rhs) const
	{
		return linId == rhs.linId && listLinsSrcCombined == rhs.listLinsSrcCombined;
		//return  linId == rhs.linId && (listLinsSrcAlways == rhs.listLinsSrcAlways) &&
		//	( listLinsSrcCondition == rhs.listLinsSrcCondition );
	}
	bool operator <(const CfgLineage &rhs) const
	{
		return   linId < rhs.linId || ( linId == rhs.linId && listLinsSrcCombined < rhs.listLinsSrcCombined);
		//return   linId < rhs.linId || ( linId == rhs.linId && listLinsSrcAlways < rhs.listLinsSrcAlways) || 
		//	( linId == rhs.linId && listLinsSrcAlways == rhs.listLinsSrcAlways && listLinsSrcCondition < rhs.listLinsSrcCondition );
	}
	//bool operator ==(const CfgLineage &rhs) const
	//{
	//	return   numCopies == rhs.numCopies && listLinsSrcAlways == rhs.listLinsSrcAlways && listLinsSrcCondition == rhs.listLinsSrcCondition;
	//}
	void Dump() const;
	//int GetCopyNum() const { return numCopies; }
	//void DecCopyNumByOne() { numCopies --; }
	bool IsBeaten(const CfgLineage &other) const;
	bool IsReticulateLineage() const {return fReticulate;}
	void SetReticulateLineage(bool f) { fReticulate = f; }
	void AssignDistinctId(int linSrcId1, int linSrcId2);
	static void GetChildrenId(int linId, int &childId1, int &childId2);
	static void GetLineageDescendentOf(int linIdD, set<int> &linIdDescs, bool fSelf = true);
	static void GetMaxLowMinHighCoalIn(int linId, int &childId1, int &childId2);
	static void AddCoalLineageToCache(int linId, CfgLineage &lin);
	static bool GetLineageById(int linId, CfgLineage &lin);
	int GetLinId() const { return linId; }
	void SetLinId(int id) { linId = id; }
	void CleanExtraLins();
	bool CleanExtraLins(const set<int> &slinSrcs);
	//bool IsPureConditional() const { return listLinsSrcAlways.size() == 0; }
	bool IsPureConditional() const;
	bool IsCoalescentAllowed() const 
	{
		// for now, only disallow those with no fusion
		return IsPureConditional() == false || fCoalButNoFusion == false;
	}
	void SetFlagCoalButNoFusion(bool f) { fCoalButNoFusion = f; }
	bool IsCoalButNoFusion() const { return fCoalButNoFusion; }
	//void GetSetEvts( set<CfgRetEvt> &setEvts) const;
	void GetCoveredNodes( set<int>& sint) const;
	//void GetCoveredNodes( set<pair<int,set<int> > >& sint) const;
	//void RemoveEvtFromSrc(CfgRetEvt evtRm);
	void CleanExtraLinsByCoveredNodes( set<int> &setNodes);
	//bool IsEventCommonInside(CfgRetEvt evtId);
	//bool IsEmpty() const {return listLinsSrcAlways.size() == 0 && listLinsSrcCondition.size()==0;}
	bool IsEmpty() const {return listLinsSrcCombined.size() == 0;}
	void GeCoveredNodesUnder(set<int> &nodesDescs) const;
	void GetSibNodesInTrees(set<int> &nodeSibs) const;
	//void GetSibNodesInTreesBoth(set<int> &nodeSibs) const;
	bool AreLineagesEquiv(const CfgLineage &rhs) const;
	bool IsEmptyPossible() const {return fEmptyPossible;}
	void SetEmptyPossible(bool f) {fEmptyPossible = f;}

	static void AssignLineageId(CfgLineage &lin);

private:
	set< CfgLineageSrc > listLinsSrcCombined;			// lineages presented which may depend on the choices at reticulation
	//set< CfgLineageSrc > listLinsSrcAlways;			// lineages always exist no matter the choices at reticulation
	//set< CfgLineageSrc > listLinsSrcCondition;		// lineages that may or may not be present, depend on choices at reticulation
	//int numCopies;									// how many copies of this lineage? Add one by reticulation
	bool fReticulate;								// Is this lineage created by reticulation?
	int linId;										// lineage id
	bool fCoalButNoFusion;							// set to true if created by a coalescent of two pure conditional lineages but no fusion lineage created
													// may be useful in limiting num of coalescent
	bool fEmptyPossible;							// is this lineage possibly lead to some empty linaage (no subtrees from this)

	static int idNextToUse;
	static map<pair<int,int>,int> mapPairsToIds;
	static map<int, pair<int,int> > mapIdsToPairs;
	static map<int,CfgLineage> mapIdToLineages;
};


// Configuration: collection of active lineages

class CfgExplorer;

class CfgConfiguration
{
	friend class CfgExplorer;
public:
	CfgConfiguration();

	// Get next configs
	bool GetNextCfgs( set<CfgConfiguration> &setCfgsNext, CfgExplorer &cfgExplorer );
	//bool GetNextCfgsPriority( set<CfgConfiguration> &setCfgsNext, CfgExplorer &cfgExplorer );
	bool operator <(const CfgConfiguration &rhs) const
	{
//		return mapLineages < rhs.mapLineages;
//#if 0
		if( GetTotNumLineages() < rhs.GetTotNumLineages() )
		{
			return true;
		}
		else
		{
			return mapLineages < rhs.mapLineages;
		}
//#endif
	}
	void InitStart();
	void Dump() const;
	bool IsTerminal() const;
	bool IsBeatenBy(const CfgConfiguration &other) const;
	bool IsBeatenByApprox(const CfgConfiguration &other) const;
	int GetTotNumLineages() const;
	int GetNumLineageTypes() const { return mapLineages.size(); }
//	CfgLineage GetLastAddedLin() const { return linLastAdded; }
	bool EvalCfgPriority(int &sumTreeCoverage);
	bool EvalCfgPriorityVer2(int &sumTreeCoverage, set<int> *pListMinCoveredNodes = NULL);
	bool EvalCfgPriorityCoarse(int &sumTreeCoverage);
	void GetCoveredNodes( set<int>& sint) const;
	void GetLinIds(set<int> &sint) const;
	int GetNumRetLinCopies() const;
	//void TraceBack() const;
	int GetId() const { return idCfg; }
	void SetDistinctId(  ) { idCfg = GetNextId(); }
	int GetSrcCfgId() const { return idSrcCfg; }
	bool IsGreedyIntermediate() const { return fGreedyIntermediate; }
	void SetGreedyIntermediate(bool f) { fGreedyIntermediate = f; }
	void CompareWith( const CfgConfiguration &cfgOther, map<CfgLineage,int> &listLinsNovelThis, map<CfgLineage,int> &listinsNovelOther ) const;
	void AddLin( CfgLineage &lin );
	bool FindMatchingLin( const CfgLineage &lin, CfgLineage &linMatch) const;

private:
	static int GetNextId();
	// initialize an config as the number of species lineage
	void RemoveLin(const CfgLineage &lin);
	void AddLin( CfgLineage &lin, int nc );
	bool IsConfigFeasible();
	bool IsConfigFeasibleStronger(int *pScore=NULL, set<int> *pSetCoveredNodes=NULL);
	bool IsConfigFeasibleEvenStronger();
	bool IsNodeContained(int nodeId) const;
	void IncNumLins( const CfgLineage &lin );
	void CleanExtraLins();
	bool CleanExtraLins(const set<int> &slins);
	void CleanExtraSrcEvts(CfgLineage &cfgLin, CfgRetEvt evtRetNew);
	void CleanExtraSrcEvts(CfgLineage &cfgLin );
	void GetAllCoveredNodes(set<int> &setNodeIds);
	bool ShrinkLineages(int scoreOld, CfgLineage &linNew);
	bool IsLinRetProfitable( const CfgLineage &cfgLin ) const;
	//bool IsCfgCoalRedundent();
	//void SetSrcCfg(CfgConfiguration *pcfg) { pCfgSource = pcfg; }
	//CfgConfiguration *GetSrcCfg() const { return pCfgSource; }
	void SetSrcCfgId(int id) { idSrcCfg = id; }

	//set< CfgLineage > listLins;
	static int idCfgNext;
	int idCfg;
	int idSrcCfg;
	bool fGreedyIntermediate;
	map< CfgLineage, int> mapLineages;
	set<CfgLineage> setLinLastAdded;
	//CfgConfiguration *pCfgSource;
	//int idLastRetLin;
	// last coals lineages a lineage has done before, useful to reduce # of coalescents
	//map<int,int> mapLastLinCoalIds;
	//bool fCoalButNoFusion;
};


// Gene Tree Info helper class
// current implementation uses the PhylogenyTree's iterator

class GeneTreeInfo;

class GeneTreeIterator
{
public:
	GeneTreeIterator(int treeId);
	void Init() { itorPhyTree.Init(); }	
	void Next() {itorPhyTree.Next(); }
	void Back() {itorPhyTree.Back(); }
	bool IsDone() { return itorPhyTree.IsDone(); }
	int GetNodeId();
	bool IsLeaf() { return itorPhyTree.GetCurrNode()->IsLeaf() ; }
	TreeNode *GetCurrNode() { return itorPhyTree.GetCurrNode(); }

private:
	PhylogenyTreeIteratorBacktrack itorPhyTree;
};


class GeneTreeInfo
{
	friend class GeneTreeIterator;
public:
	static GeneTreeInfo &Instance() { return instance; }
	void ProcGeneTrees( vector<PhylogenyTreeBasic *> &listTrees  );

	// query
	int GetNumSpecies() const;
	int GetNumGeneTrees() const { return listGeneTrees.size(); }
	int GetLeafIdInTree(int treeId, int leafId) const;
	void GetLeafIds( int treeNum, set<int> &sids) const;
	void GetLeafTaxa( int treeNum, set<int> &sids) const;
	int GetParent(int nodeId);
	int GetRootId(int tr) const;
	int GetNodeMultitreeId( TreeNode *pnode);
	bool IsNodeDescendentOf(int idChild, int idAnces);
	int GetNumDescLeaves(int idNode) ;
	int GetTreeIdForNode(int nodeId) const;
	void GetChildrenIds(int nodeId, set<int> &nodesChildren);
	int GetSibling(int idNode) const;
	void GetDescentIds(int nodeId, set<int> &setDescNodes );
	int GetTaxonIdForLeafNode(int nodeId) const;
	bool IsLeafIdIn(int tr, int taxa) const;
	bool IsRoot(int idNode)  { return  GetParent(idNode) < 0; }
	int AddDummyLeafId(int tr, int taxa);
	int GetNodeIdForLeaf(int tr, int leaf) const;
	int GetLeafIdFromNodeId( int nodeId) const;

private:
	GeneTreeInfo() {}
	PhylogenyTreeBasic &GetGeneTree(int tr) { return *listGeneTrees[tr]; }
	void SetNodeIdForLeaf(int tr, int leaf, int id);
	bool IsLeaf(int nodeId) ;
	int GetNodeId(TreeNode *pn) { return mapNodesToIds[pn]; }
	
	static GeneTreeInfo instance;
	int idToUseNext;
	// trees
	vector< PhylogenyTreeBasic *> listGeneTrees;

	// useful info
	map<TreeNode *, int> mapNodesToIds;
	map<int, TreeNode *> mapIdToNode;
	map<pair<int,int>, int> mapLeafIdToNodeId;
	vector<int> listRootIDs;
	map<int,set<int> > mapNodeDescendents;
	map<int, set<int> > mapNodesDescLeaves;
};


// main class to explore network space
class CfgExplorer
{
public:
	CfgExplorer(vector<PhylogenyTreeBasic *> &listTrees )  : listGeneTrees(listTrees), 
		pMapperTMapInfo(NULL),
		numProcessedCfgs(0), numBeatenCfgs(0), 
		numUselessCoals(0),numUselessCoalsDesc(0), numUselessRets(0),
		numInfeasible(0), numStrongInfeasible(0), numEvenStrongInfeasible(0),numDroppedCfgs(0), 
		numEarlyTerminateCfgs(0),numCfgLinSrcCleaned(0), numCfgSaveByPreferCoal(0), maxRetEvtAllowed(10000)  {}
	void SetOrigTreeInfo( const vector< pair<int,int> > &listRmPairs, const vector< int > &listSurvP, TaxaMapper *pMapper)
	{
		listRemovedPairs = listRmPairs;
		listSurvivePos = listSurvP;
		pMapperTMapInfo = pMapper;
	}

	void Explore();
	void ExplorePriority();
	void ExplorePriority2();
	bool CfgBeatenByPrevious(const CfgConfiguration& cfgTest);
	void DumpStats();
	void IncUselessCoal() { numUselessCoals++; }
	void IncUselessCoalDesc() {numUselessCoalsDesc++;}
	void IncUselessRet() { numUselessRets++; }
	void IncInfeasible() {numInfeasible++;}
	void IncStrongInfeasible() { numStrongInfeasible++; }
	void IncEvenStrongInfeasible() { numEvenStrongInfeasible++; }
	void IncProcessedCfg() {numProcessedCfgs ++;}
	void IncEarlyTermCfg() {numEarlyTerminateCfgs++;}
	void IncCfgLinSrcCleaned() {numCfgLinSrcCleaned++;}
	void AddNumDroppedCfgs(int n) {numDroppedCfgs +=n;}
	void SetMaxRetEvtAllowed(int nmax) { maxRetEvtAllowed = nmax; }
	void IncBypassedCfgsByPreferCoals(int n) 
	{
		YW_ASSERT_INFO( n >= 0, "FATAL ERROR");
		numCfgSaveByPreferCoal += n;
	}
	void TraceBack(int stageIndex, CfgConfiguration &cfgStart, vector<CfgConfiguration> &listCfgsHistory);
	void ConsNetworkGMLFromCfgs(const vector<CfgConfiguration> &listCfgsHistory, const string & networkGMLName, ReticulateNetworkImp *pResRetNet = NULL);
	void SetOrigInputTrees( vector<PhylogenyTreeBasic *> &lOIT) { listOrigInputTrees = lOIT; }

private:
	void FilterFoundCfgs(const set<CfgConfiguration> &setCfgsCandidates, set<CfgConfiguration> &setCfgsToExploreNext );
	void ConsPreprocessCfgs(vector<CfgConfiguration> &listPreprocessCfgs, const CfgConfiguration &cfg1stAfterReduction);
	void CheckResultRN( ReticulateNetworkImp &resRN );

	vector<PhylogenyTreeBasic *> &listGeneTrees;
	vector< map<int, set<CfgConfiguration> > > listStepCfgsProcessed;
	map<int, set<CfgConfiguration> > cfgsProcessed;
	set<CfgConfiguration> cfgsBeatenBefore;

	// info about orig trees
	vector< pair<int,int> > listRemovedPairs;
	vector< int > listSurvivePos;
	TaxaMapper *pMapperTMapInfo;
	vector<PhylogenyTreeBasic *> listOrigInputTrees;

	// some misc items
	int numProcessedCfgs;
	int numBeatenCfgs;
	int numUselessCoals;
	int numUselessCoalsDesc;
	int numUselessRets;
	int numInfeasible;
	int numStrongInfeasible;
	int numEvenStrongInfeasible;
	int numDroppedCfgs;
	int numEarlyTerminateCfgs;
	int numCfgLinSrcCleaned;
	int numCfgSaveByPreferCoal;
	int maxRetEvtAllowed;
};

class ProcLineagesDepot
{
public:
	static ProcLineagesDepot &Instance() {return instance;};
	void AddProcCfg( CfgConfiguration &cfg, const set<int> &auxInfo );
	bool IsCfgProcessed( CfgConfiguration &cfg, const set<int> &auxInfo );

private:
	ProcLineagesDepot() {}

	static ProcLineagesDepot instance;
	set< set<int> > setProcNodesList;
};

#ifdef RET_EVT_IMP
// keep track of set of reticulation each lineage has experienced
// that is, for each lineage src, what set of reticulaiton nodes it needs to go through
// (and make display choices) in order to make the reticulation node shown
class ReticulateSetLinSrcDepot
{
public:
	static ReticulateSetLinSrcDepot &Instance() {return instance;};
	bool GetProcessedEvtSet( int retSetId, set<CfgRetEvt> &evtSet );
	int RetrieveRetEvtSetId( set<CfgRetEvt> &evtSet );
	int GetProcessedEvtSetId( const set<CfgRetEvt> &evtSet );
	int CreateEvtSet( const set<CfgRetEvt> &evtSet);
	bool AreEvtSetsDisjoint( int retSetId1, int retSetId2, set<CfgRetEvt> *psetUnion=NULL );
	int GetExpandedEvtSetId(int evtIdOld, CfgRetEvt evtNew);
	bool IsEvtSetSubsetOf(int evtsetIdContained, int evtsetIdContainer);

private:
	ReticulateSetLinSrcDepot() {}

	static ReticulateSetLinSrcDepot instance;
	static int idReticulateSetNext;
	map< int, set<CfgRetEvt> > mapRetIdToEvtSet;
	map< set<CfgRetEvt>, int > mapEvtSetToRetId;
};
#endif

//////////////////////////////////////////////////////////////////////////

int CreateNextRetEvt(const CfgLineage &lin);


//////////////////////////////////////////////////////////////////////////
// additional utilities

const int ID_COALESCENT_NODE = -1;
const int ID_RETICULATION_NODE = -2;
const int ID_INTERMEDIATE_NODE = -3;

typedef struct 
{
	int nodeId;
	double xCoord;
	double yCoord;
	//double size;
	int type;				// >=0 for leaves, and -1: coalescent node, -2: reticulation, -3: intermediate
}GMLNode;

typedef struct 
{
	int srcNodeId;
	int destNodeId;
	bool fRet;
} GMLEdge;


#endif // EXACT_CFG_EXPLORER_H

