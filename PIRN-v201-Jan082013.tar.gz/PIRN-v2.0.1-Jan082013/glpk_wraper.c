//#include "glpk_wraper.h"

#ifdef LPSOLVER_GLPK


#include "glpk.h"


// this file is a wraper for GLPK solver

LPX* my_lpx_create_prob(void)
{
	return lpx_create_prob();
}

void my_lpx_set_prob_name(LPX *lp, char *name)
{
	lpx_set_prob_name(lp, name);
}
	
void my_lpx_set_class(LPX * lp, int cls)
{
	lpx_set_class(lp, cls);
}

void my_lpx_delete_prob(LPX * lp)
{
	lpx_delete_prob(lp);
}

void my_lpx_add_rows( LPX *lp, int nr )
{
	lpx_add_rows( lp, nr );
}

void my_lpx_add_cols( LPX * lp, int nc)
{
	lpx_add_cols(lp, nc);
}


void	my_lpx_set_col_name(LPX *lp, int c, char *name)
{
	lpx_set_col_name(lp, c, name);
}

void	my_lpx_set_col_bnds(LPX *lp, int c, int tp, double lb, double ub)
{
	lpx_set_col_bnds(lp, c, tp, lb, ub);
}

void	my_lpx_set_col_kind(LPX *lp, int c, int kd)
{
		lpx_set_col_kind(lp, c, kd);
}

void	my_lpx_set_col_coef(LPX *lp, int c, double  f)
{
	lpx_set_obj_coef( lp, c, f );
}

void	my_lpx_set_row_name(LPX *lp, int r, char *name)
{
	lpx_set_row_name(lp, r, name);
}

void	my_lpx_set_row_bnds(LPX *lp, int r, int tp, double lb, double ub)
{
	lpx_set_row_bnds(lp,  r,  tp,  lb,  ub);
}

#if 0
void	my_lpx_set_row_coef(LPX *lp, int r, double cf)
{
	lpx_set_row_coef(lp,  r,  cf);
}
#endif

void	my_lpx_load_mat3(LPX *lp, int n, int a[], int b[], double v[])
{
	//lpx_load_mat3 (lp, n, a, b, v);
    lpx_load_matrix( lp, n, a, b, v);
}

void	my_lpx_set_obj_dir(LPX * lp, int t)
{
	lpx_set_obj_dir(lp, t);
}

#if 0
void my_lpx_get_col_info(LPX *lp, int c, int *tagx,  double *vx, double *dx)
{
	lpx_get_col_info(lp,  c, tagx,  vx, dx);
}
#endif

double my_lpx_get_mip_col(LPX *lp, int c)
{
	return lpx_mip_col_val(lp,  c);
}

double my_glp_get_col_prim(LPX *lp, int c)
{
	return glp_get_col_prim(lp,  c);
}

int my_lpx_integer(LPX * lp)
{
	int status;

    /* setup cuts automatically */
    //int stateOld;
    //stateOld = lpx_get_real_parm( lp, LPX_K_USECUTS ) ;
    lpx_set_int_parm( lp, LPX_K_USECUTS, LPX_C_ALL );
	status = lpx_intopt( lp );
	if( status != LPX_E_OK )
	{
		return -1;
	}
	/* get status to make sure the solution is indeed found */
	status = lpx_mip_status(lp);
	if( status != LPX_I_OPT)
	{
		return -1;
	}
	return LPX_E_OK;
}

void my_lpx_write_lpt(LPX *lp, char *fname)
{
	lpx_write_cpxlp(lp, fname);
}

int my_lpx_get_num_int(LPX *lp)
{
	return lpx_get_num_int(lp);
}

int my_lpx_simplex(LPX *lp)
{
	return lpx_simplex(lp);
}

void my_lib_set_print_hook(void *info, int (*hook)(void *info, char *msg))
{
//#if 0
	//lpx_lib_set_print_hook( info, hook );
	glp_term_hook( hook, info  );
//#endif
}

double my_lpx_get_mip_obj(LPX *lp)
{
    return lpx_mip_obj_val(lp);
}

double my_glp_get_obj_val(LPX *lp)
{
    return glp_get_obj_val(lp);
}
#endif
