#ifndef TREE_CHILD_H
#define TREE_CHILD_H

// For tree-child network

#include "ReticulateNet.h"
#include "MarginalTree.h"
#include "ILPSolver.h"
#include "PhylogenyTreeBasic.h"

// define reticulate ILP related functions

// Tree-child lower and upper bound
class TreeChildNetBounds
{
public:
    TreeChildNetBounds(vector<MarginalTree> &listMargTrees);
	int Calculate(int &lowerBound, int &upperBound);
    int CalcLowerBound2();
    int CalcLowerBound2ILP();
    int CalcLowerBound3ILP();
    
private:
    void Init();
    int GetNumTaxa() const;
    int GetNumTrees() const;
    int CalcLBReticulateInc(const set<int> &setTaxa, int taxonAdd, vector<PhylogenyTreeBasic *> &listPhyTreesSub, vector<TreeNode *> &listSubtreeRootAttach, const map<int,int> &mapLabelToIndex );
    int CalcLBReticulateInc2(const set<int> &setTaxa, int taxonAdd, const map<int,int> &mapLabelToIndex, set<pair<set<int>, set<int> > > &setAllSplitsChildrenPairs );
    int CalcUBReticulateInc(const set<int> &setTaxa, int taxonAdd, vector<PhylogenyTreeBasic *> &listPhyTreesSub, vector<TreeNode *> &listSubtreeRootAttach );
    void GetSubtrees(const set<int> &setTaxa, vector<PhylogenyTreeBasic *> &listPhyTreesSub );
    void GetSubtreesAttach(const vector<PhylogenyTreeBasic *> &listPhyTreesSub, int taxon, vector<TreeNode *> &listSubtreeRootAttach);
    int GetMinHittingSet( int numTaxa, const set<set<int> > &setSubsets );
    void RetrievePairChildClades( set<pair<set<int>, set<int> > > & setAllSplitsChildrenPairsConv);
    
	vector<MarginalTree> &listMargTrees;
    vector<PhylogenyTreeBasic> listPhyTrees;
};


#endif
