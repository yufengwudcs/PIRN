#include "Utils.h"
#include "Utils2.h"
#include "Utils3.h"
#include "Utils4.h"
#include "TreeChild.h"
#include "ILPSolver.h"
#include "ReticulateILP.h"
#include <cmath>


// input file name
extern string fileNameInput;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tree-child network lower and upper bounds

TreeChildNetBounds :: TreeChildNetBounds(vector<MarginalTree> &listTreesPar) : listMargTrees(listTreesPar)
{
	YW_ASSERT_INFO(listTreesPar.size() >= 2, "Must have at least two trees to compute bounds");
    YW_ASSERT_INFO(GetNumTaxa() >= 3, "Must have at least three taxa to compute bounds");
    Init();
}

int TreeChildNetBounds :: Calculate(int &lowerBound, int &upperBound)
{
    lowerBound = -1;
    upperBound = -1;
    int numLvs = GetNumTaxa();
    // consider all subsets
    const int MAX_NUM_LVS = 30;
    if( numLvs > MAX_NUM_LVS )
    {
        // too many leaves
        cout << "Number of remaining taxa is too large.\n";
        return -1;
    }
    set<int> setLeafIntLabels;
    listPhyTrees[0].GetLeafIntLabels(setLeafIntLabels);
cout << "Leaf int labels: ";
DumpIntSet(setLeafIntLabels);
    vector<int> vecLeafIntLabels;
    PopulateVecBySet(vecLeafIntLabels, setLeafIntLabels);
    map<int,int> mapLabelToIndex;
    for(unsigned int i=0; i<vecLeafIntLabels.size(); ++i)
    {
        mapLabelToIndex[vecLeafIntLabels[i]] = i;
    }
    
    int szTblBounds = 0x1 << numLvs;
    vector<int> tblLbs(szTblBounds), tblUbs(szTblBounds);
    // initialize, starting from two taxa
    for(int pos = numLvs+1; pos<=numLvs+numLvs*(numLvs-1)/2; ++pos)
    {
        tblLbs[pos] = 0;
        tblUbs[pos] = 0;
    }
    // enumerate all subsets
    for(int sz = 3; sz<= numLvs; ++sz)
    {
cout << "Processing subset of taxa of sz: " << sz << endl;
        vector<int> posvec;
        GetFirstCombo(sz, numLvs, posvec);
        while(true)
        {
            vector<int> subsetIndex;
            GetIntVec(GetNumTaxa(), posvec, subsetIndex );
            int posStep = ConvVecToInt(subsetIndex);
            
            vector<int> posvecTaxa;
            ConvConsecutiveVecTo(vecLeafIntLabels, posvec, posvecTaxa);
            
            set<int> setTaxaThis;
            PopulateSetByVec(setTaxaThis, posvecTaxa);
            vector<PhylogenyTreeBasic *> listPhyTreesSub;
            GetSubtrees(setTaxaThis, listPhyTreesSub );
            
            // estimate a bound based on subsets
            int lbThis = HAP_MAX_INT;
            int ubThis = HAP_MAX_INT;
            for( int i=0; i<(int)posvecTaxa.size(); ++i  )
            {
                vector<TreeNode *> listSubtreeRootAttach;
                GetSubtreesAttach( listPhyTreesSub, posvecTaxa[i],  listSubtreeRootAttach);
                
                vector<int> copy = posvec;
                vector<int> :: iterator it = copy.begin();
                for(int j=0; j<i; ++j)
                {
                    it++;
                }
                copy.erase( it );
                vector<int> x;
                GetIntVec(GetNumTaxa(), copy, x );
                int pos = ConvVecToInt(x);

                // find the minimum from this item to the other
                set<int> scopy;
                PopulateSetByVec( scopy, copy);
                int lbInc = CalcLBReticulateInc(scopy, posvecTaxa[i], listPhyTreesSub, listSubtreeRootAttach, mapLabelToIndex );
                int ubInc = CalcUBReticulateInc(scopy, posvecTaxa[i], listPhyTreesSub, listSubtreeRootAttach );
                
//cout << "pass 4" << endl;
                int tmpLB = tblLbs[pos] + lbInc;
                int tmpUB = tblUbs[pos] + ubInc;
//cout << "lb small:" << tblLbs[pos] << ", lbInc: " << lbInc << endl;
//cout << "ub small:" << tblUbs[pos] << ", ubInc: " << ubInc << endl;
//cout << "Value = " << tmpVal << " for ";
//DumpIntVec( copy );
                if( lbThis > tmpLB)
                {
                    lbThis = tmpLB;
                }
                if( ubThis > tmpUB)
                {
                    ubThis = tmpUB;
                }
            }
            tblLbs[posStep] = lbThis;
//cout << "*Set lower bound at " << posStep << " to " << lbThis << endl;
            tblUbs[posStep] = ubThis;
            if( sz == numLvs)
            {
                lowerBound = lbThis;
                upperBound = ubThis;
            }
            
            // clean up
            for(unsigned int jj=0; jj<listPhyTreesSub.size(); ++jj)
            {
                delete listPhyTreesSub[jj];
            }
            
            if(GetNextCombo(sz, numLvs, posvec) == false)
            {
                break;
            }
        }
    }
    
    return 0;
}

// Implementations
void TreeChildNetBounds :: Init()
{
    // construct phy-trees for use
    listPhyTrees.resize(listMargTrees.size());
    for(int tr=0; tr<GetNumTrees(); ++tr)
    {
        string strNW = listMargTrees[tr].GetNewick();
        listPhyTrees[tr].ConsOnNewick(strNW);
    }
#if 0
cout << "Init:  list of given trees: \n";
for(int tr=0; tr<GetNumTrees(); ++tr)
{
string strNW;
listPhyTrees[tr].ConsNewick(strNW);
cout << "Given tree " << tr << ": " << strNW << endl;
}
#endif
//#if 0
    // now mapping id to ensure there are consecutive
    vector<PhylogenyTreeBasic *> listTreesConv;
    for(int i=0; i<GetNumTrees(); ++i)
    {
        listTreesConv.push_back(&listPhyTrees[i]);
    }
    TaxaMapper taxMap;
    ConvPhyloTreesToZeroBasedId( listTreesConv, &taxMap );
#if 0
cout << "After taxa mapping:  list of given trees: \n";
for(int tr=0; tr<GetNumTrees(); ++tr)
{
string strNW;
listPhyTrees[tr].ConsNewick(strNW, false, 1.0, true);
cout << "tree " << tr << ": " << strNW << endl;
}
#endif
//#endif
}

int TreeChildNetBounds :: GetNumTaxa() const
{
    return listMargTrees[0].GetNumLeaves();
}

int TreeChildNetBounds :: GetNumTrees() const
{
    return listMargTrees.size();
}

int TreeChildNetBounds :: CalcLBReticulateInc(const set<int> &setTaxa, int taxonAdd, vector<PhylogenyTreeBasic *> &listPhyTreesSub, vector<TreeNode *> &listSubtreeRootAttach, const map<int,int> &mapLabelToIndex )
{
//cout << "CalcLBReticulateInc: taxonAdd: " << taxonAdd << ", setTaxa: ";
//DumpIntSet(setTaxa);
    //
    set<set<int> > setTaxaAttach;
    for(unsigned int i=0; i<listSubtreeRootAttach.size(); ++i)
    {
        set<int> setDescLbls;
        listSubtreeRootAttach[i]->GetDescendentLabelSet(setDescLbls);
        
        // convert to index
        set<int> setDescLblsIndex;
        for(set<int> :: iterator it2 = setDescLbls.begin(); it2 != setDescLbls.end(); ++it2)
        {
            map<int,int> :: const_iterator it3 = mapLabelToIndex.find(*it2);
            YW_ASSERT_INFO(it3 != mapLabelToIndex.end(), "Fail to find in map");
            setDescLblsIndex.insert(it3->second);
        }
        
        setTaxaAttach.insert(setDescLblsIndex);
        

//string strNW = listPhyTreesSub[i]->ConsNewickTreeNode(listSubtreeRootAttach[i], false, 1.0, false, true);
//cout << "Attached subtree " << i << ": " << strNW << endl;
    }
    //
    int minHS = GetMinHittingSet( GetNumTaxa(), setTaxaAttach);
    
    return minHS-1;
}

int TreeChildNetBounds :: CalcUBReticulateInc(const set<int> &setTaxa, int taxonAdd, vector<PhylogenyTreeBasic *> &listPhyTreesSub, vector<TreeNode *> &listSubtreeRootAttach )
{
    // max inc = number of distinct subtrees when attaching this new taxa
    set<string> setNWSibtrees;
    for(unsigned int i=0; i<listSubtreeRootAttach.size(); ++i)
    {
        string strNW = listPhyTreesSub[i]->ConsNewickTreeNode(listSubtreeRootAttach[i], false, 1.0, false, true);
        setNWSibtrees.insert(strNW);
    }
    return setNWSibtrees.size()-1;
}

// get subtrees for taxa
void TreeChildNetBounds :: GetSubtrees(const set<int> &setTaxa, vector<PhylogenyTreeBasic *> &listPhyTreesSub )
{
//cout << "GetSubtrees: setTaxa: ";
//DumpIntSet(setTaxa);
    listPhyTreesSub.clear();
    for(int tr=0; tr<GetNumTrees(); ++tr)
    {
        PhylogenyTreeBasic *ptSub = ConsPhyTreeSubsetTaxa( &listPhyTrees[tr], setTaxa);
        listPhyTreesSub.push_back(ptSub);
//string strNW;
//ptSub->ConsNewick(strNW);
//cout << "subtree " << tr << ": " << strNW << endl;
    }
}

void TreeChildNetBounds :: GetSubtreesAttach(const vector<PhylogenyTreeBasic *> &listPhyTreesSub, int taxon, vector<TreeNode *> &listSubtreeRootAttach)
{
//cout << "GetSubtreesAttach: taxon:" << taxon << "\n";
    //
    listSubtreeRootAttach.clear();
    for(int tr=0; tr<GetNumTrees(); ++tr)
    {
        TreeNode *pnLv = NULL;
        // the following is very slow but quick to code... YW: TBD
        vector<TreeNode *> listLeafNodes;
        listPhyTreesSub[tr]->GetAllLeafNodes(listLeafNodes);
        for(int tn=0; tn<(int)listLeafNodes.size(); ++tn)
        {
            if( listLeafNodes[tn]->GetIntLabel() == taxon)
            {
                pnLv = listLeafNodes[tn];
                break;
            }
        }
        if( pnLv == NULL )
        {
            cout << "tr: " << tr << endl;
        }
        YW_ASSERT_INFO(pnLv != NULL, "Fail to find the leaf");
        // get its sibling
        vector<TreeNode *> listSibs;
        pnLv->GetSiblings(listSibs);
        YW_ASSERT_INFO(listSibs.size() == 1, "We only work with binary trees for now");
        listSubtreeRootAttach.push_back(listSibs[0]);
    }
}

int TreeChildNetBounds :: GetMinHittingSet( int numTaxa, const set<set<int> > &setSubsets )
{
cout << "GetMinHittingSet: setSubsets: " << endl;
for(set<set<int> > :: iterator it = setSubsets.begin(); it != setSubsets.end(); ++it)
{
DumpIntSet(*it);
}
    // Now, we first create a LP problem
    int numTotVarsNum = numTaxa;

    // figure out constraints
    vector<ILP_CONSTRAINT> listConstraints;

    // pairwise constraints
    for( set<set<int> > :: iterator it = setSubsets.begin(); it != setSubsets.end(); ++it )
    {
        // at least one element must be picked
        ILP_CONSTRAINT ilpc;
        for(set<int> :: iterator it2 = it->begin(); it2 != it->end(); ++it2)
        {
            ilpc.nonzeroPos.push_back( *it2 );
            ilpc.coefficients.push_back(1.0);
            ilpc.rhsBound = 1.0 ;
        }
        ilpc.fLB = true;
        listConstraints.push_back(ilpc);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // call ILP solver
    ILPSolver *pILPSolver;
#ifdef LPSOLVER_CPLEX
    pILPSolver = new CPlexILPSolver;
#endif

#ifdef LPSOLVER_GLPK
    pILPSolver = new GLPKILPSolver;
#endif


    pILPSolver->CreateProblem( listConstraints.size(), numTotVarsNum, true );    // we want to minimize

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setup variables (coluns)
    //int c = 0;
    // first part is the Ci
    for( int i = 0; i<numTotVarsNum; ++i )
    {
        int realVarId = i;
        char objName[1280];
        objName[0] = 'X';
        sprintf(&objName[1], ",%d", i );
        // the var can be any of the integer value
        // How do we assign coefficient to it
        double coeff = 1.0;
        pILPSolver->SetupVar( realVarId, objName, coeff, true);
    }

    //setup constraints
    int rcons = 0;
    for( int i = 0; i < (int) listConstraints.size(); ++i)
    {
        HAP_ILP_SENSE bdType = HAP_ILP_LB;
        if( listConstraints[i].fLB == false )
        {
            bdType = HAP_ILP_UB;
        }
        pILPSolver->AddConstraint( rcons++, listConstraints[i].nonzeroPos, listConstraints[i].coefficients,
            listConstraints[i].rhsBound, bdType);
    }

    //solve and retrive the result
    ILPSolution solILP(0, numTotVarsNum-1);
    solILP.Init( numTotVarsNum, numTotVarsNum, NULL);
    bool f = pILPSolver->Solve( solILP );

    int minHittingSet = (int)solILP.optObjective;
    
    // free up ILP
    delete pILPSolver;

    if( f == false)
    {
        // Infeasible
        cout << "ILP: infeasible" << endl;
        return 0;
    }
    // feasible
cout << "Min hitting set size: " << minHittingSet << endl;
solILP.Dump();
    return minHittingSet;
}

// Tree-child reticulation lower bound based on splits
int TreeChildNetBounds :: CalcLowerBound2()
{
    // collect all splits (in the form of two children's clades)
    map<TreeNode *, set<int> > mapNodeClade;
    for(int tr=0; tr<GetNumTrees(); ++tr)
    {
        listPhyTrees[tr].GetAllCladesNodes2(mapNodeClade);
    }
    // form all pairs
    set<pair<set<int>, set<int> > > setAllSplitsChildrenPairs;
    for(int tr=0; tr<GetNumTrees(); ++tr)
    {
        PhylogenyTreeIterator itorTree(listPhyTrees[tr]);
        itorTree.Init();
        while(itorTree.IsDone() == false )
        {
            TreeNode *pn = itorTree.GetCurrNode();
            itorTree.Next();
            set<int> sint;
            if( pn == NULL)
            {
                break;      // done with all nodes
            }
            if( pn->IsLeaf() == false )
            {
                // union all children
                YW_ASSERT_INFO( pn->GetChildrenNum()==2, "Assume binary tree");
                TreeNode *pnc1 =pn->GetChild(0);
                TreeNode *pnc2 = pn->GetChild(1);
                map<TreeNode *, set<int> > :: iterator it21 = mapNodeClade.find(pnc1);
                YW_ASSERT_INFO(it21 != mapNodeClade.end(), "Cannot find child");
                map<TreeNode *, set<int> > :: iterator it22 = mapNodeClade.find(pnc2);
                YW_ASSERT_INFO(it21 != mapNodeClade.end(), "Cannot find child");
                pair<set<int>, set<int> > pp( it21->second, it22->second );
                if( it22->second < it21->second)
                {
                    pp.first = it22->second;
                    pp.second = it21->second;
                }
                setAllSplitsChildrenPairs.insert(pp);
            }
        }
    }
cout << "setAllSplitsChildrenPairs:\n";
for(auto itt = setAllSplitsChildrenPairs.begin(); itt != setAllSplitsChildrenPairs.end(); ++itt)
{
cout << "<\n  ";
DumpIntSet(itt->first);
cout << "  ";
DumpIntSet(itt->second);
}
    
    // perform DP
    int lowerBound = HAP_MAX_INT;
    int numLvs = GetNumTaxa();
    // consider all subsets
    const int MAX_NUM_LVS = 30;
    if( numLvs > MAX_NUM_LVS )
    {
        // too many leaves
        cout << "Number of remaining taxa is too large.\n";
        return -1;
    }
    set<int> setLeafIntLabels;
    listPhyTrees[0].GetLeafIntLabels(setLeafIntLabels);
cout << "Leaf int labels: ";
DumpIntSet(setLeafIntLabels);
    
    vector<int> vecLeafIntLabels;
    PopulateVecBySet(vecLeafIntLabels, setLeafIntLabels);
    map<int,int> mapLabelToIndex;
    for(unsigned int i=0; i<vecLeafIntLabels.size(); ++i)
    {
        mapLabelToIndex[vecLeafIntLabels[i]] = i;
    }
    
    int szTblBounds = 0x1 << numLvs;
    vector<int> tblLbs(szTblBounds);
    // initialize, starting from one taxon
    tblLbs[0] = 0;
    for(int t=0; t<GetNumTaxa(); ++t)
    {
        vector<int> subsetIndex, posvec;
        posvec.push_back(t);
        GetIntVec(GetNumTaxa(), posvec, subsetIndex );
        int posStep = ConvVecToInt(subsetIndex);
        tblLbs[posStep] = 0;
    }

    // enumerate all subsets
    for(int sz = 2; sz<= numLvs; ++sz)
    {
cout << "Processing subset of taxa of sz: " << sz << endl;
        vector<int> posvec;
        GetFirstCombo(sz, numLvs, posvec);
        while(true)
        {
//cout << "Process: posvec:";
//DumpIntVec(posvec);
            vector<int> subsetIndex;
            GetIntVec(GetNumTaxa(), posvec, subsetIndex );
            int posStep = ConvVecToInt(subsetIndex);
            
            vector<int> posvecTaxa;
            ConvConsecutiveVecTo(vecLeafIntLabels, posvec, posvecTaxa);
            
            set<int> setTaxaThis;
            PopulateSetByVec(setTaxaThis, posvecTaxa);
            
            // estimate a bound based on subsets
            int lbThis = HAP_MAX_INT;
            for( int i=0; i<(int)posvecTaxa.size(); ++i  )
            {
                vector<int> copy = posvec;
                vector<int> :: iterator it = copy.begin();
                for(int j=0; j<i; ++j)
                {
                    it++;
                }
                copy.erase( it );
                vector<int> x;
                GetIntVec(GetNumTaxa(), copy, x );
                int pos = ConvVecToInt(x);

                // find the minimum from this item to the other
                set<int> scopy;
                PopulateSetByVec( scopy, copy);
                
                vector<int> posvecTaxa2;
                ConvConsecutiveVecTo(vecLeafIntLabels, copy, posvecTaxa2);
                set<int> scopy2;
                PopulateSetByVec(scopy2, posvecTaxa2);
                
                int lbInc = CalcLBReticulateInc2(scopy2, posvecTaxa[i], mapLabelToIndex, setAllSplitsChildrenPairs);

//cout << "pass 4" << endl;
                int tmpLB = tblLbs[pos] + lbInc;
//cout << "lb small:" << tblLbs[pos] << ", lbInc: " << lbInc << endl;
//cout << "Value = " << tmpVal << " for ";
//DumpIntVec( copy );
                if( lbThis > tmpLB)
                {
                    lbThis = tmpLB;
                }
            }
            tblLbs[posStep] = lbThis;
//cout << "*Set lower bound at " << posStep << " to " << lbThis << endl;
            if( sz == numLvs)
            {
                lowerBound = lbThis;
            }
            
            if(GetNextCombo(sz, numLvs, posvec) == false)
            {
                break;
            }
        }
    }
    // subtract the number of nodes minus one
    lowerBound -= GetNumTaxa()-1;
    
    return lowerBound;
}

int TreeChildNetBounds :: CalcLBReticulateInc2(const set<int> &setTaxa, int taxonAdd, const map<int,int> &mapLabelToIndex, set<pair<set<int>, set<int> > > &setAllSplitsChildrenPairs )
{
//cout << "CalcLBReticulateInc2: taxonAdd:" << taxonAdd << ", setTaxa: ";
//DumpIntSet(setTaxa);
    
    // find the case where one side of split has non-empty intersection with setTaxa but not the other (and the other contains taxonAdd)
    set<set<int> > setCandidates;
    for( set<pair<set<int>, set<int> > > :: iterator it = setAllSplitsChildrenPairs.begin(); it != setAllSplitsChildrenPairs.end(); ++it )
    {
        set<int> s12, s22;
        JoinSets(setTaxa, it->first, s12);
        JoinSets(setTaxa, it->second, s22);
        if( (s12.size() >0 && s22.size()==0 && it->second.find(taxonAdd) != it->second.end() ) || (s22.size() >0 && s12.size()==0 && it->first.find(taxonAdd) != it->first.end() )  )
        {
            // check if this source might have been counted
            set<int> sAdd;
            set<int> sint2;
            if( s12.size() > 0 )
            {
                sAdd = s12;
            }
            else
            {
                sAdd = s22;
            }
            
            // convert to index
            set<int> setDescLblsIndex;
            for(set<int> :: iterator it2 = sAdd.begin(); it2 != sAdd.end(); ++it2)
            {
                map<int,int> :: const_iterator it3 = mapLabelToIndex.find(*it2);
                YW_ASSERT_INFO(it3 != mapLabelToIndex.end(), "Fail to find in map");
                setDescLblsIndex.insert(it3->second);
            }
            setCandidates.insert(setDescLblsIndex);
        }
    }
    
    int minHS = GetMinHittingSet(GetNumTaxa(), setCandidates);
    return minHS;
}

void OutputILPMaxAgreeForest2(const char* fileName, int numTaxa, set<pair<set<int>, set<int> > > &setAllSplitsChildrenPairsIndices, vector<PhylogenyTreeBasic> &listPhyTrees );

// Tree-child reticulation lower bound based on splits
int TreeChildNetBounds :: CalcLowerBound2ILP()
{
    // output experimental ILP formulation
    set<pair<set<int>, set<int> > > setAllSplitsChildrenPairsIndices;
    RetrievePairChildClades( setAllSplitsChildrenPairsIndices);
    
    // output a file for ILP solving
    //OutputILPMaxAgreeForest2("tmp-tree-child-LB2.ilp", GetNumTaxa(), setAllSplitsChildrenPairsIndices);
    
    // calculate ILP
    // Now, we first create a LP problem
    // variables: V(i,j) for all 0 <=i < j < n. Meaning: V(i,j)=1 if there is an edge between i and j (in any direction)
    int numTaxa = GetNumTaxa();
    int numTotVarsNum = numTaxa*(numTaxa-1)/2;
//cout << "numTotVarsNum=" << numTotVarsNum << endl;
    // figure out constraints
    vector<ILP_CONSTRAINT> listConstraints;

    // pairwise constraints
    for(auto itt = setAllSplitsChildrenPairsIndices.begin(); itt != setAllSplitsChildrenPairsIndices.end(); ++itt)
    {
        // at least one element must be picked
        ILP_CONSTRAINT ilpc;
        for(set<int> :: iterator it2 = itt->first.begin(); it2 != itt->first.end(); ++it2)
        {
            for(set<int> :: iterator it3 = itt->second.begin(); it3 != itt->second.end(); ++it3)
            {
                //map<int,int> :: const_iterator it4 = mapLabelToIndex.find(*it2);
                //YW_ASSERT_INFO(it4 != mapLabelToIndex.end(), "Fail to find in map");
                //map<int,int> :: const_iterator it5 = mapLabelToIndex.find(*it3);
                //YW_ASSERT_INFO(it5 != mapLabelToIndex.end(), "Fail to find in map");
                //int posi = it4->second, posj = it5->second;
                int posi = *it2, posj = *it3;
                
                OrderInt(posi, posj);
                YW_ASSERT_INFO(posi<posj, "Order is wrong");
                int posij = ConvertToLinear(posi, posj, GetNumTaxa());
//cout << "posi: " << posi << ", posj: " << posj << ", posij:" << posij << endl;
                
                ilpc.nonzeroPos.push_back( posij );
                ilpc.coefficients.push_back(1.0);
                ilpc.rhsBound = 1.0 ;
            }
        }
//cout << endl;
        
        ilpc.fLB = true;
        listConstraints.push_back(ilpc);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // call ILP solver
    ILPSolver *pILPSolver;
#ifdef LPSOLVER_CPLEX
    pILPSolver = new CPlexILPSolver;
#endif

#ifdef LPSOLVER_GLPK
    pILPSolver = new GLPKILPSolver;
#endif


    pILPSolver->CreateProblem( listConstraints.size(), numTotVarsNum, true );    // we want to minimize

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setup variables (coluns)
    //int c = 0;
    // first part is the Ci
    for( int i = 0; i<numTotVarsNum; ++i )
    {
        int realVarId = i;
        char objName[1280];
        objName[0] = 'X';
        sprintf(&objName[1], ",%d", i );
        // the var can be any of the integer value
        // How do we assign coefficient to it
        double coeff = 1.0;
        pILPSolver->SetupVar( realVarId, objName, coeff, true);
    }

    //setup constraints
    int rcons = 0;
    for( int i = 0; i < (int) listConstraints.size(); ++i)
    {
        HAP_ILP_SENSE bdType = HAP_ILP_LB;
        if( listConstraints[i].fLB == false )
        {
            bdType = HAP_ILP_UB;
        }
        pILPSolver->AddConstraint( rcons++, listConstraints[i].nonzeroPos, listConstraints[i].coefficients,
            listConstraints[i].rhsBound, bdType);
    }

    //solve and retrive the result
    ILPSolution solILP(0, numTotVarsNum-1);
    solILP.Init( listConstraints.size(), numTotVarsNum, NULL);
    bool f = pILPSolver->Solve( solILP );
    //solILP.Dump();
    int minEdges = (int)solILP.optObjective;
    
    // free up ILP
    delete pILPSolver;

    if( f == false)
    {
        // Infeasible
        cout << "ILP: infeasible" << endl;
        return 0;
    }
    
    int lowerBound = minEdges - (numTaxa-1);
    
    return lowerBound;
}

// Tree-child reticulation lower bound that is stronger (but also slower) than the previous bound
int TreeChildNetBounds :: CalcLowerBound3ILP()
{
    // output experimental ILP formulation
    set<pair<set<int>, set<int> > > setAllSplitsChildrenPairsIndices;
    RetrievePairChildClades( setAllSplitsChildrenPairsIndices);
    
    // output a file for ILP solving
    string fileNameILP = fileNameInput + ".tmp.treechild.LB.ilp";
    OutputILPMaxAgreeForest2(fileNameILP.c_str(), GetNumTaxa(), setAllSplitsChildrenPairsIndices, listPhyTrees);
    
    // calculate ILP
    // Now, we first create a LP problem
    // variables: V(i,j) for all 0 <=i < j < n. Meaning: V(i,j)=1 if there is an edge between i and j (in any direction)
    int numTaxa = GetNumTaxa();
    int numCVars = numTaxa*(numTaxa-1)/2;
    int numTVars = numCVars;
    int numTotVarsNum = numCVars + numTVars;
//cout << "numTotVarsNum=" << numTotVarsNum << endl;
    // figure out constraints
    vector<ILP_CONSTRAINT> listConstraints;

    // Ordering constraints
    for(int i=0; i<numTaxa; ++i)
    {
        for(int j=i+1; j<numTaxa; ++j)
        {
            for(int k=j+1; k<numTaxa; ++k)
            {
                // Cij=0, Cjk=0 ==> Cik=0
                int posij = ConvertToLinear(i, j, numTaxa);
                int posik = ConvertToLinear(i, k, numTaxa);
                int posjk = ConvertToLinear(j, k, numTaxa);
                ILP_CONSTRAINT ilpc;
                ilpc.nonzeroPos.push_back( posik );
                ilpc.coefficients.push_back(1.0);
                ilpc.nonzeroPos.push_back( posij );
                ilpc.coefficients.push_back(-1.0);
                ilpc.nonzeroPos.push_back( posjk );
                ilpc.coefficients.push_back(-1.0);
                ilpc.rhsBound = 0.0 ;
                ilpc.fLB = false;
                listConstraints.push_back(ilpc);
                
                ILP_CONSTRAINT ilpc2;
                ilpc2.nonzeroPos.push_back( posik );
                ilpc2.coefficients.push_back(1.0);
                ilpc2.nonzeroPos.push_back( posij );
                ilpc2.coefficients.push_back(-1.0);
                ilpc2.nonzeroPos.push_back( posjk );
                ilpc2.coefficients.push_back(-1.0);
                ilpc2.rhsBound = -1.0 ;
                ilpc2.fLB = true;
                listConstraints.push_back(ilpc2);
                
                ILP_CONSTRAINT ilpc3;
                ilpc3.nonzeroPos.push_back( posij );
                ilpc3.coefficients.push_back(1.0);
                ilpc3.nonzeroPos.push_back( posik );
                ilpc3.coefficients.push_back(-1.0);
                ilpc3.nonzeroPos.push_back( posjk );
                ilpc3.coefficients.push_back(1.0);
                ilpc3.rhsBound = 1.0 ;
                ilpc3.fLB = false;
                listConstraints.push_back(ilpc3);
                
                ILP_CONSTRAINT ilpc4;
                ilpc4.nonzeroPos.push_back( posij );
                ilpc4.coefficients.push_back(1.0);
                ilpc4.nonzeroPos.push_back( posjk );
                ilpc4.coefficients.push_back(1.0);
                ilpc4.nonzeroPos.push_back( posik );
                ilpc4.coefficients.push_back(-1.0);
                ilpc4.rhsBound = 0.0 ;
                ilpc4.fLB = true;
                listConstraints.push_back(ilpc4);
                
                ILP_CONSTRAINT ilpc5;
                ilpc5.nonzeroPos.push_back( posjk );
                ilpc5.coefficients.push_back(1.0);
                ilpc5.nonzeroPos.push_back( posij );
                ilpc5.coefficients.push_back(1.0);
                ilpc5.nonzeroPos.push_back( posik );
                ilpc5.coefficients.push_back(-1.0);
                ilpc5.rhsBound = 1.0 ;
                ilpc5.fLB = false;
                listConstraints.push_back(ilpc5);
                
                ILP_CONSTRAINT ilpc6;
                ilpc6.nonzeroPos.push_back( posjk );
                ilpc6.coefficients.push_back(1.0);
                ilpc6.nonzeroPos.push_back( posij );
                ilpc6.coefficients.push_back(1.0);
                ilpc6.nonzeroPos.push_back( posik );
                ilpc6.coefficients.push_back(-1.0);
                ilpc6.rhsBound = 0.0 ;
                ilpc6.fLB = true;
                listConstraints.push_back(ilpc6);
            }
        }
    }
    
    // Split constraints
    for(auto itt = setAllSplitsChildrenPairsIndices.begin(); itt != setAllSplitsChildrenPairsIndices.end(); ++itt)
    {
        // at least one element must be picked
        for(set<int> :: iterator it2 = itt->first.begin(); it2 != itt->first.end(); ++it2)
        {
            for(set<int> :: iterator it3 = itt->second.begin(); it3 != itt->second.end(); ++it3)
            {
                //
                ILP_CONSTRAINT ilpc;
                int ti = *it2, tj = *it3;
                int tiOrder = ti, tjOrder = tj;
                OrderInt(tiOrder, tjOrder);
                int posij = ConvertToLinear(tiOrder, tjOrder, numTaxa);
                ilpc.nonzeroPos.push_back( posij + numCVars );
                ilpc.coefficients.push_back(1.0);
                //OutputTij(outFile, tiOrder, tjOrder);

                int szLarge1 = 0;
                for(set<int> :: iterator it4 = itt->first.begin(); it4 != itt->first.end(); ++it4)
                {
                    int tindex = *it4;
                    if( tindex != ti)
                    {
                        if( tindex < ti )
                        {
                            int posix = ConvertToLinear(tindex, ti, numTaxa);
                            ilpc.nonzeroPos.push_back( posix );
                            ilpc.coefficients.push_back(1.0);
                            //outFile << " + ";
                            //OutputCij(outFile, tindex, ti);
                        }
                        else
                        {
                            int posiy = ConvertToLinear(ti, tindex, numTaxa);
                            ilpc.nonzeroPos.push_back( posiy );
                            ilpc.coefficients.push_back(-1.0);
                            //outFile << " - ";
                            //OutputCij(outFile, ti, tindex);
                            ++szLarge1;
                        }
                    }
                }
                int szLarge2 = 0;
                for(set<int> :: iterator it5 = itt->second.begin(); it5 != itt->second.end(); ++it5)
                {
                    int tindex = *it5;
                    if( tindex != tj)
                    {
                        if( tindex < tj )
                        {
                            int posjx = ConvertToLinear(tindex, tj, numTaxa);
                            ilpc.nonzeroPos.push_back( posjx );
                            ilpc.coefficients.push_back(1.0);
                            //outFile << " + ";
                            //OutputCij(outFile, tindex, tj);
                        }
                        else
                        {
                            int posjy = ConvertToLinear(tj, tindex, numTaxa);
                            ilpc.nonzeroPos.push_back( posjy );
                            ilpc.coefficients.push_back(-1.0);
                            //outFile << " - ";
                            //OutputCij(outFile, tj, tindex);
                            ++szLarge2;
                        }
                    }
                }
                
                // rhs
                ilpc.fLB = true;
                ilpc.rhsBound = 1-szLarge1-szLarge2;
                listConstraints.push_back(ilpc);
                //outFile << " >= " << 1-szLarge1-szLarge2 << endl;
            }
        }
    }
    
    // Sinigle taxon constraints
    // Constraints based on analysis of singly connected taxon (or two taxa)
    for(int x=0; x<numTaxa; ++x)
    {
//cout << "Process singleton condition for witness taxon b=" << x << endl;
        // find all clades that contains s (then remove x)
        set< set<int> > setCladesWith;
        for(auto itt = setAllSplitsChildrenPairsIndices.begin(); itt != setAllSplitsChildrenPairsIndices.end(); ++itt )
        {
            set<int> setLeft = itt->first, setRight = itt->second;
            if( setLeft.find(x) != setLeft.end()  )
            {
                setLeft.erase(x);
                setCladesWith.insert(setLeft);
            }
            if( setRight.find(x) != setRight.end()  )
            {
                setRight.erase(x);
                setCladesWith.insert(setRight);
            }
        }
        //
        set<int> ssInt;
        FindIntersectionOfSets(setCladesWith, ssInt);
        // Single connection condition: for any taxon a that is only
        // connected to another taxon b, then any clade with b must have a
        // Thus, for any taxon b, let Sb be all the clades that contains b
        // then for any taxon a that is not present in all Sb, then
        // a cannot be only connected to b (if b is earlier than a)
        for(int a = 0; a<numTaxa; ++a)
        {
            if( a == x || ssInt.find(a) != ssInt.end() )
            {
                continue;
            }
//cout << "TAXON " << a << ": must have more than one connected other taxon \n";
            
            ILP_CONSTRAINT ilpc;
            ilpc.fLB = false;
            
            // this taxa x must have other connections
            pair<int,int> tt1(a,x);
            OrderInt(tt1.first, tt1.second);
            int posax = ConvertToLinear(tt1.first, tt1.second, numTaxa) + numCVars;
            ilpc.nonzeroPos.push_back( posax );
            ilpc.coefficients.push_back(1.0);
            
            if( x == tt1.first)
            {
                int posax2 = ConvertToLinear(x, a, numTaxa);
                ilpc.nonzeroPos.push_back( posax2 );
                ilpc.coefficients.push_back(1.0);
            }
            else
            {
                int posax3 = ConvertToLinear(a, x, numTaxa);
                ilpc.nonzeroPos.push_back( posax3 );
                ilpc.coefficients.push_back(-1.0);
            }
            
            for(int t=0; t<numTaxa; ++t)
            {
                if( t == a || t == x )
                {
                    continue;
                }
                pair<int,int> pp(a, t);
                OrderInt(pp.first, pp.second);
                int posat = ConvertToLinear(pp.first, pp.second, numTaxa)+numCVars;
                ilpc.nonzeroPos.push_back( posat);
                ilpc.coefficients.push_back(-1.0);
            }
            if( x == tt1.first)
            {
                ilpc.rhsBound = 1 ;
            }
            else
            {
                ilpc.rhsBound = 0.0 ;
            }
            listConstraints.push_back(ilpc);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // call ILP solver
    ILPSolver *pILPSolver;
#ifdef LPSOLVER_CPLEX
    pILPSolver = new CPlexILPSolver;
#endif

#ifdef LPSOLVER_GLPK
    pILPSolver = new GLPKILPSolver;
#endif


    pILPSolver->CreateProblem( listConstraints.size(), numTotVarsNum, true );    // we want to minimize

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setup variables (coluns)
    for( int i = 0; i<numCVars; ++i )
    {
        int realVarId = i;
        char objName[1280];
        objName[0] = 'C';
        sprintf(&objName[1], ",%d", i );
        // the var can be any of the integer value
        // How do we assign coefficient to it
        double coeff = 0.0;
        pILPSolver->SetupVar( realVarId, objName, coeff, true);
    }
    for( int i = 0; i<numTVars; ++i )
    {
        int realVarId = i+numCVars;
        char objName[1280];
        objName[0] = 'T';
        sprintf(&objName[1], ",%d", i );
        // the var can be any of the integer value
        // How do we assign coefficient to it
        double coeff = 1.0;
        pILPSolver->SetupVar( realVarId, objName, coeff, true);
    }

    //setup constraints
    int rcons = 0;
    for( int i = 0; i < (int) listConstraints.size(); ++i)
    {
        HAP_ILP_SENSE bdType = HAP_ILP_LB;
        if( listConstraints[i].fLB == false )
        {
            bdType = HAP_ILP_UB;
        }
        pILPSolver->AddConstraint( rcons++, listConstraints[i].nonzeroPos, listConstraints[i].coefficients,
            listConstraints[i].rhsBound, bdType);
    }

    //solve and retrive the result
    ILPSolution solILP(0, numTotVarsNum-1);
    solILP.Init( listConstraints.size(), numTotVarsNum, NULL);
    bool f = pILPSolver->Solve( solILP );
    //solILP.Dump();
    int minEdges = (int)solILP.optObjective;
    
    // free up ILP
    delete pILPSolver;

    if( f == false)
    {
        // Infeasible
        cout << "ILP: infeasible" << endl;
        return 0;
    }
    
    int lowerBound = minEdges - (numTaxa-1);
    
    return lowerBound;
}

void TreeChildNetBounds :: RetrievePairChildClades( set<pair<set<int>, set<int> > > & setAllSplitsChildrenPairsIndices)
{
    setAllSplitsChildrenPairsIndices.clear();
    
    // collect all splits (in the form of two children's clades)
    map<TreeNode *, set<int> > mapNodeClade;
    for(int tr=0; tr<GetNumTrees(); ++tr)
    {
        listPhyTrees[tr].GetAllCladesNodes2(mapNodeClade);
    }
    // form all pairs
    set<pair<set<int>, set<int> > > setAllSplitsChildrenPairs;
    for(int tr=0; tr<GetNumTrees(); ++tr)
    {
        PhylogenyTreeIterator itorTree(listPhyTrees[tr]);
        itorTree.Init();
        while(itorTree.IsDone() == false )
        {
            TreeNode *pn = itorTree.GetCurrNode();
            itorTree.Next();
            set<int> sint;
            if( pn == NULL)
            {
                break;      // done with all nodes
            }
            if( pn->IsLeaf() == false )
            {
                // union all children
                YW_ASSERT_INFO( pn->GetChildrenNum()==2, "Assume binary tree");
                TreeNode *pnc1 =pn->GetChild(0);
                TreeNode *pnc2 = pn->GetChild(1);
                map<TreeNode *, set<int> > :: iterator it21 = mapNodeClade.find(pnc1);
                YW_ASSERT_INFO(it21 != mapNodeClade.end(), "Cannot find child");
                map<TreeNode *, set<int> > :: iterator it22 = mapNodeClade.find(pnc2);
                YW_ASSERT_INFO(it21 != mapNodeClade.end(), "Cannot find child");
                pair<set<int>, set<int> > pp( it21->second, it22->second );
                if( it22->second < it21->second)
                {
                    pp.first = it22->second;
                    pp.second = it21->second;
                }
                setAllSplitsChildrenPairs.insert(pp);
            }
        }
    }
#if 0
cout << "setAllSplitsChildrenPairs:\n";
for(auto itt = setAllSplitsChildrenPairs.begin(); itt != setAllSplitsChildrenPairs.end(); ++itt)
{
cout << "<\n  ";
DumpIntSet(itt->first);
cout << "  ";
DumpIntSet(itt->second);
}
#endif
    
    set<int> setLeafIntLabels;
    listPhyTrees[0].GetLeafIntLabels(setLeafIntLabels);
//cout << "Leaf int labels: ";
//DumpIntSet(setLeafIntLabels);
    vector<int> vecLeafIntLabels;
    PopulateVecBySet(vecLeafIntLabels, setLeafIntLabels);
    map<int,int> mapLabelToIndex;
    for(unsigned int i=0; i<vecLeafIntLabels.size(); ++i)
    {
        mapLabelToIndex[vecLeafIntLabels[i]] = i;
    }
    
    for(auto itt = setAllSplitsChildrenPairs.begin(); itt != setAllSplitsChildrenPairs.end(); ++itt)
    {
        // at least one element must be picked
        set<int> ssPart1, ssPart2;
        for(set<int> :: iterator it2 = itt->first.begin(); it2 != itt->first.end(); ++it2)
        {
            map<int,int> :: const_iterator it4 = mapLabelToIndex.find(*it2);
            YW_ASSERT_INFO(it4 != mapLabelToIndex.end(), "Fail to find in map");
            int posi = it4->second;
            ssPart1.insert(posi);
        }
        for(set<int> :: iterator it2 = itt->second.begin(); it2 != itt->second.end(); ++it2)
        {
            map<int,int> :: const_iterator it4 = mapLabelToIndex.find(*it2);
            YW_ASSERT_INFO(it4 != mapLabelToIndex.end(), "Fail to find in map");
            int posi = it4->second;
            ssPart2.insert(posi);
        }
        pair<set<int>,set<int> > pp(ssPart1, ssPart2);
        setAllSplitsChildrenPairsIndices.insert(pp);
    }
}


// experiment with ILP formulation
// aux. functions for ILP output
static void OutputCij( ofstream &outFile, int i, int j )
{
    // Cij: enforce ordering can be any order
    outFile << "C," << i << "," << j;
}
static void OutputTij( ofstream &outFile, int i, int j )
{
    // Tij: add reticulate (or tree) edges (any order)
    outFile << "T," << i << "," << j;
}
static void OutputEij( ofstream &outFile, int i, int j )
{
    // Eij: extra reticulation between i and j
    outFile << "E," << i << "," << j;
}

void OutputILPMaxAgreeForest2(const char* fileName, int numTaxa, set<pair<set<int>, set<int> > > &setAllSplitsChildrenPairsIndices, vector<PhylogenyTreeBasic> &listPhyTrees )
{
    cout << "Integer programming formulation outputted to: " << fileName << ". In case it takes too long using the free GLPK ILP solver, you can use more powerful ILP solver e.g. Gurobi.\n";
#if 0
cout << "OutputILPMaxAgreeForest2: setAllSplitsChildrenPairsIndices: " << ", numTaxa: " << numTaxa << endl;
for(auto it = setAllSplitsChildrenPairsIndices.begin(); it != setAllSplitsChildrenPairsIndices.end(); ++it)
{
cout << "Pair: ";
DumpIntSet(it->first);
DumpIntSet(it->second);
}
#endif
    // output an ILP formulation for finding the lower bound
    // this formulation has fewer variables
    ofstream outFile(  fileName  );
    if(outFile.is_open() == false)
    {
        cout << "Can not open ILP output file: "<< fileName <<  endl;
        return ;
    }
    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";
    // finally the edge mutations
    for( int i = 0; i< numTaxa; ++i )
    {
        for(int j=i+1; j<numTaxa; ++j)
        {
            if( i != 0 || j != 1)
            {
                outFile << " + ";
            }
            OutputTij(outFile, i, j);
            
            // also adds-on reticulation
            outFile << " + ";
            OutputEij(outFile, i, j);
        }
        if( i < numTaxa-1 )
        {
            outFile << "\n ";
        }
    }
    outFile << " - nt";
    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;
//#if 0
    // enforce ordering
    for(int i=0; i<numTaxa; ++i)
    {
        for(int j=i+1; j<numTaxa; ++j)
        {
            for(int k=j+1; k<numTaxa; ++k)
            {
                // Cjk=1, Cik=0 ==> Cij=0
                OutputCij(outFile, i, j);
                outFile << " - ";
                OutputCij(outFile, i, k);
                outFile << " + ";
                OutputCij(outFile, j, k);
                outFile << " <= 1\n";
                
                // Cjk=0, Cik=1 ==> Cij=1
                OutputCij(outFile, i, j);
                outFile << " + ";
                OutputCij(outFile, j, k);
                outFile << " - ";
                OutputCij(outFile, i, k);
                outFile << " >= 0\n";
                
                // Cij=1, Cik=0 ==> Cjk=0
                OutputCij(outFile, j, k);
                outFile << " + ";
                OutputCij(outFile, i, j);
                outFile << " - ";
                OutputCij(outFile, i, k);
                outFile << " <= 1\n";
                
                // Cij=0, Cik=1 ==> Cjk=1
                OutputCij(outFile, j, k);
                outFile << " + ";
                OutputCij(outFile, i, j);
                outFile << " - ";
                OutputCij(outFile, i, k);
                outFile << " >= 0\n";
                
                // Cij=0, Cjk=0 ==> Cik=0
                OutputCij(outFile, i, k);
                outFile << " - ";
                OutputCij(outFile, i, j);
                outFile << " - ";
                OutputCij(outFile, j, k);
                outFile << " <= 0\n";
                
                // Cij=1, Cjk=1 ==> Cik=1
                OutputCij(outFile, i, k);
                outFile << " - ";
                OutputCij(outFile, i, j);
                outFile << " - ";
                OutputCij(outFile, j, k);
                outFile << " >= -1\n";

            }
        }
    }
//#endif
#if 0
    // enforce splits
    // pairwise constraints
    for(auto itt = setAllSplitsChildrenPairsIndices.begin(); itt != setAllSplitsChildrenPairsIndices.end(); ++itt)
    {
        bool fFirst = true;
        // at least one element must be picked
        for(set<int> :: iterator it2 = itt->first.begin(); it2 != itt->first.end(); ++it2)
        {
            for(set<int> :: iterator it3 = itt->second.begin(); it3 != itt->second.end(); ++it3)
            {
                //
                if( fFirst == false )
                {
                    outFile << " + ";
                }
                fFirst = false;
                int ti = *it2, tj = *it3;
                int tiOrder = ti, tjOrder = tj;
                OrderInt(tiOrder, tjOrder);
                OutputTij(outFile, tiOrder, tjOrder);
            }
        }
        // rhs
        outFile << " >= " << 1 << endl;
    }
#endif
//#if 0
    // enforce splits
    // pairwise constraints
    for(auto itt = setAllSplitsChildrenPairsIndices.begin(); itt != setAllSplitsChildrenPairsIndices.end(); ++itt)
    {
        // at least one element must be picked
        for(set<int> :: iterator it2 = itt->first.begin(); it2 != itt->first.end(); ++it2)
        {
            for(set<int> :: iterator it3 = itt->second.begin(); it3 != itt->second.end(); ++it3)
            {
                //
                int ti = *it2, tj = *it3;
                int tiOrder = ti, tjOrder = tj;
                OrderInt(tiOrder, tjOrder);
                OutputTij(outFile, tiOrder, tjOrder);

                int szLarge1 = 0;
                for(set<int> :: iterator it4 = itt->first.begin(); it4 != itt->first.end(); ++it4)
                {
                    int tindex = *it4;
                    if( tindex != ti)
                    {
                        if( tindex < ti )
                        {
                            outFile << " + ";
                            OutputCij(outFile, tindex, ti);
                        }
                        else
                        {
                            outFile << " - ";
                            OutputCij(outFile, ti, tindex);
                            ++szLarge1;
                        }
                    }
                }
                int szLarge2 = 0;
                for(set<int> :: iterator it5 = itt->second.begin(); it5 != itt->second.end(); ++it5)
                {
                    int tindex = *it5;
                    if( tindex != tj)
                    {
                        if( tindex < tj )
                        {
                            outFile << " + ";
                            OutputCij(outFile, tindex, tj);
                        }
                        else
                        {
                            outFile << " - ";
                            OutputCij(outFile, tj, tindex);
                            ++szLarge2;
                        }
                    }
                }
                
                // rhs
                outFile << " >= " << 1-szLarge1-szLarge2 << endl;
            }
        }
    }
//#endif
#if 0
    // enforce triple condition
    set<pair<pair<int,int>,int> > setAllTriples;
    for(unsigned int tr=0; tr<listPhyTrees.size(); ++tr)
    {
        GetAllTriplesIntLabels(&listPhyTrees[tr], setAllTriples);
    }
    cout << "List of triples\n";
    for(auto it = setAllTriples.begin(); it != setAllTriples.end(); ++it)
    {
        cout << "(" << it->first.first << "," << it->first.second << ")," << it->second << endl;
    }
    map<set<int>, int> mapTripleNums;
    for(auto it = setAllTriples.begin(); it != setAllTriples.end(); ++it)
    {
        set<int> ss;
        ss.insert(it->first.first);
        ss.insert(it->first.second);
        ss.insert(it->second);
        if( mapTripleNums.find(ss) == mapTripleNums.end())
        {
            mapTripleNums[ss] = 0;
        }
        ++mapTripleNums[ss];
    }
    set<int> setLeafIntLabels;
    listPhyTrees[0].GetLeafIntLabels(setLeafIntLabels);
    vector<int> vecLeafIntLabels;
    PopulateVecBySet(vecLeafIntLabels, setLeafIntLabels);
    set<int> setTaxa3Triples;
    for(unsigned int i=0; i<vecLeafIntLabels.size(); ++i)
    {
        for(unsigned int j=i+1; j<vecLeafIntLabels.size(); ++j)
        {
            for(unsigned int k=j+1; k<vecLeafIntLabels.size(); ++k)
            {
                set<int> ss;
                ss.insert(vecLeafIntLabels[i]);
                ss.insert(vecLeafIntLabels[j]);
                ss.insert(vecLeafIntLabels[k]);
                map<set<int>, int> :: iterator itt = mapTripleNums.find(ss);
                YW_ASSERT_INFO(itt != mapTripleNums.end(), "Fail to find triples");
                int numTriples = itt->second;
                
                // if one (say i) has only one connectiong, then there
                if( numTriples == 3 )
                {
                    UnionSets( setTaxa3Triples, ss);
                }
                
                // for one of these three (say i), if (i,j) is the only connection for i, and numTriples>=2, then k cannot be the earliest among three
                if( numTriples >= 2)
                {
                    OutputCij(outFile, i, k);
                    outFile << " + ";
                    OutputCij(outFile, j, k);
                    outFile << " - ";
                    OutputTij(outFile, i, j);
                    outFile << " + ";
                    OutputEij(outFile, i, j);
                    for(int x=0; x<numTaxa; ++x)
                    {
                        if( x != i && x != j)
                        {
                            pair<int,int> pp(x, i);
                            OrderInt(pp.first, pp.second);
                            outFile << " + ";
                            OutputTij(outFile, pp.first, pp.second);
                            outFile << " + ";
                            OutputEij(outFile, pp.first, pp.second);
                        }
                    }
                    outFile << " >= 0 \n";
                    
                    OutputCij(outFile, i, k);
                    outFile << " + ";
                    OutputCij(outFile, j, k);
                    outFile << " - ";
                    OutputTij(outFile, i, j);
                    outFile << " + ";
                    OutputEij(outFile, i, j);
                    for(int x=0; x<numTaxa; ++x)
                    {
                        if( x != i && x != j)
                        {
                            pair<int,int> pp(x, j);
                            OrderInt(pp.first, pp.second);
                            outFile << " + ";
                            OutputTij(outFile, pp.first, pp.second);
                            outFile << " + ";
                            OutputEij(outFile, pp.first, pp.second);
                        }
                    }
                    outFile << " >= 0 \n";
                    
                    OutputCij(outFile, i, k);
                    outFile << " + ";
                    OutputCij(outFile, i, j);
                    outFile << " + ";
                    OutputTij(outFile, j, k);
                    outFile << " - ";
                    OutputEij(outFile, j, k);
                    for(int x=0; x<numTaxa; ++x)
                    {
                        if( x != j && x != k)
                        {
                            pair<int,int> pp(x, j);
                            OrderInt(pp.first, pp.second);
                            outFile << " - ";
                            OutputTij(outFile, pp.first, pp.second);
                            outFile << " - ";
                            OutputEij(outFile, pp.first, pp.second);
                        }
                    }
                    outFile << " <= 2 \n";
                    
                    OutputCij(outFile, i, k);
                    outFile << " + ";
                    OutputCij(outFile, i, j);
                    outFile << " + ";
                    OutputTij(outFile, j, k);
                    outFile << " - ";
                    OutputEij(outFile, j, k);
                    for(int x=0; x<numTaxa; ++x)
                    {
                        if( x != j && x != k)
                        {
                            pair<int,int> pp(x, k);
                            OrderInt(pp.first, pp.second);
                            outFile << " - ";
                            OutputTij(outFile, pp.first, pp.second);
                            outFile << " - ";
                            OutputEij(outFile, pp.first, pp.second);
                        }
                    }
                    outFile << " <= 2 \n";
                    
                    // TBD not complete
                }
#if 0
                if( numTriples <= 1)
                {
                    continue;
                }
cout << "Triple " << i << "," << j << "," << k << ": " << numTriples << endl;
                // add constraints
                // Tij=Tik=1 and j and k have no other connections ==> Eij+Eik>=1
                //OutputTij(outFile, j, k);
                //outFile << " + ";
                OutputEij(outFile, i, j);
                outFile << " + ";
                OutputEij(outFile, i, k);
                outFile << " - ";
                OutputTij(outFile, i, j);
                outFile << " - ";
                OutputTij(outFile, i, k);
                for(int x=0; x<numTaxa; ++x)
                {
                    if( x == i || x == j || x == k)
                    {
                        continue;
                    }
                    pair<int,int> pp1(j, x);
                    OrderInt(pp1.first, pp1.second);
                    outFile << " + ";
                    OutputTij(outFile, pp1.first, pp1.second);
                    pair<int,int> pp2(k, x);
                    OrderInt(pp2.first, pp2.second);
                    outFile << " + ";
                    OutputTij(outFile, pp2.first, pp2.second);
                }
                outFile << " >= -1\n";
                // Tij=Tjk=1 and i/k have no other connections ==> Eij+Ejk>=1
                //OutputTij(outFile, i, k);
                //outFile << " + ";
                OutputEij(outFile, i, j);
                outFile << " + ";
                OutputEij(outFile, j, k);
                outFile << " - ";
                OutputTij(outFile, i, j);
                outFile << " - ";
                OutputTij(outFile, j, k);
                for(int x=0; x<numTaxa; ++x)
                {
                    if( x == i || x == j || x == k)
                    {
                        continue;
                    }
                    pair<int,int> pp1(i, x);
                    OrderInt(pp1.first, pp1.second);
                    outFile << " + ";
                    OutputTij(outFile, pp1.first, pp1.second);
                    pair<int,int> pp2(k, x);
                    OrderInt(pp2.first, pp2.second);
                    outFile << " + ";
                    OutputTij(outFile, pp2.first, pp2.second);
                }
                outFile << " >= -1\n";
                // Tik=Tjk=1 and i/j has no other connections ==> Eik+Ejk>=1
                //OutputTij(outFile, i, j);
                //outFile << " + ";
                OutputEij(outFile, i, k);
                outFile << " + ";
                OutputEij(outFile, j, k);
                outFile << " - ";
                OutputTij(outFile, i, k);
                outFile << " - ";
                OutputTij(outFile, j, k);
                for(int x=0; x<numTaxa; ++x)
                {
                    if( x == i || x == j || x == k)
                    {
                        continue;
                    }
                    pair<int,int> pp1(i, x);
                    OrderInt(pp1.first, pp1.second);
                    outFile << " + ";
                    OutputTij(outFile, pp1.first, pp1.second);
                    pair<int,int> pp2(j, x);
                    OrderInt(pp2.first, pp2.second);
                    outFile << " + ";
                    OutputTij(outFile, pp2.first, pp2.second);
                }
                outFile << " >= -1\n";
#endif
            }
        }
    }
    cout << "Taxa involved in 3-triple types: ";
    DumpIntSet(setTaxa3Triples);
    for(set<int>:: iterator it = setTaxa3Triples.begin(); it != setTaxa3Triples.end(); ++it)
    {
        // each such taxon must have at least two connections
        int num = 0;
        for(int s=0; s<numTaxa; ++s)
        {
            if( s == *it )
            {
                continue;
            }
            if( num > 0 )
            {
                outFile << " + ";
            }
            pair<int,int> pp(*it, s);
            OrderInt(pp.first, pp.second);
            OutputTij(outFile, pp.first, pp.second);
            ++num;
            outFile << " + ";
            OutputEij(outFile, pp.first, pp.second);
        }
        outFile << " >= 2\n";
    }
    for( int i = 0; i< numTaxa; ++i )
    {
        for(int j=i+1; j<numTaxa; ++j)
        {
            OutputEij(outFile, i, j);
            outFile << " - ";
            OutputTij(outFile, i, j);
            outFile << " <= 0\n";
        }
    }
#endif
    // enforce single taxon condition: for any taxon x,
    // if x is only attached to a single taxon (say y), then
    // all clades with x and something else must also have y
    for(int x=0; x<numTaxa; ++x)
    {
        // find all clades that contains s (then remove x)
        set< set<int> > setCladesWith;
        for(auto itt = setAllSplitsChildrenPairsIndices.begin(); itt != setAllSplitsChildrenPairsIndices.end(); ++itt )
        {
            set<int> setLeft = itt->first, setRight = itt->second;
            if( setLeft.find(x) != setLeft.end()  )
            {
                setLeft.erase(x);
                if( setLeft.size() > 0 )
                {
                    setCladesWith.insert(setLeft);
                }
            }
            if( setRight.find(x) != setRight.end()  )
            {
                setRight.erase(x);
                if( setRight.size() > 0)
                {
                    setCladesWith.insert(setRight);
                }
            }
        }
        //
        set<int> ssInt;
        FindIntersectionOfSets(setCladesWith, ssInt);
        if( setCladesWith.size() > 0 && ssInt.size() == 0 )
        {
//cout << "TAXON " << x << ": must have more than one connected taxon\n";
            // this taxa x must have other connections
            bool fFirst = true;
            for(int s=0; s<numTaxa; ++s)
            {
                if( s == x )
                {
                    continue;
                }
                if( fFirst == false)
                {
                    outFile << " + ";
                }
                pair<int,int> pp(s, x);
                OrderInt(pp.first, pp.second);
                OutputTij(outFile, pp.first, pp.second);
                fFirst = false;
            }
            outFile << " >= 2\n";
        }
    }
    // Constraints based on analysis of singly connected taxon (or two taxa)
    for(int x=0; x<numTaxa; ++x)
    {
//cout << "Process singleton condition for witness taxon b=" << x << endl;
        // find all clades that contains s (then remove x)
        set< set<int> > setCladesWith;
        for(auto itt = setAllSplitsChildrenPairsIndices.begin(); itt != setAllSplitsChildrenPairsIndices.end(); ++itt )
        {
            set<int> setLeft = itt->first, setRight = itt->second;
            if( setLeft.find(x) != setLeft.end()  )
            {
                setLeft.erase(x);
                setCladesWith.insert(setLeft);
            }
            if( setRight.find(x) != setRight.end()  )
            {
                setRight.erase(x);
                setCladesWith.insert(setRight);
            }
        }
        //
        set<int> ssInt;
        FindIntersectionOfSets(setCladesWith, ssInt);
        // Single connection condition: for any taxon a that is only
        // connected to another taxon b, then any clade with b must have a
        // Thus, for any taxon b, let Sb be all the clades that contains b
        // then for any taxon a that is not present in all Sb, then
        // a cannot be only connected to b (if b is earlier than a)
        for(int a = 0; a<numTaxa; ++a)
        {
            if( a == x || ssInt.find(a) != ssInt.end() )
            {
                continue;
            }
//cout << "TAXON " << a << ": must have more than one connected other taxon \n";
            // this taxa x must have other connections
            pair<int,int> tt1(a,x);
            OrderInt(tt1.first, tt1.second);
            OutputTij(outFile, tt1.first, tt1.second);
            
            if( x == tt1.first)
            {
                outFile << " + ";
                OutputCij(outFile, x, a);
            }
            else
            {
                outFile << " - ";
                OutputCij(outFile, a, x);
            }
            
            for(int t=0; t<numTaxa; ++t)
            {
                if( t == a || t == x )
                {
                    continue;
                }
                outFile << " - ";
                pair<int,int> pp(a, t);
                OrderInt(pp.first, pp.second);
                OutputTij(outFile, pp.first, pp.second);
            }
            if( x == tt1.first)
            {
                outFile << " <= 1\n";
            }
            else
            {
                outFile << " <= 0\n";
            }
        }
#if 0
        // Extention to two taxa a and b. For any taxon x (witness), if the clades involving x don't have either a or b, then a and b cannot be only connectd to x (if x is earlier than a and b)
        for(int a = 0; a<numTaxa; ++a)
        {
            for(int b=a+1; b<numTaxa; ++b)
            {
                if( a == x || b == x || (ssInt.find(a) != ssInt.end() && ssInt.find(b) != ssInt.end()  ) )
                {
                    continue;
                }
cout << "TAXA " << a << " and taxa " << b << ": must have more than one connected other taxon \n";
                // this taxa x must have other connections
                pair<int,int> tt1(a,x);
                OrderInt(tt1.first, tt1.second);
                OutputTij(outFile, tt1.first, tt1.second);
                
                int rhs = 0;
                if( x == tt1.first)
                {
                    outFile << " + ";
                    OutputCij(outFile, x, a);
                    ++rhs;
                }
                else
                {
                    outFile << " - ";
                    OutputCij(outFile, a, x);
                }
                
                outFile << " + ";
                pair<int,int> tt2(b,x);
                OrderInt(tt2.first, tt2.second);
                OutputTij(outFile, tt2.first, tt2.second);
                
                if( x == tt2.first)
                {
                    outFile << " + ";
                    OutputCij(outFile, x, b);
                    ++rhs;
                }
                else
                {
                    outFile << " - ";
                    OutputCij(outFile, b, x);
                }
                
                for(int t=0; t<numTaxa; ++t)
                {
                    if( t == a || t == b || t == x )
                    {
                        continue;
                    }
                    outFile << " - 4 ";
                    pair<int,int> pp(a, t);
                    OrderInt(pp.first, pp.second);
                    OutputTij(outFile, pp.first, pp.second);
                    outFile << " - 4 ";
                    pair<int,int> pp2(b, t);
                    OrderInt(pp2.first, pp2.second);
                    OutputTij(outFile, pp2.first, pp2.second);
                }
                outFile << " <= " << rhs << endl;
            }
        }
#endif
#if 0
        // Extention to three taxa a and b and c. For any taxon x (witness), if the clades involving x don't have either a or b or c, then a and b and c cannot be only connectd to x
        for(int a = 0; a<numTaxa; ++a)
        {
            for(int b=a+1; b<numTaxa; ++b)
            {
                for(int c=b+1; c<numTaxa; ++c)
                {
                    if( a == x || b == x || c == x || (ssInt.find(a) != ssInt.end() && ssInt.find(b) != ssInt.end() && ssInt.find(c) != ssInt.end()  ) )
                    {
                        continue;
                    }
cout << "Three taxa " << a << " and " << b << " and " << c << ": must have more than one connected other taxon \n";
                    // this taxa x must have other connections
                    int rhs = 0;
                    pair<int,int> tt1(a,x);
                    OrderInt(tt1.first, tt1.second);
                    OutputTij(outFile, tt1.first, tt1.second);
                    if( x == tt1.first)
                    {
                        outFile << " + ";
                        OutputCij(outFile, x, a);
                        ++rhs;
                    }
                    else
                    {
                        outFile << " - ";
                        OutputCij(outFile, a, x);
                    }
                    outFile << " + ";
                    pair<int,int> tt2(b,x);
                    OrderInt(tt2.first, tt2.second);
                    OutputTij(outFile, tt2.first, tt2.second);
                    if( x == tt2.first)
                    {
                        outFile << " + ";
                        OutputCij(outFile, x, b);
                        ++rhs;
                    }
                    else
                    {
                        outFile << " - ";
                        OutputCij(outFile, b, x);
                    }
                    outFile << " + ";
                    pair<int,int> tt3(c,x);
                    OrderInt(tt3.first, tt3.second);
                    OutputTij(outFile, tt3.first, tt3.second);
                    if( x == tt3.first)
                    {
                        outFile << " + ";
                        OutputCij(outFile, x, c);
                        ++rhs;
                    }
                    else
                    {
                        outFile << " - ";
                        OutputCij(outFile, c, x);
                    }
                    for(int t=0; t<numTaxa; ++t)
                    {
                        if( t == a || t == b || t == c || t == x  )
                        {
                            continue;
                        }
                        outFile << " - ";
                        pair<int,int> pp(a, t);
                        OrderInt(pp.first, pp.second);
                        OutputTij(outFile, pp.first, pp.second);
                        outFile << " - 6 ";
                        pair<int,int> pp2(b, t);
                        OrderInt(pp2.first, pp2.second);
                        OutputTij(outFile, pp2.first, pp2.second);
                        outFile << " - 6 ";
                        pair<int,int> pp3(c, t);
                        OrderInt(pp3.first, pp3.second);
                        OutputTij(outFile, pp3.first, pp3.second);
                    }
                    outFile << " <= " << rhs << endl;
                }
            }
        }
#endif
    }
    
    outFile << "nt = " << numTaxa -1 << endl;
    
    // variables
    outFile << "\nGenerals " << endl;
    outFile << "nt \n";
    
    outFile << "\nBinary " << endl;

    // Cij and Tij
    for( int i = 0; i< numTaxa; ++i )
    {
        for(int j=i+1; j<numTaxa; ++j)
        {
            OutputCij(outFile, i, j);
            outFile << endl;
            OutputTij(outFile, i, j);
            outFile << endl;
            OutputEij(outFile, i, j);
            outFile << endl;
        }
    }
    
    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();
}
