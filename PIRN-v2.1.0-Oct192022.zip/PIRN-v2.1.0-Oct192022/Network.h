#ifndef NETWORK_H
#define NETWORK_H

#include <map>
#include "Utils.h"
#include "Utils2.h"
#include "MarginalTree.h"
#include "ILPSolver.h"
//#include "BinaryMatrix.h"
#include "PhylogenyTreeBasic.h"

#include <stack>

using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// test whether MAF is good: first a valid MAF, and then is acyclic
bool IsMAFGood( const MarginalTree &tree1, const vector<int> &edgesCut, const MarginalTree &tree2  );
//void BuildMaxPhylogeny( const BinaryMatrix &matInput );


void OutputILPMaxGoodAgreeForestLeafPair(const char* fileName, const MarginalTree &treeOrig1, const MarginalTree &treeOrig2 );


////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// base class for hybrid network, providing some basic functionalities like cycle finding
class GenericHybridNetwork
{
public:
	virtual ~GenericHybridNetwork() {}

	void SetTreeList( vector<MarginalTree *> &listTreesParam ) { listTrees = listTreesParam; }
	void FindLeafPairGraphCycles();
	int GetNumForcedPathPairs() {return setForcedPathPairs.size();}
	set< pair<pair<int,int>, pair<int,int> > > & GetForcedPathPairsSet() {return setForcedPathPairs;}
	bool IsGraphAcyclic() {return listLeafPairCycles.size() == 0;}
	int GetNumInferredCycles() { return listLeafPairCycles.size(); }
	void GetCycle(int i, vector< pair<int,int> > &cycleNodes);

protected:
	// useful methods
	void ConsLeafPairGraph( vector< set<int> > &listGraphNodeNggrs );
	int GetLeafPairInd(int i, int j);
	void GetLeafPairFromId( int ind, int &leaf1, int &leaf2);
	virtual int GetNumLeaves() = 0;
	virtual int GetNumTotNodes() = 0;
	bool RecurseCycle(vector< set<int> > &listGraphNodeNggrs, int s,
		int v,  vector<int> &pointStack, vector<int> &markedStack, vector<bool> &markedFlag);

	// utility method
	void DumpNode(int id);
	void DumpListNode( const vector<int> &listNids  );
	void DumpFoundCycles();
	void OutputGML( const vector< set<int> > &listGraphNodeNggrs, const char *fileName  );


private:
	// 
	bool AreTwoPairsFullyDisjoint(int i, int j, int p, int q);
	bool AreTwoPairsGood(int i, int j, int p, int q, vector<vector< int > > &listMRCATrees, vector< vector< vector<bool> > > &ancestralMapTrees);
	bool AreTwoPairsForced(int i, int j, int p, int q, vector<vector< int > > &listMRCATrees, vector< vector< vector<bool> > > &ancestralMapTrees);


	vector<MarginalTree *> listTrees;

	// find the cycles in the graph pairs
	vector< vector<int> > listLeafPairCycles;
	set< pair<pair<int,int>, pair<int,int> > > setForcedPathPairs;	// list of pair of leaves that can not appear in list

};




// Main class for handling hybridization
// idea: use a leaf pair graph. We create a node for each leaf pair (i,j)

class HybridizeNetwork : public GenericHybridNetwork
{
public:
	HybridizeNetwork(const MarginalTree &tree1, const MarginalTree &tree2 );
	virtual ~HybridizeNetwork() {} 

	//void FindLeafPairGraphCycles();
	//int GetNumForcedPathPairs() {return setForcedPathPairs.size();}
	//set< pair<pair<int,int>, pair<int,int> > > & GetForcedPathPairsSet() {return setForcedPathPairs;}
	//bool IsGraphAcyclic() {return listLeafPairCycles.size() == 0;}
	//int GetNumInferredCycles() { return listLeafPairCycles.size(); }
	//void GetCycle(int i, vector< pair<int,int> > &cycleNodes);

protected:
	virtual int GetNumLeaves() { return tree1.GetNumLeaves(); }
	virtual int GetNumTotNodes() {return tree1.GetTotNodesNum();}

private:
	// useful methods
	//void ConsLeafPairGraph( vector< set<int> > &listGraphNodeNggrs );
	//int GetLeafPairInd(int i, int j);
	//void GetLeafPairFromId( int ind, int &leaf1, int &leaf2);
	//bool RecurseCycle(vector< set<int> > &listGraphNodeNggrs, int s,
	//	int v,  vector<int> &pointStack, vector<int> &markedStack, vector<bool> &markedFlag);

	// utility method
	//void DumpNode(int id);
	//void DumpListNode( const vector<int> &listNids  );
	//void DumpFoundCycles();
	//void OutputGML( const vector< set<int> > &listGraphNodeNggrs, const char *fileName  );

	// data
	const MarginalTree &tree1;
	const MarginalTree &tree2;
    vector<int> edgesCut;

	// find the cycles in the graph pairs
	//vector< vector<int> > listLeafPairCycles;
	//set< pair<pair<int,int>, pair<int,int> > > setForcedPathPairs;	// list of pair of leaves that can not appear in list
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Three or more trees

void OutputILPMaxGoodAgreeForestThreeTrees(const char* fileName, const MarginalTree &treeOrig1, 
										   const MarginalTree &treeOrig2, const MarginalTree &treeOrig3 );
void OutputILPMaxGoodAgreeForestMultiTrees(const char* fileName, vector<MarginalTree *> &listTreeOrig);

void OutputILPHybridUBMultiTrees(const char* fileName, vector<MarginalTree *> &listTreeOrig);
void OutputILPHybridLBMultiTrees(const char* fileName, vector<MarginalTree *> &listTreeOrig);
void OutputILPHybridLBStrongerMT(const char* fileName, vector<MarginalTree *> &listTreeOrig);

void OutputILPVecLBMT(const char* fileName, int numHybrids, vector< vector<int> > &listTreeDists);


// Class for inferring general hybrid network
class GeneralHybridNetwork : public GenericHybridNetwork
{
public:
	GeneralHybridNetwork(vector<MarginalTree *> &listTreeOrig);
	virtual ~GeneralHybridNetwork() {}

	int CalcQuickUB();
	// YW: DO NOT WORK, UNFORTUNATELY!!!!!!!!!!!!
	int CalcQuickLB();

protected:
	virtual int GetNumLeaves() { return listTreeOrig[0]->GetNumLeaves(); }
	virtual int GetNumTotNodes() {return listTreeOrig[0]->GetTotNodesNum();}

private:
	// utilities
	int CalcMinLinearOrder( const vector< vector<int> > &matPairDists );
	int CalcISForestDist( const set<int> &setTreeIndices, int nextTree );

	vector<MarginalTree *> listTreeOrig;
};


#endif  // NETWORK_H

