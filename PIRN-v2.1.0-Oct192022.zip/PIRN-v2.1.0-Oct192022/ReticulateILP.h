#ifndef RETICULATE_ILP_H
#define RETICULATE_ILP_H

#include "ReticulateNet.h"
#include "MarginalTree.h"
#include "ILPSolver.h"

// define reticulate ILP related functions

// results of stepwise inserting tree into an existing network
typedef struct
{
	vector<int> choicesRNs;			// what choices made at reticulate node: left (0) or right (1)
	vector< set<int> > resMAFParts;		// partitions of MAF in the results
} SW_INS_TREE_RES;

// define what is needed by ILP formulation
typedef struct
{
	vector<int> nonzeroPos;
	vector<double> coefficients;
	double rhsBound;
	bool fLB;
} ILP_CONSTRAINT;

// list of new nodes/edges to add and edges to modify
// here we assume we are not adding new leaves
typedef struct
{
	RN_NODE_ID descendNode;
	RN_NODE_ID par1Node;
	RN_NODE_ID par2Node;
	bool fUpdate;
} SW_NW_UPDATE_RECORD;

//typedef struct
//{
//	vector< SW_NW_UPDATE_RECORD > listUpdatedNodes;
//} SW_NETWORK_UPDATE;

typedef struct
{
	RN_NODE_ID subtreeRoot;
	RN_NODE_ID sibling;
	RN_NODE_ID parNew;
//	RN_NODE_ID parOrigsr;
//	RN_NODE_ID parOrigsib;
} SW_TREE_UPDATE_RECORD;

typedef struct
{
	// format: ((subtree root, sibling), <new parent, oldpar of sibling> )
	vector< SW_TREE_UPDATE_RECORD > listNewConnections;
	//vector< pair<RN_NODE_ID, RN_NODE_ID> > listUpdatedConnections;
} SW_TREE_UPDATE;

// utility for inserting a tree in an optimal way into a given network
class SWInsTreeILP
{
public:
	SWInsTreeILP(ReticulateNetwork &retNet, MarginalTree &treeIns);
	int Calculate( SW_INS_TREE_RES &result );
	void UpdateNetwork(SW_INS_TREE_RES &resultIns);

private:
	int GetCVarPos(int c);
	int GetRVarPos(int r, int numAVars);
	int GetAVarPos(int v, int pv, int numARVars);
	void ConsILPConstraints( vector<ILP_CONSTRAINT> &listConstraints );
	bool IsNodeDescendentOf(const RN_NODE_ID &rnid, const RN_NODE_ID &rnidAnces, map<RN_NODE_ID, set<RN_NODE_ID> > &mapAncesNodesSet)
	{
		YW_ASSERT_INFO(mapAncesNodesSet.find( rnid ) != mapAncesNodesSet.end(), "Fail to find such RNID");
		return mapAncesNodesSet[rnid].find(rnidAnces) != mapAncesNodesSet[rnid].end();
	}
    void FindSolInILP( ILPSolution &solILP, SW_INS_TREE_RES &result );   
	RN_NODE_ID FindMRCA(map<RN_NODE_ID,RN_NODE_ID > &mapEdges, const set<RN_NODE_ID> &setLeaves);
	//RN_NODE_ID FindNextSubtreeToAttach( map<RN_NODE_ID,RN_NODE_ID > &mapEdges, const vector<RN_NODE_ID> &vecSTRoots, 
	//	const vector< set<RN_NODE_ID> > listCompleteSTs,
	//	const set<RN_NODE_ID> &baseSubtree, RN_NODE_ID& nodeAttach);
	RN_NODE_ID FindNodesInSubtree(map<RN_NODE_ID,RN_NODE_ID > &mapEdges, const set<RN_NODE_ID> &setLeaves, set<RN_NODE_ID> &nodesInSubtree);
	//bool FindConnectedNodesToNode( map<RN_NODE_ID,RN_NODE_ID > &mapEdges, 
	//	const set<RN_NODE_ID> &setSTNodes, const RN_NODE_ID& nodeId, set<RN_NODE_ID> &connectNodes );
	RN_NODE_ID FindSibInTN( map<RN_NODE_ID,RN_NODE_ID > &mapEdges, const set<int> &lvLabels, const set<int> &baseTrees );
	RN_NODE_ID ExtractSubtree( map<RN_NODE_ID,RN_NODE_ID > &mapEdgesFullTree, const set<RN_NODE_ID> &subtree, 
		map<RN_NODE_ID,RN_NODE_ID > &mapEdgesSubtree );
	RN_NODE_ID ExtractSubtree( SW_INS_TREE_RES &resultIns, const set<RN_NODE_ID> &subtree, 
		map<RN_NODE_ID,RN_NODE_ID > &mapEdgesSubtree );
	void UpdateCurrTree( map<RN_NODE_ID,RN_NODE_ID > &mapEdgesFullTree, map<RN_NODE_ID,RN_NODE_ID > &mapEdgesCurrTree, 
		const set<RN_NODE_ID> &subtreeToAttach, 
		const RN_NODE_ID &ridattach, SW_TREE_UPDATE &updateTreeStatus );
	void UpdateCurrTree( SW_INS_TREE_RES &resultIns, map<RN_NODE_ID,RN_NODE_ID > &mapEdgesCurrTree, 
		const set<RN_NODE_ID> &subtreeToAttach, 
		const RN_NODE_ID &ridattach, SW_TREE_UPDATE &updateTreeStatus );
	RN_NODE_ID CreateNewNode() {return idNewNodeStart++;}
	void ConvTreeUpdateToNW( const SW_TREE_UPDATE &swTreeUpdates, SW_INS_TREE_RES &resultIns );
	void MaintainURNewPar( const RN_NODE_ID &nodeChild, const RN_NODE_ID &nodeParOld, const RN_NODE_ID &nodeParNew, SW_NW_UPDATE_RECORD &record );
	void DumpTreeMap(map<RN_NODE_ID,RN_NODE_ID > &mapTree);
	bool IsNodeAncestralInTTo( map<RN_NODE_ID,RN_NODE_ID > &mapEdges, const RN_NODE_ID &descn, const RN_NODE_ID &ancesn );
	void UpdateNetworkStep(const SW_NW_UPDATE_RECORD &updateRec, SW_INS_TREE_RES &resultIns, int rnChoice);
	void FindTreeAttachOrder( const vector<set<RN_NODE_ID> > &listCompleteTNs, vector<int> &vecOrder );
	bool AreTwoSTIntersectOnPathToRootInT( const set<RN_NODE_ID> &setNodeIds1, const set<RN_NODE_ID> &setNodeIds2 );
	bool FindTreeAttachOrderTwoTree( const vector<set<RN_NODE_ID> > &listCompleteTNs, vector<int> &vecOrder );
	bool IsSubTreeAncestralToInN( const set<RN_NODE_ID> &setNodeIds1, const set<RN_NODE_ID> &setNodeIds2 );


	ReticulateNetwork &reticulateNet;
	MarginalTree &treeIns;
	int numCVars;
	int numRVars;
	int numAVars;
	int numNodesInN;
	vector<RN_NODE_ID> vecRNNodes;
	vector< vector<RN_NODE_ID> > vecRNAncesNodes; 
	map<RN_NODE_ID, set<RN_NODE_ID> > mapRNAncesNodesSet; 
	int numReticulateNodes;
	vector<int> listRNLeafIds;
	map< pair<int,int>, set<int> > mapPathNodesLeafPairsInT;
	RN_NODE_ID idNewNodeStart;

	// for a quicker lookup of vars
	map<pair<int,int>, int> mapAVarIndex;

};


// SW Network builder
class SWNetworkBuilder
{
public:
	SWNetworkBuilder(vector<MarginalTree> &listMargTrees);
	void CalcBest();		// pick one order (random now)
	void CalcExhaustive();
	void CalcOneOrder( const vector<int> &vecOrder);
	void CalcHeu(const vector<int> &listNodeOrder);			// grow a network heuristicly
	void Test();
	void SetLB(int lb) { knownLB = lb; }
	int FindMSTOrder( const vector< vector<int> > &resDists, vector<int> &listNodeOrder );
	void SetOrigTreeInfo(int numTaxaUser, const vector< pair<int,int> > &listRemovedPairs, const vector< int > &listSurvivePos, TaxaMapper *pMapperTMapInfo);

private:
//	void UpdateNetwork( ReticulateNetwork &testNet, const SW_NETWORK_UPDATE &updateNetRec );
	int CalcCostForOrder( const vector<int> &deriveOrder, ReticulateNetwork &resNet, int curBestCost );
	int HeuAddTreeToNet( ReticulateNetwork &curNet, MarginalTree &treeToAdd, const vector<int> &indexPrevTrees );
	bool GetInputRNChoices(ReticulateNetwork &curNet, const vector<int> &indexPrevTrees, set< vector<int> >  &setChoicesRN);

	
	vector<MarginalTree> &listMargTrees;
	int knownLB;
	int numTreesRun;

	int numTaxaUser;
	vector< pair<int,int> > listRemovedPairs;
	vector< int > listSurvivePos;
	TaxaMapper *pMapperTMapInfo;
};


// SW Network lower bound
class ReticualteNetLB
{
public:
	ReticualteNetLB(vector<MarginalTree> &listMargTrees);
    ReticualteNetLB(vector<MarginalTree> &listMargTrees, const vector< vector<int> > &distPairwise);
	int Calculate();
	void GetPairwiseDists( vector< vector<int> > &resDists ) { resDists = distPairwise; }

private:
	void InitPairDists();
	int CalcLB3Trees();
	bool IsHCFeasible( int szHC );
	int GetXVarPos(int t1, int t2, int szHC);
	int GetMVarPos( int numXVars, int szHC, int t1, int t2, int h );
	
	vector<MarginalTree> &listMargTrees;
	vector< vector<int> > distPairwise;		// pairwise distances of trees
};

// Cherry bound: a much faster lower bound
class ReticulateCherryBound
{
public:
    ReticulateCherryBound(vector<MarginalTree> &listMargTrees);
    int Calculate();
    int CalculateComposite();
    
private:
    void GetCherryFor(const MarginalTree &tr, std::set<pair<int,int> > &setCherries) const;
    int GetNumTaxa() const;
    int GetNumTrees() const { return listMargTrees.size(); }
    
    vector<MarginalTree> &listMargTrees;
};

#endif
