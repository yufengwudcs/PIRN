#include "ILPSolver.h"
#include "Utils.h"

// ***************************************************************************
// Define ILP solution class
// ***************************************************************************
int ILPSolution :: ComputeBounds()
{
        /*
          Now we setup the solution lower/upper bound
          that is, what is the range of solution (columns) left or right
        */
        lb = -1;
        ub = -1;
        int nColNonZeros = 0;
        for(int i=0; i< nc; ++i)
        {
                if( pSolution[ i  ] > 0.00001 && lb == -1)
                {
                        lb = i;
                }
                if( pSolution[ i  ] > 0.00001 )
                {
                        ub = i; 
                        nColNonZeros++; 
                }
        }
    
        // Set the bounds correctly
        if(lb >=0 && mapSolIndToCol != NULL)
        {
                lb = (*mapSolIndToCol) [ lb];
        }
        if(ub >=0 && mapSolIndToCol != NULL)
        {
                ub = (*mapSolIndToCol) [ ub];
        }

        // Now record the number
        optRes = nr - nColNonZeros - 1;
        return optRes;
}


void ILPSolution :: Dump()
{
        cout << "Solution is: " << endl;
        for(int i=0; i<nc; ++i)
        {
            if( mapSolIndToCol != NULL)
            {
                cout << "C" << (*mapSolIndToCol) [i] << " = " << pSolution [ i ] << endl;
            }
            else
            {
                cout << pSolution[i] << ", ";
            }
        }
        cout << endl;
}

bool ILPSolution :: operator==(const ILPSolution &rhs)
{
	// rough check
	if( rhs.nc != nc)
	{
		return false;
	}
	// Check one bit by one to see if solution match
	for(int i=0; i<nc; ++i)
	{
		if( pSolution[i] != rhs.pSolution[i] )
		{
			return false;
		}
	}
	return true;
}

#ifdef LPSOLVER_CPLEX

//******************************************************************************
// Implementation class for CPLEX ILPSolver
CPlexILPSolver :: CPlexILPSolver( ) : env(NULL), lp(NULL), colNames(NULL), colCoeffs(NULL), cTypes(NULL),
	matIndice(0), matBegins(NULL), matInds(NULL), matVals(NULL), nRows(0), nCols(0), 
    sense(NULL), matRHS(NULL), fRelax(false)
{
	Init();
}



CPlexILPSolver :: ~CPlexILPSolver()
{
        // Cleanup CPLEX
        if(env != NULL)
        {
                int status = CPXcloseCPLEX(&env);
                if(status)
                {
                        char errmsg[1024];
                        cout << "Can not close CPLEX environment." << endl;
                        CPXgeterrorstring(env, status, errmsg);
                        cout << errmsg << endl;
                }
        }

}


void CPlexILPSolver :: Init() 
{
	int status;
        env = CPXopenCPLEXruntime(&status, 10000, "Somthing;that;i;donotknow");
        if( env == NULL)
        {
                char errmsg[1024];
                cout << "Can not close CPLEX environment." << endl;
                CPXgeterrorstring(env, status, errmsg);
                cout << errmsg << endl;
        }

}

void CPlexILPSolver :: CreateProblem(int nr, int nc, bool fMinimize)  
{
	nRows = nr; 
	nCols = nc; 
	matIndice = 0;

        int status;
          
        lp = CPXcreateprob( env, &status, "hapbound" );
        if(lp == NULL)
        {
                cout << "Failed to create CPLEX problem." << endl;
                return  ;
        }    
      
        // Now start to populate problem
        // Here, we use Myers' suggestion, that is we use MIN!!!!!
        if( fMinimize)
        {
            CPXchgobjsen(env, lp, CPX_MIN); 
        }
        else
        {
            CPXchgobjsen(env, lp, CPX_MAX); 
        }

//cout << "here 1.0" << endl;
	// Also some other issues to take care, such as name storage
        colNames = new char* [nCols];
        for(int i=0; i< nCols; ++i)
        {
		// we only need very small storge for name, since we know it!
                colNames[i] = new char[100];
        }
	colCoeffs = new double[nCols];
	cTypes = new char[nCols];
//cout << "here 1.1" << endl;
	
	matBegins = new int[ nRows ];
//cout << "here 1.2" << endl;
	matInds = new int[ nRows*nCols ];	
//cout << "here 1.2.5" << endl;
    matVals = new double [nRows*nCols];
//cout << "here 1.3" << endl;
    sense = new char[ nRows ];
    matRHS = new double[ nRows ];
//cout << "here 1.4" << endl;
}

void CPlexILPSolver :: DeleteProblem()
{
    int status = CPXfreeprob(env, &lp);
    if( status)
    {
            cout << "Can not freeup the problem." << endl;
    }
    for(int i=0; i<nCols; ++i)
    {
            delete [] colNames[i];
    }
    delete [] colNames;
	colNames = NULL;
	delete [] colCoeffs;
	colCoeffs = NULL;
	delete [] matBegins;
	delete [] cTypes;
	cTypes = NULL;
	matBegins = NULL;
	delete [] matInds;
	matInds = NULL;
    delete [] matVals;
    matVals = NULL;
    delete [] sense;
    sense = NULL;
    delete [] matRHS;
    matRHS = NULL;
	matIndice = 0;
}

// Note, in our program, we assume colNum starts from 0
void CPlexILPSolver :: SetupVar(int col, const char* varName, double objCoeff , bool fBin ) 
{
	if(col >= nCols)
	{
		cout << "Fatal error in SetupVar." << endl;
		return;
	}
//cout << "Not implemented yet." << endl;
//YW_ASSERT(false);

	strcpy( colNames[col], varName);
	colCoeffs[ col ] = objCoeff;
	if( fBin )
	  {
	    cTypes[ col ] = 'B';
	  }
	else
	  {
	    cTypes[ col ] = 'I';
	  }
}


// This function takes a vector for non-zero positions in that row
void CPlexILPSolver :: AddConstraint(int row, const vector<int> &nonzerosPos, const vector<double> &nonzeroCoeffs, 
        double rhsVal, HAP_ILP_SENSE sense   )
{
	if(row >= nRows)
	{
		cout << "Fatal error in AddConstraint." << endl;
		return;
	}
	matBegins[ row ] = matIndice;
    if( sense ==  HAP_ILP_LB)
    {
        this->sense[ row ] = 'G';
    }
    else if( sense == HAP_ILP_UB )
    {
        this->sense[ row ] = 'L';         // what should I do here?? not done yet TBD
    }
    this->matRHS[row] = rhsVal; 
    // Now setup each cell in this row
    for( int i=0; i<nonzerosPos.size(); ++i)
    {
            // Then also add constraints
        matInds[ matIndice ] = nonzerosPos[i]; 
        matVals[ matIndice ] = nonzeroCoeffs[i];

        matIndice++;
    }
	
}

// This function solve the ILP. Solution is stored inside solution
// Return true if solving is successful, false otherwise
bool CPlexILPSolver :: Solve( ILPSolution &solILP)
{
	// Now, we perform the rest of work needed
	// These include setting up variables to binary, setup constraints, etc
	int status;
        // Now setup the objective
        status =  CPXnewcols(  env, lp, nCols, colCoeffs, NULL, NULL, NULL, colNames ) ;
        if(status)
        {
                cout <<"Problem in setting up objective." << endl;
		return false;
        }

	// Now setup rows for ILP
//cout << "Pass1 \n";

        char **rowname;
//        double *rhs = new double [nRows];
        rowname = new char*[ nRows ];
        for(int i=0; i<nRows; ++i)
        {
                rowname[i] = new char[10];
				strcpy(rowname[i], " ");
//				rowname[i][0] = 'r';
//                sprintf("%d", i+1,  &rowname[i][1] );
//				rhs[i] = 1.0; 
       }
//cout << "Pass2 \n";

#if 0
        char *sense = new char[  nRows  ];
        for(int i=0; i<nRows; ++i)
        {
                sense[i] = 'G';         // when T_i is not used, we use G
        }
#endif
#if 0
        double *rmatval = new double [ nRows * nCols];
        for(int i=0; i<matIndice; ++i)
		{
		        rmatval[i] = 1.0;
		}
#endif
        // Now setup constraint
        // remember indice hold the number of non-zero indices
        status = CPXaddrows(  env, lp, 0, nRows, matIndice, matRHS, sense,
                     matBegins, matInds, matVals, NULL, rowname);
        if(status)
        {
                 // Fatal error
                 cout << "Can not populate problem!" << endl;
        }
//cout << "Pass3 \n";

        // now set all variable to be binary
#if 0
        char *ctype = new char [nCols];
        for(int i=0; i<nCols; ++i)
        {
                ctype[i] = 'B';
        }
#endif
        status = CPXcopyctype( env, lp, cTypes);
        if( status )
        {
                cout << "Can not set variables to binary type." << endl;
        }
//cout << "Pass4 \n";

//#if 0
	// Dump problem first
	status = CPXwriteprob( env, lp, "mylp.lp", NULL);
//#endif
//cout << "Pass4.1 \n";



    // Now solve it
	if( fRelax == false )
	{
		status = CPXmipopt( env, lp );
		if( status)
		{
			 // Fatal error
			   cout << "Can not solve problem" << endl;
		}
	}
	else
	{
		CPXchgprobtype(env, lp, CPXPROB_LP);
		status = CPXlpopt( env, lp );
		if( status)
		{
			 // Fatal error
			   cout << "Can not solve problem" << endl;
		}
	}
//cout << "Pass5 \n";

    // Now take solution
	if( fRelax == false )
	{
		double objval;
		int solstat = CPXgetstat(env, lp);
		status = CPXgetmipobjval (env, lp, &objval);

		if(status)
		{
				cout << "Fail to get status" << endl;
				char errmsg[1024];
				CPXgeterrorstring(env, status, errmsg);
				cout << errmsg << endl;
		}
	//cout << "Pass6 \n";

		// store the solutio ILP objective
		solILP.optObjective = objval;
//cout << "solILP.optObjective = " << solILP.optObjective << endl;

		int cur_numcols = CPXgetnumcols (env, lp);
		status = CPXgetmipx (env, lp, solILP.pSolution, 0, cur_numcols-1);
		if(status)
		{
	//             cout << "Fail to get solution." << endl;
				 solILP.lb = -1;
				 solILP.ub = -1;
				 return false;
		}
	}
	else
	{
		double objval;
		//int solstat = CPXgetstat(env, lp);
		//status = CPXgetobjval  (env, lp, &objval);

		//if(status)
		//{
		//		cout << "Fail to get status" << endl;
		//		char errmsg[1024];
		//		CPXgeterrorstring(env, status, errmsg);
		//		cout << errmsg << endl;
		//}
	//cout << "Pass6 \n";

		// store the solutio ILP objective
		//solILP.optObjective = objval;

		int cur_numcols = CPXgetnumcols (env, lp);
		int solstat;
		//status = CPXgetmipx (env, lp, solILP.pSolution, 0, cur_numcols-1);
		status = CPXsolution (env, lp, &solstat, &solILP.optObjective, solILP.pSolution, NULL, NULL, NULL);
		if(status)
		{
	//             cout << "Fail to get solution." << endl;
				 solILP.lb = -1;
				 solILP.ub = -1;
				 return false;
		}
cout << "solILP.optObjective = " << solILP.optObjective << endl;
		// get opt objective again
		//CPXgetobjval(env, lp, &solILP.optObjective);
	}

//cout << "Pass7 \n";
	// at last, perform some cleanup and quit
    for(int i=0; i<nRows; ++i)
    {
             delete [] rowname[i];
    }
    delete [] rowname;
    //delete [] ctype;
    //	delete [] sense;
//cout << "Pass8 \n";
	return true;
}

#endif



#ifdef LPSOLVER_GLPK

//******************************************************************************
// Implementation class for CPLEX ILPSolver

static  int GLPK_print_hook(void *info, char *msg)
{
	// do nothing
	return 1;			// fool GLPK
}


GLPKILPSolver :: GLPKILPSolver() : matIndice(0), rn(NULL), cn(NULL), pVals(NULL), nCols(0), nRows(0), fMinimize( true ), fRelax(false)
{
	// Turn off printing
	my_lib_set_print_hook (NULL, GLPK_print_hook);
}

GLPKILPSolver :: ~GLPKILPSolver()
{
}

void GLPKILPSolver :: Init()
{
	// nothing to do
}

void GLPKILPSolver :: CreateProblem(int nr, int nc, bool fMinimize)
{
	matIndice = 0;
	nRows = nr;
	nCols = nc;

	int numCells = nr*nc;
	rn = new int[numCells+1];
	cn = new int[numCells+1];
    pVals = new double[ numCells + 1 ];
    this->fMinimize = fMinimize;

	// create problem first
	lp = my_lpx_create_prob();
	my_lpx_set_prob_name(lp, "HapBound");
	my_lpx_set_class(lp, LPX_MIP);

	// specify problem size
	my_lpx_add_rows( lp, nr );
	my_lpx_add_cols( lp, nc );
}

void GLPKILPSolver :: DeleteProblem()
{
	my_lpx_delete_prob(lp);
	delete [] rn;
	delete [] cn;
    delete [] pVals;
}

void GLPKILPSolver :: SetupVar(int colNum, const char* varName, double objCoeff, bool fBin )
{
	// Note, in GLPK, indice starts from 1, not 0!!!!
    // for now, we assume the integer takes >=0 value (is this a good choice?)
	my_lpx_set_col_name(lp, colNum+1, (char *)varName);
    if( fBin == true)
    {
	    my_lpx_set_col_bnds(lp, colNum+1, LPX_DB, 0.0, 1.0);
    }
    else
    {
	    my_lpx_set_col_bnds(lp, colNum+1, LPX_LO, 0.0, 0.0);
    }
	my_lpx_set_col_kind(lp, colNum+1, LPX_IV);

	// also setup the objective
	my_lpx_set_col_coef(lp, colNum+1,objCoeff);
}

void GLPKILPSolver :: AddConstraint(int row, const vector<int> &nonzerosPos, const vector<double> &nonzeroCoeffs, 
        double rhsVal, HAP_ILP_SENSE sense   )
{
	// add an empty name
    char rowname[100];
	rowname[0] = 'r';
    sprintf( &rowname[1], "%d", row+1   );
	my_lpx_set_row_name(lp, row+1, rowname);

	// setup row bound, according to params
    if( sense == HAP_ILP_LB)
    {
	    my_lpx_set_row_bnds(lp, row+1, LPX_LO, rhsVal, rhsVal);
    }
    else if( sense == HAP_ILP_UB)
    {
	    my_lpx_set_row_bnds(lp, row+1, LPX_UP, rhsVal, rhsVal);
    }
    else
    {
        YW_ASSERT_INFO(false, "ILP sense error.");
    }
	for(unsigned int i=0; i<nonzerosPos.size(); ++i)
	{
		matIndice++;
		rn[matIndice] = row+1;
		cn[matIndice] = nonzerosPos[i]+1;
        pVals[matIndice] = nonzeroCoeffs[i];
	}

}

bool GLPKILPSolver :: Solve( ILPSolution &solILP)
{
//my_lpx_write_lpt(lp, "mylp-glpk.lp");
	// First finish off the matrix loading
//	double *pVals = new double[matIndice+1];
//	for(int i=0; i<=matIndice; i++)
//	{
//		pVals[i] = 1.0;
//	}
	my_lpx_load_mat3(lp, matIndice, rn, cn, pVals);

	// Set up col type to binary
	for(int i=1; i<=nCols; ++i)
	{
		my_lpx_set_col_kind(lp, i, LPX_IV);
	}

	// Now solve the problem
    if( fMinimize)
    {
	    my_lpx_set_obj_dir(lp, LPX_MIN);
    }
    else
    {
	    my_lpx_set_obj_dir(lp, LPX_MAX);
    }
my_lpx_write_lpt(lp, "mylp-glpk.lp");
//cout << "Number of integer variables = " << my_lpx_get_num_int(lp) << endl;

	// we have to run simplex first before calling lpx_integer. Weired!
	my_lpx_simplex(lp);

	if( fRelax == false )
	{
		int res = my_lpx_integer(lp);
//cout << "res = " << res << endl;

		if( res != LPX_E_OK)
		{
	// YW TBD. May need it later...
	//		cout << "GLPK fails to find the integer solution." << endl;
			delete [] pVals;
	//		return false;
	//		exit(1);
			return false;
		}
	}
	// otherwise we are done with solution

	// Query the result
	if( fRelax == false)
	{
		solILP.optObjective = my_lpx_get_mip_obj( lp );
		for(int i=1; i<=nCols; ++i)
		{
	//		my_lpx_get_col_info(lp, i, NULL,  &solILP.pSolution[i-1], NULL);
			solILP.pSolution[i-1] = my_lpx_get_mip_col(lp, i);
		}
	}
	else
	{
		// go find the LP solution instead
		solILP.optObjective = my_glp_get_obj_val(lp);
		for(int i=1; i<=nCols; ++i)
		{
	//		my_lpx_get_col_info(lp, i, NULL,  &solILP.pSolution[i-1], NULL);
			solILP.pSolution[i-1] = my_glp_get_col_prim(lp, i);
		}
	}
	// finally quit
//	delete [] pVals;
	return true;
}
	



#endif
