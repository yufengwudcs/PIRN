#ifndef ILP_SOLVER_H
#define ILP_SOLVER_H

#ifdef LPSOLVER_CPLEX
#include "cplex.h"
#endif

#ifdef LPSOLVER_GLPK
#include "glpk.h"
#include "glpk_wraper.h"
#endif

#include <iostream>
#include <set>
#include <vector>
#include <list>
using namespace std;


// define what is needed by ILP formulation
typedef struct
{
	vector<int> nonzeroPos;
	vector<double> coefficients;
	double rhsBound;
	bool fLB;
} GENERIC_ILP_CONSTRAINT;


// This class is used as solution
class ILPSolution
{
public:
        ILPSolution( int cc1, int cc2   ) : nr(0), nc(0),  lb(-1), ub(-1), optRes(0)
        {
                c1 = cc1;
                c2 = cc2;
                pSolution = NULL;
                mapSolIndToCol = NULL;
                optObjective = -1.0;    // default
        }
        ~ILPSolution()
        {
                delete [] pSolution;
        }
        void Init( int r, int c, vector<int> *pMapSolIndToCol)
        {
                nr = r;
                nc = c;
                pSolution = new double [ nc  ];
                mapSolIndToCol = pMapSolIndToCol;
        }
        int ComputeBounds();
        void Dump();
	bool operator==(const ILPSolution &rhs);
public:
        double *pSolution;
        double optObjective;
        int nr;
        int nc;
        int lb;
        int ub;
        int optRes;
        vector<int> *mapSolIndToCol;
        int c1;
        int c2;
};



// This header defines the interface/implement classes for using ILP solver
// The purpose is to support multiple ILP Solver, e.g. CPLEX, GNU gplk, etc

typedef enum 
{
    HAP_ILP_LB = 0,     // >=
    HAP_ILP_UB = 1      // <=
} HAP_ILP_SENSE;

//******************************************************************************
// Note, this class is not for general purpose. It is tailored to HapBound problem
// For example, it is assumed the goal is to maximize SUM(Var_i), etc
class ILPSolver
{
public:
    virtual ~ILPSolver() {}
	// The purpose of init is to setup ILP solver
	virtual void Init() = 0; 

	// To perform a ILP computation, one has to create an problem
	virtual void CreateProblem(int nr, int nc, bool fMinimize) = 0;
	virtual void DeleteProblem() = 0;

	// Tells how many variables in this problem. Note, must call CreateProblem first
	virtual void SetupVar(int colNum, const char* varName, double objCoeff, bool fBin ) = 0; 
	virtual void AddConstraint(int row, const vector<int> &nonzerosPos, const vector<double> &nonzeroCoeffs, 
        double rhsVal, HAP_ILP_SENSE sense ) = 0;
	virtual bool Solve( ILPSolution &solution) =0;

	// solve the linear programming releaxation
	virtual void SetLPRelax() = 0;
};



#ifdef LPSOLVER_CPLEX

//******************************************************************************
// Implementation class for CPLEX ILPSolver
class CPlexILPSolver : public ILPSolver
{
public:
	CPlexILPSolver();
	virtual ~CPlexILPSolver();

	virtual void Init() ; 
	virtual void CreateProblem(int nr, int nc, bool fMinimize);
	virtual void DeleteProblem();
	virtual void SetupVar(int colNum, const char* varName, double objCoeff , bool fBin); 
	virtual void AddConstraint(int row, const vector<int> &nonzerosPos, const vector<double> &nonzeroCoeffs, 
        double rhsVal, HAP_ILP_SENSE sense  );
	virtual bool Solve( ILPSolution &solution);
	virtual void SetLPRelax() { fRelax = true; }
	

private:
	// Private member function


	// Private data members
        // CPLEX private data
       	CPXENVptr env;	// storing CPLEX environment pointer
	CPXLPptr lp; 	// store problem pointer
	int nRows;		// number of rows for this matrix
	int nCols;		// nunber of cols in this matrix
	char **colNames; 	// names for column vars
	double *colCoeffs;
        char *cTypes;
	int matIndice;		// current num of indices set
	int *matBegins;		// beginging indices for matrix
	int *matInds;		// indices for matrix
    double *matVals;    // value for each cell
    char *sense;
    double *matRHS;
	bool fRelax;
};

#endif

#ifdef LPSOLVER_GLPK
//******************************************************************************
// Implementation class for GNU GLPK ILPSolver
class GLPKILPSolver : public ILPSolver
{
public:
	GLPKILPSolver();
	virtual ~GLPKILPSolver();

	virtual void Init(); 
	virtual void CreateProblem(int nr, int nc, bool fMinimize);
	virtual void DeleteProblem();
	virtual void SetupVar(int colNum, const char* varName, double objCoeff, bool fBin ); 
	virtual void AddConstraint(int row, const vector<int> &nonzerosPos, const vector<double> &nonzeroCoeffs, 
        double rhsVal, HAP_ILP_SENSE sense  );
	virtual bool Solve( ILPSolution &solution);
	virtual void SetLPRelax() { fRelax = true; }
	

private:
	// Private member function


	// Private data members
	LPX *lp;
	int matIndice;		// how many non-zeros are there
	int *rn;			// row number indices
	int *cn;			// column number indices. Note, we do not need value since value are all 1.0
    double *pVals;      // for now, let us allocate a rather large matrix, enough to hold every possible cells
	int nCols;
	int nRows;
    bool fMinimize;
	bool fRelax;
};
#endif

#endif  // ILP_SOLVER_H
