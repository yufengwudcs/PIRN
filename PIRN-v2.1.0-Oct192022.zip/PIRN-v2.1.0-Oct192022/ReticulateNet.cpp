#include "Utils.h"
#include "Utils2.h"
#include "Utils3.h"
#include "ReticulateNet.h"
#include "UnWeightedGraph.h"
#include "MarginalTree.h"
#include <stack>

// CAUTION: here is how a network is created typically:
// * Create a root id
// * add each edge (tree or network)
// * finish by setting the leaf ids (important: must set leaf ids, otherwise it will not work)


ReticulateNetworkImp :: ReticulateNetworkImp() : nidNext(1), reticulateIdNext(1), numTaxaUser(0), pMapperTMapInfo(NULL)
{
}

void ReticulateNetworkImp :: Init()
{
	// clear out everything
	nidNext = 1;
	reticulateIdNext = 0;
	mapTreeEdges.clear();	// first: descendent, second: parent
	mapReticulateEdges.clear();	// first: descendent, second: parent left and right
	mapRNIdToLeafId.clear();
	mapLeafIdToRNId.clear();
	mapRNIdToReticulateId.clear();
	mapReticulateIdToRNId.clear();

}

void ReticulateNetworkImp :: InitWithMTree( MarginalTree &mTree  )
{
	// initialize with a marginal tree
	Init();
	int rootPos = mTree.GetTotNodesNum()-1;
	stack< pair<int,int> > stackNodes; 
	RN_NODE_ID nid = CreateNode();
	// YW: 01/30/12: use node id instad of par pos
	//pair<int,int> pp( mTree.GetLabel(rootPos), nid );
	pair<int,int> pp(rootPos, nid);
//cout << "mTree.GetLabel(rootPos) = " << mTree.GetLabel(rootPos) << endl;
	//mapIdUsedTo2ndTaxaId.insert( map<int,int> :: value_type(rootPos, mTree.GetLabel(rootPos)) );
	mapIdUsedTo2ndTaxaId.insert( map<RN_NODE_ID,int> :: value_type(nid, mTree.GetLabel(rootPos)) );
	stackNodes.push(pp);
	while( stackNodes.empty() == false )
	{
		pair<int,int> ppn = stackNodes.top();
		stackNodes.pop();
		if( mTree.IsLeaf(ppn.first)  == false )
		{
			// queue its descendent
			RN_NODE_ID lid = CreateNode();
			RN_NODE_ID rid = CreateNode();
			AddTreeEdge(ppn.second, lid);
			AddTreeEdge(ppn.second, rid);
			// YW: 01/30/12 changed
			//pair<int,int> pp1( mTree.GetLabel( mTree.GetLeftDescendant(ppn.first) ), lid); 
			//pair<int,int> pp2( mTree.GetLabel( mTree.GetRightDescendant(ppn.first) ), rid); 
			pair<int,int> pp1( mTree.GetLeftDescendant(ppn.first), lid); 
			pair<int,int> pp2( mTree.GetRightDescendant(ppn.first), rid); 
//cout << "ppn.first's left descendent nid = " << pp1.second << ", its label: " << mTree.GetLabel( pp1.first ) << endl;
//cout << "ppn.first's right descendent nid = " << pp2.second << ", its label: " << mTree.GetLabel( pp2.first ) << endl;
			mapIdUsedTo2ndTaxaId.insert( map<RN_NODE_ID,int> :: value_type(pp1.second, mTree.GetLabel(pp1.first)) );
			mapIdUsedTo2ndTaxaId.insert( map<RN_NODE_ID,int> :: value_type(pp2.second, mTree.GetLabel(pp2.first)) );
			//mapIdUsedTo2ndTaxaId.insert( map<int,int> :: value_type(pp1.first, mTree.GetLabel(pp1.first)) );
			//mapIdUsedTo2ndTaxaId.insert( map<int,int> :: value_type(pp2.first, mTree.GetLabel(pp2.first)) );
			stackNodes.push( pp1 );
			stackNodes.push( pp2 );
		}
		else
		{
			// now setup the leaf
			SetLeafId( ppn.second, ppn.first );
		}
	}
}

RN_NODE_ID ReticulateNetworkImp :: CreateNode() 
{
	// just generate a node
	return nidNext++;
}

void ReticulateNetworkImp :: AddTreeEdge( const RN_NODE_ID &idAncestor, const RN_NODE_ID &idDescendent ) 
{
	// 
	mapTreeEdges.insert( map<RN_NODE_ID, RN_NODE_ID> :: value_type( idDescendent, idAncestor) );

	// add nodes to list of nodes (do it anyway if the node is already in)
	setNetNodes.insert(idAncestor);
	setNetNodes.insert(idDescendent);
//cout << "Adding tree edge: ancestor = " << idAncestor << ", descendent = " <<  idDescendent << endl;
}

RN_RETICULATE_ID ReticulateNetworkImp :: AddReticulateEdges(const RN_NODE_ID &idAncLeft, 
	const RN_NODE_ID &idAncRight, const RN_NODE_ID &idDescendent) 
{
	pair<RN_NODE_ID,RN_NODE_ID> pp(idAncLeft, idAncRight);
	mapReticulateEdges.insert( map<RN_NODE_ID, pair<RN_NODE_ID,RN_NODE_ID>  > :: value_type( idDescendent, pp) );

	// add nodes to list of nodes (do it anyway if the node is already in)
	setNetNodes.insert(idAncLeft);
	setNetNodes.insert(idAncRight);
	setNetNodes.insert(idDescendent);

	mapRNIdToReticulateId.insert( map<RN_NODE_ID, RN_RETICULATE_ID> :: value_type(idDescendent, reticulateIdNext) );
	mapReticulateIdToRNId.insert( map<RN_RETICULATE_ID, RN_NODE_ID> :: value_type(reticulateIdNext, idDescendent) );
	RN_RETICULATE_ID res = reticulateIdNext;
	reticulateIdNext++;
//cout << "Adding RETICULATION edges: ancestorLeft = " << idAncLeft << ", idAncRight = " << idAncRight << ", descendent = " <<  idDescendent << endl;
	return res;
}

void ReticulateNetworkImp :: UpdateEdge( const RN_NODE_ID &idAncLeft, 
		const RN_NODE_ID &idAncRight, const RN_NODE_ID &idDescendent ) 
{
//cout << "UpdateEdge: left = " << idAncLeft << ", right = " <<  idAncRight << ", desc = " << idDescendent << endl;
	// remove old entry first if the descendent is not new
	if(mapTreeEdges.find(idDescendent) != mapTreeEdges.end() )
	{
		mapTreeEdges.erase( idDescendent );
	}
	if(mapReticulateEdges.find(idDescendent) != mapReticulateEdges.end()  )
	{
		if( idAncLeft < 0 || idAncRight < 0 )
		{
			// Not done yet, TBD
			YW_ASSERT_INFO(false, "Deleting a reticulate node is not implemented yet");
		}
		else
		{
			// do not remove: we only update the map directly
			//mapReticulateEdges.erase(idDescendent);
		}
	}
	YW_ASSERT_INFO( idAncLeft >= 0, "Must be non-negative" );
	if(idAncRight < 0)
	{
		AddTreeEdge(idAncLeft, idDescendent);
	}
	else
	{
		if(mapReticulateEdges.find(idDescendent) == mapReticulateEdges.end())
		{
			AddReticulateEdges(idAncLeft, idAncRight, idDescendent);
		}
		else
		{
			mapReticulateEdges[idDescendent].first = idAncLeft;
			mapReticulateEdges[idDescendent].second = idAncRight;
			// add nodes to list of nodes (do it anyway if the node is already in)
			setNetNodes.insert(idAncLeft);
			setNetNodes.insert(idAncRight);
			setNetNodes.insert(idDescendent);
		}
	}
}


void ReticulateNetworkImp :: SetLeafId(const RN_NODE_ID &nid, int leafId)
{
	mapRNIdToLeafId.insert( map<RN_NODE_ID, int> :: value_type(nid, leafId) ) ;
	mapLeafIdToRNId.insert( map<int, RN_NODE_ID> :: value_type(leafId, nid) ) ;
}


// querying
int ReticulateNetworkImp :: GetNumLeaves() const
{
	return mapLeafIdToRNId.size();
}

int ReticulateNetworkImp :: GetNumReticulateNodes() const
{
	return mapReticulateEdges.size();	// same as reticulate edge number
}

int ReticulateNetworkImp :: GetNumTreeEdges() const
{
	// exclude the root, which does not belong to either tree or Ret
	return mapTreeEdges.size();
}

//void ReticulateNetworkImp :: GetTreeEdge(int etid, RN_NODE_ID &idAnc, RN_NODE_ID &idDesc)  const
//{
//	//YW_ASSERT_INFO();
//}

int ReticulateNetworkImp :: GetNumReticulateEdges() const
{
	// exclude the root, which does not belong to either tree or Ret
	return mapReticulateEdges.size();
}

//void ReticulateNetworkImp :: GetReticulateEdge(int erid, RN_NODE_ID &idAncLeft, RN_NODE_ID &idAncRight, RN_NODE_ID &idDesc)  const
//{
//}

bool ReticulateNetworkImp :: IsTreeEdge(const RN_NODE_ID &idAnc, const RN_NODE_ID &idDesc)  
{
	//
	if(mapTreeEdges.find(idDesc) == mapTreeEdges.end() || mapTreeEdges[idDesc] != idAnc)
	{
		return false;
	}
	return true;
}

bool ReticulateNetworkImp :: IsReticulateEdge(const RN_NODE_ID &idAnc, const RN_NODE_ID &idDesc, bool &fLeft)  
{
	if( mapReticulateEdges.find(idDesc) == mapReticulateEdges.end() || ( mapReticulateEdges[idDesc].first != idAnc && 
		mapReticulateEdges[idDesc].second != idAnc  ) )
	{
		return false;
	}
	fLeft = true;
	if(mapReticulateEdges[idDesc].second == idAnc )
	{
		fLeft = false;
	}
	return true;
}

void ReticulateNetworkImp :: GetDirectParents(const RN_NODE_ID &idnode, vector<RN_NODE_ID> &listNodesPar)  
{
	listNodesPar.clear();
	// is this tree node? 
	if(mapTreeEdges.find(idnode) != mapTreeEdges.end())
	{
		// 
		listNodesPar.push_back( mapTreeEdges[idnode] );
	}
	else if(mapReticulateEdges.find(idnode) != mapReticulateEdges.end())
	{
//		YW_ASSERT_INFO(mapReticulateEdges.find(idnode) != mapReticulateEdges.end(), "Fail to find such a node");
		listNodesPar.push_back( mapReticulateEdges[idnode].first );
		listNodesPar.push_back( mapReticulateEdges[idnode].second );
	}
}

void ReticulateNetworkImp :: GetAllAncestors(const RN_NODE_ID &idnode, set<RN_NODE_ID> &listNodesAnces)  
{
	// get all direct or indirect ancestors. we do it in a recurence fashion (note because we assume it is DAG)
	// since it is recursive, we do not clear out sets
	// start out by first find immediate ancestors
	vector<RN_NODE_ID> vecImmPars;
	GetDirectParents(idnode, vecImmPars);
	// add to list and keep the new ones
	vector<RN_NODE_ID> vecNewPars;
	for( int i=0; i<(int)vecImmPars.size(); ++i )
	{
		if( listNodesAnces.find(vecImmPars[i]) == listNodesAnces.end() )
		{
			vecNewPars.push_back( vecImmPars[i] );
			// also add to results
			listNodesAnces.insert( vecImmPars[i] );
		}
	}
	// now recurse
	for(int i=0; i<(int)vecNewPars.size(); ++i)
	{
		GetAllAncestors( vecNewPars[i], listNodesAnces );
	}
}

RN_RETICULATE_ID ReticulateNetworkImp :: GetReticulateId(const RN_NODE_ID &idDesc)  	
{
	// return -1 if not a reticulate node
	if( mapRNIdToReticulateId.find(idDesc) == mapRNIdToReticulateId.end() )
	{
		return -1;
	}
	return mapRNIdToReticulateId[idDesc];
}

void ReticulateNetworkImp :: GetLeafNodes( vector<int> &listLeafIds ) 
{
	listLeafIds.clear();
	// collect all in the map
	for( 	map<int, RN_NODE_ID> :: iterator it = mapLeafIdToRNId.begin();
		it != mapLeafIdToRNId.end(); ++it )
	{
		listLeafIds.push_back( it->first );
	}
}

void ReticulateNetworkImp :: GetReticulateNodes(set<RN_NODE_ID> &setNodesParam)
{
	setNodesParam.clear();
	for( set<RN_NODE_ID> :: iterator it = setNetNodes.begin(); it != setNetNodes.end(); ++it )
	{
		if( IsNodeReticulate( *it ) == true )
		{
			setNodesParam.insert(*it);
		}
	}
}


RN_NODE_ID ReticulateNetworkImp :: GetNodeIdFromLeafId(int leafId) 
{
	//
//cout << "leaf id = " << leafId << endl;
	YW_ASSERT_INFO( mapLeafIdToRNId.find(leafId) != mapLeafIdToRNId.end(), "Fail to find this leaf" );
	return mapLeafIdToRNId[leafId];
}

RN_NODE_ID ReticulateNetworkImp :: GetRoot()
{
	// get the root id 
	// by finding the one appear in the edge list but not as descendent
	vector<int> rootCandidates;
	set<int> setAllNodes;
	GetAllNodes(setAllNodes);
	for(set<int> :: iterator it = setAllNodes.begin(); it != setAllNodes.end(); ++it )
	{
		// is this a destination of some edge (tree or network)?
		if( mapTreeEdges.find(*it) == mapTreeEdges.end() &&  mapReticulateEdges.find(*it) == mapReticulateEdges.end()  )
		{
			//
			rootCandidates.push_back(*it);
//cout << "Root candidate found: " << *it << endl;
		}
	}
	YW_ASSERT_INFO( rootCandidates.size() == 1, "Invalid network: either no root or too many possible roots" );
	return rootCandidates[0];
}

void ReticulateNetworkImp :: GetImmDescendents(const RN_NODE_ID &nodeid, vector<RN_NODE_ID> &listDescs)
{
	// search all edges to get immediate descendents
	listDescs.clear();
	for( map<RN_NODE_ID, RN_NODE_ID> :: iterator it = mapTreeEdges.begin(); it != mapTreeEdges.end(); ++it )
	{
		// 
		if( it->second == nodeid )
		{
			listDescs.push_back(it->first);
		}
	}
	for( map<RN_NODE_ID, pair<RN_NODE_ID,RN_NODE_ID> > :: iterator it = mapReticulateEdges.begin(); it != mapReticulateEdges.end(); ++it )
	{
		// 
		if( it->second.first == nodeid || it->second.second == nodeid )
		{
			listDescs.push_back(it->first);
		}
	}
}

bool ReticulateNetworkImp :: IsNodeLeaf(const RN_NODE_ID &nodeid)
{
	// 
	return mapRNIdToLeafId.find(nodeid) != mapRNIdToLeafId.end();
}

bool ReticulateNetworkImp :: IsNodeReticulate(const RN_NODE_ID &nodeid)
{
	// is this node a reticulate node?
	return mapReticulateEdges.find( nodeid ) != mapReticulateEdges.end();
}


int ReticulateNetworkImp :: GetLeafId(const RN_NODE_ID &nodeid)
{
	if( mapRNIdToLeafId.find(nodeid) == mapRNIdToLeafId.end() )
	{
		return -1;		// not a leaf
	}
	else
	{
		return mapRNIdToLeafId[nodeid];
	}
}

void ReticulateNetworkImp :: RetrieveATree(const vector<int> &choicesRNs, map<RN_NODE_ID,RN_NODE_ID >& mapEdges )
{
	// retrieve a tree from the network based on a particular choice of reticulat enodes
	// the tree is representd by a set of network edges
	mapEdges.clear();
//cout << "RetrieveATree: 1\n";
	// start from leaf. Need to ensure we avoid duplicates
	set<RN_NODE_ID> nodesDone;
	vector<int> listLeafIds;
	GetLeafNodes( listLeafIds );
	vector<RN_NODE_ID> listLeafNodes;
	for(int i=0; i<(int)listLeafIds.size(); ++i)
	{
		listLeafNodes.push_back( GetNodeIdFromLeafId(listLeafIds[i]) );
	}

//cout << "RetrieveATree: 2\n";
	// 
	for(int i=0; i<(int)listLeafNodes.size(); ++i)
	{
		RN_NODE_ID idnode = listLeafNodes[i];
//cout << "idnode = " << idnode << endl;
		// trace backwards till the end
		while( nodesDone.find( idnode ) == nodesDone.end() )
		{
			nodesDone.insert(idnode);
//cout << "nodesdone = ";
//DumpIntSet( nodesDone);
			vector<RN_NODE_ID> listNodesPar;
			GetDirectParents(idnode, listNodesPar);
			if( listNodesPar.size() == 0 )
			{
				// reach the root
				break;
			}
			else if(listNodesPar.size() == 1)
			{
				// tree edge, take it
				mapEdges.insert( map<RN_NODE_ID,RN_NODE_ID> :: value_type(idnode, listNodesPar[0]) );
				idnode = listNodesPar[0];
			}
			else
			{
				YW_ASSERT_INFO(listNodesPar.size() == 2, "Fail");
				// find out which ret-node it is (idnode must be a reticulate node)
				RN_RETICULATE_ID rid = GetReticulateId(idnode);
				YW_ASSERT_INFO(rid >=0 && rid < (int)choicesRNs.size(), "rid: out of range" );
				if( choicesRNs[rid] == 0 )
				{
					// take left
					mapEdges.insert( map<RN_NODE_ID,RN_NODE_ID> :: value_type(idnode, listNodesPar[0]) );
					idnode = listNodesPar[0];
				}
				else
				{
					// take right
					mapEdges.insert( map<RN_NODE_ID,RN_NODE_ID> :: value_type(idnode, listNodesPar[1]) );
					idnode = listNodesPar[1];
				}
			}
		}
	}
}

void ReticulateNetworkImp :: RetriveEmbeddedTree( map<RN_NODE_ID,RN_NODE_ID> &mapRNChoices, PhylogenyTreeBasic *treeEmbedded)
{
	// the map goes to the particular node
//cout << "In RetriveEmbeddedTree: \n";
//for( map<RN_NODE_ID,RN_NODE_ID> :: iterator it =  mapRNChoices.begin(); it != mapRNChoices.end(); ++it )
//{
//cout << "RN nodes chosen: " << it->first << ", will go to the parent node: " << it->second << endl;
//}
	int nodeIdUse = 1;
	// construct a tree based on the reticulate node choices; mapRNChoices are those RN whose LEFT branch is selected
	// perform a top-down approach
	RN_NODE_ID rnRoot = GetRoot();
	TreeNode *pnRoot = new TreeNode;
	pnRoot->SetID(nodeIdUse++);
	treeEmbedded->SetRoot( pnRoot );
	stack<pair<RN_NODE_ID, TreeNode *> > stackNodes;
	pair<RN_NODE_ID, TreeNode *> pp;
	pp.first = rnRoot;
	pp.second = pnRoot;
	stackNodes.push(pp);
	while( stackNodes.empty() == false )
	{
		pair<RN_NODE_ID, TreeNode *> cpp = stackNodes.top();
		stackNodes.pop();
		vector<RN_NODE_ID> listDescs;
		GetImmDescendents( cpp.first, listDescs);
//cout << "listDescs: ";
//DumpIntVec(listDescs);
		// if non-leaf, continue
		if( listDescs.size() > 0 )
		{
			// for each descendent node, if allowed, create a new record and save it
			for( int jj=0; jj<(int)listDescs.size(); ++jj )
			{
				// 
				if( IsNodeReticulate( listDescs[jj] ) == true )
				{
//cout << "Found one reticulate node:  " << listDescs[jj] << endl;
					//bool fRet = IsReticulateEdge(cpp.first, listDescs[jj], fLeftBranch);
					//YW_ASSERT_INFO( fRet == true, "This edge must be from reticulation" );
					//
					//bool fInMap = (mapRNChoices.find( cpp.first ) != mapRNChoices.end());
					//bool fLeftBranch = true;
					//YW_ASSERT_INFO( cpp.second->GetParent() != NULL, "Fail to find parent" );
					//YW_ASSERT_INFO( cpp.second->GetParent()->GetChildrenNum() 
					bool fBranchChosen = true;
					YW_ASSERT_INFO(mapRNChoices.find( listDescs[jj] ) != mapRNChoices.end(), "Fail to find reticulate node in map");
					if( mapRNChoices[ listDescs[jj] ] != cpp.first )
					{
						fBranchChosen = false;
					}
					//if( (fLeftBranch == true && fInMap == false ) || (fLeftBranch == false && fInMap == true )  )
					if( fBranchChosen == false)
					{
						continue;
					}
				}
				// now add it
				TreeNode *pnNew = new TreeNode;
				pnNew->SetID(nodeIdUse++);
				vector<int> vecValsEmpty;
				cpp.second->AddChild(pnNew, vecValsEmpty);
				// queue it
				pair<RN_NODE_ID, TreeNode *> ppNew;
				ppNew.first = listDescs[jj];
				ppNew.second = pnNew;
				stackNodes.push(ppNew);
			}
		}
		// for leaves, setup its label/values
		else
		{
			// 
			int lid = GetLeafId( cpp.first );
			char buf[100];
			sprintf( buf, "%d", lid );
			string sbuf = buf;
			cpp.second->AddNodeValue( lid );
			cpp.second->SetLabel( sbuf );
//cout << "Set leaf label to " << sbuf << " for node " << cpp.first << endl;
		}
	}
	// finally, make sure the tree has no redundent nodes
	treeEmbedded->CleanNonLabeledLeaves();

//cout << "Done with one tree\n";
}

void ReticulateNetworkImp :: RetriveAllEmbeddedTrees( vector<PhylogenyTreeBasic *> &listEmbeddedTrees )
{
	// retrive all embedded trees within the network
	listEmbeddedTrees.clear();
	// first get all reticulate nodes
	set< RN_NODE_ID > setRNNodes;
	GetReticulateNodes(setRNNodes);
//cout << "The number of reticulate nodes: " << setRNNodes.size() << endl;
//DumpIntSet(setRNNodes);
	vector<RN_NODE_ID> vecRNNodes;
	for( set< RN_NODE_ID > :: iterator it= setRNNodes.begin(); it != setRNNodes.end(); ++it)
	{
		vecRNNodes.push_back(*it);
	}

	// for each choices of RN, get a tree
	int numRNNodes = setRNNodes.size();

	for( int k=0; k<= numRNNodes; ++k )
	{
//cout << "k = " << k << ", numRNNodes = " << numRNNodes  << endl;
		vector<int> posvec;
		GetFirstCombo(k, numRNNodes, posvec);
		while(true)
		{
//cout << "posvec: ";
//DumpIntVec( posvec );
			// get mapped choices
			map<RN_NODE_ID,RN_NODE_ID> mapChoices;
			set<int> setSelectedRNs;
			for(int ii=0; ii<(int)posvec.size(); ++ii)
			{
				YW_ASSERT_INFO( posvec[ii] < (int)vecRNNodes.size(), "Wrong111" );
				setSelectedRNs.insert( vecRNNodes[ posvec[ii] ] );
			}
			for(set<RN_NODE_ID> :: iterator ittg = setRNNodes.begin(); ittg != setRNNodes.end(); ++ittg)
			{
				bool fSelected = setSelectedRNs.find( *ittg ) != setSelectedRNs.end();
				YW_ASSERT_INFO( mapReticulateEdges.find( *ittg) != mapReticulateEdges.end(), "Not a reticulate node" );
				RN_NODE_ID nidChosen;
				if( fSelected == true)
				{
					nidChosen = mapReticulateEdges[*ittg].first;
				}
				else
				{
					nidChosen = mapReticulateEdges[*ittg].second;
				}
				mapChoices.insert( map<RN_NODE_ID,RN_NODE_ID> :: value_type( *ittg , nidChosen) );
			}

			PhylogenyTreeBasic *trCurr = new PhylogenyTreeBasic;
			//
			RetriveEmbeddedTree( mapChoices, trCurr );
//string strTemp;
//trCurr->ConsNewick(strTemp);
//cout << "Just found one tree: " << strTemp << endl;

			//
			listEmbeddedTrees.push_back( trCurr );
//cout << "Here\n";
			//
			if( GetNextCombo(k, numRNNodes, posvec) == false)
			{
//cout <<"this k is finished\n";
				break;
			}
		}
	}
//cout << "Done with RetriveAllEmbeddedTrees" << endl;
}


void ReticulateNetworkImp :: OutputGML(const char *filename)
{
return OutputGMLOrigTaxa(filename);

	// 
	string name = filename;
//cout << "num edges = " << listEdges.size() << endl;

	// Now open file to write out
	ofstream outFile( name.c_str() );

	// First output some header info
	outFile << "graph [\n"; 
	outFile << "comment ";
	OutputQuotedString(outFile, "Reticulate Network: Automatically generated by Graphing tool");
	outFile << "\ndirected  1\n";
	outFile << "id  1\n";
	outFile << "label ";
	OutputQuotedString ( outFile, "Reticulate Network\n");

	// Now output all the vertices. Leaf label is appended in FRONT
	set<RN_NODE_ID> setNodes;
	GetAllNodes( setNodes);
	//int i;
	//int numVerts = setNodes.size(); 
	for( set<RN_NODE_ID> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
	{
		outFile << "node [\n";
		char buf[100];
		buf[0] = ' '; 
		sprintf(&buf[1], "%d", *it);
		int lid = GetLeafId( *it );
		string name;
		name += buf;
		if(lid >= 0)
		{
			char buf1[100];
			sprintf(buf1, " : [%d]", lid);
			name += buf1;
		}

		outFile << "id " <<  *it  << endl;
		outFile << "label ";
		OutputQuotedString (outFile,  name.c_str()  ); 
		outFile << endl;
		outFile << "defaultAtrribute   1\n";
		outFile << "]\n";
	}

	// Now output all the edges
	for( map<RN_NODE_ID, RN_NODE_ID> :: iterator it = mapTreeEdges.begin(); it != mapTreeEdges.end(); ++it)
	{
		outFile << "edge [\n";
		outFile << "source " << it->second << endl; 
		outFile << "target  " << it->first << endl; 
		outFile << "label " ;
		OutputQuotedString( outFile,  ""  );
		outFile << "\n";
		outFile << "]\n";
	}

	for( map<RN_NODE_ID, pair<RN_NODE_ID,RN_NODE_ID> > :: iterator it = mapReticulateEdges.begin(); it != mapReticulateEdges.end(); ++it)
	{
		outFile << "edge [\n";
		outFile << "source " << it->second.first << endl; 
		outFile << "target  " << it->first << endl; 
		outFile << "label " ;
		OutputQuotedString( outFile,  ""  );
		outFile << "\n";
		outFile << "]\n";

		outFile << "edge [\n";
		outFile << "source " << it->second.second << endl; 
		outFile << "target  " << it->first << endl; 
		outFile << "label " ;
		OutputQuotedString( outFile,  ""  );
		outFile << "\n";
		outFile << "]\n";
	}

	// Finally quite after closing file
	outFile << "\n]\n";
	outFile.close();
}

// more about outputting format
void ReticulateNetworkImp :: OutputGMLOrigTaxa(const char *filename)
{
	// 
	YW_ASSERT_INFO(pMapperTMapInfo != NULL, "pMapperTMapInfo should not be NULL");
	YW_ASSERT_INFO(numTaxaUser > 0, "Number of taxa does not make sense");
	// first figure out additional network structure to output for early coalescents
	// first collect current list of node id
	// Now output all the vertices. Leaf label is appended in FRONT
	set<RN_NODE_ID> setNodes;
	GetAllNodes( setNodes);
//cout << "OutputGMLOrigTaxa: setNodes: ";
//DumpIntSet( setNodes );
	map<int, RN_NODE_ID> setNodesTaxa;
	for( set<RN_NODE_ID> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
	{
		if( mapIdUsedTo2ndTaxaId.find( *it) != mapIdUsedTo2ndTaxaId.end() )
		{
//cout << "OutputGMLOrigTaxa: taxa id to add: nodeid " << *it << ", taxa id = " << mapIdUsedTo2ndTaxaId[*it] << endl;
			setNodesTaxa.insert( map<int,RN_NODE_ID> :: value_type(mapIdUsedTo2ndTaxaId[*it], *it )  );
		}
	}

	// 
	map<int, RN_NODE_ID> listRNodesNew;
	vector< pair<RN_NODE_ID,RN_NODE_ID> > listEdgesNew;
	if( listRemovedPairs.size() > 0 )
	{
		YW_ASSERT_INFO( listRemovedPairs.size() == listSurvivePos.size(), "two list mismatch" );
//cout << "listRemovedPairs size: " << listRemovedPairs.size() << endl;
		// 
		RN_NODE_ID idRNNext = *(setNodes.rbegin())+1;
		int taxonIdNext = numTaxaUser+1;
//cout << "idRNNext = " << idRNNext << ", taxonIdNext = " << taxonIdNext << endl;
		vector<int> listTaxaCurr;
		set<int> setTaxaCurr;
		PopulateSetWithInterval(setTaxaCurr, 0, numTaxaUser-1);
		PopulateVecBySet(listTaxaCurr, setTaxaCurr);
		// add those early coalsced taxa
		for(int jj=0;jj<(int)listTaxaCurr.size()-1; ++jj)
		{
			// here add nodes only
			// add the two coalescing nodes (which do not appear in the final tree)
			if( setNodesTaxa.find( listTaxaCurr[jj] ) != setNodesTaxa.end() )
			{
				// a surviving lineage, skip
				continue;
			}

			int taxaid1 = listTaxaCurr[jj];
			int rnid1 = idRNNext++;
//cout << "Find missing initial taxa: id = " << taxaid1 << ", rnid1 = " << rnid1 << endl;
			listRNodesNew.insert( map<int,RN_NODE_ID> :: value_type(taxaid1, rnid1) );
			setNodesTaxa.insert( map<int,RN_NODE_ID> :: value_type(taxaid1, rnid1 )  );
		}

		// process each eary coalescent
		for(int i=0; i<(int)listRemovedPairs.size(); ++i )
		{
//cout << "listRemPairs: " << listRemovedPairs[i].first << ", " << listRemovedPairs[i].second << ", listSurvivePos: " << listSurvivePos[i] << endl;
//cout << "listTaxaCurr: ";
//DumpIntVec( listTaxaCurr );
			// 
			vector<int> listTaxaNext;
			for( int jj=0; jj<(int)listTaxaCurr.size(); ++jj )
			{
				if( jj != listRemovedPairs[i].first && jj != listRemovedPairs[i].second )
				{
					listTaxaNext.push_back( listTaxaCurr[jj] );
				}
			}
			// add the two coalescing nodes (which do not appear in the final tree)
			YW_ASSERT_INFO(listRemovedPairs[i].first<(int)listTaxaCurr.size() && listRemovedPairs[i].second<(int)listTaxaCurr.size(),
				"Range overflow");
			int taxaid1 = listTaxaCurr[listRemovedPairs[i].first];
			//int rnid1 = idRNNext++;
			int taxaid2 = listTaxaCurr[listRemovedPairs[i].second];
			//int rnid2 = idRNNext++;
//cout << "1. coalescing id to find: " << taxaid1 << endl;
			YW_ASSERT_INFO(listRNodesNew.find(taxaid1) != listRNodesNew.end(), "Fail to find coalescing node");
			int rnid1 = listRNodesNew[taxaid1];
//cout << "2. coalescing id to find: " << taxaid2 << endl;
			YW_ASSERT_INFO(listRNodesNew.find(taxaid2) != listRNodesNew.end(), "Fail to find coalescing node");
			int rnid2 = listRNodesNew[taxaid2];

			// now the new coalesced node
			int taxaidCoal = taxonIdNext++;
			listTaxaNext.push_back(taxaidCoal);
			RN_NODE_ID rnidCoal;
			if( setNodesTaxa.find(taxaidCoal) == setNodesTaxa.end() )
			{
				// new node, so add one new
				rnidCoal = idRNNext++;
				listRNodesNew.insert( map<int, RN_NODE_ID> :: value_type(taxaidCoal, rnidCoal) );
				setNodesTaxa.insert( map<int,RN_NODE_ID> :: value_type(taxaidCoal, rnidCoal )  );
//cout << "Insert a new coalesced node: taxid = " << taxaidCoal << ", rnidCoal = " << rnidCoal << endl;
			}			
			else
			{
				// use the original
				rnidCoal = setNodesTaxa[taxaidCoal];
//cout << "Use the original coalesced node: taxid = " << taxaidCoal << ", rnidCoal = " << rnidCoal << endl;
			}

			// add the new edge
			pair<RN_NODE_ID, RN_NODE_ID> pp1(rnidCoal, rnid1);
			listEdgesNew.push_back(pp1);
			pair<RN_NODE_ID,RN_NODE_ID> pp2( rnidCoal, rnid2);
			listEdgesNew.push_back( pp2 );

			// now update the next one:
			listTaxaCurr = listTaxaNext;
		}
	}

	// now add the new nodes into setNodes
	for( map<int,RN_NODE_ID> :: iterator itt = listRNodesNew.begin(); itt != listRNodesNew.end(); ++itt)
	{
//cout << "Adding new node: taxa id = " << itt->first << ", node id = " << itt->second << endl;
		YW_ASSERT_INFO( setNodes.find( itt->second) == setNodes.end(), "Duplicate found in setNodes" );
		setNodes.insert(itt->second);
	}

	// 
	string name = filename;
//cout << "num edges = " << listEdges.size() << endl;

	// Now open file to write out
	ofstream outFile( name.c_str() );

	// First output some header info
	outFile << "graph [\n"; 
	outFile << "comment ";
	OutputQuotedString(outFile, "Reticulate Network: Automatically generated by Graphing tool");
	outFile << "\ndirected  1\n";
	outFile << "id  1\n";
	outFile << "label ";
	OutputQuotedString ( outFile, "Reticulate Network\n");

	//int i;
	//int numVerts = setNodes.size(); 
	for( set<RN_NODE_ID> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
	{
		outFile << "node [\n";
		char buf[100];
		buf[0] = ' '; 
		//sprintf(&buf[1], "%d", *it);
		RN_NODE_ID lid = *it;
		int taxaidNew = -1;
		//int lid = GetLeafId( *it );
		// if did not find it in the original list, is this some new ones?
		for( map<int,RN_NODE_ID> :: iterator itg = listRNodesNew.begin(); itg != listRNodesNew.end(); ++itg  )
		{
//cout << "Search for rnid: " << *it << ", listRNodesNew: taxa id: " << itg->first << ", rnid: " << itg->second << endl;
			if( itg->second == lid && itg->first < numTaxaUser )
			{
				taxaidNew = itg->first;
				break;
				//lid = itg->second;
				//lid = itg->first;
			}
		}

		string name;
		name += buf;
		bool fNameFound = false;
		if(lid >= 0)
		{
			// convert to 2ndtaxa id
//cout << "lid = " << lid << endl;
			if( mapIdUsedTo2ndTaxaId.find(lid) != mapIdUsedTo2ndTaxaId.end() )
			{
				//YW_ASSERT_INFO(mapIdUsedTo2ndTaxaId.find(lid) != mapIdUsedTo2ndTaxaId.end(), "Fail to find this converted index in mapIdUsedTo2ndTaxaId");
				int tid2nd = mapIdUsedTo2ndTaxaId[lid];
//cout << "tid2nd = " << tid2nd << endl;
				//char buf1[100];
				//sprintf(buf1, "%d", lid);
				//name += buf1;
				if( pMapperTMapInfo->IsIdIn(tid2nd) == true)
				{
					fNameFound = true;
					name = pMapperTMapInfo->GetString(tid2nd);
//cout << "leaf name: " << name << endl;
				}
				else
				{
					// this is the outgroup
				//	name = "Outgroup";
				}
			}
		}
		if( fNameFound == false && taxaidNew >= 0)
		{
//cout << "taxaidNew = " << taxaidNew << endl;
			//char buf1[100];
			//sprintf(buf1, "%d", lid);
			//name += buf1;
			if( pMapperTMapInfo->IsIdIn(taxaidNew) == true)
			{
				name = pMapperTMapInfo->GetString(taxaidNew);
//cout << "(early coalesced) leaf name: " << name << endl;
			}
		}

		outFile << "id " <<  *it  << endl;
		outFile << "label ";
		OutputQuotedString (outFile,  name.c_str()  ); 
		outFile << endl;
		outFile << "defaultAtrribute   1\n";
		outFile << "]\n";
	}

	// Now output all the edges
	for( map<RN_NODE_ID, RN_NODE_ID> :: iterator it = mapTreeEdges.begin(); it != mapTreeEdges.end(); ++it)
	{
		outFile << "edge [\n";
		outFile << "source " << it->second << endl; 
		outFile << "target  " << it->first << endl; 
		outFile << "label " ;
		OutputQuotedString( outFile,  ""  );
		outFile << "\n";
		outFile << "]\n";
	}

	for( map<RN_NODE_ID, pair<RN_NODE_ID,RN_NODE_ID> > :: iterator it = mapReticulateEdges.begin(); it != mapReticulateEdges.end(); ++it)
	{
		outFile << "edge [\n";
		outFile << "source " << it->second.first << endl; 
		outFile << "target  " << it->first << endl; 
		outFile << "label " ;
		OutputQuotedString( outFile,  ""  );
		outFile << "\n";
		outFile << "]\n";

		outFile << "edge [\n";
		outFile << "source " << it->second.second << endl; 
		outFile << "target  " << it->first << endl; 
		outFile << "label " ;
		OutputQuotedString( outFile,  ""  );
		outFile << "\n";
		outFile << "]\n";
	}
	// outout additional edges
	for( int jj=0; jj<(int)listEdgesNew.size(); ++jj  )
	{
		outFile << "edge [\n";
		outFile << "source " << listEdgesNew[jj].first << endl; 
		outFile << "target  " << listEdgesNew[jj].second << endl; 
		outFile << "label " ;
		OutputQuotedString( outFile,  ""  );
		outFile << "\n";
		outFile << "]\n";
	}

	// Finally quite after closing file
	outFile << "\n]\n";
	outFile.close();
}

void ReticulateNetworkImp :: SetOrigTreeInfo(int ntu, const vector< pair<int,int> > &lrp, const vector< int > &lsp, TaxaMapper *pmtm)
{
	// 
	numTaxaUser = ntu;
	listRemovedPairs = lrp;
	listSurvivePos = lsp;
	pMapperTMapInfo = pmtm;
}


RN_NODE_ID ReticulateNetworkImp :: GetLeafRoot( )
{
//#if 0
	RN_NODE_ID rootId = GetRoot();
	vector<RN_NODE_ID> vecRootDescs;
	GetImmDescendents( rootId, vecRootDescs);

	//YW_ASSERT_INFO( leafNode >= 0, "Fail" );
	RN_NODE_ID leafNode;
	if( IsNodeLeaf(vecRootDescs[0]) )
	{
		leafNode = vecRootDescs[0];
	}
	else
	{
		leafNode = vecRootDescs[1];
	}
	YW_ASSERT_INFO( IsNodeLeaf(leafNode) == true, "The network is not in right format: must have a leaf node attached to root" );
	return leafNode;
//#endif

	// YW: important.....
	// assume leaf root id = NLvs -1
	//int lvid = GetNumLeaves()-1;

	//return GetNodeIdFromLeafId(lvid);
}

RN_NODE_ID ReticulateNetworkImp :: GetLeafRootSib()
{
	RN_NODE_ID rootId = GetRoot();
	vector<RN_NODE_ID> vecRootDescs;
	GetImmDescendents( rootId, vecRootDescs);

	//YW_ASSERT_INFO( leafNode >= 0, "Fail" );
	RN_NODE_ID nonLeafNode;
	if( IsNodeLeaf(vecRootDescs[0]) )
	{
		nonLeafNode = vecRootDescs[1];
	}
	else
	{
		nonLeafNode = vecRootDescs[0];
	}
	return nonLeafNode;
}


bool ReticulateNetworkImp :: IsAcyclic() 
{
	// check whether a network is acyclic or not (that is, allow any choice of edges)
	// we just create a graph and call the proper method there to check
	DirectedGraph dg;
	set<RN_NODE_ID> setNodes;
	GetAllNodes( setNodes );
	map<int,int> mapRNtoNids;
	for( set<RN_NODE_ID> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
	{
		// 
		int id = dg.AddVertex( 0 );
		mapRNtoNids.insert( map<int,int> :: value_type(*it, id) );
	}
	// add edge
	for(map<RN_NODE_ID, RN_NODE_ID> :: iterator it = mapTreeEdges.begin(); it != mapTreeEdges.end(); ++it)
	{
		dg.AddEdge( mapRNtoNids[it->second], mapRNtoNids[it->first], 0 );
	}
	for( map<RN_NODE_ID, pair<RN_NODE_ID,RN_NODE_ID> > :: iterator it = mapReticulateEdges.begin(); it != mapReticulateEdges.end(); ++it )
	{
		dg.AddEdge( mapRNtoNids[it->second.first], mapRNtoNids[it->first], 0 );
		dg.AddEdge( mapRNtoNids[it->second.second], mapRNtoNids[it->first], 0 );
	}
//dg.OutputGML( "dg.gml" );
	return dg.IsAcyclic();
}


void ReticulateNetworkImp :: FindDisjointAncesTwinPaths( vector< pair<int,int> > &listEnclosedPaths, vector< pair<int,int> > &listEnclosingPaths )
{
	// find a pair of paths (of leaves) so that the two paths in network
	// is (1) disjoint, (2) one path is ancestral to the other (i.e. there is a way of extracting a tree from net
	// so that the tree has the two paths and one is enclosing the other)
	// 
	vector<int> listVertsOrder;
	FindAcyclicOrder( listVertsOrder );
//cout << "Acyclic order : ";
//DumpIntVec( listVertsOrder );

    // create a quick index 
	map<int,int> mapVertIndices;
	for( int i=0; i<(int)listVertsOrder.size(); ++i  )
	{
		mapVertIndices.insert( map<int,int> :: value_type(listVertsOrder[i], i) );
	}

	vector< set<RN_NODE_ID> > vecAncesNodes;
	for(int i=0; i<(int)listVertsOrder.size(); ++i  )
	{
		set<RN_NODE_ID> sids;
		GetAllAncestors(  listVertsOrder[i], sids  );
		vecAncesNodes.push_back( sids );
	}

	// now find the paths by DP
	map< pair< pair<int,int>, pair<int,int> >, bool > mapPairsGood;
	for(int m1 = 1; m1 <(int)listVertsOrder.size(); ++m1)
	{
		// m1: the largest value of x,y,z,w
		// which can be either y or w. Make it two loops
		for(int k=0; k<=1; ++k)
		{
			// loop the other form 
			for(int x=0; x<=m1; ++x)
			{
				for(int z=0; z<=m1; ++z)
				{
					for(int yw=0; yw<=m1; ++yw)
					{
						int y = -1, w = -1;
						if( k==0)
						{
							y=m1;
							w=yw;
						}
						else
						{
							w=m1;
							y=yw;
						}
						// make sure the order
						if( x > y || z > w)
						{
							continue;
						}
						// make sure inequality here
						// YW: to make it easier, we allow degenerate case where x=y=z=w is true
						if( x == z || x == w || y == z || y == w )
						{
							continue;
						}
//cout << "x: " << x << ", y: " << y << ", z: " << z << ", w: " << w << endl;

						// boundary conditions here
						pair<int,int> pp1(x,y), pp2(z,w);
						pair< pair<int,int>, pair<int,int> >  pp(pp1,pp2);
						if( z == w )
						{
							if( x == y)
							{
								// is z ancestral to x?
								if(  x == z ||  vecAncesNodes[x].find( listVertsOrder[z] ) != vecAncesNodes[x].end() )
								{
									//  create an entry
									mapPairsGood.insert( map< pair< pair<int,int>, pair<int,int> >, bool > :: value_type(pp, true) ) ;
//cout << "0: Adding x: " << x << ", y: " << y << ", z: " << z << ", w: " << w << endl;
								}

								continue;
							}

							// if w is larger, then we are done because z,w colapse earlier
							if( k != 0 )
							{
								continue;
							}
						}
						//if( x == y && x > z && x > w && z != w)
						//{
						//	if(  IsSibling( listVertsOrder[x], listVertsOrder[z] ) == true || 
						//		IsSibling( listVertsOrder[x], listVertsOrder[w] ) == true  ||
						//		IsImmParent(listVertsOrder[x], listVertsOrder[z]) == true ||
						//		IsImmParent(listVertsOrder[x], listVertsOrder[w]) == true )
						//	{
						//		mapPairsGood.insert( map< pair< pair<int,int>, pair<int,int> >, bool > :: value_type(pp, true) ) ;
//cout << "1: Adding x: " << x << ", y: " << y << ", z: " << z << ", w: " << w << endl;
						//	}
						//}

						// from now on, z < w
						// get the largest one (m1 here) to move backwards
						vector<RN_NODE_ID> parlist;
						GetDirectParents( listVertsOrder[m1], parlist );
						YW_ASSERT_INFO( parlist.size() > 0, "parlist size can not be zero" );
						for(  int jj=0; jj<(int)parlist.size(); ++jj )
						{
							pair<int,int> ppup1, ppup2;
							if(k == 0)
							{
								if( x < y )
								{
									// x and y are not the same, so move y up
									ppup1.first = x;
									YW_ASSERT_INFO( mapVertIndices.find( parlist[jj] ) != mapVertIndices.end(), "Map: no entry" );
									ppup1.second = mapVertIndices[ parlist[jj] ];
									OrderInt( ppup1.first, ppup1.second );
								}
								else
								{
									// when x and y are same, move them together
									YW_ASSERT_INFO( x == y, "Must be thes same" );
									YW_ASSERT_INFO( mapVertIndices.find( parlist[jj] ) != mapVertIndices.end(), "Map: no entry" );
									ppup1.first = mapVertIndices[ parlist[jj] ];
									ppup1.second = mapVertIndices[ parlist[jj] ];
								}
								ppup2.first = z;
								ppup2.second = w;
							}
							else
							{
								ppup1.first = x;
								ppup1.second = y;

								YW_ASSERT_INFO( mapVertIndices.find( parlist[jj] ) != mapVertIndices.end(), "Map: no entry" );
								if( z < w )
								{
									ppup2.first = z;
									ppup2.second = mapVertIndices[ parlist[jj] ];
									OrderInt( ppup2.first, ppup2.second );									
								}
								else
								{
									YW_ASSERT_INFO( z == w, "Must be thes same" );
									ppup2.first = mapVertIndices[ parlist[jj] ];
									ppup2.second = mapVertIndices[ parlist[jj] ];
								}
							}
							pair< pair<int,int>, pair<int,int> >  ppup(ppup1,ppup2);
							// either the record is already known to be good OR
							// we reach the point where x=y=z (or w) or z=w=x (or y): this is a degenerate case
							if( ( mapPairsGood.find(ppup) != mapPairsGood.end()  && mapPairsGood[ppup] == true )
								|| ( ppup.first.first == ppup.first.second && 
										(ppup.first.first == ppup.second.first || ppup.first.first == ppup.second.second  ) ) 
								|| ( ppup.second.first == ppup.second.second && 
										(ppup.second.first == ppup.first.first || ppup.second.first == ppup.first.second  ) ) 
								)
							{
								// 
								mapPairsGood.insert( map< pair< pair<int,int>, pair<int,int> >, bool > :: value_type(pp, true) ) ;
//cout << "2: Adding x: " << x << ", y: " << y << ", z: " << z << ", w: " << w << endl;
							}
						}

					}
				}
			}
		}
	}
//cout << "Number of pairs in map: " << mapPairsGood.size() << endl;
//for( map< pair< pair<int,int>, pair<int,int> >, bool > :: iterator it = mapPairsGood.begin(); it != mapPairsGood.end(); ++it )
//{
//cout << "x: " << it->first.first.first << ", y: " << it->first.first.second << ", z: " << it->first.second.first << ", w: ";
//cout << it->first.second.second << endl;
//}
	// get the real path here
	for( map< pair< pair<int,int>, pair<int,int> >, bool > :: iterator it = mapPairsGood.begin(); it != mapPairsGood.end(); ++it  )
	{
		// need to be distinct
		if(  it->first.first.first ==  it->first.first.second
		|| it->first.first.first ==  it->first.second.first
		||  it->first.first.first ==  it->first.second.second  
		||  it->first.first.second ==  it->first.second.first 
		||  it->first.first.second ==  it->first.second.second 
		||  it->first.second.first ==  it->first.second.second 
		)
		{
			continue;
		}
		int xl = GetLeafId( listVertsOrder[it->first.first.first] );
		int yl = GetLeafId( listVertsOrder[it->first.first.second] );
		int zl = GetLeafId( listVertsOrder[it->first.second.first] );
		int wl = GetLeafId( listVertsOrder[it->first.second.second] );
		if( xl < 0 || yl < 0 || zl < 0 || wl < 0 )
		{
			// 
			continue;
		}
//cout << "Find non-intersecting, ancestral pairs (" << xl << ", " << yl << ")    (" << zl << ", " << wl << ")" << endl;
		pair<int,int> ppxy(xl, yl);
		pair<int,int> ppzw(zl, wl);
		listEnclosedPaths.push_back( ppxy );
		listEnclosingPaths.push_back( ppzw );
	}
}

void ReticulateNetworkImp :: FindAcyclicOrder( vector<int> &listNodesOrder )
{
	// for each node in network, an ancestral node is critical
	// if there is no other way to root unless passing this node
	// build a graph, and each time search for a sink
	DirectedGraph dg;
	set<RN_NODE_ID> setNodes;
	GetAllNodes( setNodes );
	map<int,int> mapRNtoNids;
	map<int,int> mapNidstoRN;
	set<int> nidsCurr;
	for( set<RN_NODE_ID> :: iterator it = setNodes.begin(); it != setNodes.end(); ++it )
	{
		// 
		int id = dg.AddVertex( 0 );
		mapRNtoNids.insert( map<int,int> :: value_type(*it, id) );
		mapNidstoRN.insert( map<int,int> :: value_type(id, *it) );
		nidsCurr.insert( id );
	}
	// add edge
	for(map<RN_NODE_ID, RN_NODE_ID> :: iterator it = mapTreeEdges.begin(); it != mapTreeEdges.end(); ++it)
	{
		dg.AddEdge( mapRNtoNids[it->second], mapRNtoNids[it->first], 0 );
	}
	for( map<RN_NODE_ID, pair<RN_NODE_ID,RN_NODE_ID> > :: iterator it = mapReticulateEdges.begin(); it != mapReticulateEdges.end(); ++it )
	{
		dg.AddEdge( mapRNtoNids[it->second.first], mapRNtoNids[it->first], 0 );
		dg.AddEdge( mapRNtoNids[it->second.second], mapRNtoNids[it->first], 0 );
	}
	YW_ASSERT_INFO( dg.IsAcyclic(), "Graph not acyclic" );

	// now find the sink iteratively
	listNodesOrder.clear();
	while(true)
	{
		//if( dg.GetNumVertices() == 1)
		if( nidsCurr.size() == 1)
		{
			// add it
			int nid = *nidsCurr.begin() ;
			listNodesOrder.push_back( mapNidstoRN[nid] );
			ReverseIntVec(listNodesOrder);
			break;
		}

		// find the sink
		int nidNext = -1;
		for(set<int> :: iterator it = nidsCurr.begin(); it != nidsCurr.end(); ++it)
		{
			if( dg.IsNodeSink( *it ) == true )
			{
				nidNext = *it;
				break;
			}
		}
		YW_ASSERT_INFO( nidNext >= 0, "Fail to find next sink" );
		listNodesOrder.push_back( mapNidstoRN[nidNext] );

		// remove it
		nidsCurr.erase( nidNext );
		dg.RemoveVertex( nidNext );
	}
}


bool ReticulateNetworkImp :: IsSibling(RN_NODE_ID nid1, RN_NODE_ID nid2) 
{
	// are node1 and node2 sibling (share a parent)
	vector<RN_NODE_ID> parlist1;
	GetDirectParents( nid1, parlist1 );
	vector<RN_NODE_ID> parlist2;
	GetDirectParents( nid2, parlist2 );
	set<int> parset1, parset2;
	PopulateSetByVec(parset1, parlist1);
	PopulateSetByVec(parset2, parlist2);
	set<int> sint;
	JoinSets( parset1, parset2, sint );
	return sint.size() > 0;
}

bool ReticulateNetworkImp :: IsImmParent(RN_NODE_ID nid1, RN_NODE_ID nidpar)
{
	vector<RN_NODE_ID> parlist1;
	GetDirectParents( nid1, parlist1 );
	set<int> parset1;
	PopulateSetByVec(parset1, parlist1);
	return parset1.find( nidpar ) != parset1.end();
}

void ReticulateNetworkImp :: ConvToMTree( map<RN_NODE_ID,RN_NODE_ID >& mapEdges, MarginalTree &mTree )
{
	set<RN_NODE_ID> setNodesInMapEdges;
	for( map<RN_NODE_ID,RN_NODE_ID > :: iterator it = mapEdges.begin(); it != mapEdges.end(); ++it )
	{
		setNodesInMapEdges.insert( it->first );
		setNodesInMapEdges.insert( it->second );
	}

	// first get a list of nodes s.t. if (a,b) in edge, then a appear early than b
	vector<RN_NODE_ID> listNodes;
	// ensure the leaf nodes are properly ordered
	for( int i=0; i<GetNumLeaves(); ++i )
	{
		YW_ASSERT_INFO( mapLeafIdToRNId.find(i) != mapLeafIdToRNId.end(), "Fatal error: can not find the leaf" );
		//pair<RN_NODE_ID, int> pp( i, mapLeafIdToRNId[i] );
		//mapRNToIndex.insert( map<RN_NODE_ID, int> :: value_type(  mapLeafIdToRNId[i] , i ) ) ;
		listNodes.push_back( mapLeafIdToRNId[i]  );		// init to -1
	}
	// perform an sort when adding the rest
	for( set<RN_NODE_ID> :: iterator it = setNodesInMapEdges.begin(); it != setNodesInMapEdges.end(); ++it )
	{
		if( IsNodeLeaf( *it) == true)
		{
			continue;
		}
//cout << "Adding node: " << *it << endl;

		// add it to the end first, and then sort
		int lastposgreater = -1;
		for( int j = (int)listNodes.size()-1; j>=0; --j  )
		{
			if( IsNodeUnder( mapEdges, *it, listNodes[j] ) == true )
			{
				//
				lastposgreater = j;
			}
		}
//cout << "lastposgreater = " << lastposgreater << endl;
		// move it
		listNodes.push_back(*it);
		if(lastposgreater >= 0)
		{
			for( int j=(int)listNodes.size()-2; j>= lastposgreater; --j )
			{
				listNodes[j+1] = listNodes[j];
			}
			listNodes[lastposgreater] = *it;
		}		
//cout << "listNodes: ";
//DumpIntVec( listNodes );
	}
//cout << "ConvToMTree: ";
//DumpIntVec( listNodes );
	map<RN_NODE_ID, int> mapRNToIndex;
	for( int i=0; i<(int)listNodes.size(); ++i )
	{
		//pair<RN_NODE_ID, int> pp( i, mapLeafIdToRNId[i] );
		mapRNToIndex.insert( map<RN_NODE_ID, int> :: value_type(  listNodes[i] , i ) ) ;
	}

	//
	mTree.Clear();

	// arbitarily setup
	vector<int> listLabels(listNodes.size() );
	vector<int> listParentNodePos(listNodes.size() );

	// setup arbitary labels
	//int numTotNodes = setNetNodes();
	for(int i=0; i<(int)listNodes.size(); ++i)
	{
		listLabels[i] = i;
	}

	// figure out parent position
	for( map<RN_NODE_ID,RN_NODE_ID > :: iterator it = mapEdges.begin(); it != mapEdges.end(); ++it )
	{
		YW_ASSERT_INFO( mapRNToIndex.find(it->first) != mapRNToIndex.end(), "FATAL error: node not found" );
		YW_ASSERT_INFO( mapRNToIndex.find(it->second) != mapRNToIndex.end(), "FATAL error: node not found" );
		listParentNodePos[  mapRNToIndex[it->first] ] = mapRNToIndex[it->second];
	}
	// fix the root
	listParentNodePos[ listParentNodePos.size()-1 ] = -1;


	//for( int i=0; i<GetNumLeaves(); ++i )
	//{
	//	// 
	//	RN_NODE_ID nid = mapLeafIdToRNId[i];
	//	int nindex = i;
	//	while(true)
	//	{
	//		if( mapEdges.find(nid) == mapEdges.end() )
	//		{
	//			// done with this up-path
	//			break;
	//		}
	//		// 
	//		RN_NODE_ID nidpar = mapEdges[nid];
	//		int parindex = -1;
	//		if( mapRNToIndex.find(nidpar) != mapRNToIndex.end() )
	//		{
	//			// reach an existing one, stop
	//		}
	//	}
	//}


	// init tree
//cout << "listLabels: ";
//DumpIntVec( listLabels );
//cout << "listParentNodePos: ";
//DumpIntVec( listParentNodePos );
	InitMarginalTree(mTree,  GetNumLeaves(), listLabels, listParentNodePos );
	// remove degree-one node and dangling leaves
	mTree.Consolidate();

	// finally build desc info
	mTree.BuildDescendantInfo();
}

bool ReticulateNetworkImp :: IsNodeUnder( map<RN_NODE_ID,RN_NODE_ID >& mapEdges, RN_NODE_ID nodeid, RN_NODE_ID nodepar )
{
	// test whether we can trace upwards n the tree edges to reach nodepar or not
	bool res = false;

	RN_NODE_ID nodecur = nodeid;
	while(true)
	{
		if( nodecur == nodepar)
		{
			res = true;
			break;
		}

		if( mapEdges.find( nodecur ) == mapEdges.end() )
		{
			break;
		}
		nodecur = mapEdges[nodecur];
	}

	return res;
}


