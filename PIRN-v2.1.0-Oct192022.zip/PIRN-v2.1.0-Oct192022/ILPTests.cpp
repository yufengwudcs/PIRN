#include "ILPTests.h"
#include "ReticulateNet.h"
#include <iostream>
#include "MarginalTree.h"


// Create a simple network
void CreateSimpleNet1(ReticulateNetwork &network )
{
	// 
	network.Init();

	const int NUM_LEAVES = 6;	// with the root node		

	// 
	//RN_NODE_ID rnidDesc, rnidPar1, rnidPar2;
	//RN_RETICULATE_ID rtid;
	//rnidPar1 = network.CreateNode();
	//rnidDesc = network.CreateNode();
	network.AddTreeEdge( 1, 2 );
	network.SetLeafId( 2, NUM_LEAVES-1 );					// this is to consistent with MarginalTree Imp, where the special leaf is -2
	//rnidDesc = network.CreateNode();
	network.AddTreeEdge( 1, 3 );
	// save it as new par
	network.AddTreeEdge( 3, 4 );
	network.AddTreeEdge( 3, 5 );
	network.AddTreeEdge( 4, 6 );
	network.AddTreeEdge( 4, 7 );
	network.AddTreeEdge( 5, 9 );
	network.SetLeafId( 9, 4 );
	network.AddReticulateEdges(7, 5, 8);
	network.AddReticulateEdges(6, 7, 10);
	network.AddTreeEdge( 8, 13 );
	network.AddTreeEdge( 10, 12 );
	network.AddTreeEdge( 6, 11 );
	network.SetLeafId( 11, 0 );
	network.AddTreeEdge( 12, 15 );
	network.SetLeafId( 15, 1 );
	network.AddTreeEdge( 13, 16 );
	network.SetLeafId( 16, 3 );

	network.AddReticulateEdges(12, 13, 14);
	network.SetLeafId( 14, 2 );

	YW_ASSERT_INFO( network.GetNumLeaves() == NUM_LEAVES, "Leaf number mismatch" );
}

void CreateRetNet2(ReticulateNetwork &network )
{
	// 
	network.Init();

//	const int NUM_LEAVES = 10;	// with the root node	
	network.AddTreeEdge( 1, 2 );
	network.AddTreeEdge( 1, 3 );
	network.AddTreeEdge( 3, 4 );
	network.AddTreeEdge( 3, 5 );
	network.AddTreeEdge( 5, 6 );
	network.AddTreeEdge( 5, 7 );
	network.AddTreeEdge( 4, 10 );
	network.AddTreeEdge( 10, 14 );
	network.AddTreeEdge( 13, 22 );
	network.AddTreeEdge( 7, 11 );
	network.AddTreeEdge( 11, 27 );
	network.AddTreeEdge( 27, 19 );
	network.AddTreeEdge( 9, 28 );
	network.AddTreeEdge( 17, 29 );
	network.AddTreeEdge( 27, 26 );
	network.AddTreeEdge( 19, 21 );
	network.AddReticulateEdges(4, 6, 8);	
	network.AddReticulateEdges(6, 7, 9);	
	network.AddReticulateEdges(8, 9, 12);	
	network.AddReticulateEdges(28, 11, 17);	
	network.AddReticulateEdges(10, 12, 13);	
	network.AddReticulateEdges(13, 29, 15);	
	network.AddReticulateEdges(12, 29, 16);	
	network.AddReticulateEdges(16, 18, 24);	
	network.AddReticulateEdges(28, 19, 20);	
	network.AddTreeEdge( 17, 18 );
	network.AddTreeEdge( 18, 25 );
	network.AddTreeEdge( 16, 23 );

	network.SetLeafId( 14, 0 );
	network.SetLeafId( 22, 1 );
	network.SetLeafId( 15, 2 );
	network.SetLeafId( 23, 3 );
	network.SetLeafId( 24, 4 );
	network.SetLeafId( 25, 5 );
	network.SetLeafId( 20, 6 );
	network.SetLeafId( 21, 7 );
	network.SetLeafId( 26, 8 );
	network.SetLeafId( 2, 9 );
}

void CreateRetNet3(ReticulateNetwork &network )
{
	// 
	network.Init();

//	const int NUM_LEAVES = 10;	// with the root node	
	network.AddTreeEdge( 1, 2 );
	network.AddTreeEdge( 1, 3 );
	network.AddTreeEdge( 3, 4 );
	network.AddTreeEdge( 3, 5 );
	network.AddTreeEdge( 5, 6 );
	network.AddTreeEdge( 5, 7 );
	network.AddTreeEdge( 4, 10 );
	network.AddTreeEdge( 10, 14 );
	network.AddTreeEdge( 13, 22 );
	network.AddTreeEdge( 7, 11 );
	network.AddTreeEdge( 11, 27 );
	network.AddTreeEdge( 27, 19 );
	network.AddTreeEdge( 9, 28 );
	network.AddTreeEdge( 17, 29 );
	network.AddTreeEdge( 27, 30 );
	network.AddTreeEdge( 19, 21 );
	network.AddTreeEdge( 12, 35 );
	network.AddTreeEdge( 12, 39 );

	network.AddReticulateEdges(4, 6, 8);	
	network.AddReticulateEdges(6, 7, 9);	
	network.AddReticulateEdges(8, 9, 12);	
	network.AddReticulateEdges(28, 11, 17);	
	network.AddReticulateEdges(10, 35, 13);	
	network.AddReticulateEdges(13, 29, 15);	
	network.AddReticulateEdges(39, 29, 16);	
	network.AddReticulateEdges(16, 18, 24);	
	network.AddReticulateEdges(28, 19, 20);	
	network.AddReticulateEdges(15, 35, 34);	
	network.AddReticulateEdges(34, 39, 41);	
	network.AddReticulateEdges(14, 22, 43);	
	network.AddReticulateEdges(23, 24, 37);	
	network.AddReticulateEdges(33, 32, 46);	
	network.AddReticulateEdges(20, 30, 31);	

	network.AddTreeEdge( 32, 47 );
	network.AddTreeEdge( 24, 36 );
	network.AddTreeEdge( 23, 38 );
	network.AddTreeEdge( 33, 45 );
	network.AddTreeEdge( 15, 33 );
	network.AddTreeEdge( 14, 42 );
	network.AddTreeEdge( 22, 44 );
	network.AddTreeEdge( 34, 40 );
	network.AddTreeEdge( 17, 18 );
	network.AddTreeEdge( 18, 25 );
	network.AddTreeEdge( 16, 23 );
	network.AddTreeEdge( 20, 32 );
	network.AddTreeEdge( 30, 26 );

	network.SetLeafId( 42, 0 );
	network.SetLeafId( 43, 1 );
	network.SetLeafId( 44, 2 );
	network.SetLeafId( 45, 3 );
	network.SetLeafId( 40, 4 );
	network.SetLeafId( 41, 5 );
	network.SetLeafId( 38, 6 );
	network.SetLeafId( 37, 7 );
	network.SetLeafId( 36, 8 );
	network.SetLeafId( 25, 9 );
	network.SetLeafId( 46, 10 );
	network.SetLeafId( 47, 11 );
	network.SetLeafId( 21, 12 );
	network.SetLeafId( 31, 13 );
	network.SetLeafId( 26, 14 );
	network.SetLeafId( 2, 15 );

}


void CreateRetNetBug1(ReticulateNetwork &network )
{
	// 
	network.Init();

	const int NUM_LEAVES = 11;	// with the root node		

	// 
	//RN_NODE_ID rnidDesc, rnidPar1, rnidPar2;
	//RN_RETICULATE_ID rtid;
	//rnidPar1 = network.CreateNode();
	//rnidDesc = network.CreateNode();
	network.AddTreeEdge( 1, 2 );
	network.SetLeafId( 2, NUM_LEAVES-1 );					// this is to consistent with MarginalTree Imp, where the special leaf is -2
	//rnidDesc = network.CreateNode();
	network.AddTreeEdge( 1, 3 );
	// save it as new par
	network.AddTreeEdge( 3, 4 );
	network.AddTreeEdge( 3, 5 );
	network.AddTreeEdge( 5, 6 );
	network.AddTreeEdge( 5, 7 );
	network.AddTreeEdge( 7, 9 );
	network.AddTreeEdge( 7, 22);
	network.AddTreeEdge( 22, 8 );
	network.AddTreeEdge( 9, 10 );
	network.AddTreeEdge( 9, 11 );
	network.AddTreeEdge( 10, 20 );
	network.AddTreeEdge( 10, 21 );
	network.AddTreeEdge( 11, 13 );
	network.AddTreeEdge( 13, 14 );
	network.AddTreeEdge( 13, 15 );
	network.AddTreeEdge( 15, 16 );
	network.AddTreeEdge( 15, 17 );
	network.AddTreeEdge( 12, 18 );
	network.AddTreeEdge( 12, 19 );
	network.AddReticulateEdges(11, 22, 12);

	network.SetLeafId( 4, 0 );
	network.SetLeafId( 6, 2 );
	network.SetLeafId( 20, 3 );
	network.SetLeafId( 21, 7 );
	network.SetLeafId( 8, 4 );
	network.SetLeafId( 14, 8 );
	network.SetLeafId( 16, 6 );
	network.SetLeafId( 17, 9 );
	network.SetLeafId( 19, 5 );
	network.SetLeafId( 18, 1 );

	YW_ASSERT_INFO( network.GetNumLeaves() == NUM_LEAVES, "Leaf number mismatch" );
}

void CreateRetNetBug2(ReticulateNetwork &network )
{
	// 
	network.Init();

	const int NUM_LEAVES = 11;	// with the root node		

	// 
	//RN_NODE_ID rnidDesc, rnidPar1, rnidPar2;
	//RN_RETICULATE_ID rtid;
	//rnidPar1 = network.CreateNode();
	//rnidDesc = network.CreateNode();
	network.AddTreeEdge( 1, 2 );
	network.AddTreeEdge( 1, 22 );
	network.AddReticulateEdges(22, 26, 3);
	network.AddTreeEdge( 3, 4 );
	network.AddTreeEdge( 3, 5 );
	network.AddTreeEdge( 5, 6 );
	network.AddReticulateEdges(5, 25, 7);
	network.AddTreeEdge( 7, 8 );
	network.AddTreeEdge( 7, 9);
	network.AddTreeEdge( 8, 19 );
	network.AddTreeEdge( 19, 21 );
	network.AddReticulateEdges(19, 25, 20);
	network.AddTreeEdge( 8, 26 );
	network.AddTreeEdge( 26, 18 );
	network.AddReticulateEdges(22, 9, 10);
	network.AddTreeEdge( 10, 15 );
	network.AddTreeEdge( 15, 17 );
	network.AddReticulateEdges(15, 24, 16);
	network.AddTreeEdge( 10, 24 );
	network.AddTreeEdge( 24, 23 );
	network.AddTreeEdge( 23, 14 );
	network.AddTreeEdge( 23, 25 );
	network.AddTreeEdge( 9, 11 );
	network.AddTreeEdge( 11, 12 );
	network.AddTreeEdge( 11, 13 );

	network.SetLeafId( 2, NUM_LEAVES-1 );					// this is to consistent with MarginalTree Imp, where the special leaf is -2
	network.SetLeafId( 4, 0 );
	network.SetLeafId( 6, 2 );
	network.SetLeafId( 21, 5 );
	network.SetLeafId( 18, 4 );
	network.SetLeafId( 12, 3 );
	network.SetLeafId( 13, 7 );
	network.SetLeafId( 17, 9 );
	network.SetLeafId( 16, 6 );
	network.SetLeafId( 14, 8 );
	network.SetLeafId( 20, 1 );

	YW_ASSERT_INFO( network.GetNumLeaves() == NUM_LEAVES, "Leaf number mismatch" );
}



void CreateATree(MarginalTree &tr)
{
	int numLvs = 6;
	vector<int> listLabels;
	listLabels.push_back(0);
	listLabels.push_back(1);
	listLabels.push_back(2);
	listLabels.push_back(3);
	listLabels.push_back(4);
	listLabels.push_back(-2);
	listLabels.push_back(5);
	listLabels.push_back(6);
	listLabels.push_back(7);
	listLabels.push_back(8);
	listLabels.push_back(-3);
	vector<int> listParentNodePos;
//#if 0
	listParentNodePos.push_back(7);
	listParentNodePos.push_back(6);
	listParentNodePos.push_back(6);
	listParentNodePos.push_back(9);
	listParentNodePos.push_back(7);
	listParentNodePos.push_back(10);
	listParentNodePos.push_back(8);
	listParentNodePos.push_back(8);
	listParentNodePos.push_back(9);
	listParentNodePos.push_back(10);
	listParentNodePos.push_back(-1);
//#endif
#if 0
	listParentNodePos.push_back(7);
	listParentNodePos.push_back(6);
	listParentNodePos.push_back(6);
	listParentNodePos.push_back(8);
	listParentNodePos.push_back(8);
	listParentNodePos.push_back(10);
	listParentNodePos.push_back(7);
	listParentNodePos.push_back(9);
	listParentNodePos.push_back(9);
	listParentNodePos.push_back(10);
	listParentNodePos.push_back(-1);
#endif
	InitMarginalTree(tr,  numLvs, listLabels, listParentNodePos );
//    GenRandBinaryTree(numLvs, tr);
//	AddRootAsLeafToTree(tr);
tr.OutputGML("trtmp.gml");
	tr.Dump();
}

void CreateATree2(MarginalTree &tr)
{
	// this tree takes 28 sec on GLPK (my laptop) and <3 sec on CPLEX, giving result of 4
	int numLvs = 10;
	vector<int> listLabels;
	listLabels.push_back(0);
	listLabels.push_back(1);
	listLabels.push_back(2);
	listLabels.push_back(3);
	listLabels.push_back(4);
	listLabels.push_back(5);
	listLabels.push_back(6);
	listLabels.push_back(7);
	listLabels.push_back(8);
	listLabels.push_back(-2);
	listLabels.push_back(9);
	listLabels.push_back(10);
	listLabels.push_back(11);
	listLabels.push_back(12);
	listLabels.push_back(13);
	listLabels.push_back(14);
	listLabels.push_back(15);
	listLabels.push_back(16);
	listLabels.push_back(-3);
	vector<int> listParentNodePos;
//#if 0
	listParentNodePos.push_back(10);
	listParentNodePos.push_back(11);
	listParentNodePos.push_back(17);
	listParentNodePos.push_back(12);
	listParentNodePos.push_back(14);
	listParentNodePos.push_back(13);
	listParentNodePos.push_back(11);
	listParentNodePos.push_back(10);
	listParentNodePos.push_back(12);
	listParentNodePos.push_back(18);
	listParentNodePos.push_back(15);
	listParentNodePos.push_back(13);
	listParentNodePos.push_back(14);
	listParentNodePos.push_back(16);
	listParentNodePos.push_back(15);
	listParentNodePos.push_back(16);
	listParentNodePos.push_back(17);
	listParentNodePos.push_back(18);
	listParentNodePos.push_back(-1);
//#endif

	InitMarginalTree(tr,  numLvs, listLabels, listParentNodePos );
//    GenRandBinaryTree(numLvs, tr);
//	AddRootAsLeafToTree(tr);
tr.OutputGML("trtmp.gml");
	tr.Dump();
}


void CreateATree3(MarginalTree &tr)
{
	// this tree takes 7864 seconds on CPLEX to solve, give answer 7
	int numLvs = 16;
	vector<int> listLabels;
	listLabels.push_back(0);
	listLabels.push_back(1);
	listLabels.push_back(2);
	listLabels.push_back(3);
	listLabels.push_back(4);
	listLabels.push_back(5);
	listLabels.push_back(6);
	listLabels.push_back(7);
	listLabels.push_back(8);
	listLabels.push_back(9);
	listLabels.push_back(10);
	listLabels.push_back(11);
	listLabels.push_back(12);
	listLabels.push_back(13);
	listLabels.push_back(14);
	listLabels.push_back(-2);
	listLabels.push_back(15);
	listLabels.push_back(16);
	listLabels.push_back(17);
	listLabels.push_back(18);
	listLabels.push_back(19);
	listLabels.push_back(20);
	listLabels.push_back(21);
	listLabels.push_back(22);
	listLabels.push_back(23);
	listLabels.push_back(24);
	listLabels.push_back(25);
	listLabels.push_back(26);
	listLabels.push_back(27);
	listLabels.push_back(28);
	listLabels.push_back(-3);
	vector<int> listParentNodePos;
//#if 0
	listParentNodePos.push_back(29);
	listParentNodePos.push_back(16);
	listParentNodePos.push_back(18);
	listParentNodePos.push_back(22);
	listParentNodePos.push_back(18);
	listParentNodePos.push_back(23);
	listParentNodePos.push_back(19);
	listParentNodePos.push_back(26);
	listParentNodePos.push_back(20);
	listParentNodePos.push_back(25);
	listParentNodePos.push_back(16);
	listParentNodePos.push_back(19);
	listParentNodePos.push_back(17);
	listParentNodePos.push_back(25);
	listParentNodePos.push_back(20);
	listParentNodePos.push_back(30);
	listParentNodePos.push_back(17);
	listParentNodePos.push_back(26);
	listParentNodePos.push_back(21);
	listParentNodePos.push_back(24);
	listParentNodePos.push_back(21);
	listParentNodePos.push_back(22);
	listParentNodePos.push_back(23);
	listParentNodePos.push_back(24);
	listParentNodePos.push_back(27);
	listParentNodePos.push_back(27);
	listParentNodePos.push_back(28);
	listParentNodePos.push_back(28);
	listParentNodePos.push_back(29);
	listParentNodePos.push_back(30);
	listParentNodePos.push_back(-1);
//#endif

	InitMarginalTree(tr,  numLvs, listLabels, listParentNodePos );
//    GenRandBinaryTree(numLvs, tr);
//	AddRootAsLeafToTree(tr);
tr.OutputGML("trtmp.gml");
	tr.Dump();
}

void CreateATreeBug1(MarginalTree &tr)
{
	// this tree takes 28 sec on GLPK (my laptop) and <3 sec on CPLEX, giving result of 4
	int numLvs = 11;
	vector<int> listLabels;
	listLabels.push_back(0);
	listLabels.push_back(1);
	listLabels.push_back(2);
	listLabels.push_back(3);
	listLabels.push_back(4);
	listLabels.push_back(5);
	listLabels.push_back(6);
	listLabels.push_back(7);
	listLabels.push_back(8);
	listLabels.push_back(9);
	listLabels.push_back(-2);
	listLabels.push_back(10);
	listLabels.push_back(11);
	listLabels.push_back(12);
	listLabels.push_back(13);
	listLabels.push_back(14);
	listLabels.push_back(15);
	listLabels.push_back(16);
	listLabels.push_back(17);
	listLabels.push_back(18);
	listLabels.push_back(-3);
	vector<int> listParentNodePos;
//#if 0
	listParentNodePos.push_back(11);
	listParentNodePos.push_back(16);
	listParentNodePos.push_back(11);
	listParentNodePos.push_back(14);
	listParentNodePos.push_back(12);
	listParentNodePos.push_back(13);
	listParentNodePos.push_back(18);
	listParentNodePos.push_back(14);
	listParentNodePos.push_back(17);
	listParentNodePos.push_back(19);
	listParentNodePos.push_back(20);
	listParentNodePos.push_back(12);
	listParentNodePos.push_back(13);
	listParentNodePos.push_back(15);
	listParentNodePos.push_back(15);
	listParentNodePos.push_back(16);
	listParentNodePos.push_back(17);
	listParentNodePos.push_back(18);
	listParentNodePos.push_back(19);
	listParentNodePos.push_back(20);
	listParentNodePos.push_back(-1);
//#endif

	InitMarginalTree(tr,  numLvs, listLabels, listParentNodePos );
//    GenRandBinaryTree(numLvs, tr);
//	AddRootAsLeafToTree(tr);
tr.OutputGML("trtmp.gml");
	tr.Dump();
}

void CreateATreeBug2(MarginalTree &tr)
{
	// this tree takes 28 sec on GLPK (my laptop) and <3 sec on CPLEX, giving result of 4
	int numLvs = 11;
	vector<int> listLabels;
	listLabels.push_back(0);
	listLabels.push_back(1);
	listLabels.push_back(2);
	listLabels.push_back(3);
	listLabels.push_back(4);
	listLabels.push_back(5);
	listLabels.push_back(6);
	listLabels.push_back(7);
	listLabels.push_back(8);
	listLabels.push_back(9);
	listLabels.push_back(-2);
	listLabels.push_back(10);
	listLabels.push_back(11);
	listLabels.push_back(12);
	listLabels.push_back(13);
	listLabels.push_back(14);
	listLabels.push_back(15);
	listLabels.push_back(16);
	listLabels.push_back(17);
	listLabels.push_back(18);
	listLabels.push_back(-3);
	vector<int> listParentNodePos;
//#if 0
	listParentNodePos.push_back(19);
	listParentNodePos.push_back(12);
	listParentNodePos.push_back(18);
	listParentNodePos.push_back(11);
	listParentNodePos.push_back(17);
	listParentNodePos.push_back(12);
	listParentNodePos.push_back(13);
	listParentNodePos.push_back(11);
	listParentNodePos.push_back(14);
	listParentNodePos.push_back(13);
	listParentNodePos.push_back(20);
	listParentNodePos.push_back(16);
	listParentNodePos.push_back(15);
	listParentNodePos.push_back(14);
	listParentNodePos.push_back(15);
	listParentNodePos.push_back(16);
	listParentNodePos.push_back(17);
	listParentNodePos.push_back(18);
	listParentNodePos.push_back(19);
	listParentNodePos.push_back(20);
	listParentNodePos.push_back(-1);
//#endif

	InitMarginalTree(tr,  numLvs, listLabels, listParentNodePos );
//    GenRandBinaryTree(numLvs, tr);
//	AddRootAsLeafToTree(tr);
tr.OutputGML("trtmp.gml");
	tr.Dump();
}



void CreateATreeRandom(MarginalTree &tr, int numLvs)
{
    GenRandBinaryTree(numLvs-1, tr);
	AddRootAsLeafToTree(tr);
	tr.Dump();
}

static void OutputCki( ofstream &outFile, int i )
{
	// the cut is make in T (the binary tree)
    outFile << "C," << i;  
} 
static void OutputAij( ofstream &outFile, int i, int j )
{
	// A,i,j = 1 if in T_N, node i is descendent of j
    outFile << "A," << i << "," << j;  
} 
static void OutputRi( ofstream &outFile, int i )
{
	// R,i = 1 if in T_N, reticulate node i is taken to be RIGHT
    outFile << "R," << i;  
} 

static bool IsNodeDescendentOf(const RN_NODE_ID &rnid, const RN_NODE_ID &rnidAnces, map<RN_NODE_ID, set<RN_NODE_ID> > &mapAncesNodesSet)
{
	YW_ASSERT_INFO(mapAncesNodesSet.find( rnid ) != mapAncesNodesSet.end(), "Fail to find such RNID");
	return mapAncesNodesSet[rnid].find(rnidAnces) != mapAncesNodesSet[rnid].end();
}

// create a ILP file for adding a simple tree
void OutputMinCostAddTree( char *fileName )
{
	// initialize network and a test tree
	ReticulateNetworkImp testNet;
	//CreateSimpleNet1( testNet );
	//CreateRetNet2( testNet );
	//CreateRetNet3( testNet );
	CreateRetNetBug1( testNet );
	//CreateRetNetBug2( testNet );
cout << "The number of Leaves in the net: " << testNet.GetNumLeaves() << endl;
cout << "The number of reticulate nodes in the net: " << testNet.GetNumReticulateNodes() << endl;
cout << "The number of tree edges in the net: " << testNet.GetNumTreeEdges() << endl;
cout << "The number of reticulate edges in the net: " << testNet.GetNumReticulateEdges() << endl;

	MarginalTree tr;
	//CreateATree(tr);
	//CreateATree2(tr);
	//CreateATree3(tr);
	CreateATreeBug1(tr);
	//CreateATreeBug2(tr);
	//const int NUM_LEAVES = 16;
	//CreateATreeRandom( tr, NUM_LEAVES);	

	// useful properties of network
	int numNodesInN = testNet.GetTotNumNodes();
	set<RN_NODE_ID> setNodes;
	testNet.GetAllNodes( setNodes );
	YW_ASSERT_INFO( (int)setNodes.size() == numNodesInN, "Mismatch in set size" );
	// convert to vector
	vector<RN_NODE_ID> vecNodes;
	PopulateVecBySet( vecNodes, setNodes );
	// collect possible ancestors
	vector< vector<RN_NODE_ID> > vecAncesNodes; 
	map<RN_NODE_ID, set<RN_NODE_ID> > mapAncesNodesSet; 
    for( int i= 0; i< (int)vecNodes.size() ; ++i  )
	{
		set<RN_NODE_ID> listNodesAnces;
		testNet.GetAllAncestors(vecNodes[i], listNodesAnces);
		vector<RN_NODE_ID> vecNodesAnces;
		PopulateVecBySet( vecNodesAnces, listNodesAnces );
cout << "For node " << vecNodes[i] << ", ancestor nodes = ";
DumpIntVec(vecNodesAnces);
		vecAncesNodes.push_back( vecNodesAnces );
		mapAncesNodesSet.insert( map<RN_NODE_ID, set<RN_NODE_ID> > :: value_type( vecNodes[i], listNodesAnces) );
	}
	int numReticulateNodes = testNet.GetNumReticulateNodes();
	vector<int> listLeafIds;
	testNet.GetLeafNodes( listLeafIds ) ;
cout << "List of leaf ids = ";
DumpIntVec(listLeafIds);

	// collect info from tree
	map< pair<int,int>, set<int> > mapPathNodesLeafPairs;
    for( int i= 0; i< tr.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tr.GetNumLeaves(); ++j)
        {
            // first we need to find MRCA of i,j. 
            // note that we actually want to exluce MRCA, but include i,j!
            set<int> listPathNodes;
            int n1=i, n2 = j;
            listPathNodes.insert(i);
            listPathNodes.insert(j);
            while( n1 != n2 )
            {
                // we alternatively move up, depend on which one is smaller
                int nodeNew;
                if( n1 < n2  )
                {
                    // move n1
                    n1 = tr.GetParent(n1);
                    nodeNew = n1;
                }
                else
                {
                    // move n2
                    n2 = tr.GetParent(n2);
                    nodeNew = n2;
                }
                // save this when n1 != n2
                if( n1 != n2 )
                {
                    listPathNodes.insert( nodeNew );
                }
            }
            // pop up the last item MRCA
            //listPathNodes.pop_back();
            listPathNodes.erase(  n1  );
            pair<int,int> pp(i,j);
			mapPathNodesLeafPairs.insert( map< pair<int,int>, set<int> > :: value_type(pp, listPathNodes)  );
cout << "For leaves " << i << ", " << j << ", list of path nodes = ";
DumpIntSet(listPathNodes);
        }
    }


	// now start ILP
    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tr.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, i);
        if( i < tr.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }

    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;

	// first some trivial facts
	// A,a,a = 1
    for( int i= 0; i< (int)vecNodes.size() ; ++i  )
    {
        OutputAij( outFile, vecNodes[i], vecNodes[i] );
        outFile << "=1" << endl;
    }
	// A,x,root = 1
	RN_NODE_ID rootId = testNet.GetRoot();
	cout << "Root of the network is: " << rootId << endl;
    for( int i= 0; i< (int)vecNodes.size() ; ++i  )
    {
        OutputAij( outFile, vecNodes[i], rootId );
        outFile << "=1" << endl;
    }
	// also, the one not in the root leaf is also root to all other nodes (except of course the leaf node)
	vector<RN_NODE_ID> vecRootDescs;
	testNet.GetImmDescendents(rootId, vecRootDescs);
	YW_ASSERT_INFO(vecRootDescs.size() == 2, "Network is either not binary or just contain a root");
	RN_NODE_ID leafRoot = vecRootDescs[0];
	RN_NODE_ID rootNodeReal = vecRootDescs[1];
	if(testNet.IsNodeLeaf(leafRoot) == false)
	{
		leafRoot = vecRootDescs[1];
		rootNodeReal = vecRootDescs[0];
		YW_ASSERT_INFO( testNet.IsNodeLeaf(leafRoot) == true, "Network in bad format: no root leaf." );
	}
    for( int i= 0; i< (int)vecNodes.size() ; ++i  )
    {
		if( vecNodes[i] != leafRoot && vecNodes[i] != rootId)
		{
			OutputAij( outFile, vecNodes[i], rootNodeReal );
			outFile << "=1" << endl;
		}
    }
#if 0
	// YW: 060609: handle involved situation of unconnected parts
    for( int i= 0; i< (int)vecNodes.size() ; ++i  )
    {
		// for any node v, if pv connect to it through reticulation
		// then, A,v,pv = 1 only if A,z,pv = 1 (where z is the other node)
		int v = vecNodes[i];
	}
#endif
	// ???
    for( int i= 0; i< (int)vecNodes.size() ; ++i  )
    {
		int v = vecNodes[i];
        for( int j= 0; j< (int)vecAncesNodes[i].size() ; ++j  )
        {
			int pv = vecAncesNodes[i][j];
			// is [v,pv] an tree edge?
			vector<RN_NODE_ID> listNodesParOfv;
			testNet.GetDirectParents(v, listNodesParOfv);

			// if this is a tree edge, then we are done
			if( listNodesParOfv.size() == 1 )
			{
				// A,v,pv = A,par(v),pv in this case
				OutputAij( outFile, v, pv );
				outFile << " - ";
				OutputAij( outFile, listNodesParOfv[0], pv );
				outFile << " = 0 " << endl;
 			}
			else
			{
				// this is a reticulate nodes, then it is the same as R,i
				int rid = testNet.GetReticulateId( v );
				YW_ASSERT_INFO( rid >= 0, "Fail to get reticulate id" );

				bool fLeftUnderpv =  (pv == listNodesParOfv[0]) || IsNodeDescendentOf(listNodesParOfv[0], pv, mapAncesNodesSet);
				bool fRightUnderpv = (pv == listNodesParOfv[1]) || IsNodeDescendentOf(listNodesParOfv[1], pv, mapAncesNodesSet);

				// if parleft can possibly be desc of pv, 
				if(fLeftUnderpv == true)
				{
					OutputAij( outFile, v, pv );
					outFile << " + ";
					OutputRi(outFile, rid );
					outFile << " - ";
					OutputAij( outFile, listNodesParOfv[0], pv );
					outFile << " >= 0 " << endl;
				}

				if( fRightUnderpv == true)
				{
					OutputAij( outFile, v, pv );
					outFile << " - ";
					OutputRi(outFile, rid );
					outFile << " - ";
					OutputAij( outFile, listNodesParOfv[1], pv );
					outFile << " >= -1 " << endl;
				}

				// then finally if neither works, we set to 0
				if( fLeftUnderpv == true)
				{
					// If R=0 (taking this branch), and its parent is 0, then it is zero
					OutputAij( outFile, v, pv );
					outFile << " - ";
					OutputRi(outFile, rid );
					outFile << " - ";
					OutputAij( outFile, listNodesParOfv[0], pv );
					outFile << " <= 0 " << endl;
				}
				else
				{
					OutputAij( outFile, v, pv );
					outFile << " - ";
					OutputRi(outFile, rid );
					outFile << " <= 0 " << endl;
				}

				if( fRightUnderpv == true)
				{
					OutputAij( outFile, v, pv );
					outFile << " + ";
					OutputRi(outFile, rid );
					outFile << " - ";
					OutputAij( outFile, listNodesParOfv[1], pv );
					outFile << " <= 1 " << endl;
				}
				else
				{
					OutputAij( outFile, v, pv );
					outFile << " + ";
					OutputRi(outFile, rid );
					outFile << " <= 1 " << endl;
				}

			}
       }
    }

//#if 0
	// now enforce triple condition
    // now try all possible triples of leaves i,j,k
	YW_ASSERT_INFO( tr.GetNumLeaves() == (int)listLeafIds.size(), "Size mismatch" );
    for( int i= 0; i< tr.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tr.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tr.GetNumLeaves(); ++k)
            {
				int la = listLeafIds[i], lb = listLeafIds[j], lc = listLeafIds[k];

				// skip the leaf root, because it will never involve in any incompaiblity
				//if( la == leafRoot || lb == leafRoot || lc == leafRoot)
				//{
				//	continue;
				//}

//cout << "la = " << la << ", lb = " << lb << ", lc = " << lc << endl;
//cout << "Triple (" << la << ", " << lb << ", " << lc << ")" << endl;

				// here is the set of path edges in T, which we want to cut
				pair<int,int> pp(i,j);
				set<int> tripleEdges = mapPathNodesLeafPairs[pp];
				pp.first = j;
				pp.second = k;
				UnionSets(tripleEdges, mapPathNodesLeafPairs[pp]);

                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int tripleijk = tr.GetTriple( la, lb, lc );

				// now try all possible ancestor of a1,b1,c1 and a2,b2,c2
				int a[2],b[2],c[2];
				if( tripleijk == 1 )
				{
					a[0]=lb;
					b[0]=lc;
					c[0]=la;
					a[1]=la;
					b[1]=lc;
					c[1]=lb;
				}
				else if(tripleijk == 2)
				{
					a[0]=la;
					b[0]=lb;
					c[0]=lc;
					a[1]=la;
					b[1]=lc;
					c[1]=lb;
				}
				else
				{
					a[0]=la;
					b[0]=lb;
					c[0]=lc;
					a[1]=lb;
					b[1]=lc;
					c[1]=la;
				}

				// if ((a1,b1),c1), enforce constraint
				for(int index=0; index<2; ++index)
				{
					// convert from leaf id to node id
					RN_NODE_ID node1, node2, node3;
					node1 = testNet.GetNodeIdFromLeafId( a[index] );
					node2 = testNet.GetNodeIdFromLeafId( b[index] );
					node3 = testNet.GetNodeIdFromLeafId( c[index] );
//cout << "node1 = " << node1 << ", node2 = " << node2 << ", node3 = " << node3 << endl;

					// get the possible x, which is intersection of par a1, b1 (but not c1)
					// y: join of all three
					set<int> tmpset1 = mapAncesNodesSet[node1];
					set<int> tmpset2 = mapAncesNodesSet[node2];
					set<int> choicesx;
					JoinSets(tmpset1, tmpset2, choicesx);

					// get rid of root and its immediate descendent
					//choicesx.erase( rootId );
					//choicesx.erase( rootNodeReal );


					// try them all
					vector<int> vecChoicex;
					PopulateVecBySet( vecChoicex, choicesx );

					for(int iii=0; iii<(int)vecChoicex.size(); ++iii)
					{
						if(IsNodeDescendentOf(node3, vecChoicex[iii], mapAncesNodesSet) == true)
						{
							OutputAij( outFile, node3, vecChoicex[iii] );
						}
						outFile << " - ";
					    OutputAij( outFile, node1, vecChoicex[iii] );							
						outFile << " - ";
					    OutputAij( outFile, node2, vecChoicex[iii] );

						// 
						//pair<int,int> pp( vecChoicex[iii], vecChoicey[jjj] );
						//OrderInt( pp.first, pp.second);
						for(set<int> :: iterator itttt= tripleEdges.begin(); itttt != tripleEdges.end(); ++itttt)
						{
							outFile << " + ";
							OutputCki(outFile, *itttt);
							outFile << endl;
						}
						outFile << " >= -1\n";
							
							
					}

				}
			}
		}
	}
//#endif

//#if 0
	// now the twin path constraints
    // if the two pairs are left in one tree
	int numTwinPathsProc = 0;
    for( int i= 0; i< tr.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tr.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tr.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tr.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tr.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
					numTwinPathsProc++;
//cout << "(" << i << "," << j << ") disjoins (" << p << "," << q << ")\n";

					// here is the set of path edges in T, which we want to cut
					pair<int,int> pp(i,j);
					set<int> twinEdges = mapPathNodesLeafPairs[pp];
					pp.first = p;
					pp.second = q;
					UnionSets(twinEdges, mapPathNodesLeafPairs[pp]);
//cout << "In T, twin path edges = ";
//DumpIntSet(twinEdges);
					// Check whether (a,b) and (c,d) intersect in T_N
					int la = listLeafIds[i], lb = listLeafIds[j], lc = listLeafIds[p], ld = listLeafIds[q];
//cout << "la = " << la << ", lb = " << lb << ", lc = " << lc  << ", ld = " << ld << endl;


					// Now we think of two pairs of leaves: (a,b) and (c,d)
					// suppose there are disjoint in T. Now consider T_N
					// we need to add edge cuts if in T_N, the two pairs
					// intersect
					// to make them intersect, we need to have a node x, st.
					// A,a,x=1, A,c,x=1, A,b,x=0, 
					// Note for un-ordered (a,b),(c,d), we need 
					// to have all possible ways covered:
					// A,b,x=1, A,c,x=1, A,a,x=1 and
					// A,a,x=1, A,d,x=1, A,b,x=0, 
					// A,b,x=1, A,d,x=1, A,a,x=0, 
					// For one of them (the first), we have:
					// SUM(C_i) + 1 + A,b,x >= A,a,x + A,c,x 

					int a[4],b[4],c[4],d[4];
					a[0]=la;
					b[0]=lb;
					c[0]=lc;
					d[0]=ld;

					a[1]=lb;
					b[1]=la;
					c[1]=lc;
					d[1]=ld;

					a[2]=la;
					b[2]=lb;
					c[2]=ld;
					d[2]=lc;

					a[3]=lb;
					b[3]=la;
					c[3]=ld;
					d[3]=lc;

					// find possible x
					for(int index=0; index<4; ++index)
					{
						// convert from leaf id to node id
						RN_NODE_ID node1, node2, node3, node4;
						node1 = testNet.GetNodeIdFromLeafId( a[index] );
						node2 = testNet.GetNodeIdFromLeafId( b[index] );
						node3 = testNet.GetNodeIdFromLeafId( c[index] );
						node4 = testNet.GetNodeIdFromLeafId( d[index] );
//cout << "node1 = " << node1 << ", node2 = " << node2 << ", node3 = " << node3  << ", node4 = " << node4  << endl;

						// get the possible x, which is intersection of par a1, b1 (but not c1)
						// y: join of all three
						set<int> tmpset1 = mapAncesNodesSet[node1];
						set<int> tmpset2 = mapAncesNodesSet[node3];
						set<int> choicesx;
						JoinSets(tmpset1, tmpset2, choicesx);
						// again, root can not be x: we assume x is lower one
						//choicesx.erase(rootId);

						// try them all
						vector<int> vecChoicex;
						PopulateVecBySet( vecChoicex, choicesx );
						for(int iii=0; iii<(int)vecChoicex.size(); ++iii)
						{
							if(IsNodeDescendentOf(node2, vecChoicex[iii], mapAncesNodesSet) == true)
							{
								OutputAij( outFile, node2, vecChoicex[iii] );
							}
							if(IsNodeDescendentOf(node4, vecChoicex[iii], mapAncesNodesSet) == true)
							{
								outFile << " + ";
								OutputAij( outFile, node4, vecChoicex[iii] );
							}
							outFile << " - ";
					        OutputAij( outFile, node1, vecChoicex[iii] );							
							outFile << " - ";
					        OutputAij( outFile, node3, vecChoicex[iii] );

							// 
							//pair<int,int> pp( vecChoicex[iii], vecChoicey[jjj] );
							//OrderInt( pp.first, pp.second);
							for(set<int> :: iterator itttt= twinEdges.begin(); itttt != twinEdges.end(); ++itttt)
							{
								outFile << " + ";
								OutputCki(outFile, *itttt);
								outFile << endl;
							}
							outFile << " >= -1\n";
							

						}
					}
				}
			}
		}
	}
//#endif
	cout << "Number of pair of disjoint paths = " << numTwinPathsProc << endl;

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// now (simplified) timing constraints
#if 0
	int numTwinPathsTCs = 0;
    for( int i= 0; i< tr.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tr.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tr.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tr.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tr.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
					// here is the set of path edges in T, which we want to cut
					pair<int,int> pp(i,j);
					set<int> twinEdges = mapPathNodesLeafPairs[pp];
					pp.first = p;
					pp.second = q;
					UnionSets(twinEdges, mapPathNodesLeafPairs[pp]);
//cout << "In timing constraints generation, twin path edges = ";
//DumpIntSet(twinEdges);


					int a[4], b[4], c[4], d[4];
					a[0] = i;
					b[0] = j;
					c[0] = p;
					d[0] = q;

					a[1] = j;
					b[1] = i;
					c[1] = p;
					d[1] = q;

					a[2] = p;
					b[2] = q;
					c[2] = i;
					d[2] = j;

					a[3] = q;
					b[3] = p;
					c[3] = i;
					d[3] = j;


					// check which pair is higher
					for(int k=0; k<4; ++k)
					{
//cout << "a[k] = " << a[k] << ", b[k] = " << b[k] << endl;
//cout << "c[k] = " << c[k] << ", d[k] = " << d[k] << endl;
						int mrcaab1 = tr.GetMRCA(a[k],b[k]);
						int mrcacd1 = tr.GetMRCA(c[k],d[k]);
//cout << "mrcaab = " << mrcaab1 << ", mrcacd1 = " << mrcacd1 << endl;
						if( tr.IsNodeUnder( mrcaab1, mrcacd1) == false)
						{
							continue;
						}

						// now consider T_N
						RN_NODE_ID node1, node2, node3, node4;
						node1 = testNet.GetNodeIdFromLeafId( a[k]  );
						node2 = testNet.GetNodeIdFromLeafId( b[k]  );
						node3 = testNet.GetNodeIdFromLeafId( c[k]  );
						node4 = testNet.GetNodeIdFromLeafId( d[k]  );
//cout << "node1 = " << node1 << ", node2 = " << node2 << ", node3 = " << node3  << ", node4 = " << node4  << endl;

						// get the possible x, which is intersection of par a1, b1 (but not c1)
						// y: join of all three
						set<int> tmpset1 = mapAncesNodesSet[node1];
						set<int> tmpset2 = mapAncesNodesSet[node3];
						set<int> tmpset3 = mapAncesNodesSet[node4];
						set<int> choicesx, tmpjoin;
						JoinSets(tmpset1, tmpset2, tmpjoin);
						JoinSets(tmpset3, tmpjoin, choicesx);

						// try them all
						vector<int> vecChoicex;
						PopulateVecBySet( vecChoicex, choicesx );
						for(int iii=0; iii<(int)vecChoicex.size(); ++iii)
						{
							if(IsNodeDescendentOf(node2, vecChoicex[iii], mapAncesNodesSet) == true)
							{
								OutputAij( outFile, node2, vecChoicex[iii] );
							}

							outFile << " - ";
					        OutputAij( outFile, node1, vecChoicex[iii] );							
							outFile << " - ";
					        OutputAij( outFile, node3, vecChoicex[iii] );
							outFile << " - ";
					        OutputAij( outFile, node4, vecChoicex[iii] );

							// 
							//pair<int,int> pp( vecChoicex[iii], vecChoicey[jjj] );
							//OrderInt( pp.first, pp.second);
							for(set<int> :: iterator itttt= twinEdges.begin(); itttt != twinEdges.end(); ++itttt)
							{
								outFile << " + ";
								OutputCki(outFile, *itttt);
								outFile << endl;
							}
							outFile << " >= -2\n";
							

						}

					}

					numTwinPathsTCs++;
				}
			}
		}
	}
	cout << "Number of pair of timing constraint pairs of pairs = " << numTwinPathsTCs << endl;
#endif

    for( int i= 0; i< tr.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tr.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tr.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tr.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tr.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
					// here is the set of path edges in T, which we want to cut
					pair<int,int> pp(i,j);
					set<int> twinEdges = mapPathNodesLeafPairs[pp];
					pp.first = p;
					pp.second = q;
					UnionSets(twinEdges, mapPathNodesLeafPairs[pp]);
//cout << "In timing constraints generation, twin path edges = ";
//DumpIntSet(twinEdges);

					// find whether (a,b) can be ancestral to (c,d) in N (or the other way around)
					int a[2], b[2], c[2], d[2];
					a[0] = i;
					b[0] = j;
					c[0] = p;
					d[0] = q;

					a[1] = p;
					b[1] = q;
					c[1] = i;
					d[1] = j;

					// check which pair is higher
					for(int k=0; k<2; ++k)
					{
//cout << "a[k] = " << a[k] << ", b[k] = " << b[k] << endl;
//cout << "c[k] = " << c[k] << ", d[k] = " << d[k] << endl;
						int mrcaab1 = tr.GetMRCA(a[k],b[k]);
						int mrcacd1 = tr.GetMRCA(c[k],d[k]);
//cout << "mrcaab = " << mrcaab1 << ", mrcacd1 = " << mrcacd1 << endl;
						if( tr.IsNodeUnder( mrcaab1, mrcacd1) == false)
						{
							continue;
						}

						// now consider T_N
						RN_NODE_ID node1, node2, node3, node4;
						node1 = testNet.GetNodeIdFromLeafId( a[k]  );
						node2 = testNet.GetNodeIdFromLeafId( b[k]  );
						node3 = testNet.GetNodeIdFromLeafId( c[k]  );
						node4 = testNet.GetNodeIdFromLeafId( d[k]  );
//cout << "node1 = " << node1 << ", node2 = " << node2 << ", node3 = " << node3  << ", node4 = " << node4  << endl;

						// get the possible x, which is intersection of par a1, b1 (but not c1)
						// y: join of all three
						set<int> tmpset1 = mapAncesNodesSet[node1];
						set<int> tmpset2 = mapAncesNodesSet[node2];
						set<int> tmpset3 = mapAncesNodesSet[node3];
						set<int> tmpset4 = mapAncesNodesSet[node4];
						set<int> choicesx, choicesy;
						JoinSets(tmpset1, tmpset2, choicesx);
						JoinSets(tmpset3, tmpset4, choicesy);
						//set<int> mrcacd;
						SubtractSets(choicesy, choicesx);

						// try them all
						if( choicesy.size() > 0 )
						{
							// 
							//pair<int,int> pp( vecChoicex[iii], vecChoicey[jjj] );
							//OrderInt( pp.first, pp.second);
							for(set<int> :: iterator itttt= twinEdges.begin(); itttt != twinEdges.end(); ++itttt)
							{
								outFile << " + ";
								OutputCki(outFile, *itttt);
								outFile << endl;
							}
							outFile << " >= 1\n";
							

						}

					}

					//numTwinPathsTCs++;
				}
			}
		}
	}

    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tr.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, i );
        outFile << endl;
    }
	// Ri
	for(int i=0; i<numReticulateNodes; ++i)
	{
		OutputRi(outFile, i);
		outFile << endl;
	}
    // Aij
    for( int i= 0; i< (int)vecNodes.size() ; ++i  )
    {
        OutputAij( outFile, vecNodes[i], vecNodes[i] );
        outFile << endl;
    }
    for( int i= 0; i< (int)vecNodes.size() ; ++i  )
    {
        for( int j= 0; j< (int)vecAncesNodes[i].size() ; ++j  )
        {

            OutputAij( outFile, vecNodes[i], vecAncesNodes[i][j] );
            outFile << endl;
        }
    }


    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();
cout << "Constrains finished\n";
}

