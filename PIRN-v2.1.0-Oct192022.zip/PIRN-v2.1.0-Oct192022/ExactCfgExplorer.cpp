#include "ExactCfgExplorer.h"
#include "GML2ExtNewick.h"

extern void OutputQuotedString(ofstream &outFile, const char *buf);

///////////////////////////////////////////////////////////////////////////////
//#define DUMP_CFG_DEBUG 1
//#define DUMP_CFG_DEBUG_MORE 1


int numCfgClassKeptChoices = HAP_MAX_INT;
int maxNumCfgsKept = HAP_MAX_INT;
bool fApproxMode = true;
bool fNearOptMode = true;
bool fGreedyCfg = true;

void SetCfgExplorerApproxMode(bool f)
{
	fApproxMode = f;
	// at the same time, set greedy flag as well
	//fGreedyCfg = f;
}

void SetNumCfgClassKept(int numClassKept)
{
	numCfgClassKeptChoices = numClassKept;

	// when number of classes set, set approx to be true
	//SetCfgExplorerApproxMode(true);
}

void SetMaxNumCfgsKept(int maxn)
{
	maxNumCfgsKept = maxn;

	// when number of classes set, set approx to be true
	//SetCfgExplorerApproxMode(true);
}



///////////////////////////////////////////////////////////////////////////////
// Event for reticulation (branching when looking backwards in time)

int CreateNextRetEvt( const CfgLineage & linToRet )
{
#if 0
	static int nextEvtId = 0;
	static map<CfgLineage,int> mapCreatedEvtIds;

	if(  mapCreatedEvtIds.find( linToRet) != mapCreatedEvtIds.end() )
	{
		return mapCreatedEvtIds[linToRet];
	}
	int res = ++nextEvtId;
	mapCreatedEvtIds.insert( map<CfgLineage,int> :: value_type(linToRet, res) );

	return res;
#endif
	return linToRet.GetLinId();
}

///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
// Lineage source of a lineage (i.e. which gene tree lineage it traces to)

void CfgLineageSrc :: AddEvt(int evtId)
{
#ifdef RET_EVT_IMP
	// add one new event to the event set
	idRetEvtSet = ReticulateSetLinSrcDepot::Instance().GetExpandedEvtSetId(idRetEvtSet, evtId);
#endif
//return;
#if 0
	CfgRetEvt evtNew = evtId;
	//evtNew.first = evtId ;
	//evtNew.second = fLeft;
	setRetEvtFlags.insert( evtNew );
	//setRetEvtIdsOnly.insert( evtId);
#endif
}

bool CfgLineageSrc :: CoalesceWith(const CfgLineageSrc &lsrcOther, CfgLineageSrc &srcNew) const
{
	//
	int idNodeNew1 = GeneTreeInfo:: Instance().GetParent( nodeInGeneTree ) ;
	int idNodeNew2 = GeneTreeInfo:: Instance().GetParent( lsrcOther.nodeInGeneTree ) ;
//cout << "In CfgLineageSrc :: CoalesceWith: idNew1 = " << idNodeNew1 << ", idNew2 = " << idNodeNew2 << endl;
	if( nodeInGeneTree != lsrcOther.nodeInGeneTree && idNodeNew1 == idNodeNew2 )
	{
		// make sure there is no conflict
		// which means there can be no common events
		//set<int> linsUnder, linsUnderOther;
		//CfgLineage::GetLineageDescendentOf(  );
//		set<int> evtCommon;
//		JoinSets( setRetEvtFlags, lsrcOther.setRetEvtFlags, evtCommon);
//		if( evtCommon.size() > 0)
		//{
		//	// can not coalesce
		//	return false;
		//}

#ifdef RET_EVT_IMP
		set<CfgRetEvt> setUnion;
		if( ReticulateSetLinSrcDepot::Instance().AreEvtSetsDisjoint( this->idRetEvtSet, lsrcOther.idRetEvtSet, &setUnion ) == false )
		{
			return false;
		}
#endif
		// compatible, so we just merge the two lists
		srcNew.nodeInGeneTree = idNodeNew1;
#ifdef RET_EVT_IMP
		srcNew.idRetEvtSet = ReticulateSetLinSrcDepot::Instance().RetrieveRetEvtSetId( setUnion );
#endif
		//srcNew.setRetEvtFlags = setRetEvtFlags;
		//UnionSets(srcNew.setRetEvtFlags, lsrcOther.setRetEvtFlags);
		//srcNew.setRetEvtFlags = setRetEvtFlags;
		//for( set<CfgRetEvt> :: iterator itt = lsrcOther.setRetEvtFlags.begin(); itt != lsrcOther.setRetEvtFlags.end(); ++itt )
		//{
		//	srcNew.setRetEvtFlags.insert(*itt);
		//}
		return true;
	}
	else
	{
//cout << "Can not coalesce2\n";
		return false;
	}
}

bool CfgLineageSrc:: IsNodeContained(int nodeId) const
{
	if( nodeInGeneTree == nodeId )
	{
		return true;
	}
	else
	{
		return false;
	}
}

void CfgLineageSrc :: Dump() const
{
	cout << "Lineage " << nodeInGeneTree;
#ifdef RET_EVT_IMP
	cout << ": <" << idRetEvtSet << ">:  ";
	set<CfgRetEvt >  setRetEvtFlags;
	ReticulateSetLinSrcDepot::Instance().GetProcessedEvtSet( idRetEvtSet, setRetEvtFlags );
//cout << "CfgLineageSrc :: Dump(): " << idRetEvtSet << ": ";
//DumpIntSet(setRetEvtFlags);
//#if 0
	for( set<CfgRetEvt > :: iterator it1 = setRetEvtFlags.begin(); it1 != setRetEvtFlags.end(); ++it1 )
	{
		cout << "[" << *it1;
		//if( it1->second == true)
		//{
		//	cout <<",0";
		//}
		//else
		//{
		//	cout << ",1";
		//}
		cout << "],";
	}
#endif
	cout << endl;
//#endif
}

bool CfgLineageSrc :: IsBeaten(const CfgLineageSrc &other) const
{
	if( nodeInGeneTree != other.nodeInGeneTree )
	{
		return false;
	}
#ifdef RET_EVT_IMP
	return ReticulateSetLinSrcDepot::Instance().IsEvtSetSubsetOf( idRetEvtSet, other.idRetEvtSet );
#else
	return true;
#endif
#if 0
	set<CfgRetEvt> evtDiff = setRetEvtFlags;
	SubtractSets(evtDiff, other.setRetEvtFlags);
	if( evtDiff.size() + other.setRetEvtFlags.size() == setRetEvtFlags.size() )
	{
		return true;
	}
	else
	{
		return false;
	}
#endif
}


///////////////////////////////////////////////////////////////////////////////
// Lineage in a configuration

int CfgLineage :: idNextToUse = 0;
map<pair<int,int>,int> CfgLineage :: mapPairsToIds;
map<int, pair<int,int> > CfgLineage :: mapIdsToPairs;
map<int,CfgLineage> CfgLineage::mapIdToLineages;


CfgLineage :: CfgLineage() : fReticulate(false), fEmptyPossible(false)
{
}

void CfgLineage :: AssignLineageId(CfgLineage &lin)
{
	lin.linId = ++idNextToUse;
}

void CfgLineage :: AddRetEvt(int evtId)
{
	// simply add this condition for each lineages
	// when reticulation evt is added, every mapped lineage becomes conditional
	set< CfgLineageSrc > listLinsSrcNew;
	for( set< CfgLineageSrc > :: iterator it= listLinsSrcCombined.begin(); it != listLinsSrcCombined.end(); ++it)
	{
		CfgLineageSrc linNew = *it;
		linNew.AddEvt( evtId );
		listLinsSrcNew.insert( linNew);
	}
	//for( set< CfgLineageSrc > :: iterator it= listLinsSrcAlways.begin(); it != listLinsSrcAlways.end(); ++it)
	//{
	//	CfgLineageSrc linNew = *it;
	//	linNew.AddEvt( evtId );
	//	listLinsSrcNew.insert( linNew);
	//}
	//for( set< CfgLineageSrc > :: iterator it= listLinsSrcCondition.begin(); it != listLinsSrcCondition.end(); ++it)
	//{
	//	CfgLineageSrc linNew = *it;
	//	linNew.AddEvt( evtId );
	//	listLinsSrcNew.insert( linNew);
	//}
	//listLinsSrcCondition = listLinsSrcNew;
	//listLinsSrcAlways.clear();

	listLinsSrcCombined = listLinsSrcNew;

	fReticulate = true;
	this->fEmptyPossible = true;

//	CfgRetEvt evtNew( evtId );
//	pair<CfgRetEvt,bool> pp(evtNew, fLeft);
//	setRetEvtFlags.insert( pp );
}

bool CfgLineage :: CoalesceWith(const CfgLineage &linOther, CfgLineage &linNew) const
{
#if 0 // NO, this part does not make ssense. in principle, any two lineage can coalesce
	// 090711: make sure the two lineages do not share any descendent lineages
	set<int> linsUnder, linsUnderOther;
	CfgLineage::GetLineageDescendentOf(this->GetLinId(), linsUnder );
	CfgLineage::GetLineageDescendentOf(linOther.GetLinId(), linsUnderOther );
	set<int> linsUnderCommon;
	JoinSets(linsUnder, linsUnderOther, linsUnderCommon);
	if( linsUnderCommon.size() > 0)
	{
		return false;
		// 101911: new idea: if there is overlap in the lineages,
		// then the two lineages can only directly merge (no coalescent is allowed)
#if 0
cout << "****These two lineages: ";
this->Dump();
cout << ", and ";
linOther.Dump();
cout << "HAVE NON EMPTY INTERSECTION, and so can only merge\n";
cout << "linsUnder = ";
DumpIntSet(linsUnder);
cout << "linsUnderOther = ";
DumpIntSet( linsUnderOther);
#endif

		// always present = join of two must have
		//set< CfgLineageSrc > listLinsSrcAlwaysNew = this->listLinsSrcAlways;
		linNew.listLinsSrcAlways.clear();
		linNew.listLinsSrcCondition = this->listLinsSrcCondition;
		for( set< CfgLineageSrc > :: iterator it1= linOther.listLinsSrcCondition.begin(); it1 != linOther.listLinsSrcCondition.end(); ++it1)
		{
			linNew.listLinsSrcCondition.insert(*it1);
		}
		for( set< CfgLineageSrc > :: iterator it1= linOther.listLinsSrcAlways.begin(); it1 != linOther.listLinsSrcAlways.end(); ++it1)
		{
			if( this->listLinsSrcAlways.find(*it1) != this->listLinsSrcAlways.end() )
			{
				linNew.listLinsSrcAlways.insert(*it1);
			}
			else
			{
				linNew.listLinsSrcCondition.insert(*it1);
			}
		}
		for( set< CfgLineageSrc > :: iterator it1= this->listLinsSrcAlways.begin(); it1 != this->listLinsSrcAlways.end(); ++it1)
		{
			if( linOther.listLinsSrcAlways.find(*it1) != linOther.listLinsSrcAlways.end() )
			{
				linNew.listLinsSrcAlways.insert(*it1);
			}
			else
			{
				linNew.listLinsSrcCondition.insert(*it1);
			}
		}
		return true;
	}
#endif

	// is the lineage being created before? If so, take the cached copy
#if 0
	pair<int,int> pp(this->linId, linOther.linId);
	OrderInt( pp.first, pp.second);
	if( mapPairsToIds.find( pp) != mapPairsToIds.end() )
	{
		int idOrig = mapPairsToIds[pp];
//cout << "first lineage: " << pp.first << ", second lineage: " << pp.second << endl;
		YW_ASSERT_INFO( mapIdToLineages.find(idOrig) != mapIdToLineages.end(), "Fail to find the lineage" );
		linNew = mapIdToLineages[idOrig];
		return true;
	}
#endif

#if 0
	// 8/16/11: take a heuristic (?) rule: a coalescent must generate a new lineage
	// first find the set of always-present gene lineages
	set< CfgLineageSrc > listLinsSrcAlwaysNew;
	set< CfgLineageSrc > listLinsSrcConditionNew;

	bool fNewLins = false;

	// take care of the case when this lineage has no always-present ones but the other has
	if( linOther.listLinsSrcAlways.size() > 0 && listLinsSrcAlways.size() == 0 )
	{
		listLinsSrcAlwaysNew = linOther.listLinsSrcAlways;
	}
	else if( linOther.listLinsSrcAlways.size() == 0 && listLinsSrcAlways.size() > 0  )
	{
		listLinsSrcAlwaysNew = listLinsSrcAlways;
	}
	else if( linOther.listLinsSrcAlways.size() > 0 && listLinsSrcAlways.size() > 0 )
	{
		//
		for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
		{
			for( set< CfgLineageSrc > :: iterator it2= linOther.listLinsSrcAlways.begin(); it2 != linOther.listLinsSrcAlways.end(); ++it2)
			{
				// caolesce them if we can
				CfgLineageSrc srcLinNew;
				if( it1->CoalesceWith(*it2, srcLinNew) == true )
				{
					// 
					listLinsSrcAlwaysNew.insert( srcLinNew );
					fNewLins = true;
				}
				//else
				//{
				//	// if can not coalesce, then just add the two lineages: do not seem to make sense
				//	listLinsSrcAlwaysNew.insert( *it1 );
				//	listLinsSrcAlwaysNew.insert( *it2 );
				//}
			}
		}
	}

	// consider coalesce between the new MUST-have with the optional
	set< CfgLineageSrc > listLinsSrcCondOrig1 = listLinsSrcCondition;
	set< CfgLineageSrc > listLinsSrcCondOrig2 = linOther.listLinsSrcCondition;
	set< CfgLineageSrc > listLinsSrcAlwaysOrig1 = listLinsSrcAlways;
	set< CfgLineageSrc > listLinsSrcAlwaysOrig2 = linOther.listLinsSrcAlways;

	// YW: 011312
	// keep track of linsrc that coalesce to something; remove those afterwords from alwayssrc
	set<CfgLineageSrc> setFinishedCoalLins;
 
	if(listLinsSrcCondOrig1.size() < listLinsSrcCondOrig2.size() )
	{
		listLinsSrcCondOrig2 = listLinsSrcCondition;
		listLinsSrcCondOrig1 = linOther.listLinsSrcCondition;
		listLinsSrcAlwaysOrig2 = listLinsSrcAlways;
		listLinsSrcAlwaysOrig1 = linOther.listLinsSrcAlways;
	}
	// 
	if(listLinsSrcCondOrig1.size() > 0)
	{
		for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondOrig1.begin(); it1 != listLinsSrcCondOrig1.end(); ++it1)
		{
			for( set< CfgLineageSrc > :: iterator it2= listLinsSrcAlwaysOrig2.begin(); it2 != listLinsSrcAlwaysOrig2.end(); ++it2)
			{
				// caolesce them if we can
				CfgLineageSrc srcLinNew;
				if( it1->CoalesceWith(*it2, srcLinNew) == true )
				{
					// 
					listLinsSrcConditionNew.insert( srcLinNew );
					fNewLins = true;

					// keep track which lins has gotten into coal lins
					setFinishedCoalLins.insert(*it1);
					setFinishedCoalLins.insert(*it2);
				}
			}
		}
	}
	if(listLinsSrcCondOrig2.size() > 0)
	{
		for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondOrig2.begin(); it1 != listLinsSrcCondOrig2.end(); ++it1)
		{
			for( set< CfgLineageSrc > :: iterator it2= listLinsSrcAlwaysOrig1.begin(); it2 != listLinsSrcAlwaysOrig1.end(); ++it2)
			{
				// caolesce them if we can
				CfgLineageSrc srcLinNew;
				if( it1->CoalesceWith(*it2, srcLinNew) == true )
				{
					// 
					listLinsSrcConditionNew.insert( srcLinNew );
					fNewLins = true;
					// keep track which lins has gotten into coal lins
					setFinishedCoalLins.insert(*it1);
					setFinishedCoalLins.insert(*it2);

				}
			}
		}
	}
	// now condition vs condition..
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondOrig1.begin(); it1 != listLinsSrcCondOrig1.end(); ++it1)
	{
		for( set< CfgLineageSrc > :: iterator it2= listLinsSrcCondOrig2.begin(); it2 != listLinsSrcCondOrig2.end(); ++it2)
		{
			// caolesce them if we can
			CfgLineageSrc srcLinNew;
			if( it1->CoalesceWith(*it2, srcLinNew) == true )
			{
				// 
				listLinsSrcConditionNew.insert( srcLinNew );
				fNewLins = true;

				// keep track which lins has gotten into coal lins
				setFinishedCoalLins.insert(*it1);
				setFinishedCoalLins.insert(*it2);

			}
		}
	}
	if( listLinsSrcAlwaysOrig2.size() == 0)
	{
		// we may also just skip the other side (if there is no must)
		for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondOrig1.begin(); it1 != listLinsSrcCondOrig1.end(); ++it1)
		{
			// 
			listLinsSrcConditionNew.insert( *it1 );
		}
	}
	if( listLinsSrcAlwaysOrig1.size() == 0)
	{
		// we may also just skip the other side (if there is no must)
		for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondOrig2.begin(); it1 != listLinsSrcCondOrig2.end(); ++it1)
		{
			// 
			listLinsSrcConditionNew.insert( *it1 );
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////
	// YW: 011312: this should slightly reduce the num of lineages
	// remove entries that in always that have already coalesce into something
	// similarly, also remove from conditional lineages
	// WHY does this work? B/c since the other lineage must be conditional as well
	// thus we can avoid it and reach this lineage and choose this side lineage instead!!!!
	for( set<CfgLineageSrc>::iterator ittm= setFinishedCoalLins.begin(); ittm!= setFinishedCoalLins.end(); ++ittm )
	{
		listLinsSrcAlwaysNew.erase(*ittm);
		listLinsSrcConditionNew.erase(*ittm);
	}


	//////////////////////////////////////////////////////////////////////////////////////////////////

	// that is all
	linNew.listLinsSrcAlways = listLinsSrcAlwaysNew;
	linNew.listLinsSrcCondition = listLinsSrcConditionNew;

	// if no lineage can be found along this branch, skip it
	if( linNew.listLinsSrcAlways.size() == 0 && linNew.listLinsSrcCondition.size() == 0)
	{
//cout << "^^^^^^^Empty lineage. Skipped\n";
		return false;
	}
	// if the new lineage is identical to one of the two involved lins, no need to continue (skip)
	if( (linNew.listLinsSrcAlways == this->listLinsSrcAlways && linNew.listLinsSrcCondition == this->listLinsSrcCondition)  ||
		(linNew.listLinsSrcAlways == linOther.listLinsSrcAlways && linNew.listLinsSrcCondition == linOther.listLinsSrcCondition)  )
	{
		return false;
	}
	if( this->IsPureConditional() == true && linOther.IsPureConditional() == true && fNewLins == false)
	{
		// this lineage is created by simply combining (but no fusion) of two conditional lineages
		// such lineage can be ignored in coalescing since we can defer the action.
		linNew.SetFlagCoalButNoFusion(true);
	}
	// YW: 083011, for now, disallow any coalescent that generates no new lineages
	// NOTE: THIS MAY NOT BE OPTIMAL BUT PRACTICALLY IT SEEMS TO PERFORM WELL
	if(fApproxMode == true && fNewLins == false)
	{
		return false;
	}
	return true;
#endif

	// 08/19/12: streamline the old code by combining so called always and conditional 
	// this works since lineage src now carry the set of reticulation nodes conditional
	set< CfgLineageSrc > listLinsSrcCombinedNew;

	// if one lineage can be empty, then add all other lin src
	if( this->IsEmptyPossible() == true)
	{
		listLinsSrcCombinedNew = linOther.listLinsSrcCombined;
	}
	if( linOther.IsEmptyPossible() == true)
	{
		for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
		{
			listLinsSrcCombinedNew.insert( *it1 );
		}
	}

	bool fNewLins = false;

	// take care of the case when this lineage has no always-present ones but the other has
	//
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		// if this linsrc contains the root, add it
		if(GeneTreeInfo::Instance().IsRoot(it1->GetNodeId()  ) == true)
		{
			listLinsSrcCombinedNew.insert(*it1);
		}

		for( set< CfgLineageSrc > :: iterator it2= linOther.listLinsSrcCombined.begin(); it2 != linOther.listLinsSrcCombined.end(); ++it2)
		{
			if(GeneTreeInfo::Instance().IsRoot(it2->GetNodeId()  ) == true)
			{
				listLinsSrcCombinedNew.insert(*it2);
			}

//cout << "Testing linsrc ";
//it1->Dump();
//cout << "   with linsrc ";
//it2->Dump();
			// caolesce them if we can
			CfgLineageSrc srcLinNew;
			if( it1->CoalesceWith(*it2, srcLinNew) == true )
			{
//cout << "Yes coalesce into: ";
//srcLinNew.Dump();
				// 
				listLinsSrcCombinedNew.insert( srcLinNew );
				fNewLins = true;
			}
//else
//{
//cout << "Can not coalesce\n";
//}

			// also, if one lineage src has non-empty condition, then add this one
			// this is not allowed if there is no intersection betwen this two lineages
			//set<CfgRetEvt> setUnion;
			//if( ReticulateSetLinSrcDepot::Instance().AreEvtSetsDisjoint( it1->GetRetEvtSetId(), it2->GetRetEvtSetId() ) == true )
			//{
			//	if( it1->IsEmptyRetEvtSet() == false)
			//	{
			//		// add the other
			//		//CfgLineageSrc srcLinNew = *it2;
			//		//srcLinNew.SetEvtSetId(  ReticulateSetLinSrcDepot::Instance().RetrieveRetEvtSetId( setUnion )  );
			//		listLinsSrcCombinedNew.insert(*it2);
			//	}
			//	if( it2->IsEmptyRetEvtSet() == false)
			//	{
			//		//CfgLineageSrc srcLinNew = *it1;
			//		//srcLinNew.SetEvtSetId(  ReticulateSetLinSrcDepot::Instance().RetrieveRetEvtSetId( setUnion )  );
			//		listLinsSrcCombinedNew.insert(*it1);
			//	}
			//}
		}
	}


	//////////////////////////////////////////////////////////////////////////////////////////////////
	// YW: 011312: this should slightly reduce the num of lineages
	// remove entries that in always that have already coalesce into something
	// similarly, also remove from conditional lineages
	// WHY does this work? B/c since the other lineage must be conditional as well
	// thus we can avoid it and reach this lineage and choose this side lineage instead!!!!
	//for( set<CfgLineageSrc>::iterator ittm= setFinishedCoalLins.begin(); ittm!= setFinishedCoalLins.end(); ++ittm )
	//{
	//	listLinsSrcAlwaysNew.erase(*ittm);
	//	listLinsSrcConditionNew.erase(*ittm);
	//}


	//////////////////////////////////////////////////////////////////////////////////////////////////

	// that is all
	linNew.listLinsSrcCombined = listLinsSrcCombinedNew;
	//linNew.listLinsSrcAlways = listLinsSrcAlwaysNew;
	//linNew.listLinsSrcCondition = listLinsSrcConditionNew;

	// if no lineage can be found along this branch, skip it
	//if( linNew.listLinsSrcAlways.size() == 0 && linNew.listLinsSrcCondition.size() == 0)
	if( linNew.listLinsSrcCombined.size() == 0 )
	{
//cout << "^^^^^^^Empty lineage. Skipped\n";
		return false;
	}
	// if the new lineage is identical to one of the two involved lins, no need to continue (skip)
	//if( (linNew.listLinsSrcAlways == this->listLinsSrcAlways && linNew.listLinsSrcCondition == this->listLinsSrcCondition)  ||
	//	(linNew.listLinsSrcAlways == linOther.listLinsSrcAlways && linNew.listLinsSrcCondition == linOther.listLinsSrcCondition)  )
	if( (linNew.listLinsSrcCombined == this->listLinsSrcCombined)  ||
		(linNew.listLinsSrcCombined == linOther.listLinsSrcCombined )  )
	{
//cout << "This new lineage is redundent!\n";
		return false;
	}
	if( this->IsPureConditional() == true && linOther.IsPureConditional() == true && fNewLins == false)
	{
		// this lineage is created by simply combining (but no fusion) of two conditional lineages
		// such lineage can be ignored in coalescing since we can defer the action.
		linNew.SetFlagCoalButNoFusion(true);
	}
	// if both lineage are empty possible, then it is empty possible; otherwise it is not
	if( this->IsEmptyPossible() == true && linOther.IsEmptyPossible() == true)
	{
		linNew.SetEmptyPossible(true);
	}
	else
	{
		linNew.SetEmptyPossible(false);
	}

	// YW: 083011, for now, disallow any coalescent that generates no new lineages
	// NOTE: THIS MAY NOT BE OPTIMAL BUT PRACTICALLY IT SEEMS TO PERFORM WELL
	if(fApproxMode == true && fNewLins == false)
	{
		return false;
	}
	return true;
}

bool CfgLineage :: IsCoalRedundent(const CfgLineage &linOther, const CfgLineage &linNew) const
{
	// is this cfg redundent by coalescent?
	// assume this cfg is created by coalescent, then it is redudent if this cfg
	// can be created through coalescent from a child of one lienage with the other lineage
	// Then if redundent, ignore this branch of search
	int idChild11, idChild12;
	GetChildrenId(this->linId, idChild11, idChild12);
	int idChild21, idChild22;
	GetChildrenId(linOther.linId, idChild21, idChild22);

	//
	vector< pair<CfgLineage,CfgLineage> > listPairsToTry;
	if( idChild11 >=0 && idChild12 >=0 )
	{
//cout << "idC11 = " << idChild11 << ", idC12 = " << idChild12 << endl;
		CfgLineage lin11;
		bool f1 = GetLineageById(idChild11, lin11);
		YW_ASSERT_INFO(f1 == true, "Fail to find1");
		pair<CfgLineage,CfgLineage>  pp( lin11, linOther );
		listPairsToTry.push_back(pp);
		CfgLineage lin12;
		bool f2 = GetLineageById(idChild12, lin12);
		YW_ASSERT_INFO(f2 == true, "Fail to find2");
		pair<CfgLineage,CfgLineage>  pp2( lin12, linOther );
		listPairsToTry.push_back(pp2);
	}
	if( idChild21 >=0 && idChild22 >=0 )
	{
//cout << "idC21 = " << idChild21 << ", idC22 = " << idChild22 << endl;
		CfgLineage lin11;
		bool f1 = GetLineageById(idChild21, lin11);
		YW_ASSERT_INFO(f1 == true, "Fail to find3");
		pair<CfgLineage,CfgLineage> pp( lin11, *this );
		listPairsToTry.push_back(pp);
		CfgLineage lin12;
		bool f2 = GetLineageById(idChild22, lin12);
		YW_ASSERT_INFO(f2 == true, "Fail to find4");
		pair<CfgLineage,CfgLineage>  pp2( lin12, *this );
		listPairsToTry.push_back(pp2);
	}
	for(int i=0; i<(int)listPairsToTry.size(); ++i  )
	{
		CfgLineage lin1New;
		if( listPairsToTry[i].second.CoalesceWith(listPairsToTry[i].first, lin1New) == true)
		{
			if(lin1New.AreLineagesEquiv(linNew) == true )
			{
				return true;
			}
		}
	}
	return false;
}

bool CfgLineage :: AreLineagesEquiv(const CfgLineage &rhs) const
{
	return this->listLinsSrcCombined == rhs.listLinsSrcCombined;
//	return this->listLinsSrcAlways == rhs.listLinsSrcAlways &&
//		this->listLinsSrcCondition == rhs.listLinsSrcCondition;
}


bool CfgLineage :: IsNodeContained(int nodeId) const
{
	for( set< CfgLineageSrc > :: iterator it= listLinsSrcCombined.begin(); it != listLinsSrcCombined.end(); ++it)
	{
		if( it->IsNodeContained(nodeId ) == true )
		{
			return true;
		}
	}

	//for( set< CfgLineageSrc > :: iterator it= listLinsSrcAlways.begin(); it != listLinsSrcAlways.end(); ++it)
	//{
	//	if( it->IsNodeContained(nodeId ) == true )
	//	{
	//		return true;
	//	}
	//}
	//for( set< CfgLineageSrc > :: iterator it= listLinsSrcCondition.begin(); it != listLinsSrcCondition.end(); ++it)
	//{
	//	if( it->IsNodeContained(nodeId ) == true )
	//	{
	//		return true;
	//	}
	//}
	return false;
}

void CfgLineage:: Dump() const
{
	cout << "<" << this->linId << ">";
	if( IsReticulateLineage() == true )
	{
		cout << "[R]";
	}
	else
	{
		cout << "[C]";
	}
	cout << endl;
	//cout << "Num of lineages always present: " << listLinsSrcAlways.size() << endl;	
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		it1->Dump();
	}
	//cout << "Num of lineages always present: " << listLinsSrcAlways.size() << endl;	
	//for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
	//{
	//	it1->Dump();
	//}
	//cout << "Num of lineages conditional: " << listLinsSrcCondition.size() << endl;	
	//for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	//{
	//	it1->Dump();
	//}
}

bool CfgLineage :: IsBeaten(const CfgLineage &other) const
{
	// a lineage is beaten by another if it contains exactly the same set of lineage names and strictly smaller conditions
	//
	CfgLineage otherLin = other;
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		bool fFound = false;
		for( set< CfgLineageSrc > :: iterator it2= otherLin.listLinsSrcCombined.begin(); it2 != otherLin.listLinsSrcCombined.end(); ++it2)
		{
			if( it1->IsBeaten(*it2) == true)
			{
				otherLin.listLinsSrcCombined.erase( *it2 );
				fFound = true;
				break;
			}
		}
		if( fFound == false)
		{
			return false;
		}
	}

#if 0
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
	{
		bool fFound = false;
		for( set< CfgLineageSrc > :: iterator it2= otherLin.listLinsSrcAlways.begin(); it2 != otherLin.listLinsSrcAlways.end(); ++it2)
		{
			if( it1->IsBeaten(*it2) == true)
			{
				otherLin.listLinsSrcAlways.erase( *it2 );
				fFound = true;
				break;
			}
		}
		if( fFound == false)
		{
			return false;
		}
	}
	// merge the two list of src lins in other
	for( set< CfgLineageSrc > :: iterator it2= otherLin.listLinsSrcAlways.begin(); it2 != otherLin.listLinsSrcAlways.end(); ++it2)
	{
		otherLin.listLinsSrcCondition.insert( *it2 );
	}
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	{
		bool fFound = false;
		for( set< CfgLineageSrc > :: iterator it2= otherLin.listLinsSrcCondition.begin(); it2 != otherLin.listLinsSrcCondition.end(); ++it2)
		{
			// 
			if( it1->IsBeaten(*it2) == true)
			{
				otherLin.listLinsSrcCondition.erase( *it2 );
				fFound = true;
				break;
			}
		}
		if( fFound == false)
		{
			return false;
		}
	}
#endif
	return true;
}

void CfgLineage :: AssignDistinctId(int linSrcId1, int linSrcId2)
{
	// there are two cases: (1) the lineage is an extant lineage (and in this case, both src = -1)
	// (2) the lineage is a coalescent of two existing sequences. So in this case, we need to pass in two
	//static int idNextToUse = 0;
	//static map<pair<int,int>,int> mapPairsToIds;

	//if( linSrcId1 < 0 || linSrcId2 < 0 )
	//{
	//	this->linId = ++idNextToUse;
	//}
	//else
	{
		// check to see whether we have see the pair before
		pair<int,int> pp(linSrcId1, linSrcId2);
		if( linSrcId1 > linSrcId2)
		{
			pp.first = linSrcId2;
			pp.second = linSrcId1;
		}
		if( mapPairsToIds.find(pp) != mapPairsToIds.end() )
		{
			this->linId = mapPairsToIds[pp];
		}
		else
		{
			this->linId = ++idNextToUse;
			// remember it
			mapPairsToIds.insert( map<pair<int,int>,int> :: value_type(pp, this->linId) ) ;
			mapIdsToPairs.insert( map<int,pair<int,int> > :: value_type(this->linId, pp) );
		}
	}
}

void CfgLineage :: GetChildrenId(int linId, int &childId1, int &childId2)
{
	if( mapIdsToPairs.find(linId) == mapIdsToPairs.end() )
	{
		//
		childId1 = -1;
		childId2 = -1;
	}
	else
	{
		childId1 = mapIdsToPairs[linId].first;
		childId2 = mapIdsToPairs[linId].second;
	}
}

void CfgLineage :: GetLineageDescendentOf(int linId, set<int> &linIdDescs, bool fSelf)
{
	// 
	if( fSelf == true)
	{
		linIdDescs.insert(linId);
	}
	int idChild1, idChild2;
	GetChildrenId(linId, idChild1, idChild2);
	if( idChild1 >= 0 && idChild2 >= 0 )
	{
		YW_ASSERT_INFO( idChild1 != idChild2, "Can not have same descendents" );
		GetLineageDescendentOf(idChild1, linIdDescs, true);
		GetLineageDescendentOf(idChild2, linIdDescs, true);
	}
}

void CfgLineage :: AddCoalLineageToCache(int linId, CfgLineage &lin)
{
//#if 0
	if( mapIdToLineages.find( linId ) != mapIdToLineages.end() )
	{
		// already done
		return;
	}
	mapIdToLineages.insert(map<int,CfgLineage>:: value_type( linId, lin ) );
//#endif
}

bool CfgLineage :: GetLineageById(int linId, CfgLineage &lin)
{
	if( mapIdToLineages.find( linId ) == mapIdToLineages.end() )
	{
		// already done
		return false;
	}
	lin = mapIdToLineages[linId];
	return true;
}

void CfgLineage :: GetMaxLowMinHighCoalIn(int linId, int &childId1, int &childId2)
{
#if 0
	set<int> setDescIds;
	GetLineageDescendentOf( linId, setDescIds );
//cout << "GetMaxLowMinHighCoalIn: setDescIds = ";
//DumpIntSet( setDescIds );
	set< pair<int,int> > setDescPairs;
	for( set<int> :: iterator itt = setDescIds.begin(); itt != setDescIds.end(); ++itt)
	{
		if( *itt < 0 )
		{
			continue;
		}
		int cid1, cid2;
		GetChildrenId(*itt, cid1, cid2);
		if( cid1 >= 0 && cid2 >= 0)
		{
			pair<int,int> pp(cid1, cid2);
			setDescPairs.insert(pp);
		}
	}
	if( setDescPairs.size() > 0 )
	{
		childId1 = (setDescPairs.begin())->first;
		childId2 = (setDescPairs.begin())->second;
	}
	else
	{
		childId1 = -1;
		childId2 = -1;
	}
#endif
//#if 0
	// 
	childId1 = -1;
	childId2 = -1;
	int resChild1 = -1, resChild2 = -1;
	stack<int> stackLinIds;
	stackLinIds.push(linId);
	while(stackLinIds.empty() == false )
	{
		int idTest = stackLinIds.top();
		YW_ASSERT_INFO(idTest >= 0, "Id in stack wrong");
		stackLinIds.pop();
		int cidStep1, cidStep2;
		GetChildrenId(idTest, cidStep1, cidStep2);
		if( cidStep1 >= 0 )
		{
			// push to stack
			stackLinIds.push(cidStep1);
			stackLinIds.push(cidStep2);

			// should we update the interval
			if( resChild1 < cidStep1 || (resChild1  == cidStep1 && resChild2 < cidStep2 )  )
			{
				resChild1 = cidStep1;
				resChild2 = cidStep2;
			}
		}
	}
	childId1 = resChild1;
	childId2 = resChild2;
//#endif
}

void CfgLineage :: CleanExtraLins()
{
//return;
	//set< CfgLineageSrc > listLinsSrcAlwaysNew;		
	//set< CfgLineageSrc > listLinsSrcConditionNew;	
	set< CfgLineageSrc > listLinsSrcCombinedNew;	
//cout << "Before cleanextralins: ";
//Dump();
	// scan through always and conditional lineages and prune those dominated by their prior lineage src
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		if( it1 !=  listLinsSrcCombined.begin() )
		{
			 set< CfgLineageSrc > :: iterator it2 = it1;
			 it2--;
			 if( it1->IsBeaten(*it2) == false)
			 {
				 listLinsSrcCombinedNew.insert(*it1);
			 }
		}
		else
		{
			 listLinsSrcCombinedNew.insert(*it1);
		}
	}
	this->listLinsSrcCombined = listLinsSrcCombinedNew;

#if 0
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
	{
		if( it1 !=  listLinsSrcAlways.begin() )
		{
			 set< CfgLineageSrc > :: iterator it2 = it1;
			 it2--;
			 if( it1->IsBeaten(*it2) == false)
			 {
				 listLinsSrcAlwaysNew.insert(*it1);
			 }
		}
		else
		{
			 listLinsSrcAlwaysNew.insert(*it1);
		}
	}
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	{
		if( it1 !=  listLinsSrcCondition.begin() )
		{
			 set< CfgLineageSrc > :: iterator it2 = it1;
			 it2--;
			 if( it1->IsBeaten(*it2) == false)
			 {
				 listLinsSrcConditionNew.insert(*it1);
			 }
		}
		else
		{
			 listLinsSrcConditionNew.insert(*it1);
		}
	}
	// update
//if(listLinsSrcAlways != listLinsSrcAlwaysNew || listLinsSrcCondition != listLinsSrcConditionNew )
//{
//cout << "DDDDDDDDDDDDDDDDDDDDDDD\n";
//}
	listLinsSrcAlways = listLinsSrcAlwaysNew;
	listLinsSrcCondition = listLinsSrcConditionNew;
//cout << "AFTER cleanextralins: ";
//Dump();
#endif

#if 0
	if( fApproxMode == true)
	{
		set<int> listNodeIdsKept;
		for(set<CfgLineageSrc> :: iterator it1 = listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1 )
		{
			listNodeIdsKept.insert( it1->GetNodeId() );
		}
		for(set<CfgLineageSrc> :: iterator it1 = listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1 )
		{
			listNodeIdsKept.insert( it1->GetNodeId() );
		}

		// TEST: remove each lineage src if its ancestor has already been in there
		set<int> listNodeIdsKeptReduced;
		for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
		{
			// 
			GeneTreeIterator gtItor(tr);
			gtItor.Init();
			while( gtItor.IsDone() == false )
			{
				// 
				int nodeId = gtItor.GetNodeId( );
				if( listNodeIdsKept.find(nodeId) != listNodeIdsKept.end()  )
				{
					// backout
	//cout << "Moving back...\n";
					listNodeIdsKeptReduced.insert( nodeId );
					gtItor.Back();
				}
				else
				{
					// continue
	//cout << "Moving forward...\n";
					gtItor.Next();
				}
			}
		}
	//cout << "listNodeIdsKeptReduced: ";
	//DumpIntSet( listNodeIdsKeptReduced );
		// drop any lineage if it is not in the keptReduced list
		set< CfgLineageSrc > listLinsSrcAlwaysNew2;		
		set< CfgLineageSrc > listLinsSrcConditionNew2;	
		// scan through always and conditional lineages and prune those dominated by their prior lineage src
	//#if 0
		for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
		{
			if( listNodeIdsKeptReduced.find( it1->GetNodeId() ) != listNodeIdsKeptReduced.end() )
			{
				listLinsSrcAlwaysNew2.insert( *it1 );
			}
		}
	//#endif
		for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
		{
			if( listNodeIdsKeptReduced.find( it1->GetNodeId() ) != listNodeIdsKeptReduced.end() )
			{
				listLinsSrcConditionNew2.insert( *it1 );
			}
		}
		// update
		listLinsSrcAlways = listLinsSrcAlwaysNew2;
		listLinsSrcCondition = listLinsSrcConditionNew2;
	//cout << "AFTER cleanextralins(2): ";
	//Dump();
	}
#endif
}

bool CfgLineage :: CleanExtraLins(const set<int> &slinSrcs)
{
	bool res = false;
	// only remove those in conditional ones
	//set< CfgLineageSrc > listLinsSrcConditionNew;	
	set< CfgLineageSrc > listLinsSrcCombinedNew;	
//cout << "Before cleanextralins: ";
//Dump();
	// scan through always and conditional lineages and prune those dominated by their prior lineage src
	//for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		if( it1->IsEmptyRetEvtSet() == false )
		{
			if( slinSrcs.find(it1->GetNodeId() ) != slinSrcs.end() )
			{
				 listLinsSrcCombinedNew.insert(*it1);
			}
			else
			{
				res = true;
			}
		}
		else
		{
			listLinsSrcCombinedNew.insert( *it1 );
		}
	}
	// update
//if(listLinsSrcAlways != listLinsSrcAlwaysNew || listLinsSrcCondition != listLinsSrcConditionNew )
//{
//cout << "DDDDDDDDDDDDDDDDDDDDDDD\n";
//}
	if( res == true)
	{
		this->listLinsSrcCombined = listLinsSrcCombinedNew;
		//listLinsSrcCondition = listLinsSrcConditionNew;
	}
	return res;
}

void CfgLineage :: CleanExtraLinsByCoveredNodes( set<int> &setNodes)
{
	set< CfgLineageSrc > listLinsSrcCombinedNew;		
//cout << "Before cleanextralins: ";
//Dump();
	// scan through always and conditional lineages and prune those dominated by their prior lineage src
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		// is its sibling derivable? if so, add it
		int idSrc = it1->GetNodeId();
		int idSrcSib = GeneTreeInfo::Instance().GetSibling( idSrc );
		if( idSrcSib < 0  || setNodes.find(idSrcSib) != setNodes.end()  )
		{
			 listLinsSrcCombinedNew.insert(*it1);
		}
		else
		{
//cout << "VVVVVVVVVVVVVVVVVVVDelete lin (always) src ";
//it1->Dump();
//cout << "from Lineage: ";
//Dump();
		}
	}

	// update
	listLinsSrcCombined = listLinsSrcCombinedNew;

#if 0
	set< CfgLineageSrc > listLinsSrcAlwaysNew;		
	set< CfgLineageSrc > listLinsSrcConditionNew;	
//cout << "Before cleanextralins: ";
//Dump();
	// scan through always and conditional lineages and prune those dominated by their prior lineage src
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
	{
		// is its sibling derivable? if so, add it
		int idSrc = it1->GetNodeId();
		int idSrcSib = GeneTreeInfo::Instance().GetSibling( idSrc );
		if( idSrcSib < 0  || setNodes.find(idSrcSib) != setNodes.end()  )
		{
			 listLinsSrcAlwaysNew.insert(*it1);
		}
		else
		{
//cout << "VVVVVVVVVVVVVVVVVVVDelete lin (always) src ";
//it1->Dump();
//cout << "from Lineage: ";
//Dump();
		}
	}
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	{
		int idSrc = it1->GetNodeId();
		int idSrcSib = GeneTreeInfo::Instance().GetSibling( idSrc );
		if( idSrcSib < 0  || setNodes.find(idSrcSib) != setNodes.end()  )
		{
			 listLinsSrcConditionNew.insert(*it1);
		}
		else
		{
//cout << "VVVVVVVVVVVVVVVVVVVDelete lin (conditional) src ";
//it1->Dump();
//cout << "from Lineage: ";
//Dump();
		}
	}
	// update
	listLinsSrcAlways = listLinsSrcAlwaysNew;
	listLinsSrcCondition = listLinsSrcConditionNew;
#endif
}


#if 0
void CfgLineage :: GetSetEvts( set<CfgRetEvt> &setEvts) const
{
	// obtain set of events under this lineage
	setEvts.clear();
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
	{
		set<CfgRetEvt> setEvtsStep1;
		it1->GetSetEvts(setEvtsStep1);
		UnionSets( setEvts, setEvtsStep1 );
	}
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	{
		set<CfgRetEvt> setEvtsStep1;
		it1->GetSetEvts(setEvtsStep1);
		UnionSets( setEvts, setEvtsStep1 );
	}
}
#endif

void CfgLineage :: GetCoveredNodes( set<int>& sint) const
{
	sint.clear();
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		sint.insert( it1->GetNodeId() );
	}
	//for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
	//{
	//	sint.insert( it1->GetNodeId() );
	//}
	//for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	//{
	//	sint.insert( it1->GetNodeId() );
	//}
}

void CfgLineage :: GeCoveredNodesUnder(set<int> &nodesDescs) const
{
	// different form above, perform recurisively
	set<int> sint;
	GetCoveredNodes(sint);
	nodesDescs = sint;
	// now gets descendent of each
	for( set<int> :: iterator itt = sint.begin(); itt != sint.end(); ++itt)
	{
		// 
		set<int> sdescs;
		GeneTreeInfo::Instance().GetDescentIds(*itt, sdescs);
		UnionSets( nodesDescs, sdescs );
	}
}

#if 0
void CfgLineage :: GetCoveredNodes( set<pair<int,set<int> > >& sint) const
{
	sint.clear();
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
	{
		pair<int,set<int> > ss;
		ss.first = it1->GetNodeId();
		it1->GetSetEvts( ss.second );
		sint.insert( ss );
	}
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	{
		pair<int,set<int> > ss;
		ss.first = it1->GetNodeId();
		it1->GetSetEvts( ss.second );
		sint.insert( ss );
	}
}
#endif

#if 0
void CfgLineage :: RemoveEvtFromSrc(CfgRetEvt evtRm)
{
	// can not work on those with always 
	YW_ASSERT_INFO( listLinsSrcAlways.size() == 0, "Wrong: can not deal with non-fully-conditional lineage" );
	set< CfgLineageSrc > listLinsSrcConditionNew;	

	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	{
		set<CfgRetEvt> setEvtsStep1;
		it1->GetSetEvts(setEvtsStep1);
		if( setEvtsStep1.find( evtRm ) != setEvtsStep1.end() )
		{
			CfgLineageSrc csrc = *it1;
			setEvtsStep1.erase( evtRm );
			csrc.SetRetEvts(setEvtsStep1);
			listLinsSrcConditionNew.insert(csrc);
		}
		else
		{
			listLinsSrcConditionNew.insert(*it1);
		}	
	}
	listLinsSrcCondition = listLinsSrcConditionNew;
}
#endif

#if 0
bool CfgLineage::IsEventCommonInside(CfgRetEvt evtId)
{
	if(listLinsSrcAlways.size() > 0)
	{
		return false;
	}

	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	{
		set< CfgRetEvt > setEvts;
		it1->GetSetEvts( setEvts);
		if(setEvts.find(evtId) != setEvts.end() )
		{
			return false;
		}
	}
	return true;
}
#endif

//void CfgLineage :: GetSibNodesInTrees(set<int> &nodeSibs) const
//{
//	// retrive sibling encoded by current nodes inside this lineage
//	nodeSibs.clear();
//	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
//	{
//		int idSrc = it1->GetNodeId();
//		int idSrcSib = GeneTreeInfo::Instance().GetSibling( idSrc );
//		nodeSibs.insert( idSrcSib );
//	}
//}
void CfgLineage :: GetSibNodesInTrees(set<int> &nodeSibs) const
{
	// retrive sibling encoded by current nodes inside this lineage
	nodeSibs.clear();
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		int idSrc = it1->GetNodeId();
		int idSrcSib = GeneTreeInfo::Instance().GetSibling( idSrc );
		nodeSibs.insert( idSrcSib );
	}
	//for( set< CfgLineageSrc > :: iterator it1= listLinsSrcAlways.begin(); it1 != listLinsSrcAlways.end(); ++it1)
	//{
	//	int idSrc = it1->GetNodeId();
	//	int idSrcSib = GeneTreeInfo::Instance().GetSibling( idSrc );
	//	nodeSibs.insert( idSrcSib );
	//}
	//for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCondition.begin(); it1 != listLinsSrcCondition.end(); ++it1)
	//{
	//	int idSrc = it1->GetNodeId();
	//	int idSrcSib = GeneTreeInfo::Instance().GetSibling( idSrc );
	//	nodeSibs.insert( idSrcSib );
	//}
}

bool CfgLineage :: IsPureConditional() const
{
	for( set< CfgLineageSrc > :: iterator it1= listLinsSrcCombined.begin(); it1 != listLinsSrcCombined.end(); ++it1)
	{
		if( it1->IsEmptyRetEvtSet() == true)
		{
			return false;
		}
	}
	return true;
}


///////////////////////////////////////////////////////////////////////////////
// Configuration: collection of active lineages
const int MAX_LIN_RET_NUM = 2;
int CfgConfiguration :: idCfgNext = 1;


CfgConfiguration ::	CfgConfiguration()   //  : fCoalButNoFusion(false)   // : idLastRetLin(-1)
{
	idCfg = GetNextId();
	SetSrcCfgId(-1);
	fGreedyIntermediate = false;
}

int CfgConfiguration :: GetNextId( )
{
	return idCfgNext++;
}

void CfgConfiguration :: IncNumLins( const CfgLineage &lin )
{
	// inc number of this lineage by one
	YW_ASSERT_INFO( mapLineages.find( lin ) != mapLineages.end(), "Fail to find" );
	mapLineages[lin] ++;
	setLinLastAdded.insert( lin );
}

int CfgConfiguration :: GetNumRetLinCopies() const
{
	int res = 0;
	for( map< CfgLineage,int > :: iterator  itg = const_cast<CfgConfiguration &>(*this).mapLineages.begin(); 
	itg != const_cast<CfgConfiguration &>(*this).mapLineages.end(); ++itg )
	{
		res += itg->second-1;
	}
	return res;
}


// Get next configs
//const int MAX_RET_LINS_ALLOWED_CFG = 4;

bool CfgConfiguration :: GetNextCfgs( set<CfgConfiguration> &setCfgsNext, CfgExplorer &cfgExplorer )
{
#if 0
	// directly return if too many ret lineages
	if( fApproxMode == true && GetNumRetLinCopies() > MAX_RET_LINS_ALLOWED_CFG )
	{
		return false;
	}
#endif

	bool fRes = false;

//#if 0
	// 011612: YW: do not allow further reticulation if it already has at least two lineages with more
	// than 1 lineages (through reticulation). This is because one can always order events s.t. 
	// no more than a coalescent event follows after two lineages are reticulated
	int numRetLins2orMore = 0;
	for( map< CfgLineage,int > :: iterator  it = mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		if( it->second >= 2)
		{
			numRetLins2orMore++;
		}
	}
	if(numRetLins2orMore >= 2)
	{
		//cout << "----This cfg already has more than 2 ret lineages. Should do some coalescence now\n";
		//this->Dump();
		cfgExplorer.IncUselessRet();
		return false;
	}
//#endif

	// store set of cfg ids that we should not continue exploring in the next round
	set<int> setCfgIdsTerminal;

	// retrieve nodes info for each lineage
	set<int> nodesCoveredByCfg;
	vector<set<int> > listNodesCoveredByLins;
	vector<set<int> > listNodeSibsOfLins;
	for( map< CfgLineage,int > :: iterator  it = mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		set<int> nodesCovered;
		it->first.GetCoveredNodes(nodesCovered);
		listNodesCoveredByLins.push_back(nodesCovered);
		//if( setLinLastAdded.find( it->first) != setLinLastAdded.end()  )
		{
			// only consider those newly considered
			UnionSets(nodesCoveredByCfg, nodesCovered);
		}
		set<int> nodeSibs;
		it->first.GetSibNodesInTrees( nodeSibs );
		listNodeSibsOfLins.push_back( nodeSibs );
	}
	// clear the current cfgs' history
	setLinLastAdded.clear();
	// get what descendent lineages of this cfg
	set<int> setLinDescIdCurr;
	for( map< CfgLineage,int > :: iterator  itg = mapLineages.begin(); itg !=  mapLineages.end(); ++itg )
	{
		// excluding self
		CfgLineage::GetLineageDescendentOf(itg->first.GetLinId(), setLinDescIdCurr, false);
	}

	set<int> nodesIdDerviable;
	// YW: 011312, only do this when approx mode is on
	if( fApproxMode == true || fNearOptMode == true)
	{
		//GetAllCoveredNodes(nodesIdDerviable);
		for( map< CfgLineage,int > :: iterator  itg = mapLineages.begin(); itg !=  mapLineages.end(); ++itg )
		{
			set<int> sint;
			itg->first.GeCoveredNodesUnder(sint);
			UnionSets(nodesIdDerviable, sint);
		}
	}

	// try one reticulation, and all possible coalescences
	//setCfgsNext.clear();
	set<CfgConfiguration> setCfgsNextRet;
	int linNum = 0;
	set<pair<CfgLineage,int> > setBypassedApproxRetLins;


	for( map< CfgLineage,int > :: iterator  it = mapLineages.begin(); it != mapLineages.end(); ++it, ++linNum )
	{
		// split this lineage
YW_ASSERT_INFO( it->second >= 1, "Must have at least one copy");

		// do not allow reticulate if there are newer (with larger id) has reticulated already
		//if( this->idLastRetLin >  it->first.GetLinId()  )
		//{
		//	cfgExplorer.IncUselessRet();
		//	continue;
		//}

		// 011612: YW: do not allow reticulate more than num of gene trees
		// this is because if more than num of gene trees lineages appear
		// then only num-gene-tree lineages will be used anyway when displaying
		if(it->second >= GeneTreeInfo::Instance().GetNumGeneTrees()  )
		{
			cfgExplorer.IncUselessRet();
			continue;
		}

		// do not allow reticulation if has reticulated before
		if( setLinDescIdCurr.find( it->first.GetLinId() ) != setLinDescIdCurr.end() )
		{
			cfgExplorer.IncUselessRet();
			continue;
		}

		// do not allow reticulation if this lineage's
		set<int> nodeSibsCovered;
		JoinSets(nodesCoveredByCfg, listNodeSibsOfLins[linNum], nodeSibsCovered);
//if 0	// YW: 01/14/12, do not quite work I think
		// 08/21/12: I think it works: if a reticulation does not provide a way to continue coalescences
		// then we can always choose to reticulate another one earlier...
		//if( fApproxMode == true  && nodeSibsCovered.size() == 0)
		if( nodeSibsCovered.size() == 0)
		{
#ifdef DUMP_CFG_DEBUG
cout << "Lineage: ";
it->first.Dump();
cout << "Inside configuraiton: ";
this->Dump();
cout << "Nodes covered in cfg: ";
DumpIntSet(nodesCoveredByCfg);
cout << "Sibling of this lineage: ";
DumpIntSet(listNodeSibsOfLins[linNum]);
#endif
			cfgExplorer.IncUselessRet();
			continue;
		}
//#endif

		// in the approx mode, also require at least some novel reticulate feasible
		// YW: this rule seems to be pretty good: if no novel lineage creaed then allow it
		if( fApproxMode == true )
		{
			bool fCont = false;
			for( set<int> :: iterator itg = nodeSibsCovered.begin(); itg != nodeSibsCovered.end(); ++itg  )
			{
				int nodepar = GeneTreeInfo :: Instance().GetParent(*itg);
				if( nodesIdDerviable.find( nodepar) == nodesIdDerviable.end() )
				{
					fCont = true;
					break;
				}
			}
			if( fCont == false)
			{
#if 0
cout << "2.Lineage: ";
it->first.Dump();
cout << "Inside configuraiton: ";
this->Dump();
cout << "Derivable nodes covered in cfg: ";
DumpIntSet(nodesIdDerviable);
cout << "Sibling of this lineage: ";
DumpIntSet(nodeSibsCovered);
#endif
				cfgExplorer.IncUselessRet();
				continue;
			}

			// another way of trimming reticulation: if this lineage is profitable to reticulate
			//if( IsLinRetProfitable(it->first) == false )
			//{
			//	setBypassedApproxRetLins.insert(*it);
			//	cfgExplorer.IncUselessRet();
			//	continue;
			//}
		}

#if 0
		//
		if( fApproxMode == true && it->second >= MAX_LIN_RET_NUM )
		{
			// impose a max number of reticulation allowed for some lineage
			continue;
		}

		// get the newest linid as coalescent lineage
		int linIdNewestCoal = -1;
		int linIdNewestCoalChildMax = -1;
		int linIdNewestRet = -1;

		for( map< CfgLineage,int > :: iterator  itg = mapLineages.begin(); itg != mapLineages.end(); ++itg )
		{
			int idChild1 = -1;
			int idChild2 = -1;
			CfgLineage::GetChildrenId( itg->first.GetLinId(), idChild1, idChild2 );
			if(  idChild2 >= 0 && idChild1 != idChild2 &&  itg->first.GetLinId() >  linIdNewestCoal  )
			{
				linIdNewestCoal = itg->first.GetLinId();
			}
			if( idChild1 != idChild2 && idChild1 > linIdNewestCoalChildMax)
			{
				linIdNewestCoalChildMax = idChild1;
			}
			if( idChild1 != idChild2 && idChild2 > linIdNewestCoalChildMax)
			{
				linIdNewestCoalChildMax = idChild2;
			}
			if( itg->first.IsReticulateLineage() == true )
			{
				linIdNewestRet = itg->first.GetLinId();
			}
		}
		// a coalescent result, then only allow reticulation if it is the currently largest one
		//if( fApproxMode == false &&  linIdNewestCoal >= 0 && it->first.GetLinId()  != linIdNewestCoal )
		if( linIdNewestCoal >= 0 && it->first.GetLinId()  != linIdNewestCoal )
		{
			// can not reticulate
			//cfgExplorer.IncUselessRet();
			//continue;
		}
		if( linIdNewestRet >= 0 && it->first.GetLinId() < linIdNewestRet )
		{
			// can not reticulate
			cfgExplorer.IncUselessRet();
			continue;
		}
		if( linIdNewestCoalChildMax >= 0 && it->first.GetLinId() < linIdNewestCoalChildMax)
		{
			// a reticulation must be earlier than involved coalescent
			cfgExplorer.IncUselessRet();
			continue;
		}
#endif

		CfgConfiguration cfgNew = *this;
		cfgNew.SetDistinctId();
		cfgNew.SetSrcCfgId(this->GetId() );
		if( it->second == 1  && it->first.IsReticulateLineage() == false  )
		{
			int revtIdNew = CreateNextRetEvt(  it->first);
	//cout << "A new reticulation event: " << revtIdNew << endl;
			cfgNew.RemoveLin( it->first );
	//cout << "pass0.1\n";
			int numCopies =  it->second +1;
			CfgLineage linNew1 = it->first;
			linNew1.AddRetEvt( revtIdNew );
			linNew1.SetFlagCoalButNoFusion(false);		// enable coalescent
	//cout << "pass0.2\n";
			cfgNew.AddLin( linNew1, numCopies);
			// clean up the src evets after this addition
			cfgNew.CleanExtraSrcEvts( linNew1, revtIdNew );
	//cout << "pass1\n";
		}
		else
		{
			// simply increase the copy
			cfgNew.IncNumLins( it->first );
		}
		// clear out coalescent limit since reticulation may allow more events to occur
		//cfgNew.mapLastLinCoalIds.clear();

		//CfgLineage linNew2 = *it;
		//linNew2.AddRetEvt( revtIdNew, false );
		//cfgNew.AddLin( linNew2);
//cout << "pass2\n";

		// 
		if( cfgExplorer.CfgBeatenByPrevious( cfgNew ) == true )
		{
			continue;
		}
		// update the latest ret lineage of the new cfg
		//cfgNew.idLastRetLin = it->first.GetLinId();

		setCfgsNextRet.insert( cfgNew );
		cfgExplorer.IncProcessedCfg();


#ifdef DUMP_CFG_DEBUG
cout << "---- By reticulation, found a new cfg: ";
cfgNew.Dump();
#endif
	}
	// if nothing reticulate and we have something found before, reticulate those as well
	if( setCfgsNextRet.size() == 0 &&  setBypassedApproxRetLins.size() > 0)
	{
		for(set<pair<CfgLineage,int> > :: iterator it = setBypassedApproxRetLins.begin(); it != setBypassedApproxRetLins.end(); ++it )
		{
			CfgConfiguration cfgNew = *this;
			cfgNew.SetDistinctId();
			cfgNew.SetSrcCfgId(this->GetId() );
			if( it->second == 1  && it->first.IsReticulateLineage() == false  )
			{
				int revtIdNew = CreateNextRetEvt(  it->first);
		//cout << "A new reticulation event: " << revtIdNew << endl;
				cfgNew.RemoveLin( it->first );
		//cout << "pass0.1\n";
				int numCopies =  it->second +1;
				CfgLineage linNew1 = it->first;
				linNew1.AddRetEvt( revtIdNew );
				linNew1.SetFlagCoalButNoFusion(false);		// enable coalescent
		//cout << "pass0.2\n";
				cfgNew.AddLin( linNew1, numCopies);
				// clean up the src evets after this addition
				cfgNew.CleanExtraSrcEvts( linNew1, revtIdNew );
		//cout << "pass1\n";
			}
			else
			{
				// simply increase the copy
				cfgNew.IncNumLins( it->first );
			}

			//CfgLineage linNew2 = *it;
			//linNew2.AddRetEvt( revtIdNew, false );
			//cfgNew.AddLin( linNew2);
	//cout << "pass2\n";

			// 
			if( cfgExplorer.CfgBeatenByPrevious( cfgNew ) == true )
			{
				continue;
			}

			setCfgsNextRet.insert( cfgNew );
			cfgExplorer.IncProcessedCfg();

#ifdef DUMP_CFG_DEBUG
cout << "---- By reticulation, found a new cfg: ";
cfgNew.Dump();
#endif
		}
	}

//cout << "Now process coalescent events\n";
	// also include each newly found configs by reticulation
	set< CfgConfiguration > setCfgsNextCoal;
	set< CfgConfiguration > setCfgLinsCoal = setCfgsNextRet;
	//setCfgLinsCoal.insert(*this);

	while(setCfgLinsCoal.size() > 0)
	{
		// which lineages has been created for the first time
		set< CfgLineage> setNewlCoalLineages;

		set< CfgConfiguration > setCfgLinsCoalNext;
		// process each of the candidate configs
		// NOTE: do not allow identical lineages to coalesce
		for( set< CfgConfiguration > :: iterator itt = setCfgLinsCoal.begin(); itt != setCfgLinsCoal.end(); ++itt )
		{
#ifdef DUMP_CFG_DEBUG
cout << "oooooooooooooooooExplore configurations by coalescing: ";
itt->Dump();
#endif
			set<int> setLinIdsCurr;
			itt->GetLinIds(setLinIdsCurr);

			set<int> setNodeDescIdCurr;
			for( map< CfgLineage,int > :: iterator  itg = const_cast<CfgConfiguration &>(*itt).mapLineages.begin(); 
			    itg !=  const_cast<CfgConfiguration &>(*itt).mapLineages.end(); ++itg )
			{
				set<int> sint;
				itg->first.GeCoveredNodesUnder(sint);
				UnionSets(setNodeDescIdCurr, sint);
			}
//cout << "Descendent node Ids: ";
//DumpIntSet(setNodeDescIdCurr);
#if 0
// seem work but not very powerful and slower
			set<int> setLinDescIdCurr;
			for( map< CfgLineage,int > :: iterator  itg = const_cast<CfgConfiguration &>(*itt).mapLineages.begin(); 
			    itg !=  const_cast<CfgConfiguration &>(*itt).mapLineages.end(); ++itg )
			{
				CfgLineage::GetLineageDescendentOf(itg->first.GetLinId(), setLinDescIdCurr);
			}
//cout << "Descendent Ids: ";
//DumpIntSet(setLinDescIdCurr);
#endif

#if 0
			// get basic info of this cfg
			int linIdNewestCoal = -1;
			int linIdNewestCoalChild = -1;		// the largest id that is a result of ////
			//int linIdNewestRet = -1;
			for( map< CfgLineage,int > :: iterator  itg = const_cast<CfgConfiguration &>(*itt).mapLineages.begin(); 
			    itg !=  const_cast<CfgConfiguration &>(*itt).mapLineages.end(); ++itg )
			{
				int idChild1 = -1;
				int idChild2 = -1;
				CfgLineage::GetChildrenId( itg->first.GetLinId(), idChild1, idChild2 );
				if(  idChild2 >= 0 && idChild1 != idChild2 &&  itg->first.GetLinId() >  linIdNewestCoal  )
				{
					linIdNewestCoal = itg->first.GetLinId();
				}
			//	if( itg->first.IsReticulateLineage() == true )
			//	{
			//		linIdNewestRet = itg->first.GetLinId();
			//	}
			}
#endif

            set<CfgConfiguration> setCfgsNextCoalStepTmp;
            //set<CfgConfiguration> setCfgsNextCoalStepTmpAdvCoal;
			// This is the single configuration that should go from here 
			// needed when such a coalescent leads to a common subtree in every input tree
			//set<CfgConfiguration> cfgsCommonSubtree;
			//bool fCommonSubtree = false;

			// this map<int,int>: <lin, last coalescent lin considered>
			// purpose: exclude a possible coalescent event if it has been ignored before
			// this way, we hope to save redundent coalescents by following a single path
			//map<int,int> mapLastLinCoalIdsCfg;

			// now try to get all reachable cfgs by coalescences only
			//map< CfgLineage,int > :: iterator  it1 = const_cast<CfgConfiguration &>(*itt).mapLineages.begin(); 
			for( map< CfgLineage,int > :: iterator  it1 = const_cast<CfgConfiguration &>(*itt).mapLineages.begin(); 
			it1 != const_cast<CfgConfiguration &>(*itt).mapLineages.end(); ++it1 )
			//for( set< CfgLineage > :: iterator  it3 = itt->setLinLastAdded.begin(); it3 != itt->setLinLastAdded.end(); ++it3 )
			{

				//YW_ASSERT_INFO(itt->GetLastAddedLin() != NULL, "Can not be NULL");
//cout << "For the current lineage, the last added lineage = ";
//itt->GetLastAddedLin().Dump();

				// continue if this lineage is not allowed to coalesce
				//if( it1->first.IsCoalescentAllowed() == false)
				//{
				//	continue;
				//}

				//mapLastLinCoalIdsCfg.insert( map<int,int> :: value_type(it1->first.GetLinId(), -1) );

				map< CfgLineage,int > :: iterator  it2 = it1;
				it2++;
				//map< CfgLineage,int > :: iterator  it2 = const_cast<CfgConfiguration &>(*itt).mapLineages.begin();
				for( ; it2 != const_cast<CfgConfiguration &>(*itt).mapLineages.end(); ++it2 )
				{
					// continue if this lineage is not allowed to coalesce
					//if( ( it1->first.IsCoalescentAllowed() == false && it2->first.IsCoalescentAllowed() == true)  ||
					//	( it1->first.IsCoalescentAllowed() == true && it2->first.IsCoalescentAllowed() == false)  )
					//{
					//	continue;
					//}

					//if( it2->first == itt->GetLastAddedLin() )
					//{
					//	// must coalescent with the last added lineage
					//	continue;
					//}
					//if( it2->first == *it3)
					//{
					//	continue;
					//}


					// ensure one of the two lineages are earlier than other coalesced lineages
					int linId1 = it1->first.GetLinId();
					int linId2 = it2->first.GetLinId();
					OrderInt( linId1, linId2);
					YW_ASSERT_INFO( linId1 == it1->first.GetLinId(), "Ordering wrong" );
#if 0
					YW_ASSERT_INFO( mapLastLinCoalIdsCfg[linId1] < linId2, "Mapped lin ids wrong" );
					// skip if this has been explored before
					if( const_cast<CfgConfiguration &>(*itt).mapLastLinCoalIds.find(linId1) != 
						const_cast<CfgConfiguration &>(*itt).mapLastLinCoalIds.end() && 
						const_cast<CfgConfiguration &>(*itt).mapLastLinCoalIds[linId1] >= linId2  )
					{
#ifdef DUMP_CFG_DEBUG_MORE
cout << "linId1 = " << linId1 << ", linId2 = " << linId2 << endl;
cout << "have been explored before\n";
#endif

//						continue;
					}
					mapLastLinCoalIdsCfg[linId1] = linId2;
#endif

					bool fBypass = false;

#ifdef DUMP_CFG_DEBUG_MORE
cout << "linId1 = " << linId1 << ", linId2 = " << linId2 << endl;
//cout << "Coalescent fails\n";
#endif
#if 0
					for( map< CfgLineage,int > :: iterator  it3 = const_cast<CfgConfiguration &>(*itt).mapLineages.begin(); 
						it3 != const_cast<CfgConfiguration &>(*itt).mapLineages.end(); ++it3 )
					{
						if( it3 == it1 || it3 == it2)
						{
							continue;
						}
						// 
						int idChild1 = -1;
						int idChild2 = -1;
						CfgLineage::GetChildrenId( it3->first.GetLinId(), idChild1, idChild2 );
						//CfgLineage::GetMaxLowMinHighCoalIn( it3->first.GetLinId(), idChild1, idChild2 );
//cout << "it3's id = " << it3->first.GetLinId() << " has child1 = " << idChild1 << ", child2 = " << idChild2 << endl;
						if(  idChild1 >= 0 && (  linId1 < idChild1  || (linId1 == idChild1 && linId2 < idChild2)  )   )
						{
#ifdef DUMP_CFG_DEBUG_MORE
cout << "it3's id = " << it3->first.GetLinId() << " has child1 = " << idChild1 << ", child2 = " << idChild2;
cout << ": BYPASSED\n";
#endif
							fBypass = true;
							break;
						}
					}
#endif
					// must be feasible after coalescing
					// continue...
					CfgLineage linNew;
					//if( linNew.GetLinId() < linIdNewestCoal  )
					//{
					//	// do not allow out-of-order coalescent
					//	fBypass = true;
					//}
					//if( linId2 < linIdNewestRet  )
					//{
					//	// do not allow too late coalescent comparing with latest reticulation
					//	fBypass = true;
					//}

					if( fBypass == true)
					{
						cfgExplorer.IncUselessCoal();
						continue;
					}

					bool fCoalStepRes = it1->first.CoalesceWith(it2->first, linNew);
					//bool fCoalStepRes = itt->GetLastAddedLin().CoalesceWith(it2->first, linNew);
					//bool fCoalStepRes = it3->CoalesceWith(it2->first, linNew);
					if( fCoalStepRes == false)
					{
#ifdef DUMP_CFG_DEBUG_MORE
cout << "Coalescent fails\n";
#endif
						cfgExplorer.IncUselessCoal();
						continue;
					}
					// store it
					linNew.AssignDistinctId( it1->first.GetLinId(), it2->first.GetLinId() );
					CfgLineage::AddCoalLineageToCache(linNew.linId, linNew);


					//if( linNew.IsCoalButNoFusion() == true)
					//{
//cout << ">>>THIS CFG IS COAL BUT NO FUSION>>>>\n";
					//	this->fCoalButNoFusion = true;
					//}


					if( setLinIdsCurr.find( linNew.GetLinId() ) != setLinIdsCurr.end() )
					{
#ifdef DUMP_CFG_DEBUG_MORE
cout << "No new coalescent lineage created\n";
#endif
						// must create a novel lineage
						cfgExplorer.IncUselessCoal();
						continue;
					}

					// is this coalescent redundent; for now, only test when one of the coalesced lineage
					// is a merge but no fusion lineage
					if( (it1->first.IsCoalButNoFusion() == true  || it2->first.IsCoalButNoFusion() == true) 
						&& it1->first.IsCoalRedundent(it2->first, linNew) == true)
					{
#ifdef DUMP_CFG_DEBUG_MORE
cout << "Coalescent: redundent\n";
cout << "************Redundent: lin1 = ";
it1->first.Dump();
cout << "Redudent lin2 = ";
it2->first.Dump();
cout << "redudent new = " ;
linNew.Dump();
cout << ".... this is from config: ";
itt->Dump();
#endif
						cfgExplorer.IncUselessCoal();
						continue;
					}

#if 0
					// check to see if there are new things in it
					//bool fNewNodeEveryTree = false;
					//if(fApproxMode == true || fNearOptMode == true )
					{
						// YW: 01/22/12: if a coalescent leads to a new cluster every input tree, take it
						//bool fAbort = true;
						set<int> nodesInLin;
						linNew.GetCoveredNodes( nodesInLin );
						// check each 
						set<int> setTreesForNodes;
						for( set<int> :: iterator itt2 = nodesInLin.begin(); itt2 != nodesInLin.end(); ++itt2)
						{
							if( setNodeDescIdCurr.find(*itt2) == setNodeDescIdCurr.end() )
							{
								//fAbort = false;
								//break;
								int tid = GeneTreeInfo::Instance().GetTreeIdForNode(*itt2);
								setTreesForNodes.insert(tid);
							}
						}
						if( (int)setTreesForNodes.size() == GeneTreeInfo::Instance().GetNumGeneTrees() )
						{
							fCommonSubtree = true;
							//cfgCommonSubtree = *itt;
							//fNewNodeEveryTree = true;
						}

						//if( fAbort == true)
						//{
//cout << "This lineage is not novel enough. ABORT\n";
//linNew.Dump();
						//	cfgExplorer.IncUselessCoal();
						//	continue;
						//}
					}
#endif


#if 0
// it seems worked but not very powerful and slower
					if(setLinDescIdCurr.find(linNew.GetLinId() ) != setLinDescIdCurr.end() )
					{
//cout << "Filtered out due to old descendent ids\n";
//cout << "Coalescing lineage: ";
//it1->first.Dump();
//cout << "and lineage: ";
//it2->first.Dump();
//cout << "new lineage: ";
//linNew.Dump();
//cout << "In config: ";
//itt->Dump();
						cfgExplorer.IncUselessCoalDesc();
						continue;
					}
#endif

//cout << "Coalescing lineage: ";
//it1->first.Dump();
//cout << "and lineage: ";
//it2->first.Dump();
//cout << "which becomes ";
//linNew.Dump();
					// 
					CfgConfiguration cfgNew = *itt;
					cfgNew.SetDistinctId();
					cfgNew.SetSrcCfgId( itt->GetId() );
#if 0
					// update coalescent bound
					for( map<int,int> :: iterator ittm = mapLastLinCoalIdsCfg.begin(); ittm != 	mapLastLinCoalIdsCfg.end(); ++ittm)
					{
						if( cfgNew.mapLastLinCoalIds.find( ittm->first) == cfgNew.mapLastLinCoalIds.end() )
						{
							cfgNew.mapLastLinCoalIds.insert( *ittm );
						}
						else if( cfgNew.mapLastLinCoalIds[ittm->first] < ittm->second )
						{
							cfgNew.mapLastLinCoalIds[ittm->first] = ittm->second;
						}
					}
#endif
					cfgNew.RemoveLin( it2->first );
					//cfgNew.RemoveLin( itt->GetLastAddedLin() );
					cfgNew.RemoveLin( it1->first );
					//cfgNew.RemoveLin( *it3 );
					cfgNew.AddLin(linNew);
//cout << "cfgNew: ";
//cfgNew.Dump();
					if( cfgNew.IsConfigFeasible( ) == true )
					{
						int scoreCfg;
						set<int> setMinLinSrcs;
						if(cfgNew.IsConfigFeasibleStronger(&scoreCfg, &setMinLinSrcs) == false)
						{
#ifdef DUMP_CFG_DEBUG_MORE
cout << "Not feasible1\n";
#endif

							cfgExplorer.IncStrongInfeasible();
							continue;
						}
						// one more round of testing
						if( cfgNew.IsConfigFeasibleEvenStronger() == false)
						{
#ifdef DUMP_CFG_DEBUG_MORE
cout << "Not feasible2\n";
#endif

							cfgExplorer.IncEvenStrongInfeasible();
							continue;
						}

						// now clean up it
						//cfgNew.CleanExtraSrcEvts(linNew );
//cout << "setMinLinSrcs = ";
//DumpIntSet(setMinLinSrcs);
//cout << "Before cleaning, cfgNew: ";
//cfgNew.Dump();
//#if 0
						if(fApproxMode == true && cfgNew.ShrinkLineages(scoreCfg, linNew) == true)
						{
							// if a configuration can be shrunk, we assume it is not really essential
							// we keep track only the most compact ones
							cfgExplorer.IncCfgLinSrcCleaned();
							continue;
						}
//#endif
//#if 0
						if( fApproxMode == true && cfgNew.CleanExtraLins(setMinLinSrcs) == true)
						{
							cfgExplorer.IncCfgLinSrcCleaned();
//cout << "After cleaning, cfgNew: ";
//cfgNew.Dump();
						}
						cfgNew.CleanExtraLins();
//#endif
						if( cfgExplorer.CfgBeatenByPrevious( cfgNew ) == true )
						{
#ifdef DUMP_CFG_DEBUG_MORE
cout << "Beaten by a previous config\n";
#endif

							continue;
						}
//#if 0
						set<int> sint;
						//cfgNew.GetCoveredNodes( sint );
						cfgNew.GetLinIds( sint );
						if( fApproxMode == true)
						{
							if( ProcLineagesDepot :: Instance().IsCfgProcessed( cfgNew, sint ) == true )
							{
								cfgExplorer.IncUselessCoal();
								continue;
							}
						}
//#endif
						//if( fNewNodeEveryTree == true)
						//{
						//	setCfgsNextCoalStepTmpAdvCoal.insert(cfgNew);
						//}
						//
						//setCfgsNextCoalStepTmp.insert(cfgNew);
						//setCfgsNextCoal.insert( cfgNew );
						cfgExplorer.IncProcessedCfg();
//#if 0
						ProcLineagesDepot :: Instance().AddProcCfg( cfgNew, sint );
//#endif

#ifdef DUMP_CFG_DEBUG
cout << "+++ By coalescence, found a new cfg: ";
cfgNew.Dump();
#endif

#if 0
						// also add to tmp stack
						setCfgLinsCoalNext.insert( cfgNew );
#endif


						if( fApproxMode == false || setNewlCoalLineages.find( linNew ) == setNewlCoalLineages.end() )
						{
							// create a copy of this configuraiton that creates a new cfg
							//if( fNewNodeEveryTree == true)
							//{
							//	setCfgsNextCoalStepTmpAdvCoal.insert(cfgNew);
							//}
							setCfgsNextCoalStepTmp.insert(cfgNew);
							//setCfgLinsCoalNext.insert( cfgNew );
							setNewlCoalLineages.insert(linNew);
						}

						// test whether we reach the end
						if( cfgNew.IsTerminal() == true )
						{
							//setCfgsNext.insert(cfgNew);
							//return true;
							fRes = true;
						}

#if 0
						// if this config is a common-subtree-created, then will only fix on this
						// YW: 01/22/12: if a coalescent leads to a new cluster every input tree, take it
						//bool fAbort = true;
						set<int> nodesInLin;
						linNew.GetCoveredNodes( nodesInLin );
						// check each 
						set<int> setTreesForNodes;
						for( set<int> :: iterator itt2 = nodesInLin.begin(); itt2 != nodesInLin.end(); ++itt2)
						{
							if( setNodeDescIdCurr.find(*itt2) == setNodeDescIdCurr.end() )
							{
								//fAbort = false;
								//break;
								int tid = GeneTreeInfo::Instance().GetTreeIdForNode(*itt2);
								setTreesForNodes.insert(tid);
							}
						}
						if( (int)setTreesForNodes.size() == GeneTreeInfo::Instance().GetNumGeneTrees() )
						{
							fCommonSubtree = true;
							//cfgCommonSubtree = *itt;
							//fNewNodeEveryTree = true;
						}

						//if( fAbort == true)
						//{
//cout << "This lineage is not novel enough. ABORT\n";
//linNew.Dump();
						//	cfgExplorer.IncUselessCoal();
						//	continue;
						//}
						if( fCommonSubtree == true)
						{
							cfgsCommonSubtree.insert( cfgNew );
							//break;
						}
#endif
					}
					else
					{
//cout << "This configuration is not feasible; so ignore....\n";
						cfgExplorer.IncInfeasible();
					}

					if( fRes == true)
					{
						break;
					}
				}

				if( fRes == true)
				{
					break;
				}

				//if( fCommonSubtree == true)
				//{
				//	break;
				//}
			}
			// add in the found coalescent cfgs
//			if( setCfgsNextCoalStepTmpAdvCoal.size() == 0  || fApproxMode == false )
			//if(  fApproxMode == false )
			//if( fCommonSubtree == false)
			{
				for( set< CfgConfiguration > :: iterator ittg1 = setCfgsNextCoalStepTmp.begin(); ittg1 != setCfgsNextCoalStepTmp.end(); ++ittg1 )
				{
					setCfgLinsCoalNext.insert(*ittg1);

					// we keep all found cfgs if greedy flag is off
					if( fGreedyCfg == true)
					{
						// temporary add it into a list of cfgs to avoid
						setCfgIdsTerminal.insert(ittg1->GetId() );
					//	const_cast<CfgConfiguration &>(*ittg1).SetGreedyIntermediate(true);
					}
					setCfgsNextCoal.insert(*ittg1);
				}
				// 01/21/12: YW: only keep the most-coalesced lineages
				if( fGreedyCfg == true && setCfgsNextCoalStepTmp.size() == 0 )
				{
					// when greedy flag is turned on, only keep cfgs when can not continue coalescing
//					setCfgsNextCoal.insert(*itt);
					//const_cast<CfgConfiguration &>(*itt).SetGreedyIntermediate(false);
					//YW_ASSERT_INFO(setCfgsNextCoal.find(*itt) != setCfgsNextCoal.end(), "FATAL ERROR333");
					//if( setCfgsNextCoal.find(*itt) != setCfgsNextCoal.end() )
					//{
					// remove the entry
					setCfgIdsTerminal.erase( itt->GetId() );
						//const_cast<CfgConfiguration &>(*setCfgsNextCoal.find(*itt)).SetGreedyIntermediate(false);
					//}
				}
			}
#if 0
			else
			{
				for( set< CfgConfiguration > :: iterator ittg1 = cfgsCommonSubtree.begin(); ittg1 != cfgsCommonSubtree.end(); ++ittg1 )
				{

#ifdef DUMP_CFG_DEBUG_MORE
cout << "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC Follow this common-subtree configuration: \n";
ittg1->Dump();
#endif
					// only follow the single common-subtree coalescent
					setCfgsNextCoal.insert(*ittg1);
				}
			}
#endif
			//else
			//{
//if(setCfgsNextCoalStepTmp.size() > setCfgsNextCoalStepTmpAdvCoal.size())
//{
//cout << "Preferred coalescent histories found: ";
//cout << setCfgsNextCoalStepTmpAdvCoal.size()  << " from original " << setCfgsNextCoalStepTmp.size() << endl;
//}
				// in this case only
				//for( set< CfgConfiguration > :: iterator ittg1 = setCfgsNextCoalStepTmpAdvCoal.begin(); ittg1 != setCfgsNextCoalStepTmpAdvCoal.end(); ++ittg1 )
				//{
				//	setCfgLinsCoalNext.insert(*ittg1);
				//	setCfgsNextCoal.insert(*ittg1);
				//}
				//cfgExplorer.IncBypassedCfgsByPreferCoals( setCfgsNextCoalStepTmp.size() - setCfgsNextCoalStepTmpAdvCoal.size()  );
			//}
		}
		//if( setCfgLinsCoalNext.size() == 0)
		//{
		//	// only when we have exhausted all ways of caolescents, we stop 
		//	for( set< CfgConfiguration > :: iterator ittg1 = setCfgLinsCoal.begin(); ittg1 != setCfgLinsCoal.end(); ++ittg1 )
		//	{
		//		setCfgLinsCoalNext.insert(*ittg1);
		//	}
		//	break;
		//}
		// 
		setCfgLinsCoal = setCfgLinsCoalNext;

		if( fRes == true)
		{
			break;
		}
	}
#if 0
	int numRetLins = 0;
	for( map< CfgLineage,int > :: iterator  it = mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		if( it->first.IsReticulateLineage() == true)
		{
			numRetLins += it->second;
		}
	}
#endif

//	if( setCfgsNextCoal.size() > 0 || numRetLins <=1)
	{
		//if( fGreedyCfg == false )
		//{
			// add two things to next confgurations to explore
			for( set< CfgConfiguration > :: iterator it = setCfgsNextRet.begin(); it != setCfgsNextRet.end(); ++it )
			{
				setCfgsNext.insert(*it);
			}
		//}
//#if 0
// do not queue this since we will re-do the coalescent again
		for( set< CfgConfiguration > :: iterator it = setCfgsNextCoal.begin(); it != setCfgsNextCoal.end(); ++it )
		{
			CfgConfiguration cfg = *it;
			if( setCfgIdsTerminal.find( cfg.GetId() ) != setCfgIdsTerminal.end() )
			{
				cfg.SetGreedyIntermediate(true);
			}
			else
			{
				cfg.SetGreedyIntermediate(false);
			}
			setCfgsNext.insert(cfg);
		}
//#endif
	}
//	else
//	{
//		cfgExplorer.IncEarlyTermCfg();
//	}

	// return false if we have not yet reached the destination
	return fRes;
}

#if 0
const int NUM_TOP_CLASS_PROC = 5;

bool CfgConfiguration :: GetNextCfgsPriority( set<CfgConfiguration> &setCfgsNext, CfgExplorer &cfgExplorer )
{
	// now put some objective in searching: prefer those more likely to lead to good cfgs first
	// can be equivalent to the original exploring
	// score: total amount of tree coverage
	setLinLastAdded.clear();

	map<int, set<CfgConfiguration> > mapCfgsToExplore;

	// try one reticulation, and all possible coalescences
	//setCfgsNext.clear();
	for( map< CfgLineage,int > :: iterator  it = mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		// split this lineage
YW_ASSERT_INFO( it->second >= 1, "Must have at least one copy");

		// get the newest linid as coalescent lineage
		int linIdNewestCoal = -1;
		int linIdNewestCoalChildMax = -1;
		int linIdNewestRet = -1;

		for( map< CfgLineage,int > :: iterator  itg = mapLineages.begin(); itg != mapLineages.end(); ++itg )
		{
			int idChild1 = -1;
			int idChild2 = -1;
			CfgLineage::GetChildrenId( itg->first.GetLinId(), idChild1, idChild2 );
			if(  idChild2 >= 0 &&  itg->first.GetLinId() >  linIdNewestCoal  )
			{
				linIdNewestCoal = itg->first.GetLinId();
			}
			if( idChild1 > linIdNewestCoalChildMax)
			{
				linIdNewestCoalChildMax = idChild1;
			}
			if( idChild2 > linIdNewestCoalChildMax)
			{
				linIdNewestCoalChildMax = idChild2;
			}
			if( itg->first.IsReticulateLineage() == true )
			{
				linIdNewestRet = itg->first.GetLinId();
			}
		}
		// a coalescent result, then only allow reticulation if it is the currently largest one
		if( linIdNewestCoal >= 0 && it->first.GetLinId()  != linIdNewestCoal )
		{
			// can not reticulate
			cfgExplorer.IncUselessRet();
			continue;
		}
		if( linIdNewestRet >= 0 && it->first.GetLinId() < linIdNewestRet )
		{
			// can not reticulate
			cfgExplorer.IncUselessRet();
			continue;
		}
		if( linIdNewestCoalChildMax >= 0 && it->first.GetLinId() < linIdNewestCoalChildMax)
		{
			// a reticulation must be earlier than involved coalescent
			cfgExplorer.IncUselessRet();
			continue;
		}

		CfgConfiguration cfgNew = *this;
		if( it->second == 1  && it->first.IsReticulateLineage() == false  )
		{
			int revtIdNew = CreateNextRetEvt(  it->first);
	//cout << "A new reticulation event: " << revtIdNew << endl;
			cfgNew.RemoveLin( it->first );
	//cout << "pass0.1\n";
			int numCopies =  it->second +1;
			CfgLineage linNew1 = it->first;
			linNew1.AddRetEvt( revtIdNew );
			linNew1.SetFlagCoalButNoFusion(false);		// enable coalescent
	//cout << "pass0.2\n";
			cfgNew.AddLin( linNew1, numCopies);
			// clean up the src evets after this addition
			cfgNew.CleanExtraSrcEvts( linNew1, revtIdNew );
	//cout << "pass1\n";
		}
		else
		{
			// simply increase the copy
			cfgNew.IncNumLins( it->first );
		}
		// 
		if( cfgExplorer.CfgBeatenByPrevious( cfgNew ) == true )
		{
			continue;
		}

		setCfgsNext.insert( cfgNew );
		cfgExplorer.IncProcessedCfg();
		// now add it to the next stage
		int cfgPriority = 0;
		cfgNew.EvalCfgPriority(cfgPriority);
		// add to map
		if( mapCfgsToExplore.find(cfgPriority) == mapCfgsToExplore.end() )
		{
			set<CfgConfiguration> setCfgs;
			mapCfgsToExplore.insert( map<int, set<CfgConfiguration> > :: value_type(cfgPriority, setCfgs) );
		}
		mapCfgsToExplore[cfgPriority].insert(cfgNew);


#ifdef DUMP_CFG_DEBUG
cout << "---- By reticulation, found a new cfg: ";
cfgNew.Dump();
#endif
	}

	int numClassProc = 0;
	int lastPrior = HAP_MAX_INT;
	while(true)
	{
// set of cfgs with priority
//cout << "@@@@@@GetNextCfgsPriority: current configurations = \n";
//for( map<int, set<CfgConfiguration> > :: iterator ittg = mapCfgsToExplore.begin(); ittg != mapCfgsToExplore.end(); ++ittg )
//{
//cout << "#### PRIORITY " << ittg->first << endl;
//for( set<CfgConfiguration> :: iterator ittg2 = ittg->second.begin(); ittg2 != ittg->second.end(); ++ittg2 )
//{
//ittg2->Dump();
//}
//}

		// extract the lowest key's config
		YW_ASSERT_INFO( (mapCfgsToExplore.begin())->second.size() > 0, "Can not have empty lists" );
		CfgConfiguration cfgCurr = *((mapCfgsToExplore.begin())->second.begin() );
		(mapCfgsToExplore.begin())->second.erase( (mapCfgsToExplore.begin())->second.begin() );
		if( (mapCfgsToExplore.begin())->second.size() == 0 )
		{
			int curPrior = (mapCfgsToExplore.begin())->first;

			mapCfgsToExplore.erase( mapCfgsToExplore.begin() );
			if( curPrior < lastPrior)
			{
				numClassProc++;
				lastPrior = curPrior;
			}
			if( numClassProc >= NUM_TOP_CLASS_PROC )
			{
				// done
				break;
			}
		}

#ifdef DUMP_CFG_DEBUG
cout << "oooooooooooooooooExplore configurations by coalescing, prioty = " << (mapCfgsToExplore.begin())->first << endl;
cfgCurr.Dump();
#endif
		set<int> setLinIdsCurr;
		cfgCurr.GetLinIds(setLinIdsCurr);

		// now try to get all reachable cfgs by coalescences only
		for( map< CfgLineage,int > :: iterator  it1 = cfgCurr.mapLineages.begin(); it1 != cfgCurr.mapLineages.end(); ++it1 )
		{
			map< CfgLineage,int > :: iterator  it2 = it1;
			it2++;
			//map< CfgLineage,int > :: iterator  it2 = const_cast<CfgConfiguration &>(*itt).mapLineages.begin();
			for( ; it2 != cfgCurr.mapLineages.end(); ++it2 )
			{
				// ensure one of the two lineages are earlier than other coalesced lineages
				int linId1 = it1->first.GetLinId();
				int linId2 = it2->first.GetLinId();
				OrderInt( linId1, linId2);
				bool fBypass = false;

//#if 0
				for( map< CfgLineage,int > :: iterator  it3 = cfgCurr.mapLineages.begin(); it3 != cfgCurr.mapLineages.end(); ++it3 )
				{
					if( it3 == it1 || it3 == it2)
					{
						continue;
					}
					// 
					int idChild1 = -1;
					int idChild2 = -1;
					CfgLineage::GetChildrenId( it3->first.GetLinId(), idChild1, idChild2 );
					if(  idChild1 >= 0 && (  linId1 < idChild1  || (linId1 == idChild1 && linId2 < idChild2)  )   )
					{
						fBypass = true;
						break;
					}
				}
//#endif
				// must be feasible after coalescing
				// continue...
				CfgLineage linNew;

				if( fBypass == true)
				{
					cfgExplorer.IncUselessCoal();
					continue;
				}

				bool fCoalStepRes = it1->first.CoalesceWith(it2->first, linNew);
				linNew.AssignDistinctId( it1->first.GetLinId(), it2->first.GetLinId() );
				//bool fCoalStepRes = itt->GetLastAddedLin().CoalesceWith(it2->first, linNew);
				//bool fCoalStepRes = it3->CoalesceWith(it2->first, linNew);
				if( fCoalStepRes == false)
				{
					cfgExplorer.IncUselessCoal();
					continue;
				}
				if( setLinIdsCurr.find( linNew.GetLinId() ) != setLinIdsCurr.end() )
				{
					// must create a novel lineage
					cfgExplorer.IncUselessCoal();
					continue;
				}
//cout << "Coalescing lineage: ";
//it1->first.Dump();
//cout << "and lineage: ";
//it2->first.Dump();
//cout << "which becomes ";
//linNew.Dump();
				// 
				CfgConfiguration cfgNew = cfgCurr;
				cfgNew.RemoveLin( it2->first );
				//cfgNew.RemoveLin( itt->GetLastAddedLin() );
				cfgNew.RemoveLin( it1->first );
				//cfgNew.RemoveLin( *it3 );
				cfgNew.AddLin(linNew);
//cout << "cfgNew: ";
//cfgNew.Dump();
				if( cfgNew.IsConfigFeasible( ) == true )
				{
					if(cfgNew.IsConfigFeasibleStronger() == false)
					{
						cfgExplorer.IncStrongInfeasible();
						continue;
					}
					// one more round of testing
					if( cfgNew.IsConfigFeasibleEvenStronger() == false)
					{
						cfgExplorer.IncEvenStrongInfeasible();
						continue;
					}

					// now clean up it
					cfgNew.CleanExtraSrcEvts( linNew );
					cfgNew.CleanExtraLins();

					if( cfgExplorer.CfgBeatenByPrevious( cfgNew ) == true )
					{
						continue;
					}

					// 
					setCfgsNext.insert( cfgNew );
					cfgExplorer.IncProcessedCfg();

#ifdef DUMP_CFG_DEBUG
cout << "+++ By coalescence, found a new cfg: ";
cfgNew.Dump();
#endif
					// also add to tmp stack
					//setCfgLinsCoalNext.insert( cfgNew );
					int cfgPriority = 0;
					cfgNew.EvalCfgPriority(cfgPriority);
					// add to map
					if( mapCfgsToExplore.find(cfgPriority) == mapCfgsToExplore.end() )
					{
						set<CfgConfiguration> setCfgs;
						mapCfgsToExplore.insert( map<int, set<CfgConfiguration> > :: value_type(cfgPriority, setCfgs) );
					}
					mapCfgsToExplore[cfgPriority].insert(cfgNew);


					// test whether we reach the end
					if( cfgNew.IsTerminal() == true )
					{
						return true;
					}

				}
				else
				{
					cfgExplorer.IncInfeasible();
				}
			}
		}
		// stop when no more
		if( mapCfgsToExplore.size() == 0)
		{
			break;
		}
	}



	// return false if we have not yet reached the destination
	return false;
}
#endif


void CfgConfiguration :: AddLin( CfgLineage &lin ) 
{ 
	if( mapLineages.find( lin) == mapLineages.end() )
	{
		mapLineages.insert( map<CfgLineage,int>:: value_type(lin,1) ); 
	}
	else
	{
		mapLineages[lin]++;
	}
	setLinLastAdded.insert( lin );
}

void CfgConfiguration :: AddLin( CfgLineage &lin, int nc ) 
{ 
	if( mapLineages.find( lin) == mapLineages.end() )
	{
		mapLineages.insert( map<CfgLineage,int>:: value_type(lin,nc) ); 
	}
	else
	{
		mapLineages[lin] = nc;
	}
	setLinLastAdded.insert( lin );
	//mapLineages.insert( map<CfgLineage,int>:: value_type(lin,nc) ); 
}

void CfgConfiguration :: RemoveLin(const CfgLineage &lin) 
{ 
	if( mapLineages.find( lin) == mapLineages.end() )
	{
		cout << "Have trouble in finding this lin to delete:";
		lin.Dump();
		cout << "FROM: ";
		this->Dump();
	}
	YW_ASSERT_INFO( mapLineages.find( lin) != mapLineages.end(), "Fail to delete" );
	if( mapLineages[lin] == 1 )
	{
		mapLineages.erase(lin); 

		// remove the copy from last-added-list
		setLinLastAdded.erase( lin );
	}
	else
	{
		//
		mapLineages[lin]--;
		//const_cast<CfgLineage&>(*listLins.find( lin)).DecCopyNumByOne();
		//const_cast<CfgLineage&>(lin).DecCopyNumByOne();
	}
}


// initialize an config as the number of species lineage
void CfgConfiguration :: InitStart()
{
	mapLineages.clear();

	set<int> setLvIds;
	GeneTreeInfo::Instance().GetLeafTaxa(0, setLvIds);
//cout << "Leave taxa: ";
//DumpIntSet( setLvIds );

	//int numTaxa = GeneTreeInfo:: Instance().GetNumSpecies();
//cout << "Num taxa: " << numTaxa << endl;
	//for(int t=0; t<numTaxa; ++t)
	for( set<int> :: iterator it = setLvIds.begin(); it != setLvIds.end(); ++it )
	{
		int lvId = *it;
		// create a gene lineage
		CfgLineage clin;
		clin.AssignDistinctId(-1*(lvId+1),-1*(lvId+1));
		// src is from each tree at each extant taxa
		for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
		{
			int linId = GeneTreeInfo:: Instance().GetLeafIdInTree( tr, lvId);
//cout << "Tree " << tr << ", taxa " << lvId  << ", linId = " << linId << endl;
			CfgLineageSrc linsrc(linId);
			//clin.AddSrc( linsrc, true );
			clin.AddSrc( linsrc);
		}
		AddLin(clin);
		//		mapLineages.insert( map< CfgLineage, int> :: value_type(  clin, 1 )  );

		CfgLineage::AddCoalLineageToCache(clin.linId, clin);
	}
}


bool CfgConfiguration :: IsConfigFeasible( )
{
//cout << "IsConfigFeasible: ";
//Dump();
	set<int> setNodeIds;
	GetAllCoveredNodes( setNodeIds );
//cout << "setNodeIds: ";
//DumpIntSet( setNodeIds );
	// is root of each tree derviable, if yes, feasible
	for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
	{
		int rid = GeneTreeInfo:: Instance().GetRootId(tr);
//cout << "rid for tree " << tr << ": " << rid << endl;
		if(setNodeIds.find(rid) == setNodeIds.end())
		{
//cout << "XXXXXX INFEASIBLE\n";
			return false;
		}
	}
	return true;
#if 0
	// is the configuration allowed (as the product of coalesce these two lineages)?
	// we can if we can still dervie all trees after this marging
	// approach: traverse each gene tree top-down; 
	// stop once reaching a node that is in the config;
	// not feasible if we ever reach a leaf that is not in this config
	for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
	{
		// 
		GeneTreeIterator gtItor(tr);
		gtItor.Init();
		while( gtItor.IsDone() == false )
		{
			// 
			int nodeId = gtItor.GetNodeId( );
			if( IsNodeContained(nodeId) == true )
			{
				// backout
//cout << "Moving back...\n";
				gtItor.Back();
			}
			else
			{
				// declare not feasible if it is a leaf
				if( gtItor.IsLeaf() == true  )
				{
//cout << "INFEASIBLE: For tree " << tr << ", this leaf is reached: " << gtItor.GetNodeId() << endl; 
					return false;
				}

				// continue
//cout << "Moving forward...\n";
				gtItor.Next();
			}
		}
	}
	// now enforce stronger condition
//	if( IsConfigFeasibleStronger() == false)
//	{
//cout << "******NOT FEASIBLE IN A STRONG SENSE: \n";
//Dump();
//		return false;
//	}
//cout << "******Yes FEASIBLE IN A STRONG SENSE: \n";
//Dump();

	return true;
#endif
}

bool CfgConfiguration :: IsConfigFeasibleStronger(int *pScore, set<int> *pSetCoveredNodes)
{
//return true;
	int sumTreeCoverage;
	bool res = EvalCfgPriorityVer2(sumTreeCoverage, pSetCoveredNodes);
	if( pScore != NULL)
	{
		*pScore = sumTreeCoverage;
	}
//if( res == false )
//{
//// dump it
//cout << "********** Strongly infeasible: \n";
//this->Dump();
//cout << "*******************************\n";
//exit(1);
//}

//	int sumTreeCoverage2;
//	bool res2 = EvalCfgPriorityVer2(sumTreeCoverage2);
//cout << "sumTreeCoverage = " << sumTreeCoverage << ", sumTreeCoverage2 = " << sumTreeCoverage2 << endl;
//	YW_ASSERT_INFO( res == res2 && sumTreeCoverage == sumTreeCoverage2, "FAIL in EvalCfgPriorityVer2" );
	return res;
}

bool CfgConfiguration :: IsConfigFeasibleEvenStronger()
{
return true;
	if( fApproxMode == false )
	{
		return true;
	}
	// continue if only one or two lineage is left
	if( mapLineages.size() <= 2 )
	{
		return true;
	}

	// inc copy num of the latest lineage by one and check whether
	// coalescing pairs of those are feasible or not
	// if none of those coalescents are feasible, ignore this as well
	CfgConfiguration cfgExpand = *this;
	cfgExpand.mapLineages.rbegin()->second++;		// increase the number of copy of the latest item by one
//cout << "IsConfigFeasibleEvenStronger::cfgExpand: ";
//cfgExpand.Dump();
	bool fShouldContinue = false;

	// now try to get all reachable cfgs by coalescences only
	for( map< CfgLineage,int > :: iterator  it1 = cfgExpand.mapLineages.begin(); 	it1 != cfgExpand.mapLineages.end(); ++it1 )
	{
		map< CfgLineage,int > :: iterator  it2 = it1;
		it2++;
		for( ; it2 != cfgExpand.mapLineages.end(); ++it2 )
		{
			// ensure one of the two lineages are earlier than other coalesced lineages
			int linId1 = it1->first.GetLinId();
			int linId2 = it2->first.GetLinId();
			OrderInt( linId1, linId2);
			bool fBypass = false;
//cout << "lindId1 = " << linId1 << ", linId2 = " << linId2 << endl;
//#if 0
			for( map< CfgLineage,int > :: iterator  it3 = cfgExpand.mapLineages.begin(); it3 != cfgExpand.mapLineages.end(); ++it3 )
			{
				if( it3 == it1 || it3 == it2)
				{
					continue;
				}
				// 
				int idChild1 = -1;
				int idChild2 = -1;
				CfgLineage::GetChildrenId( it3->first.GetLinId(), idChild1, idChild2 );
				if(  idChild1 >= 0 && (  linId1 < idChild1  || (linId1 == idChild1 && linId2 < idChild2)  )   )
				{
					fBypass = true;
					break;
				}
			}
//#endif
			// must be feasible after coalescing
			// continue...
			CfgLineage linNew;

			if( fBypass == true)
			{
//cout << "Bypassed1\n";
				continue;
			}

			bool fCoalStepRes = it1->first.CoalesceWith(it2->first, linNew);
			if( fCoalStepRes == false)
			{
//cout << "Bypassed2\n";
				continue;
			}
			// store it
			linNew.AssignDistinctId( it1->first.GetLinId(), it2->first.GetLinId() );
			CfgLineage::AddCoalLineageToCache(linNew.linId, linNew);

			//if( setLinIdsCurr.find( linNew.GetLinId() ) != setLinIdsCurr.end() )
			//{
			//	continue;
			//}
//cout << "Coalescing lineage: ";
//it1->first.Dump();
//cout << "and lineage: ";
//it2->first.Dump();
//cout << "which becomes ";
//linNew.Dump();
			// 
			CfgConfiguration cfgNew = cfgExpand;
			cfgNew.RemoveLin( it2->first );
			cfgNew.RemoveLin( it1->first );
			cfgNew.AddLin(linNew);
//cout << "cfgNew: ";
//cfgNew.Dump();
			if( cfgNew.IsConfigFeasible( ) == true )
			{
				if(cfgNew.IsConfigFeasibleStronger() == false)
				{
//cout << "Bypassed3\n";
					continue;
				}

				// now should continue
				fShouldContinue = true;
				break;
			}
			else
			{
//cout << "Bypassed3.1\n";
			}
		}
		if( fShouldContinue == true)
		{
			break;
		}
	}
#ifdef DUMP_CFG_DEBUG
//if(fShouldContinue == false)
//{
//cout << "+++++++++++++++This config is dropped due to even stronger infeasiblity test\n";
//Dump();
//}
#endif
	return fShouldContinue;
}


bool CfgConfiguration :: EvalCfgPriority(int &sumTreeCoverage)
{
	// now simply return the version 2 result
	return EvalCfgPriorityVer2(sumTreeCoverage);
	// assign a score on the priority of this config

// disable for now
//return true;
//cout << "-----Inside EvalCfgPriority\n";
//Dump();
	// a stronger but slower check whether the current config is feasible
	// Idea: each lineage can only contribute a single node for each tree
	// and the combined nodes must cover the entire tree

	vector< set<int> > listCoveredNodesByLins;
	for( map< CfgLineage,int > :: iterator  it = mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		set<int> sint;
		it->first.GetCoveredNodes(sint);
		// can not have empty covered nodes
		//YW_ASSERT_INFO( sint.size() > 0, "Must cover something" );
		listCoveredNodesByLins.push_back(sint);
	}
	// knows how many leaves covered by each node
	sumTreeCoverage = 0;

	for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
	{
//cout << "Processing TREE " << tr << endl;
		// obtain for each lineage the set of non-ancestral nodes
		vector< vector<int> > listNonAncesNodes( listCoveredNodesByLins.size() );

		GeneTreeIterator gtItor(tr);
		gtItor.Init();
		while( gtItor.IsDone() == false )
		{
			// 
			int nodeId = gtItor.GetNodeId( );
			for( int i=0; i<(int)listCoveredNodesByLins.size(); ++i )
			{
				if( listCoveredNodesByLins[i].find(nodeId) != listCoveredNodesByLins[i].end() )
				{
					// make sure non ancestral relation exists
					bool fAdd = true;
					for(int j=0; j<(int)listNonAncesNodes[i].size(); ++j )
					{
						if( GeneTreeInfo::Instance().IsNodeDescendentOf(nodeId, listNonAncesNodes[i][j] ) == true  )
						{
							fAdd = false;
							break;
						}
					}
					if( fAdd == true)
					{
						listNonAncesNodes[i].push_back(nodeId);
					}
				}
			}

			// continue
//cout << "Moving forward...\n";
			gtItor.Next();
		}
//cout << "listNonAncesNodes: \n";
//for(int iii=0; iii<(int)listNonAncesNodes.size(); ++iii)
//{
//DumpIntVec( listNonAncesNodes[iii]);
//}

		bool fFoundCover = false;
		// try a subset of lineages up to the whole number
		//for(int szLinsInSS = (int)listNonAncesNodes.size(); szLinsInSS >= 1; --szLinsInSS)
		int szLinsInSS = 1;
		for(; szLinsInSS <= (int)listNonAncesNodes.size(); ++szLinsInSS)
		{
			vector<int> posvec;
			GetFirstCombo(szLinsInSS, (int)listNonAncesNodes.size(), posvec);

			while(true)
			{
				// now enumerate the lineages
				// make sure no lineage is empty
				vector<int> senum, senumLimit;
				for(int i=0; i<(int)posvec.size(); ++i)
				{
//		cout << "Tree " << tr << ": lineage " << i << ": listNonAncesNodes: ";
//		DumpIntVec( listNonAncesNodes[i] );
					// 
					//YW_ASSERT_INFO( listNonAncesNodes[posvec[i] ].size() > 0, "Fail333" );
					senum.push_back(0);
					senumLimit.push_back( listNonAncesNodes[  posvec[i] ].size());
				}
				while(true)
				{
					// start enum
					// test whether the choice is pairwise non-ancestral
					bool fIncompat = false;

					for( int ii=0; ii<(int)senum.size(); ++ii )
					{
						if( listNonAncesNodes[posvec[ii] ].size() == 0)
						{
							continue;
						}
						int idNode1 = listNonAncesNodes[posvec[ii] ][senum[ii] ];
						for(int jj=ii+1; jj<(int)senum.size(); ++jj)
						{
							if( listNonAncesNodes[posvec[jj] ].size() == 0)
							{
								continue;
							}
							int idNode2 = listNonAncesNodes[posvec[jj] ][senum[jj] ];
							if( GeneTreeInfo::Instance().IsNodeDescendentOf(idNode1, idNode2) == true ||  
								GeneTreeInfo::Instance().IsNodeDescendentOf(idNode2, idNode1) == true )
							{
								fIncompat = true;
								break;
							}
						}
						if( fIncompat == true)
						{
//		cout << "Incompatible!\n";
//		for(int kkk=0; kkk<(int)senum.size(); ++kkk)
//		{
//		cout << "[" << senum[kkk] << "]" << listNonAncesNodes[posvec[kkk] ][senum[kkk] ] << "  ";
//		}
//		cout << endl;
							break;
						}
					}

					// then check if the added sum is equal to the whole set of taxa
					if( fIncompat == false)
					{
//cout << "Good: compatible\n";
						// check size
						int szTot = 0;
						for(int iii=0; iii<(int)senum.size(); ++iii)
						{
							if( listNonAncesNodes[posvec[iii] ].size() == 0)
							{
								continue;
							}
							int szStep = GeneTreeInfo::Instance().GetNumDescLeaves( listNonAncesNodes[posvec[iii] ][senum[iii] ] );
							szTot += szStep;
						}
//cout << "Sztot = " << szTot << endl;
						if(szTot == GeneTreeInfo::Instance().GetNumSpecies() )
						{
// results
//cout << "Coverage lineages: ";
//for(int iii=0; iii<(int)senum.size(); ++iii)
//{
//if( listNonAncesNodes[posvec[iii] ].size() == 0)
//{
//continue;
//}
//cout << listNonAncesNodes[posvec[iii] ][senum[iii] ];
//cout << "  ";
//}
//cout << endl;

							fFoundCover = true;
							break;
						}
					}

					// move on
					if( GetNextEnumVec( senum, senumLimit) == false )
					{
						break;
					}
				}
				if( fFoundCover == true)
				{
					break;
				}

				// try next combo
				if( GetNextCombo(szLinsInSS, (int)listNonAncesNodes.size(), posvec) == false )
				{
					break;
				}
			}
			if( fFoundCover == true)
			{
				break;
			}
		}



		if( fFoundCover == false)
		{
//cout << "-----Out of EvalCfgPriority (fail to find)\n";
			return false;
		}

		// update coverage
		sumTreeCoverage += szLinsInSS;


	}
//cout << "-----Out of EvalCfgPriority\n";

	return true;
}

bool CfgConfiguration :: EvalCfgPriorityVer2(int &sumTreeCoverage, set<int> *pListMinCoveredNodes)
{
//cout << "-----Inside EvalCfgPriorityVer2\n";
//Dump();
	// a different and (should be) faster implmenetion of the same test
	// approach: bottom up; at each node of a tree, maintain a list of lineage sets
	// that can derive that node; combine the info at children (and self) as moving up
	vector< set<int> > listCoveredNodesByLins;
	for( map< CfgLineage,int > :: iterator  it = mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		set<int> sint;
		it->first.GetCoveredNodes(sint);
		// can not have empty covered nodes
		//YW_ASSERT_INFO( sint.size() > 0, "Must cover something" );
		listCoveredNodesByLins.push_back(sint);
	}
	// also collect for each tree, which nodes are covered, format: <nodeid, lineage num>
	// such format allows us easily find out for a node which lineages covering it
	vector< map<int,set<int> > > listCoveredNodesPerTree(GeneTreeInfo:: Instance().GetNumGeneTrees() );
	for(int i=0; i<(int) listCoveredNodesByLins.size(); ++i)
	{
		for( set<int> :: iterator itt = listCoveredNodesByLins[i].begin(); itt != listCoveredNodesByLins[i].end(); ++itt)
		{
			int treeId = GeneTreeInfo:: Instance().GetTreeIdForNode(*itt);
			if(listCoveredNodesPerTree[treeId].find(*itt) == listCoveredNodesPerTree[treeId].end() )
			{
				set<int> sint;
				listCoveredNodesPerTree[treeId].insert(map<int,set<int> > :: value_type(*itt,sint) );
			}
			listCoveredNodesPerTree[treeId][*itt].insert(i);
		}
	}

	if(pListMinCoveredNodes != NULL)
	{
		pListMinCoveredNodes->clear();
	}


	// knows how many leaves covered by each node
	sumTreeCoverage = 0;

	for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
	{
//cout << "Processing tree: " << tr << endl;
		// get leave ids first
		set<int> idsLeavesInTree;
		GeneTreeInfo:: Instance().GetLeafIds(tr, idsLeavesInTree);
//cout << "Leaves: ";
//DumpIntSet(idsLeavesInTree);
		// maintain <node id, set of lineage sets covering this node>
		map< int, set<  set<int> > > mapNodesCoveredByLins;

		// bottom up: so leaves first
		set<int> nodeIdsToProc;
		for( set<int> :: iterator itt = idsLeavesInTree.begin(); itt != idsLeavesInTree.end(); ++itt )
		{
			if( listCoveredNodesPerTree[tr].find(*itt) != listCoveredNodesPerTree[tr].end() )
			{
				set< set<int> > ssint;
				mapNodesCoveredByLins.insert(map< int, set<  set<int> > > :: value_type(*itt, ssint)  );
				// each of the lineage cover it
				for( set<int> :: iterator itg = listCoveredNodesPerTree[tr][*itt].begin(); itg != listCoveredNodesPerTree[tr][*itt].end(); ++itg )
				{
					set<int> stt;
					stt.insert(*itg);
					mapNodesCoveredByLins[*itt].insert( stt  );
				}
//cout << "Leaf " << *itt << " has covering lin sets: " << mapNodesCoveredByLins[*itt].size() << endl;
			}
			// let its parent to process
			int parid = GeneTreeInfo:: Instance().GetParent(*itt);
			if( parid >= 0)
			{
				nodeIdsToProc.insert( parid );
			}
		}

		// now move up
		while(nodeIdsToProc.size() > 0)
		{
//cout << "Nodes toproc: ";
//DumpIntSet(nodeIdsToProc);
			// get next one to proc
			int nodeCurr = *(nodeIdsToProc.begin() );
			nodeIdsToProc.erase( nodeIdsToProc.begin() );
			int parid = GeneTreeInfo:: Instance().GetParent(nodeCurr);
			if( parid >= 0)
			{
				nodeIdsToProc.insert( parid );
			}

			// test whether its children are done
			set<int> idChildren;
			GeneTreeInfo:: Instance().GetChildrenIds(nodeCurr, idChildren);
			YW_ASSERT_INFO( idChildren.size() == 2, "Tree must be binary" );

			// if a lienage cover it then such a singleton set cover this node
			if( listCoveredNodesPerTree[tr].find(nodeCurr) != listCoveredNodesPerTree[tr].end()  )
			{
				// 
				set< set<int> > ssint;
				mapNodesCoveredByLins.insert(map< int, set<  set<int> > > :: value_type(nodeCurr, ssint)  );
				for(set<int> :: iterator itg = listCoveredNodesPerTree[tr][nodeCurr].begin(); itg != listCoveredNodesPerTree[tr][nodeCurr].end(); ++itg )
				{
					set<int> ssing;
					ssing.insert( *itg );
					mapNodesCoveredByLins[nodeCurr].insert(ssing);
				}
//cout << "Number of direct coverage for node " << nodeCurr << " is: " <<  mapNodesCoveredByLins[nodeCurr].size() << endl;
			}

			// 
			int nodeChild1 = *(idChildren.begin());
			int nodeChild2 = *(idChildren.rbegin());
			// if both has records, then combine them
			if( mapNodesCoveredByLins.find(nodeChild1)!=mapNodesCoveredByLins.end() 
				&& mapNodesCoveredByLins.find(nodeChild2) !=mapNodesCoveredByLins.end() )
			{
//cout << "proc two children " << nodeChild1 << " " << nodeChild2 << endl;
				// 
				set< set<int> > ssResSets;

				// combiine pairs
				for( set<set<int> > :: iterator itg1 = mapNodesCoveredByLins[nodeChild1].begin(); itg1 !=mapNodesCoveredByLins[nodeChild1].end();++itg1)
				{
					for( set<set<int> > :: iterator itg2 = mapNodesCoveredByLins[nodeChild2].begin(); itg2 !=mapNodesCoveredByLins[nodeChild2].end();++itg2)
					{
						set<int> sint;
						JoinSets( *itg1, *itg2, sint);
						if( sint.size() == 0)
						{
							// a valid covering by its union
							set<int> rset = *itg1;
							UnionSets( rset, *itg2);
							ssResSets.insert( rset);
//cout << "Find one combo pair: ";
//DumpIntSet( rset );
						}
					}

				}

				// create the record just in case
				if( ssResSets.size() > 0)
				{
					if( mapNodesCoveredByLins.find(nodeCurr) == mapNodesCoveredByLins.end() )
					{
						set< set<int> > ssint;
						mapNodesCoveredByLins.insert(map< int, set<  set<int> > > :: value_type(nodeCurr, ssint)  );
					}
					for( set<set<int> > :: iterator itt2 = ssResSets.begin(); itt2 != ssResSets.end(); ++itt2 )
					{
						mapNodesCoveredByLins[nodeCurr].insert(*itt2);
					}
				}
			}
		}

		// now consider the root
		int rootId = GeneTreeInfo:: Instance().GetRootId(tr);
		if( mapNodesCoveredByLins.find(rootId) == mapNodesCoveredByLins.end() )
		{
			// fail to cover the true, that is it
			return false;
		}

		// otherwise, the score is the SMALLEST subset of the root
		int resStep = HAP_MAX_INT;

		for( set< set<int> > :: iterator ittg = mapNodesCoveredByLins[rootId].begin(); ittg != mapNodesCoveredByLins[rootId].end(); ++ittg)
		{
			if( (int)ittg->size() < resStep )
			{
				resStep = (int)ittg->size();
			}
		}
//cout << "resStep = " << resStep << endl;
		sumTreeCoverage += resStep;

		// return list of nodes that are in the minimum nodes set
		if( pListMinCoveredNodes != NULL)
		{
			// 
			for( set< set<int> > :: iterator ittg = mapNodesCoveredByLins[rootId].begin(); ittg != mapNodesCoveredByLins[rootId].end(); ++ittg)
			{
				if( (int)ittg->size() == resStep )
				{
					for( set<int> :: iterator ittg2 = ittg->begin(); ittg2 != ittg->end(); ++ittg2)
					//set<int> :: iterator ittg2 = ittg->begin(); 
					{
//cout << "found a minimal subset: ";
//DumpIntSet(listCoveredNodesByLins[*ittg2]);
						UnionSets(*pListMinCoveredNodes, listCoveredNodesByLins[*ittg2]);
					}
				}
			}
		}
	}
//cout << "-----Exit EvalCfgPriorityV2\n";

	return true;
}


bool CfgConfiguration :: EvalCfgPriorityCoarse(int &sumTreeCoverage)
{
	// for each tree, the score is equal to the current maximal subtree composition number
	// is the configuration allowed (as the product of coalesce these two lineages)?
	// we can if we can still dervie all trees after this marging
	// approach: traverse each gene tree top-down; 
	// stop once reaching a node that is in the config;
	// not feasible if we ever reach a leaf that is not in this config
	// This works because the gene tree iterator takes an in-order tree traversal approach
	sumTreeCoverage = 0;
	for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
	{
		// 
		GeneTreeIterator gtItor(tr);
		gtItor.Init();
		while( gtItor.IsDone() == false )
		{
			// 
			int nodeId = gtItor.GetNodeId( );
			if( IsNodeContained(nodeId) == true )
			{
				// backout
//cout << "Moving back...\n";
				gtItor.Back();
				sumTreeCoverage ++;
			}
			else
			{
				// declare not feasible if it is a leaf
				if( gtItor.IsLeaf() == true  )
				{
//cout << "INFEASIBLE: For tree " << tr << ", this leaf is reached: " << gtItor.GetNodeId() << endl; 
					return false;
				}

				// continue
//cout << "Moving forward...\n";
				gtItor.Next();
			}
		}
	}
	// now enforce stronger condition
//	if( IsConfigFeasibleStronger() == false)
//	{
//cout << "******NOT FEASIBLE IN A STRONG SENSE: \n";
//Dump();
//		return false;
//	}
//cout << "******Yes FEASIBLE IN A STRONG SENSE: \n";
//Dump();
	return true;
}


// is this node in some linegeas
bool CfgConfiguration :: IsNodeContained(int nodeId) const
{
	for( map< CfgLineage,int > :: iterator  it = const_cast<CfgConfiguration *>(this)->mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		if( it->first.IsNodeContained(nodeId) == true  )
		{
			return true;
		}
	}
	return false;
}

void CfgConfiguration:: Dump() const
{
	cout << "(" << this->GetId() << "," << this->GetSrcCfgId() << ")" << "[Num of lineages in config: " << mapLineages.size() << "]" << endl;
	for( map< CfgLineage,int> :: iterator  it = const_cast<CfgConfiguration *>(this)->mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		cout << "[" << it->second << "]:";
		it->first.Dump();
	}	
}

bool CfgConfiguration :: IsTerminal() const
{
	// have we reached the root of all input trees?
	for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
	{
		int rootId = GeneTreeInfo:: Instance().GetRootId( tr );
		if( IsNodeContained(rootId) == false )
		{
			return false;
		}
	}
	return true;
}

void CfgConfiguration :: GetLinIds(set<int> &sint) const
{
	sint.clear();
	for( map< CfgLineage,int> :: iterator  it = const_cast<CfgConfiguration *>(this)->mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		sint.insert( it->first.GetLinId() );
	}	

}
void CfgConfiguration :: GetCoveredNodes( set<int>& sint) const
{
	sint.clear();
	for( map< CfgLineage,int> :: iterator  it = const_cast<CfgConfiguration *>(this)->mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		set<int> ss1;
		it->first.GetCoveredNodes(ss1);
		UnionSets( sint, ss1);
	}	
}


bool CfgConfiguration :: IsBeatenBy(const CfgConfiguration &other) const
{
	//if( fApproxMode == true)
	//{
	//	return IsBeatenByApprox(other);
	//}

//cout << "In CfgConfiguration :: IsBeatenBy: \n";
	// the current cfg is beaten by the other if each current lineage has its counterpart
	// in the other (same or less ret-events
	map< CfgLineage,int> mapLinsOther = other.mapLineages;

	for( map< CfgLineage,int> :: iterator  it = const_cast<CfgConfiguration *>(this)->mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		if(mapLinsOther.find(it->first) != mapLinsOther.end() )
		{
//cout << "This lineage is shared: ";
//it->first.Dump();
			if( mapLinsOther[it->first] < it->second )
			{
//cout << "Not enough copies \n";
				return false;	// not enough copies
			}
			if( mapLinsOther[it->first] == it->second  )
			{
//cout << "Just erase it\n";
				// remove it
				mapLinsOther.erase( it->first );
			}
			else
			{
				// decrease it
				mapLinsOther[it->first] -= it->second; 
//cout << "Reduce its number to: " << mapLinsOther[it->first] << endl;
			}
		}
		else
		{
//cout << "This lineage is NOT shared: ";
//it->first.Dump();
			// does there exist a more relaxed copies of the set
			bool fFound = false;
			for( map< CfgLineage,int> :: iterator  it2 = mapLinsOther.begin(); it2 != mapLinsOther.end(); ++it2 )
			{
//cout << "Checking: [" << it2->second << "]: ";
//it2->first.Dump();
				// 
				if( it->second <= it2->second &&   it->first.IsBeaten( it2->first ) == true )
				{
//cout << "Beatn by this lineage\n";
					// modify it
					if( it2->second == it->second  )
					{
//cout << "Erase it\n";
						// remove it
						mapLinsOther.erase( it2->first );
					}
					else
					{
						// decrease it
						mapLinsOther[it2->first] -= it->second; 
//cout << "Reduce(2) its number to: " << mapLinsOther[it->first] << endl;
					}
					fFound = true;
					break;
				}
			}
			if( fFound == false)
			{
//cout << "Fail to find a witness\n";
				return false;
			}
		}
	}
	return true;
}

bool CfgConfiguration :: IsBeatenByApprox(const CfgConfiguration &other) const
{
	// 090811: does not work. For example, this one easily beat any reticulated configs
	// faster test of beaten or not
	set<int> nodesCover, nodesCoverOther;
	GetCoveredNodes(nodesCover);
	other.GetCoveredNodes(nodesCoverOther);
	set<int> sint = nodesCoverOther;
	SubtractSets( sint, nodesCover);
	return sint.size() + nodesCover.size() == nodesCoverOther.size();
}

int CfgConfiguration :: GetTotNumLineages() const
{
	int res = 0;
	for( map< CfgLineage,int> :: iterator  it = const_cast<CfgConfiguration *>(this)->mapLineages.begin(); it != mapLineages.end(); ++it )
	{
		res += it->second;
	}
	return res;
}

// remove all lineage srcs that are not in the passed in set
bool CfgConfiguration :: CleanExtraLins(const set<int> &sLinSrcs)
{
	bool res = false;	// by default, not cleaned
// YW: do not clean
return res;

	map< CfgLineage, int> mapLineagesNew;
//#if 0
//cout << "CleanExtraLins: cfg = ";
//Dump();
	for( map< CfgLineage, int> :: iterator itt= mapLineages.begin(); itt != mapLineages.end(); ++itt)
	{
		CfgLineage linNew = itt->first;
		if( linNew.CleanExtraLins(sLinSrcs) == true)
		{
			// set cleaned flag
			res = true;
		}

		// 
		if( linNew.IsEmpty() == false)
		{
			YW_ASSERT_INFO( mapLineagesNew.find( linNew) == mapLineagesNew.end(), "FAIL 3333" );
			mapLineagesNew.insert(map<CfgLineage,int> :: value_type(linNew, itt->second ) );
		}
	}
//YW_ASSERT_INFO( (this->mapLineages != mapLineagesNew) == res, "SOMETHING WRONG");
//bool fDump = false;
//if( this->mapLineages != mapLineagesNew)
//{
//cout << "EEEEEEEEEEE";
//cout << "Original cfg = ";
//Dump();
//fDump = true;
//}
	this->mapLineages = mapLineagesNew;
//if( fDump == true)
//{
//Dump();
//}
	return res;
}

// some lineage src info is not useful
// e.g. if node 3 has nodes 1 and 2 as descendents, and nodes 1 and 3 are in config (but not node 2
// can not be obtained through coalescent of existing lineages)
// in this case, node 1 can be removed since it will not able to be useful
void CfgConfiguration :: CleanExtraLins()
{
return;
	if(fApproxMode == false)
	{
		return;
	}

	map< CfgLineage, int> mapLineagesNew;
//#if 0
//cout << "CleanExtraLins: cfg = ";
//Dump();
	for( map< CfgLineage, int> :: iterator itt= mapLineages.begin(); itt != mapLineages.end(); ++itt)
	{
		CfgLineage linNew = itt->first;
		linNew.CleanExtraLins();

		// 
		YW_ASSERT_INFO( mapLineagesNew.find( linNew) == mapLineagesNew.end(), "FAIL 3333" );
		mapLineagesNew.insert(map<CfgLineage,int> :: value_type(linNew, itt->second ) );
	}
//if( this->mapLineages != mapLineagesNew)
//{
//cout << "EEEEEEEEEEE\n";
//}
	this->mapLineages = mapLineagesNew;
//cout << "After lineage cleanup, cfg = ";
//Dump();
//#endif

//#if 0
//cout << "bbbbbbIn CleanExtraLins:\n";
//Dump();
	// another round of cleanup: remove all lineage srcs that can not continue
	mapLineagesNew.clear();
	set<int> setCoveredNodesIds;
	GetAllCoveredNodes(setCoveredNodesIds);
	for( map< CfgLineage, int> :: iterator itt= mapLineages.begin(); itt != mapLineages.end(); ++itt)
	{
		CfgLineage linNew = itt->first;
		linNew.CleanExtraLinsByCoveredNodes(setCoveredNodesIds);

		// 
		mapLineagesNew.insert(map<CfgLineage,int> :: value_type(linNew, itt->second ) );
	}
	this->mapLineages = mapLineagesNew;
//cout << "BBBBBafter CleanExtraLins:\n";
//Dump();

//#endif


#if 0
	set<int> setLinsDerivable;	// which lineages can still be derived through coalescent of lineages

	for(int tr=0; tr<GeneTreeInfo:: Instance().GetNumGeneTrees(); ++tr)
	{
		// 
		GeneTreeIterator gtItor(tr);
		gtItor.Init();
		while( gtItor.IsDone() == false )
		{
			// 
			int nodeId = gtItor.GetNodeId( );
			if( IsNodeContained(nodeId) == true )
			{
				// backout
//cout << "Moving back...\n";
				setLinsDerivable.insert(nodeId);
			}
			else
			{
				// otherwise if it is not a leaf and its descendent
				if(  gtItor.IsLeaf() == false )
				{
					// get its descendent
					TreeNode *pnode = gtItor.GetCurrNode();
					int idChild1 = GeneTreeInfo::Instance().GetNodeMultitreeId( pnode->GetChild(0)  ); 
					int idChild2 = GeneTreeInfo::Instance().GetNodeMultitreeId( pnode->GetChild(1)  ); 
					//
					if( setLinsDerivable.find( idChild1 ) != setLinsDerivable.end() && setLinsDerivable.find(idChild2) != setLinsDerivable.end() )
					{
						// should also be in
						setLinsDerivable.insert( nodeId );
					}
				}


				// continue
//cout << "Moving forward...\n";
			}
			gtItor.Next();
		}
	}

	// now scan through the list of lineages to clean up it
	map< CfgLineage, int> mapLineagesNew;

	for( map< CfgLineage, int> :: iterator itt= mapLineages.begin(); itt != mapLineages.end(); ++itt)
	{

		CfgLineage linNew;
		linNew.SetLinId( itt->first.GetLinId() );
		linNew.SetReticulateLineage( itt->first.IsReticulateLineage() );
		//
		for( set< CfgLineageSrc > :: iterator it= itt->first.listLinsSrcAlways.begin(); it != itt->first.listLinsSrcAlways.end(); ++it )
		{
			if( setLinsDerivable.find( it->GetNodeId() ) != setLinsDerivable.end() )
			{
				linNew.AddSrc(*it, true);
			}
		}
		for( set< CfgLineageSrc > :: iterator it= itt->first.listLinsSrcCondition.begin(); it != itt->first.listLinsSrcCondition.end(); ++it )
		{
			if( setLinsDerivable.find( it->GetNodeId() ) != setLinsDerivable.end() )
			{
				linNew.AddSrc(*it, false);
			}
		}

		// 
		mapLineagesNew.insert(map<CfgLineage,int> :: value_type(linNew, itt->second ) );
	}
#endif
}

// after reticulation (adding a new event), remove redundent events (those priviate to the newly reticulated events)
// because the new ret-event is enough to ensure mutual exclusive
void CfgConfiguration :: CleanExtraSrcEvts(CfgLineage &cfgLin, CfgRetEvt evtRetNew)
{
// YW: 082511, not very useful, so disable for now
return;

#if 0
	YW_ASSERT_INFO(mapLineages.find(cfgLin) != mapLineages.end(), "Fail to find cfg" );

	// obtain event ids for other lineages
	set<CfgRetEvt> evtsInOtherLins;
	set<CfgRetEvt> evtsInThisLin;
	//
	cfgLin.GetSetEvts(evtsInThisLin);
	for( map< CfgLineage, int> :: iterator itt= mapLineages.begin(); itt != mapLineages.end(); ++itt)
	{
		if( (itt->first == cfgLin) == false )
		{
			set<CfgRetEvt> evtsStep;
			itt->first.GetSetEvts(evtsStep);
			UnionSets( evtsInOtherLins, evtsStep );
		}
	}

	//
	int ncopy = mapLineages[cfgLin];
	CfgLineage cfgLinNew = cfgLin;
	for( set<CfgRetEvt> :: iterator it = evtsInThisLin.begin(); it != evtsInThisLin.end(); ++it )
	{
		if(*it != evtRetNew && evtsInOtherLins.find( *it) == evtsInOtherLins.end() )
		{
			//
			cfgLinNew.RemoveEvtFromSrc( *it );
		}
	}
	// add back
	mapLineages.insert( map<CfgLineage,int>:: value_type(cfgLinNew,ncopy) );
#endif
}

// after coalescent, remove redundent events (those priviate to the newly reticulated events)
// because the new ret-event is enough to ensure mutual exclusive, if there is only one copy of this lineage
void CfgConfiguration :: CleanExtraSrcEvts(CfgLineage &cfgLin)
{
// YW: 082511, not very useful, so disable for now
return;

#if 0
	YW_ASSERT_INFO(mapLineages.find(cfgLin) != mapLineages.end(), "Fail to find cfg" );
	int ncopy = mapLineages[cfgLin];
	if( ncopy > 1)
	{
		return ;
	}

	// obtain event ids for other lineages
	set<CfgRetEvt> evtsInOtherLins;
	set<CfgRetEvt> evtsInThisLin;
	//
	cfgLin.GetSetEvts(evtsInThisLin);
	// find common events. Only remove common events
	set<CfgRetEvt> evtsInThisLinCommon;
	for(set<CfgRetEvt>::iterator itt= evtsInThisLin.begin(); itt !=evtsInThisLin.end(); ++itt )
	{
		if(cfgLin.IsEventCommonInside(*itt) == true )
		{
			evtsInThisLinCommon.insert(*itt);
		}
	}

	for( map< CfgLineage, int> :: iterator itt= mapLineages.begin(); itt != mapLineages.end(); ++itt)
	{
		if( (itt->first == cfgLin) == false )
		{
			set<CfgRetEvt> evtsStep;
			itt->first.GetSetEvts(evtsStep);
			UnionSets( evtsInOtherLins, evtsStep );
		}
	}

	//
	if( evtsInThisLinCommon.size() > 1)
	{
		int numRemEvts = 0;
		CfgLineage cfgLinNew = cfgLin;
		for( set<CfgRetEvt> :: iterator it = evtsInThisLinCommon.begin(); it != evtsInThisLin.end(); ++it )
		{
			if( numRemEvts < (int)evtsInThisLinCommon.size()  && evtsInOtherLins.find( *it) == evtsInOtherLins.end() )
			{
				//
				cfgLinNew.RemoveEvtFromSrc( *it );
				numRemEvts++;
			}
		}
if( numRemEvts > 0)
{
cout << "Removing extra events: original cfg \n";
this->Dump();
}
		// add back
		mapLineages.erase(cfgLin);
		mapLineages.insert( map<CfgLineage,int>:: value_type(cfgLinNew,ncopy) );
if( numRemEvts > 0)
{
cout << "Removing extra events: NEW cfg \n";
this->Dump();
}
	}
#endif
}


void CfgConfiguration :: GetAllCoveredNodes(set<int> &setNodeIds)
{
	// get all derivable tree nodes from this configuration
	// first obtain all current nodes in each tree
	vector< set<int> > listNodesInTrees(GeneTreeInfo :: Instance().GetNumGeneTrees()  );
	for( map< CfgLineage, int> :: iterator itt= mapLineages.begin(); itt != mapLineages.end(); ++itt)
	{
		set<int> sint;
		itt->first.GetCoveredNodes(sint);
		for( set<int> :: iterator it1 = sint.begin(); it1 != sint.end(); ++it1)
		{
			// determine which tree is it
			int treeId = GeneTreeInfo :: Instance().GetTreeIdForNode( *it1);
			listNodesInTrees[treeId].insert( *it1 );
		}
	}
	setNodeIds.clear();
	// now traverse each list of nodes
	for(int tr=0; tr<(int)listNodesInTrees.size(); ++tr)
	{
//cout << "listNodesInTrees[treeId]: " << tr << ", ";
//DumpIntSet( listNodesInTrees[tr] );
		// approach: extract the smallest node, and see if the next smallest one is also in
		// if so, add their parent. otherwise remove it
		while( listNodesInTrees[tr].size() >= 1 )
		{
			int nodeSmallest = *listNodesInTrees[tr].begin();
			setNodeIds.insert(nodeSmallest);
			listNodesInTrees[tr].erase(nodeSmallest);
			int parid = GeneTreeInfo :: Instance().GetParent(nodeSmallest);
			if( parid < 0)
			{
				break;
			}
			//YW_ASSERT_INFO(parid >=0, "Must have a valid parent");
			set<int> setChildrenIds;
			GeneTreeInfo :: Instance().GetChildrenIds(parid, setChildrenIds);
			setChildrenIds.erase( nodeSmallest );
			YW_ASSERT_INFO(setChildrenIds.size()==1, "Fail334");
//cout << "sibling of " << nodeSmallest << " is " << *setChildrenIds.begin() << ", for setNodeIds = ";
//DumpIntSet( setNodeIds ); 
			if( setNodeIds.find( *setChildrenIds.begin() ) !=  setNodeIds.end()   )
			{
				// put parent into the list since the other sibling has been derived
				listNodesInTrees[tr].insert(parid);
			}
		}
		// add the remaning node 
		//setNodeIds.insert( *listNodesInTrees[tr].begin()  );
	}
}

bool CfgConfiguration :: ShrinkLineages(int scoreOld, CfgLineage &linNew)
{
// YW: for now do not allow shrink lineages
return false;
	// try to drop one lineage from configuration and see if remains feasible and same score
	// Note: do not drop the newest lineage
	const int MIN_NUM_LINS_RED = 5;
	if( GetNumLineageTypes() < MIN_NUM_LINS_RED)
	{
		return false;
	}

//cout << "ShrinkLineages::cfgExpand: ";
//Dump();
	bool fShrunk = false;

	// now try to get all reachable cfgs by coalescences only
	for( map< CfgLineage,int > :: iterator  it1 = this->mapLineages.begin(); 	it1 != this->mapLineages.end(); ++it1 )
	{
		//if( it1->first == linNew || it1->first.IsPureConditional() == false )
		if( it1->first.IsPureConditional() == false )
		{
			continue;
		}

		CfgConfiguration cfgExpand = *this;
		// remove this lineage
		cfgExpand.mapLineages.erase(it1->first);
		int resUpdate;
		if( cfgExpand.EvalCfgPriorityVer2(resUpdate) == true && resUpdate == scoreOld)
		{
			fShrunk = true;
//cout << "XXXX ShrinkLineages: old cfg = ";
//Dump();
			// update lineages
			this->mapLineages.erase(it1->first);
//cout << "After ShrinkLineages: new cfg = ";
//Dump();
			break;
		}

		// score it

	}
//if(fShrunk == true)
//{
//cout << "+++++++++++++++This config is dropped due to even stronger infeasiblity test\n";
//Dump();
//}
	return fShrunk;
}

bool CfgConfiguration :: IsLinRetProfitable( const CfgLineage &cfgLin ) const
{
return true;	// for now
	// when there are only two trees, allow it
	if( GeneTreeInfo::Instance().GetNumGeneTrees() <= 2)
	{
		return true;
	}

	set<int> setLinIdsCurr;
	GetLinIds(setLinIdsCurr);

	set<int> setNodeDescIdCurr;
	for( map< CfgLineage,int > :: iterator  itg = const_cast<CfgConfiguration &>(*this).mapLineages.begin(); 
		itg !=  const_cast<CfgConfiguration &>(*this).mapLineages.end(); ++itg )
	{
		set<int> sint;
		itg->first.GeCoveredNodesUnder(sint);
		UnionSets(setNodeDescIdCurr, sint);
	}

	// a lineage may not be benefitial to reticulate if
	// there are no two lineages that new subtrees (gene tree nodes) can generate
	// so check each lineage and try to coalesce them
	bool fSeeOneGoodLin = false;
	for( map< CfgLineage,int > :: iterator  it1 = const_cast<CfgConfiguration &>(*this).mapLineages.begin(); 
		it1 != const_cast<CfgConfiguration &>(*this).mapLineages.end(); ++it1 )
	{
		// check to see whether something new has been obtained
		if( (*it1).first == cfgLin )
		{
			continue;
		}

		// continue...
		CfgLineage linNew;

		bool fCoalStepRes = cfgLin.CoalesceWith(it1->first, linNew);
		if( fCoalStepRes == false)
		{
			continue;
		}
		if( setLinIdsCurr.find( linNew.GetLinId() ) != setLinIdsCurr.end() )
		{
			// must create a novel lineage
			continue;
		}

		// check to see if there are new things in it
		set<int> nodesInLin;
		linNew.GetCoveredNodes( nodesInLin );
		// check each 
		set<int> setTreesForNodes;
		for( set<int> :: iterator itt2 = nodesInLin.begin(); itt2 != nodesInLin.end(); ++itt2)
		{
			if( setNodeDescIdCurr.find(*itt2) == setNodeDescIdCurr.end() )
			{
				if( fSeeOneGoodLin == false)
				{
					fSeeOneGoodLin = true;
					break;
				}
				else
				{
					// another instance, so done
					return true;
				}
			}
		}

	}
	// we do not find this lineage should be subject to reticulation
	return false;
}


//bool CfgConfiguration :: IsCfgCoalRedundent()
//{
//	// is this cfg redundent by coalescent?
//	// assume this cfg is created by coalescent, then it is redudent if this cfg
//	// can be created through coalescent from a child of one lienage with the other lineage
//	// Then if redundent, ignore this branch of search
//	int idChild1, idChild2;
//	CfgLineage:: GetChildrenId(this);
//}

//void CfgConfiguration :: TraceBack() const
//{
//	// for now, just dump out the configurations going through
//	CfgConfiguration *pCurCfg = const_cast<CfgConfiguration *>( this );
//	int nIter = 1;
//	while( pCurCfg != NULL)
//	{
//		cout << "Trace back step " << ++nIter << ": cfg = ";
//		pCurCfg->Dump();
//		pCurCfg = pCurCfg->GetSrcCfg();
//	}
//}


void CfgConfiguration :: CompareWith( const CfgConfiguration &cfgOther, map<CfgLineage,int> &listLinsNovelThis, map<CfgLineage,int> &listLinsNovelOther ) const
{
	CfgConfiguration &cfgOtherUse = const_cast<CfgConfiguration &>(cfgOther);
	// compare two cfgs and obtain lineages only in this cfg and those only in the other cfg
	for( map< CfgLineage,int > :: iterator  it1 = const_cast<CfgConfiguration &>(*this).mapLineages.begin(); 
		it1 != const_cast<CfgConfiguration &>(*this).mapLineages.end(); ++it1 )
	{
		// 
		if( cfgOther.mapLineages.find(it1->first) == cfgOther.mapLineages.end() )
		{
			// novel here
			listLinsNovelThis.insert( map<CfgLineage,int> :: value_type(it1->first, it1->second) );
		}
		else if( it1->second > cfgOtherUse.mapLineages[it1->first] )
		{
			// add more to this
			listLinsNovelThis.insert( map<CfgLineage,int> :: value_type(it1->first, it1->second -cfgOtherUse.mapLineages[it1->first] ) );
		}
		else if( it1->second < cfgOtherUse.mapLineages[it1->first] )
		{
			// add more to this
			listLinsNovelOther.insert( map<CfgLineage,int> :: value_type(it1->first, cfgOtherUse.mapLineages[it1->first] - it1->second ) );
		}
	}
	// now find the lineages only in the other
	for( map< CfgLineage,int > :: iterator  it1 = const_cast<CfgConfiguration &>(cfgOther).mapLineages.begin(); 
		it1 != const_cast<CfgConfiguration &>(cfgOther).mapLineages.end(); ++it1 )
	{
		// 
		if( this->mapLineages.find(it1->first) == this->mapLineages.end() )
		{
			// novel here
			listLinsNovelOther.insert( map<CfgLineage,int> :: value_type(it1->first, it1->second) );
		}

	}
}

bool CfgConfiguration:: FindMatchingLin( const CfgLineage &lin, CfgLineage &linMatch) const
{
	// check whether equivalent lin is their
	for( map< CfgLineage,int > :: iterator  it1 = const_cast<CfgConfiguration &>(*this).mapLineages.begin(); 
		it1 != const_cast<CfgConfiguration &>(*this).mapLineages.end(); ++it1 )
	{
		if( it1->first.AreLineagesEquiv( lin ) == true )
		{
			linMatch = it1->first;
			return true;
		}
	}
	return false;
}

///////////////////////////////////////////////////////////////////////////////
GeneTreeIterator :: GeneTreeIterator(int treeId) : itorPhyTree(GeneTreeInfo::Instance().GetGeneTree(treeId)  ) 
{  
}

int GeneTreeIterator :: GetNodeId() 
{ 
	return GeneTreeInfo::Instance().GetNodeMultitreeId( itorPhyTree.GetCurrNode()  ); 
}


///////////////////////////////////////////////////////////////////////////////
// Gene Tree Info helper class

GeneTreeInfo GeneTreeInfo :: instance;


// query
int GeneTreeInfo :: GetNumSpecies() const
{
	// for now assume each tree is of same size
	return const_cast<PhylogenyTreeBasic *>(listGeneTrees[0])->GetNumLeaves();
}

int GeneTreeInfo :: GetLeafIdInTree(int treeId, int leafId) const
{
	return GetNodeIdForLeaf(treeId, leafId);
}

int GeneTreeInfo :: GetLeafIdFromNodeId( int nodeId) const
{
	//
	for( map<pair<int,int>,int> :: iterator it = const_cast<GeneTreeInfo &>(*this).mapLeafIdToNodeId.begin(); it != mapLeafIdToNodeId.end(); ++it )
	{
		if( it->second == nodeId )
		{
			return it->first.second;
		}
	}
	return -1;
}

int GeneTreeInfo :: GetNodeMultitreeId( TreeNode *pnode)
{
	// retrive convereted id
	if( mapNodesToIds.find(pnode) == mapNodesToIds.end() )
	{
		// not found
		return -1;
	}
	return mapNodesToIds[pnode];
}
	

void GeneTreeInfo :: ProcGeneTrees( vector<PhylogenyTreeBasic *> &listTrees  ) 
{
	// clean up existing data (if any)
	mapNodesToIds.clear();
	mapIdToNode.clear();
	mapLeafIdToNodeId.clear();
	listRootIDs.clear();

	// process gene trees to take some info
	listGeneTrees = listTrees; 

	// assign a distinct node id to each species tree node
	idToUseNext = 0;
	for(int tr=0; tr<GetNumGeneTrees(); ++tr)
	{
//cout << "*** Processing tree " << tr << endl;
		// 
		PhylogenyTreeIterator gtItor( *listGeneTrees[tr] );
		gtItor.Init();
		while( gtItor.IsDone() == false )
		{
			// 
			int nodeToUse = ++idToUseNext;
			TreeNode * pnode = gtItor.GetCurrNode( );
			mapNodesToIds.insert( map<TreeNode *, int> :: value_type( pnode, nodeToUse ) );
			mapIdToNode.insert( map<int,TreeNode *> :: value_type(nodeToUse, pnode)  );
//cout << "Processing a node, id = " << pnode->GetID() << endl;

			// if this is leaf, remember it
			if( pnode->IsLeaf() == true)
			{
				SetNodeIdForLeaf(tr, pnode->GetID(), nodeToUse);
			}
			if(pnode->GetParent() == NULL)
			{
				listRootIDs.push_back( nodeToUse );
//cout << "For tree "<< tr << ", root is set to " << nodeToUse << endl;
			}

			// continue
			gtItor.Next();
		}
	}

	// now initialize descendent info
	for(int tr=0; tr<GetNumGeneTrees(); ++tr)
	{
//cout << "*** Processing tree " << tr << endl;
		// 
		PhylogenyTreeIterator gtItor( *listGeneTrees[tr] );
		gtItor.Init();
		while( gtItor.IsDone() == false )
		{
			// use a stack to recursively find all descendents
			//stack<int> nodesToProc;
			//nodesToProc.push( GetRootId(tr) );
			//while( nodesToProc.empty() == false )
			//{
			//int nid = nodesToProc.top();
			TreeNode *pnode = gtItor.GetCurrNode();
			int nid = GetNodeId(pnode) ;
			//nodesToProc.pop();
			set<int> sint;
			GetDescentIds(nid, sint);
			mapNodeDescendents.insert(	map<int,set<int> > :: value_type( nid, sint )  );

			// check how many are leaves
			set<int> sintLeaves;
			for( set<int> :: iterator itg = sint.begin(); itg != sint.end(); ++itg )
			{
				if( IsLeaf( *itg) == true)
				{
					sintLeaves.insert(*itg);
				}
			}
			mapNodesDescLeaves.insert(	map<int,set<int> > :: value_type( nid, sintLeaves )  );

				// push its children into it
			//	set<int> schildren;
			//	GetChildrenIds( nid, schildren );
			//	for( set<int> :: iterator itt = schildren.begin(); itt != schildren.end(); ++itt )
			//	{
			//		// 
			//		nodesToProc.push( *itt );
			//	}
			//}


			// continue
			gtItor.Next();
		}
	}

}


int GeneTreeInfo :: GetNodeIdForLeaf(int tr, int leaf) const
{
	pair<int,int> pp(tr,leaf);
	GeneTreeInfo &gtiUse = const_cast<GeneTreeInfo &> (*this);
	if( mapLeafIdToNodeId.find(pp) != mapLeafIdToNodeId.end() )
	{
		return gtiUse.mapLeafIdToNodeId[pp];
	}
	else
	{
		return -1;
	}
}

void GeneTreeInfo :: GetLeafIds( int tr, set<int> &sids) const
{
	sids.clear();
	set<int> lfids;
	YW_ASSERT_INFO(listGeneTrees.size() > 0, "FAIL");
	listGeneTrees[0]->GetLeaveIds(lfids);
	//for(int lv = 0; lv<GetNumSpecies(); ++lv)
	for( set<int> :: iterator it = lfids.begin(); it != lfids.end(); ++it)
	{
		int lv = *it;
		sids.insert( GetNodeIdForLeaf(tr, lv) );
	}
}

void GeneTreeInfo :: GetLeafTaxa( int treeNum, set<int> &sids) const
{
	sids.clear();
	YW_ASSERT_INFO((int)listGeneTrees.size() > treeNum, "FAIL");
	listGeneTrees[treeNum]->GetLeaveIds(sids);
}

void GeneTreeInfo :: SetNodeIdForLeaf(int tr, int leaf, int id)
{
//cout << "Tree " << tr << ",  found a leaf: " << leaf << ", id = " << id << endl;

	pair<int,int> pp(tr,leaf);
	mapLeafIdToNodeId.insert( map< pair<int,int>,int> :: value_type( pp, id) );
}

int GeneTreeInfo :: GetParent(int nodeId)
{
	if( mapIdToNode.find( nodeId ) == mapIdToNode.end() )
	{
		return -1;
	}
	TreeNode *pnode = mapIdToNode[nodeId];
	TreeNode *pnodepp = pnode->GetParent();
	if( pnodepp == NULL)
	{
		return -1;
	}
	//YW_ASSERT_INFO( mapNodesToIds.find( pnode ) != mapNodesToIds.end(), "Fail to find parent" );
	return GetNodeMultitreeId( pnodepp );
}

int GeneTreeInfo :: GetRootId(int tr) const
{
	YW_ASSERT_INFO( tr <(int)listRootIDs.size(), "Tree index out of bound" );
	return listRootIDs[tr];
}

void GeneTreeInfo :: GetDescentIds(int nodeId, set<int> &setDescNodes )
{
	// use a stack to recurisvely find
	setDescNodes.clear();
	// node itself is considered to be a descendents
	setDescNodes.insert( nodeId );
	stack<int> nodesToProc;
	nodesToProc.push(nodeId);
	while( nodesToProc.empty() == false)
	{
		// 
		int nid = nodesToProc.top();
		nodesToProc.pop();
		set<int> nodesChildren;
		GetChildrenIds( nid, nodesChildren);
		UnionSets(setDescNodes, nodesChildren);
		for(set<int> :: iterator it = nodesChildren.begin(); it != nodesChildren.end(); ++it )
		{
			// 
			nodesToProc.push(*it);
		}
	}
}

void GeneTreeInfo :: GetChildrenIds(int nodeId, set<int> &nodesChildren)
{
	// 
	nodesChildren.clear();
	TreeNode *pnode = mapIdToNode[nodeId];
	for(int i=0; i<pnode->GetChildrenNum(); ++i)
	{
		TreeNode *pchild = pnode->GetChild(i);
		int childId = GetNodeMultitreeId(pchild);
		nodesChildren.insert(childId);
	}
}

bool GeneTreeInfo :: IsNodeDescendentOf(int idChild, int idAnces)
{
	// 
	YW_ASSERT_INFO( mapNodeDescendents.find( idAnces) != mapNodeDescendents.end(), "Fail to find the ancestor in IsNodeDescendentOf" );
	return mapNodeDescendents[idAnces].find(idChild) != mapNodeDescendents[idAnces].end();
}

bool GeneTreeInfo :: IsLeaf(int nodeId) 
{
	//YW_ASSERT_INFO( mapIdToNode.find(nodeId) != mapIdToNode.end(), "Fail to find node id" );
	return mapIdToNode[nodeId]->IsLeaf();
}

int GeneTreeInfo :: GetTaxonIdForLeafNode(int nodeId) const
{
	if( mapIdToNode.find( nodeId ) == mapIdToNode.end() )
	{
		return -1;
	}
	TreeNode *pn = const_cast<GeneTreeInfo *>(this)->mapIdToNode[nodeId];
	if(pn->IsLeaf() == false )
	{
		return -1;
	}
	return pn->GetIntLabel();
}

int GeneTreeInfo :: GetNumDescLeaves(int idNode) 
{
	//YW_ASSERT_INFO(mapNodesDescLeaves.find(idNode) != mapNodesDescLeaves.end(), "Fail to find id");
	return mapNodesDescLeaves[idNode].size();
}

int GeneTreeInfo :: GetTreeIdForNode(int nodeId) const
{
	// YW: for now, ASSUME EACH TREE IS BINARY and TREE ID starts from ZERO
	return (int) (nodeId-1)/(2*GetNumSpecies()-1) ;
}

int GeneTreeInfo :: GetSibling(int idNode) const
{
	int parid = const_cast<GeneTreeInfo *>(this)->GetParent(idNode);
	if(parid < 0 )
	{
		return -1;
	}

	//YW_ASSERT_INFO(parid >=0, "Must have a valid parent");
	set<int> setChildrenIds;
	const_cast<GeneTreeInfo *>(this)->GetChildrenIds(parid, setChildrenIds);
	setChildrenIds.erase( idNode );
	YW_ASSERT_INFO(setChildrenIds.size()==1, "Fail334");
//cout << "sibling of " << nodeSmallest << " is " << *setChildrenIds.begin() << ", for setNodeIds = ";
//DumpIntSet( setNodeIds ); 
	return *setChildrenIds.begin();
}

bool GeneTreeInfo :: IsLeafIdIn(int tr, int taxa) const
{
	//
	pair<int,int> pp(tr,taxa);
	return 	mapLeafIdToNodeId.find( pp ) != mapLeafIdToNodeId.end();
}

int GeneTreeInfo :: AddDummyLeafId(int tr, int taxa)
{
	pair<int,int> pp(tr,taxa);
	int idToUse = ++idToUseNext;
	//for( map<int, TreeNode *> :: iterator it = mapIdToNode.begin(); it != mapIdToNode.end(); ++it)
	//{
	//	if(it->first > idLast)
	//	{
	//		idLast = it->first;
	//	}
	//}
	//int idToUse = idLast+1;
	mapLeafIdToNodeId.insert( map<pair<int,int>, int> :: value_type( pp, idToUse ) );
	return idToUse;
}


///////////////////////////////////////////////////////////////////////////////////////////


void CfgExplorer :: Explore()
{
//return ExplorePriority();
return ExplorePriority2();

	this->numBeatenCfgs= 0;

	// 
	GeneTreeInfo::Instance().ProcGeneTrees(listGeneTrees);

	// clear cache
	cfgsProcessed.clear();

	// now start exploring
	CfgConfiguration cfgInit;
	cfgInit.InitStart();
//cout << "Initial config: ";
//cfgInit.Dump();
	set<CfgConfiguration> setCfgsToExplore;
	setCfgsToExplore.insert( cfgInit );

	// explore up to certain steps
	//const int NUM_RET_EVT = 3;
	int numSteps = 0;
	bool fDone = false;
	while( ++numSteps <= maxRetEvtAllowed )
	{
cout << "*************************************** ITERATION " << numSteps << " ******************************" << endl;
cout << "Number of configuration to process in this step: " << setCfgsToExplore.size() << endl;
		// 
		set<CfgConfiguration> setCfgsToExploreNext;
cout << "Number of configuraitons found during this iteration so far: ";
		for( set<CfgConfiguration> :: iterator itt = setCfgsToExplore.begin(); itt != setCfgsToExplore.end(); ++itt )
		{
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
cout << "Processing configuration: ";
itt->Dump();
#endif
			// is this beaten by previously seen cfgs?
			//if( CfgBeatenByPrevious( *itt ) == true )
			//{
			//	continue;
			//}
			// include it in the processed
			//cfgsProcessed.insert(*itt);

			set<CfgConfiguration> setCfgsToExploreNextStep;
			// explore from it: GetNextCfgsPriority
			//if( const_cast<CfgConfiguration &>(*itt).GetNextCfgs(setCfgsToExploreNextStep, *this) == true)
			if( const_cast<CfgConfiguration &>(*itt).GetNextCfgs(setCfgsToExploreNextStep, *this) == true)
			{
				// we are done
				cout << "We have found the optimal network. \n";
				//cout << "Here is a list of configurations containing the solution.\n";
				for( set<CfgConfiguration> :: iterator itt2 = setCfgsToExploreNextStep.begin(); itt2 != setCfgsToExploreNextStep.end(); ++itt2 )
				{
					if( itt2->IsTerminal() == true)
					{
						//cout << "++++++++++";
						//itt2->Dump();
					}
				}
				fDone = true;
				break;
			}
			// make sure the original cfg is not part of the next cfgs
			//YW_ASSERT_INFO( setCfgsToExploreNextStep.find(*itt) == setCfgsToExploreNextStep.end(), "The original cfg is still in!!!!!!" );
			// add the currently found cfgs
			for( set<CfgConfiguration> :: iterator itt2 = setCfgsToExploreNextStep.begin(); itt2 != setCfgsToExploreNextStep.end(); ++itt2 )
			{
				setCfgsToExploreNext.insert(*itt2);
			}

cout << setCfgsToExploreNext.size() << "  ";
cout.flush();
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
#endif
		}
		if( fDone == true)
		{
			break;
		}
cout << endl;

		// start from new
		setCfgsToExplore.clear();
		FilterFoundCfgs(setCfgsToExploreNext, setCfgsToExplore);
		//setCfgsToExplore = setCfgsToExploreNext;
	}

	// dump out some statistics
	DumpStats();

	if( fDone == false)
	{
		cout << "WARNING: FAIL TO FIND SOLUTIONS. You may want to increase the number of allowed reticulation events.\n";
	}
	else
	{
		cout << "The minimum number of reticulation = " << numSteps << endl;
	}
}

//const int numPriorClassKept = 10;
const int maxSizePriorClass = HAP_MAX_INT;

void CfgExplorer :: ExplorePriority()
{
	//
	// 
	GeneTreeInfo::Instance().ProcGeneTrees(listGeneTrees);

	// clear cache
	cfgsProcessed.clear();

	// now start exploring
	CfgConfiguration cfgInit;
	cfgInit.SetGreedyIntermediate(false);

	cfgInit.InitStart();
//cout << "Initial config: ";
//cfgInit.Dump();
	set<CfgConfiguration> setCfgsToExplore;
	setCfgsToExplore.insert( cfgInit );

	// explore up to certain steps
	//const int NUM_RET_EVT = 3;
	int numSteps = 0;
	bool fDone = false;
	while( ++numSteps <= maxRetEvtAllowed )
	{
cout << "*************************************** ITERATION " << numSteps << " ******************************" << endl;
cout << "Number of configuration to process in this step: " << setCfgsToExplore.size() << endl;
		// 
		set<CfgConfiguration> setCfgsToExploreNext;
//cout << "Number of configuraitons found during this iteration so far: ";
		for( set<CfgConfiguration> :: iterator itt = setCfgsToExplore.begin(); itt != setCfgsToExplore.end(); ++itt )
		{
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
cout << "Processing configuration: ";
itt->Dump();
#endif
			// is this beaten by previously seen cfgs?
			//if( CfgBeatenByPrevious( *itt ) == true )
			//{
			//	continue;
			//}
			// include it in the processed
			//cfgsProcessed.insert(*itt);

			set<CfgConfiguration> setCfgsToExploreNextStep;
			// explore from it: GetNextCfgsPriority
			//if( const_cast<CfgConfiguration &>(*itt).GetNextCfgs(setCfgsToExploreNextStep, *this) == true)
			if( const_cast<CfgConfiguration &>(*itt).GetNextCfgs(setCfgsToExploreNextStep, *this) == true)
			{
				// we are done
				cout << "We have found the optimal network.";
				//cout << "Here is a list of configurations containing the solution.\n";
				for( set<CfgConfiguration> :: iterator itt2 = setCfgsToExploreNextStep.begin(); itt2 != setCfgsToExploreNextStep.end(); ++itt2 )
				{
					if( itt2->IsTerminal() == true)
					{
						//cout << "++++++++++";
						//itt2->Dump();
					}
				}
				fDone = true;
				break;
			}
			// add the currently found cfgs
			for( set<CfgConfiguration> :: iterator itt2 = setCfgsToExploreNextStep.begin(); itt2 != setCfgsToExploreNextStep.end(); ++itt2 )
			{
				setCfgsToExploreNext.insert(*itt2);
			}

//cout << setCfgsToExploreNext.size() << "  ";
//cout.flush();
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
#endif
		}
		if( fDone == true)
		{
			break;
		}
//cout << endl;

		// start from new
		setCfgsToExplore.clear();

		// figure out what to keep
		set<int> setNumLinTypes;
		map<int, set<CfgConfiguration> > mapPriorCfgs;
		for(set<CfgConfiguration> :: iterator ittg = setCfgsToExploreNext.begin(); ittg != setCfgsToExploreNext.end(); ++ittg)
		{
			// now add it to the next stage
			int cfgPriority = 0;
			//const_cast<CfgConfiguration &>(*ittg).EvalCfgPriorityCoarse(cfgPriority);
			const_cast<CfgConfiguration &>(*ittg).EvalCfgPriority(cfgPriority);
			// add to map
			if( mapPriorCfgs.find(cfgPriority) == mapPriorCfgs.end() )
			{
				set<CfgConfiguration> setCfgs;
				mapPriorCfgs.insert( map<int, set<CfgConfiguration> > :: value_type(cfgPriority, setCfgs) );
			}
			if( (int)mapPriorCfgs[cfgPriority].size() < maxSizePriorClass )
			{
				mapPriorCfgs[cfgPriority].insert(*ittg);

				setNumLinTypes.insert( ittg->GetNumLineageTypes() );
			}
			else
			{
				AddNumDroppedCfgs(1);
			}
		}
		// 
		//int numRemainCfgs = 0;
		//int i=0;
#ifdef DUMP_CFG_DEBUG
cout << "##########################Current list of configurations:\n";
#endif
		int numCfgKept = 0;
		bool fTerm = false;
		for(map<int, set<CfgConfiguration> >:: iterator ittt = mapPriorCfgs.begin(); ittt != mapPriorCfgs.end(); ++ittt)
		{
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxPriority score: " << ittt->first << endl;
#endif
			//if( i++< numCfgClassKeptChoices )
			//{
			for( set<CfgConfiguration> :: iterator ittg = ittt->second.begin(); ittg != ittt->second.end(); ++ittg)
			{
#ifdef DUMP_CFG_DEBUG
cout << "ccccccccccccc";
ittg->Dump();
#endif

				// do not queue if too many lineages types
#if 0
// seems to be too harsh
				const int MIN_CUT_OFF_STAGE_NUM = 5;
				const int MIN_CUT_OFF_LIN_TYPES = 5;
				set<int> :: reverse_iterator itBack2 = setNumLinTypes.rbegin();
				//itBack2++;
				if( numSteps >= MIN_CUT_OFF_STAGE_NUM && (int)setNumLinTypes.size() >= MIN_CUT_OFF_LIN_TYPES &&
					(ittg->GetNumLineageTypes() == *(setNumLinTypes.rbegin() ) || ittg->GetNumLineageTypes() == *itBack2  ) )
				{
					continue;
				}
#endif
				if( ++numCfgKept <= numCfgClassKeptChoices)
				{
					setCfgsToExplore.insert(*ittg);
				}
				else
				{
					fTerm = true;
					break;
				}
			}
			//	numRemainCfgs += ittt->second.size();
			//}
			//else
			//{
			//	AddNumDroppedCfgs( ittt->second.size() );
			//}
			if( fTerm == true)
			{
				break;
			}
		}
		cout << "The number of configurations found during this stage: " <<  setCfgsToExploreNext.size() << endl;
		cout << "The number of configurations kept at the end of this iteration: " << numCfgKept << endl;
		cout << "The best tree coverage score = " << mapPriorCfgs.begin()->first  << endl;
		//FilterFoundCfgs(setCfgsToExploreNext, setCfgsToExplore);
		//setCfgsToExplore = setCfgsToExploreNext;

		setCfgsToExploreNext.clear();
	}

	// dump out some statistics
	DumpStats();

	if( fDone == false)
	{
		cout << "WARNING: FAIL TO FIND SOLUTIONS. You may want to increase the number of allowed reticulation events.\n";
	}
	else
	{
		cout << "The minimum number of reticulation = " << numSteps << endl;
	}
}


void CfgExplorer :: ExplorePriority2()
{
	//
	// 
	GeneTreeInfo::Instance().ProcGeneTrees(listGeneTrees);

	// clear cache
	cfgsProcessed.clear();
	listStepCfgsProcessed.clear();
	listStepCfgsProcessed.resize(maxRetEvtAllowed+1);

	// now start exploring
	CfgConfiguration cfgInit;
	cfgInit.InitStart();
//cout << "Initial config: ";
//cfgInit.Dump();
	//set<CfgConfiguration> setCfgsToExplore;
	//setCfgsToExplore.insert( cfgInit );
	map<int, set<CfgConfiguration> > *pmapPriorCfgs = &listStepCfgsProcessed[0];
	int cfgPriority = -1;
	cfgInit.EvalCfgPriority(cfgPriority);
	// add to map
	//if( mapPriorCfgs.find(cfgPriority) == mapPriorCfgs.end() )
	{
		set<CfgConfiguration> setCfgs;
		(*pmapPriorCfgs).insert( map<int, set<CfgConfiguration> > :: value_type(cfgPriority, setCfgs) );
	}
	(*pmapPriorCfgs)[cfgPriority].insert(cfgInit);

	// explore up to certain steps
	//const int NUM_RET_EVT = 3;
	int numSteps = 0;
	bool fDone = false;
	int numCfgKept = 1;
	bool fTerm = false;

	while( ++numSteps <= maxRetEvtAllowed )
	{
cout << "*************************************** ITERATION " << numSteps << " ******************************" << endl;
cout << "Number of configuration to process in this step: " << numCfgKept << endl;
		numCfgKept = 0;
		// 
		//set<CfgConfiguration> setCfgsToExploreNext;
		pmapPriorCfgs = &listStepCfgsProcessed[numSteps-1];
		map<int, set<CfgConfiguration> > *pmapPriorCfgsNext = &listStepCfgsProcessed[numSteps];
//cout << "Number of configuraitons found during this iteration so far: ";
		int numPriorityClassExplored = 0;

		for( map<int, set<CfgConfiguration> > :: iterator ittmg = pmapPriorCfgs->begin(); ittmg != pmapPriorCfgs->end(); ++ittmg )
		{
			if( ++numPriorityClassExplored > numCfgClassKeptChoices)
			{
				// stop when the number of priority class limit is exceeded
				break;
			}
#ifdef DUMP_CFG_DEBUG
//cout << "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
cout << "Processing configuration with priority: ";
cout << ittmg->first << endl;
#endif
			for( set<CfgConfiguration> :: iterator itt = ittmg->second.begin(); itt != ittmg->second.end(); ++itt )
			{
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
cout << "Processing configuration: ";
itt->Dump();
#endif
				// is this beaten by previously seen cfgs?
				//if( CfgBeatenByPrevious( *itt ) == true )
				//{
				//	continue;
				//}
				// include it in the processed
				//cfgsProcessed.insert(*itt);

				// if a greedy intermdinate (i.e.more coalescent possible), skip
				if( itt->IsGreedyIntermediate() == true)
				{
					continue;
				}

				set<CfgConfiguration> setCfgsToExploreNextStep;
				// explore from it: GetNextCfgsPriority
				//if( const_cast<CfgConfiguration &>(*itt).GetNextCfgs(setCfgsToExploreNextStep, *this) == true)
				bool fFinish = const_cast<CfgConfiguration &>(*itt).GetNextCfgs(setCfgsToExploreNextStep, *this);

				// add the currently found cfgs
				for( set<CfgConfiguration> :: iterator itt2 = setCfgsToExploreNextStep.begin(); itt2 != setCfgsToExploreNextStep.end(); ++itt2 )
				{
					++ numCfgKept;
					// in case we want to reduce the number of kept configs
					// 09/16/12: HOWEVER, if finish has been found, then we do not discard anything b/c otherwise
					// we might lose the one leading to the finish cfg
					if( ++numCfgKept > maxNumCfgsKept && fFinish == false )
					{
						fTerm = true;
						break;
					}

					// now add it to the next stage
					//int cfgPriority = 0;
					//const_cast<CfgConfiguration &>(*itt2).EvalCfgPriorityCoarse(cfgPriority);
					//const_cast<CfgConfiguration &>(*itt2).EvalCfgPriority(cfgPriority);
					// add to map
					int numLinsCfg = itt2->GetTotNumLineages();
#ifdef DUMP_CFG_DEBUG_MORE
cout << "numLinsCfg = " << numLinsCfg << ": cfg = ";
itt2->Dump();
#endif

					if( pmapPriorCfgsNext->find(numLinsCfg) == pmapPriorCfgsNext->end() )
					{
						set<CfgConfiguration> setCfgs;
						pmapPriorCfgsNext->insert( map<int, set<CfgConfiguration> > :: value_type(numLinsCfg, setCfgs) );
					}
					if( (int)(*pmapPriorCfgsNext)[numLinsCfg].size() < maxSizePriorClass )
					{
						(*pmapPriorCfgsNext)[numLinsCfg].insert(*itt2);

						//setNumLinTypes.insert( itt2->GetNumLineageTypes() );
					}
					else
					{
						AddNumDroppedCfgs(1);
					}
				}

				if( fFinish == true)
				{
					// we are done
					cout << "We have found the optimal network. \n";
					//cout << "Here is a list of configurations containing the solution.\n";
					for( set<CfgConfiguration> :: iterator itt2 = setCfgsToExploreNextStep.begin(); itt2 != setCfgsToExploreNextStep.end(); ++itt2 )
					{
#ifdef DUMP_CFG_DEBUG
itt2->Dump();
#endif
						if( itt2->IsTerminal() == true)
						{
							//cout << "++++++++++";
							//itt2->Dump();

							// now trace back
							vector<CfgConfiguration> listHistoryCfgsTB;
							TraceBack(numSteps, const_cast<CfgConfiguration &>(*itt2), listHistoryCfgsTB);
							cout << "The number of configurations found in trace-back: " << listHistoryCfgsTB.size() << endl;


							// add originally coalesced history
							vector<CfgConfiguration> listPreprocessCfgs;
							ConsPreprocessCfgs(listPreprocessCfgs, listHistoryCfgsTB[ listHistoryCfgsTB.size()-1 ]);
							// now concatnate the two list
							vector<CfgConfiguration> listComboCfgs = listHistoryCfgsTB;
							for(int jjj=(int)listPreprocessCfgs.size()-1; jjj>=0; jjj--)
							{
								listComboCfgs.push_back(listPreprocessCfgs[jjj]);
							}

							// now output a gml file
							const string networkGMLNameTemp = "HybridizationNetwork.gml.tmp";
							//ReticulateNetworkImp rnResultTemp;
							//ConsNetworkGMLFromCfgs(listComboCfgs, networkGMLNameTemp, &rnResultTemp );
							ConsNetworkGMLFromCfgs(listComboCfgs, networkGMLNameTemp, NULL );
							//CheckResultRN(rnResultTemp);
							const string networkGMLName = "HybridizationNetwork.gml";
							bool fHVLines = true;
							refineNetwork(networkGMLNameTemp, networkGMLName, fHVLines);
							cout << "Constructed hybridization network is output to " << networkGMLName << endl;

							// now output the extended newick format of the network
							const string networkGMLNameTemp2 = "HybridizationNetwork.gml.tmp2";
							refineNetwork(networkGMLNameTemp,networkGMLNameTemp2,false);
							//const string networkGMLNameEWK ="HybridizationNetwork.ewk";
							string strEWK = convertGML2ExtNewick(networkGMLNameTemp2,false);
							cout << "**************************************************************\n";
							cout << "The constructed network (in the extended Newick format): \n" << strEWK << endl;
							//cout << "The EWK format is also outputted to a file called " << networkGMLNameEWK << endl;
							break;
						}
					}
					fDone = true;
					break;
				}

			}
			if( fDone == true)
			{
				break;
			}
//cout << setCfgsToExploreNext.size() << "  ";
//cout.flush();
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
#endif
		}
		if( fDone == true)
		{
			break;
		}
//cout << endl;

		// start from new
		//mapPriorCfgs.clear();
		//mapPriorCfgs = mapPriorCfgsNext;

		// figure out what to keep
		//set<int> setNumLinTypes;
		//map<int, set<CfgConfiguration> > mapPriorCfgs;

		// 
		//int numRemainCfgs = 0;
		//int i=0;
#ifdef DUMP_CFG_DEBUG
cout << "##########################Current list of configurations:\n";
#endif
		for(map<int, set<CfgConfiguration> >:: iterator ittt = pmapPriorCfgsNext->begin(); ittt != pmapPriorCfgsNext->end(); ++ittt)
		{
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxPriority score: " << ittt->first << endl;
#endif
			//if( i++< numCfgClassKeptChoices )
			//{
			for( set<CfgConfiguration> :: iterator ittg = ittt->second.begin(); ittg != ittt->second.end(); ++ittg)
			{
#ifdef DUMP_CFG_DEBUG
cout << "ccccccccccccc";
ittg->Dump();
#endif

				// do not queue if too many lineages types
#if 0
// seems to be too harsh
				const int MIN_CUT_OFF_STAGE_NUM = 5;
				const int MIN_CUT_OFF_LIN_TYPES = 5;
				set<int> :: reverse_iterator itBack2 = setNumLinTypes.rbegin();
				//itBack2++;
				if( numSteps >= MIN_CUT_OFF_STAGE_NUM && (int)setNumLinTypes.size() >= MIN_CUT_OFF_LIN_TYPES &&
					(ittg->GetNumLineageTypes() == *(setNumLinTypes.rbegin() ) || ittg->GetNumLineageTypes() == *itBack2  ) )
				{
					continue;
				}
#endif
#if 0
				if( ++numCfgKept <= maxNumCfgsKept)
				{
					setCfgsToExplore.insert(*ittg);
				}
				else
				{
					fTerm = true;
					break;
				}
#endif
			}
			//	numRemainCfgs += ittt->second.size();
			//}
			//else
			//{
			//	AddNumDroppedCfgs( ittt->second.size() );
			//}
			if( fTerm == true)
			{
				break;
			}
		}
		//cout << "The number of configurations found during this stage: " <<  setCfgsToExploreNext.size() << endl;
		cout << "The number of configurations kept at the end of this iteration: " << numCfgKept << endl;
		cout << "The best tree coverage score = " << pmapPriorCfgsNext->begin()->first  << endl;
		//FilterFoundCfgs(setCfgsToExploreNext, setCfgsToExplore);
		//setCfgsToExplore = setCfgsToExploreNext;

		//setCfgsToExploreNext.clear();
	}

	// dump out some statistics
	DumpStats();

	if( fDone == false)
	{
		cout << "WARNING: FAIL TO FIND SOLUTIONS. You may want to increase the number of allowed reticulation events.\n";
	}
	else
	{
		cout << "The minimum number of reticulation = " << numSteps << endl;
	}
}

void CfgExplorer :: CheckResultRN( ReticulateNetworkImp &resRN )
{
//cout << "In CheckResultRN:\n";
	// check resulting RN to ensure each input tree is embedded in it
	// find all embedded trees
	vector<PhylogenyTreeBasic *> listEmbeddedTrees;
	resRN.RetriveAllEmbeddedTrees( listEmbeddedTrees );
cout << "The number of total embedded trees: " << listEmbeddedTrees.size() << endl;
	// collect all trees embedded in it (in the sorted Newick format
	set< string > listNWEmbeddedTrees;
	for( int tr=0; tr<(int)listEmbeddedTrees.size(); ++tr )
	{
		listEmbeddedTrees[tr]->Order();
		string strNW;
		listEmbeddedTrees[tr]->ConsNewick( strNW );
//cout << "******* Found one embedded tree: " << strNW << endl;
		listNWEmbeddedTrees.insert( strNW );
	}
	// ensure each input tree is contained
	for(int ii=0; ii<(int)listOrigInputTrees.size(); ++ii)
	{
		listOrigInputTrees[ii]->Order();
		string strNW;
		listOrigInputTrees[ii]->ConsNewick( strNW );
//cout << "Current strNW = " << strNW << endl;
		// convert back to UDF taxa
		YW_ASSERT_INFO( pMapperTMapInfo != NULL, "Mapper: not set" );
		string strNWConv = pMapperTMapInfo->ConvIdStringWithOrigTaxa(strNW);
//cout << "Checking one input gene tree: " << strNWConv << endl;

		// need to sort it so we just use another (yes another) tree as the tool
		PhylogenyTreeBasic trToUse;
		trToUse.ConsOnNewick( strNWConv );
		trToUse.Order();
		string strNWConvSort;
		trToUse.ConsNewick( strNWConvSort );
//cout << "After sorting, the tree becomes: " << strNWConvSort << endl;
//cout << "Checking one input gene tree: " << strNWConvSort << endl;
		if( listNWEmbeddedTrees.find( strNWConvSort) == listNWEmbeddedTrees.end()  )
		{
cout << "*********************THIS INPUT TREE IS NOT EMBEDDED in the network: " << strNWConvSort << endl;
			YW_ASSERT_INFO(false, "FATAL ERROR: input tree is not present!");
		}
	}
	// cleanup memeory
	for( int tr=0; tr<(int)listEmbeddedTrees.size(); ++tr )
	{
		delete listEmbeddedTrees[tr];
	}
	cout << "PASSING INPUT TREE CONSTRAINT CHECKING\n";
}


void CfgExplorer :: TraceBack(int stageIndex, CfgConfiguration &cfgStart, vector<CfgConfiguration> &listCfgsHistory) 
{
#ifdef DUMP_CFG_DEBUG
cout << "stageIndex : " << stageIndex << endl;
cout << "The number of cfgs at stage 0: " << listStepCfgsProcessed[0].size() << endl;
cout << "The number of cfgs at stage 1: " << listStepCfgsProcessed[1].size() << endl;
cout << "The number of cfgs at stage 2: " << listStepCfgsProcessed[2].size() << endl;
#endif
	// for now, just dump out the configurations going through
	//CfgConfiguration *pCurCfg = const_cast<CfgConfiguration *>( this );
#ifdef DUMP_CFG_DEBUG
	int nIter = 0;
#endif 
	CfgConfiguration curCfg = cfgStart;
	int curStage = stageIndex;
	while( true)
	{
		listCfgsHistory.push_back(curCfg);
#ifdef DUMP_CFG_DEBUG
		cout << "Trace back step " << ++nIter << ": cfg = ";
		curCfg.Dump();
#endif
		// 
		int idCfgSrc = curCfg.GetSrcCfgId();
#ifdef DUMP_CFG_DEBUG
cout << "idCfgSrc = " << idCfgSrc  << ", curstage = " << curStage << endl;
#endif
		if( idCfgSrc < 0 )
		{
			// done
			break;
		}

		// search during the current stage to see if can find such a id
		bool fFound = false;
		for(int ii=0; ii<2; ++ii)
		{
			for(map<int, set<CfgConfiguration> >:: iterator ittt = listStepCfgsProcessed[curStage].begin(); 
				ittt != listStepCfgsProcessed[curStage].end(); ++ittt)
			{
#ifdef DUMP_CFG_DEBUG
cout << "xxxxxxxxxxxxxxPriority score: " << ittt->first << endl;
#endif
				//if( i++< numCfgClassKeptChoices )
				//{
				for( set<CfgConfiguration> :: iterator ittg = ittt->second.begin(); ittg != ittt->second.end(); ++ittg)
				{
#ifdef DUMP_CFG_DEBUG
cout << "ooooooooooooooooCfg: ";
ittg->Dump();
#endif

					if( ittg->GetId() == idCfgSrc )
					{
						curCfg = *ittg;
						fFound = true;
						break;
					}
				}
				if(fFound == true)
				{
					break;
				}
			}
			if( fFound == false)
			{
				YW_ASSERT_INFO(ii == 0, "FATAL ERROR in TRACE-BACK");
				// now search for a level below
				curStage --;
				YW_ASSERT_INFO( curStage >= 0, "curStage: underflow" );
			}
			else
			{
				break;
			}
		}

	}
}

#if 0
static void DumpNode( const GMLNode &node)
{
	cout << "Node " << node.nodeId << ": ";
	if( node.type >= 0)
	{
		cout << "Leaf taxon " << node.type;
	}
	else if(node.type == ID_COALESCENT_NODE)
	{
		cout << "[C]";
	}
	else if(node.type == ID_RETICULATION_NODE)
	{
		cout << "[R]";
	}
	else 
	{
		cout << "[Int]";
	}
	cout << "(" << node.xCoord << ", " << node.yCoord << ")\n";
}
#endif

static bool fShowInternNodeId = false;

void CfgExplorer :: ConsNetworkGMLFromCfgs(const vector<CfgConfiguration> &listCfgsHistory, const string & networkGMLName, ReticulateNetworkImp *pResRetNet)
{
	YW_ASSERT_INFO(listCfgsHistory.size() >= 1, "Must have something");
	const double widthCanvas = 400.0;
	const double heightCanvs = 400.0;

	// construct a network based on the give history and output to the GML file
	int numStage = listCfgsHistory.size();
	int numTaxa = GeneTreeInfo :: Instance().GetNumSpecies();

	double xDistRetLinFromOrig = 0.3*widthCanvas/numTaxa;
	double szNodeCircle = 0.1*widthCanvas/numTaxa;

	int nodeInGMLIdStart = 1;

	// keep track which lineage correspond to which node
	// that is, each lineage (with its lineage id) maps to some distinct node id in GML
	// This is needed since same lineage may have different node id in gml as moving backwards
	// pair<int,int>: lineage id and copy index
	map<pair<int,int>,GMLNode> lineageIdsPrevious;

	// keep track list of nodes and edges
	vector< GMLNode > listGMLNodes;
	vector< GMLEdge > listGMLEdges;
	vector< pair<GMLEdge, GMLEdge> > listRetEdges;

//cout << "Initial cfg: ";
//listCfgsHistory[ listCfgsHistory.size()-1 ].Dump();
	// start from the last cfg with all leaves
	int nIndex = 0;
	for( map< CfgLineage, int> :: iterator it =  const_cast<CfgConfiguration &>(listCfgsHistory[ listCfgsHistory.size()-1 ]).mapLineages.begin(); 
		it != const_cast<CfgConfiguration &>(listCfgsHistory[ listCfgsHistory.size()-1 ]).mapLineages.end(); ++it )
	{
		// 
		YW_ASSERT_INFO( it->second == 1, "Can only have a single lineage upon start" );
		//int linId = it->first.GetLinId();
		// create a gml node
		GMLNode node;
		node.nodeId = nodeInGMLIdStart++;
		set<int> sint;
		it->first.GetCoveredNodes(sint);
		YW_ASSERT_INFO(sint.size() > 0, "Fatal error");
		int idGTLeaf = *(sint.begin());
//cout << "idGTLeaf = " << idGTLeaf << endl;
		node.type = GeneTreeInfo::Instance().GetTaxonIdForLeafNode(idGTLeaf);
		if( node.type < 0 )
		{
			// then check for dummy leaves (which arise due to initial preprocessing)
			node.type = GeneTreeInfo::Instance().GetLeafIdFromNodeId( idGTLeaf);
			YW_ASSERT_INFO( node.type >=0, "Fail to find dummy leaf node" );
		}

		// position near the bottm
		node.yCoord = 0.0;
		node.xCoord = (widthCanvas/numTaxa)*(nIndex++);
//DumpNode(node);
		pair<int,int> pp(it->first.GetLinId(), 0);
		lineageIdsPrevious.insert( map<pair<int,int>,GMLNode> :: value_type(pp, node) );
		listGMLNodes.push_back( node );
	}

	// start from the last cfg, which is the leaves
	double htChange = 1.0*heightCanvs/numStage;
	for(int ns = numStage-2; ns>=0; ns--)
	{
//cout << "**********************Processing stage " << ns << endl;
//cout << "List of previous lineage and their id \n";
//for( map< pair<int,int>, GMLNode> :: iterator itt3 = lineageIdsPrevious.begin(); itt3 != lineageIdsPrevious.end(); ++itt3)
//{
//cout << "<" << itt3->first.first << ", " << itt3->first.second << ">:";
//DumpNode( itt3->second);
//}
		map<pair<int,int>,GMLNode> lineageIdsPreviousNext;


		// figure out the difference of two configurations
		map<CfgLineage,int> listLinsNovelThis;
		map<CfgLineage,int> listLinsNovelOther;
		listCfgsHistory[ns].CompareWith( listCfgsHistory[ns+1], listLinsNovelThis, listLinsNovelOther );
//cout << "Prior cfg: \n";
//listCfgsHistory[ns+1].Dump();
//cout << "Current cfg: \n";
//listCfgsHistory[ns].Dump();
//cout << "------After comparison: listLinsNovelThis =\n";
//for( map< CfgLineage, int> :: iterator it =  listLinsNovelThis.begin(); it !=listLinsNovelThis.end(); ++it )
//{
//cout << "Lineage: [" << it->second << "]:";
//it->first.Dump();
//}
//cout << "++++++After comparison: listLinsNovelOther =\n";
//for( map< CfgLineage, int> :: iterator it =  listLinsNovelOther.begin(); it !=listLinsNovelOther.end(); ++it )
//{
//cout << "Lineage: [" << it->second << "]:";
//it->first.Dump();
//}
		// make sure the diff is not too big
		YW_ASSERT_INFO( listLinsNovelThis.size() == 1, "ERROR 1");
		YW_ASSERT_INFO( listLinsNovelOther.size() <=2, "ERROR 2");

		// first move on with the lineages that are still in the play
		map<CfgLineage,int> listCfgsContinuing;
		for( map< CfgLineage, int> :: iterator it =  const_cast<CfgConfiguration &>(listCfgsHistory[ ns+1 ]).mapLineages.begin(); 
			it != const_cast<CfgConfiguration &>(listCfgsHistory[ ns+1 ]).mapLineages.end(); ++it )
		{
			// only deal with continuing (i.e. not involved in events)
			if( listLinsNovelOther.find(it->first) == listLinsNovelOther.end() )
			{
				int numCopies = it->second;
				// if there is a reduction of this lineage (as reflected by LinsNovelThis), then use it
				if( listLinsNovelThis.find( it->first ) != listLinsNovelThis.end() )
				{
					numCopies -= listLinsNovelThis[it->first];
				}
				//YW_ASSERT_INFO( numCopies >= 1, "Number of copies must be positive" );
				if(  numCopies >= 1 )
				{
					listCfgsContinuing.insert( map<CfgLineage,int>:: value_type(it->first, numCopies) );
				}
			}
		}
		// also add lineages after coalescent or reticulation
		set< pair<int,int> > setLinsLostInEvt;		// <lineage id, copy index>
		for( map< CfgLineage, int> :: iterator it = listLinsNovelOther.begin(); it != listLinsNovelOther.end(); ++it )
		{
			YW_ASSERT_INFO( const_cast<CfgConfiguration &>(listCfgsHistory[ ns+1 ]).mapLineages.find(it->first ) 
				!= const_cast<CfgConfiguration &>(listCfgsHistory[ ns+1 ]).mapLineages.end(), "FATAL ERROR 3.1"  );
			// if there is a difference (i.e. remaining)
			if(const_cast<CfgConfiguration &>(listCfgsHistory[ ns+1 ]).mapLineages[it->first] > it->second)
			{
				YW_ASSERT_INFO( const_cast<CfgConfiguration &>(listCfgsHistory[ ns ]).mapLineages.find(it->first ) 
					!= const_cast<CfgConfiguration &>(listCfgsHistory[ ns ]).mapLineages.end(), "FATAL ERROR 3.1.1"  );
				listCfgsContinuing.insert( map<CfgLineage,int>:: value_type(it->first, 
					const_cast<CfgConfiguration &>(listCfgsHistory[ ns+1 ]).mapLineages[it->first]-it->second   ) );
				YW_ASSERT_INFO(const_cast<CfgConfiguration &>(listCfgsHistory[ ns+1 ]).mapLineages[it->first] 
					== it->second+const_cast<CfgConfiguration &>(listCfgsHistory[ ns ]).mapLineages[it->first], "CAN NOT LOSE TWO COPIES AT ONE TIME");
				//pair<int,int> pp(it->first.GetLinId(), it->second);
				pair<int,int> pp(it->first.GetLinId(), const_cast<CfgConfiguration &>(listCfgsHistory[ ns ]).mapLineages[it->first] );
				setLinsLostInEvt.insert(pp);
			}
			else
			{
				pair<int,int> pp(it->first.GetLinId(), 0);
				setLinsLostInEvt.insert(pp);
			}
		}

		for( map< CfgLineage, int> :: iterator it =  listCfgsContinuing.begin(); it != listCfgsContinuing.end(); ++it )
		{

			// repeat for some
			for(int ii=0; ii<it->second; ++ii)
			{
				// create new node
				GMLNode node;
				node.nodeId = nodeInGMLIdStart++;
				node.type = ID_INTERMEDIATE_NODE;
				pair<int,int> pp(it->first.GetLinId(), ii);
				YW_ASSERT_INFO( lineageIdsPrevious.find(pp) != lineageIdsPrevious.end(), "FATAL ERROR 3"  );
				node.xCoord = lineageIdsPrevious[pp].xCoord;
				node.yCoord = lineageIdsPrevious[pp].yCoord+htChange;
//cout << "1. lineageIdsPreviousNext: Add one node: linid=" << pp.first << ", copyindex=" << pp.second << endl; 
				lineageIdsPreviousNext.insert( map<pair<int,int>,GMLNode> :: value_type(pp, node) );
				listGMLNodes.push_back( node );

				// now edges
				GMLEdge e;
				YW_ASSERT_INFO(lineageIdsPrevious.find(pp) != lineageIdsPrevious.end(), "ERROR4: Fail to find the lineage record");
				e.srcNodeId = lineageIdsPrevious[pp].nodeId;
				e.destNodeId = node.nodeId;
				e.fRet = false;
				listGMLEdges.push_back(e);
			}
		}

		// now deal with the two cases
		// first the newly created one is a coalescent
		if( setLinsLostInEvt.size() > 0 && setLinsLostInEvt.size() == 2 )
		{
			// deal with coalescent, should have two lineages involved
			YW_ASSERT_INFO(setLinsLostInEvt.size() == 2, "Failure in coalescent");
			// should also have one new lineage
			YW_ASSERT_INFO(listLinsNovelThis.size() == 1 && (*(listLinsNovelThis.begin())).second == 1, "ERROR 9");
			// move the two coalesced lineages back
			for(set< pair<int,int> >:: iterator itt2 =  setLinsLostInEvt.begin(); itt2 !=setLinsLostInEvt.end(); ++itt2 )
			{
//cout << "Lost in coalescent: lin id = " << itt2->first << ", copy index = " << itt2->second << endl;
				// 
				YW_ASSERT_INFO( lineageIdsPrevious.find(*itt2) != lineageIdsPrevious.end(), "ERROR8" );
				// create one new nodes and one new edges
				GMLNode node1;
				// first node directly above it
				node1.nodeId = nodeInGMLIdStart++;
				node1.type = ID_INTERMEDIATE_NODE;
				node1.xCoord = lineageIdsPrevious[*itt2].xCoord;
				node1.yCoord = lineageIdsPrevious[*itt2].yCoord+htChange;
				listGMLNodes.push_back( node1 );

				GMLEdge e1;
				//pair<int,int> pp(it->first.GetLinId(), ii);
				//YW_ASSERT_INFO(lineageIdsPrevious.find(pp) != lineageIdsPrevious.end(), "ERROR4: Fail to find the lineage record");
				e1.srcNodeId = lineageIdsPrevious[*itt2].nodeId;
				e1.destNodeId = node1.nodeId;
				e1.fRet = false;
				listGMLEdges.push_back(e1);
			}
			// now one more node
			YW_ASSERT_INFO( listGMLNodes.size() >=2, "Something very wrong" );
			int idPrevCoal1 = listGMLNodes[listGMLNodes.size()-1].nodeId;
			int idPrevCoal2 = listGMLNodes[listGMLNodes.size()-2].nodeId;
			GMLNode node3;
			// first node directly above it
			node3.nodeId = nodeInGMLIdStart++;
			node3.type = ID_COALESCENT_NODE;
			node3.xCoord = 0.5*(listGMLNodes[listGMLNodes.size()-1].xCoord + listGMLNodes[listGMLNodes.size()-2].xCoord);
			node3.yCoord = listGMLNodes[listGMLNodes.size()-1].yCoord;
			listGMLNodes.push_back( node3 );
			// this is a true new lineage
			pair<int,int> pp;
			pp.first = (*(listLinsNovelThis.begin())).first.GetLinId();
			pp.second = 0;
//cout << "2.lineageIdsPreviousNext: Add one node: linid=" << pp.first << ", copyindex=" << pp.second << endl; 
			lineageIdsPreviousNext.insert( map<pair<int,int>,GMLNode> :: value_type(pp, node3) );

			// create two more edges
			GMLEdge e1,e2;
			e1.srcNodeId = idPrevCoal1;
			e1.destNodeId = node3.nodeId;
			e1.fRet = false;
			listGMLEdges.push_back(e1);
			e2.srcNodeId = idPrevCoal2;
			e2.destNodeId = node3.nodeId;
			e2.fRet = false;
			listGMLEdges.push_back(e2);
		}
		else
		{
			// deal with reticulation
			YW_ASSERT_INFO(listLinsNovelThis.size() == 1 , "ERROR 5");
			// also this lineage must be in old lineage
			CfgLineage linRetPrev;
			//if( listCfgsHistory[ ns+1 ].mapLineages.find((*(listLinsNovelThis.begin())).first) != listCfgsHistory[ ns+1 ].mapLineages.end() )
			if( listLinsNovelOther.size() == 0 )
			{
				// then ret lin is exactly the same as the one in the original one
				linRetPrev = (*(listLinsNovelThis.begin())).first;
			}
			else
			{
				// then take the one in the ret other
				YW_ASSERT_INFO( listLinsNovelOther.size() == 1, "Wrong in ret lins" );
				linRetPrev = (*(listLinsNovelOther.begin())).first; 
			}
			YW_ASSERT_INFO( listCfgsHistory[ ns+1 ].mapLineages.find( linRetPrev ) != listCfgsHistory[ ns+1 ].mapLineages.end(), "ERROR 6" );

			// by default, assume the last copy will reticulate
			int linIdRet = linRetPrev.GetLinId() ;
			int copyIndex = const_cast<CfgConfiguration &>(listCfgsHistory[ ns+1 ]).mapLineages[linRetPrev]-1;
//cout << "linIdRet: " << linIdRet << ", copyIndex = " << copyIndex << endl;
			YW_ASSERT_INFO(copyIndex >= 0, "FAIL");
			pair<int,int> pp(linIdRet, copyIndex);
			YW_ASSERT_INFO( lineageIdsPrevious.find(pp) != lineageIdsPrevious.end(), "ERROR7" );
			// create three new nodes and edges
			GMLNode node1,node2,node3;
			// first node directly above it
			node1.nodeId = nodeInGMLIdStart++;
			node1.type = ID_RETICULATION_NODE;
			node1.xCoord = lineageIdsPrevious[pp].xCoord;
			node1.yCoord = lineageIdsPrevious[pp].yCoord+htChange;
			listGMLNodes.push_back( node1 );
			// second to the left of first one by some distance
			node2.nodeId = nodeInGMLIdStart++;
			node2.type = ID_INTERMEDIATE_NODE;
			node2.xCoord = lineageIdsPrevious[pp].xCoord-xDistRetLinFromOrig;
			node2.yCoord = lineageIdsPrevious[pp].yCoord+htChange;
			// this is a true new lineage
//cout << "a.lineageIdsPreviousNext: Add one node: linid=" << pp.first << ", copyindex=" << pp.second << endl; 
			// erase a previous one if any
			lineageIdsPreviousNext.erase(pp);
			lineageIdsPreviousNext.insert( map<pair<int,int>,GMLNode> :: value_type(pp, node2) );
			listGMLNodes.push_back( node2 );
			// thrid to the right of first one by some distance
			node3.nodeId = nodeInGMLIdStart++;
			node3.type = ID_INTERMEDIATE_NODE;
			node3.xCoord = lineageIdsPrevious[pp].xCoord+xDistRetLinFromOrig;
			node3.yCoord = lineageIdsPrevious[pp].yCoord+htChange;
			// this is a true new lineage
			pair<int,int> pp2=pp;
			pp2.second++;
//cout << "aa.lineageIdsPreviousNext: Add one node: linid=" << pp2.first << ", copyindex=" << pp2.second << endl; 
			lineageIdsPreviousNext.insert( map<pair<int,int>,GMLNode> :: value_type(pp2, node3) );
			listGMLNodes.push_back( node3 );

			// now edges
			GMLEdge e1,e2,e3;
			//pair<int,int> pp(it->first.GetLinId(), ii);
			//YW_ASSERT_INFO(lineageIdsPrevious.find(pp) != lineageIdsPrevious.end(), "ERROR4: Fail to find the lineage record");
			e1.srcNodeId = lineageIdsPrevious[pp].nodeId;
			e1.destNodeId = node1.nodeId;
			e1.fRet = false;
			listGMLEdges.push_back(e1);
			e2.srcNodeId = node1.nodeId;
			e2.destNodeId = node2.nodeId;
			e2.fRet = true;
			listGMLEdges.push_back(e2);
			e3.srcNodeId = node1.nodeId;
			e3.destNodeId = node3.nodeId;
			e3.fRet = true;
			listGMLEdges.push_back(e3);

			// add reticulate records
			pair<GMLEdge, GMLEdge> ppRetEdges;
			ppRetEdges.first = e2;
			ppRetEdges.second = e3;
			listRetEdges.push_back( ppRetEdges );
		}
		// update the previous id map
		lineageIdsPrevious = lineageIdsPreviousNext;
	}

	// now output to the gml file (finally)
	// Now output a file in GML format
	// First create a new name

	// Now open file to write out
	ofstream outFile( networkGMLName.c_str() );

	// First output some header info
	outFile << "graph [\n"; 
	outFile << "comment ";
	OutputQuotedString(outFile, "Automatically generated by Graphing tool");
	outFile << "\ndirected  0\n";		// do not use direction: direction is trivially held
	outFile << "id  1\n";
	outFile << "label ";
	OutputQuotedString ( outFile, "Hybridization Network Generated by PIRN");
	outFile << endl;

	// Now output all the vertices
	int indexRetNode = 1;
	for(int ii=0; ii<(int)listGMLNodes.size(); ++ii)
	{
		outFile << "node [\n";

		outFile << "id " <<  listGMLNodes[ii].nodeId  << endl;
		outFile << "label ";
 		string nameToUse = " ";
		bool fLeaf = false;
        if( listGMLNodes[ii].type >= 0 )
        {
			// retrive from mapper if any
			if( pMapperTMapInfo != NULL)
			{
				nameToUse = pMapperTMapInfo->GetString( listGMLNodes[ii].type );
			}
			else
			{
				char buf[100];
				sprintf( buf, "%d", listGMLNodes[ii].type  );
				nameToUse = buf;
			}
			fLeaf = true;
        }
		// for now, all intermediate shows ID string
		else if( fShowInternNodeId == true )
		{
			char buf[100];
			sprintf( buf, "s%d", listGMLNodes[ii].nodeId );
			nameToUse = buf;
		}
		if(listGMLNodes[ii].type == ID_RETICULATION_NODE)
		{
			// assign some distinct Reticulation ID
			char buf[100];
			sprintf( buf, "#H%d", indexRetNode++ );
			nameToUse = buf;
		}

        const char *name = nameToUse.c_str();

        OutputQuotedString (outFile,  name  ); 
		outFile << endl;

		// output the location
		outFile << "graphics [\n";
        outFile << " Image [ \n Type ";
		OutputQuotedString( outFile,  "URL"  );
		outFile << " \n  Location ";
		OutputQuotedString(outFile, "");
		outFile << "\n  ] \n";
#if 0
		if(fLeaf == true)
		{
			outFile << "fill ";
			OutputQuotedString( outFile,  "#FFFFFF"  );
			outFile << "\n";
		}
		else if( listGMLNodes[ii].type  == ID_RETICULATION_NODE)
		{
			outFile << "fill ";
			OutputQuotedString( outFile,  "#FF0000"  );
			outFile << "\n";
		}
		else if( listGMLNodes[ii].type  == ID_COALESCENT_NODE)
		{
			outFile << "fill ";
			OutputQuotedString( outFile,  "#888888"  );
			outFile << "\n";
		}
#endif
		outFile << "  center [\n";
		outFile << "x " << listGMLNodes[ii].xCoord << "  \n  y " << listGMLNodes[ii].yCoord << "  \n" << " z 0.0 \n";
		double sz = szNodeCircle;
		if( listGMLNodes[ii].type == ID_INTERMEDIATE_NODE)
		{
			sz = 0.001;
		}
        outFile << " ] \n   width " << sz << "\n  height " << sz << "\n  depth " << sz << "\n   ] \n";

        // See if we need special shape here
        if( listGMLNodes[ii].type == ID_RETICULATION_NODE)
        {
            outFile << "vgj [ \n shape  ";
            OutputQuotedString( outFile, "Rectangle");
    		outFile << "\n]\n";
        }
        else
        {
		    outFile << "defaultAtrribute   1\n";
        }
        
		outFile << "]\n";

//cout << "a.1.2\n";
	}
//cout << "a.1.3\n";

	for(int ii=0; ii<(int)listGMLEdges.size(); ++ii)
	{

//cout << "Output an edge \n"; 
		outFile << "edge [\n";
		outFile << "source " << listGMLEdges[ii].srcNodeId << endl; 
		outFile << "target  " << listGMLEdges[ii].destNodeId << endl; 
		outFile << "label " ;
		OutputQuotedString( outFile,  ""  );
		outFile << "\n";
		outFile << "]\n";
	}

	// if needed, construct a phylo net for it
	if( pResRetNet != NULL)
	{
		// 
		pResRetNet->Init();

		// Now output all the vertices
		for(int ii=0; ii<(int)listGMLNodes.size(); ++ii)
		{
			// create a node
			RN_NODE_ID nid = pResRetNet->CreateNode();

			bool fLeaf = false;
	 		string nameToUse = " ";
			if( listGMLNodes[ii].type >= 0 )
			{
				// retrive from mapper if any
				if( pMapperTMapInfo != NULL)
				{
					nameToUse = pMapperTMapInfo->GetString( listGMLNodes[ii].type );
				}
				else
				{
					char buf[100];
					sprintf( buf, "%d", listGMLNodes[ii].type  );
					nameToUse = buf;
				}
				fLeaf = true;
			}
//cout << "nametouse: " << nameToUse << endl;
			int leafId = -1;
			if( fLeaf == true)
			{
				const char *name = nameToUse.c_str();
				sscanf( name, "%d", &leafId);
				YW_ASSERT_INFO( leafId >= 0, "Leaf id must be >= 0" );
				pResRetNet->SetLeafId( nid, leafId);
//cout << "NETWORK CONSTRUCTION: Adding leaf id: " << leafId << endl;
			}

	//cout << "a.1.2\n";
		}
	//cout << "a.1.3\n";

		for(int ii=0; ii<(int)listGMLEdges.size(); ++ii)
		{
			if( listGMLEdges[ii].fRet == false)
			{
				pResRetNet->AddTreeEdge( listGMLEdges[ii].destNodeId, listGMLEdges[ii].srcNodeId); 
			}
		}
		// now add reticulate edges
		for(int ii=0; ii<(int)listRetEdges.size(); ++ii)
		{
			YW_ASSERT_INFO( listRetEdges[ii].first.srcNodeId ==  listRetEdges[ii].second.srcNodeId, "mismatch in nodes" );
			pResRetNet->AddReticulateEdges( listRetEdges[ii].first.destNodeId, listRetEdges[ii].second.destNodeId, 
				listRetEdges[ii].first.srcNodeId); 
		}
	}


	// Finally quite after closing file
	outFile << "\n]\n";
	outFile.close();
}

void CfgExplorer :: ConsPreprocessCfgs(vector<CfgConfiguration> &listPreprocessCfgs, const CfgConfiguration &cfg1stAfterReduction)
{
	// construct coalescent cfgs due to preprocessing
	if( listRemovedPairs.size() == 0 )
	{
		// nothing to be done
		return;
	}
	YW_ASSERT_INFO( pMapperTMapInfo !=NULL, "Taxon mapper must be there");
//cout << "ConsPreprocessCfgs :: cfg1stAfterReduction: ";
//cfg1stAfterReduction.Dump();
	// start by creating a single cfg with the original set of lineages
	CfgConfiguration cfgInit;
	// YW: NOTE: assume in the starting ids, it starts with lineage 0,1,2,3...
	// this is because TaxonMapper assumes it
	vector< CfgLineage > listLinsPrev;
	for(int i=0; i<pMapperTMapInfo->GetNumTaxaInMapper(); ++i)
	{
		CfgLineage clin;
		CfgLineage::AssignLineageId(clin);
		for(int tr =0; tr<GeneTreeInfo :: Instance().GetNumGeneTrees(); ++tr)
		{
			int cid =-1;
			if( GeneTreeInfo::Instance().IsLeafIdIn(tr,i) == false  )
			{
				cid = GeneTreeInfo::Instance().AddDummyLeafId(tr, i);
			}
			else
			{
				cid = GeneTreeInfo::Instance().GetNodeIdForLeaf(tr, i);
			}
//cout << "taxon " << i << ", tr = " << tr << ", cid = " << cid << endl;
			CfgLineageSrc clinSrc(cid);
			//clin.AddSrc(clinSrc, true);
			clin.AddSrc(clinSrc);
		}
		// if this lin really new? If not, use the original copy
		CfgLineage linCopy;
		if( cfg1stAfterReduction.FindMatchingLin(clin, linCopy) == true )
		{
//cout << "xxxFind a copy for this lineage: linCopy = ";
//linCopy.Dump();
//cout << " for the query: clin = ";
//clin.Dump();
			clin = linCopy;
		}
		cfgInit.AddLin( clin);

		// also save for next
		listLinsPrev.push_back( clin );
	}
	listPreprocessCfgs.push_back( cfgInit );

	// now going backwards...
	int idToUseNext = pMapperTMapInfo->GetNumTaxaInMapper()+1;
	YW_ASSERT_INFO(listRemovedPairs.size() == listSurvivePos.size(), "SIZE mismatch" );
	for( int i=0; i<(int)listRemovedPairs.size()-1; ++i )
	{
		// note: the last removal leads to the starting cfg in the shrunk space, and thus do not need to consider
		// create new cfg by removing 
		CfgConfiguration cfgCurr;
		// remove the lineages specified by rem pairs
		pair<int,int> rmPairs = listRemovedPairs[i];
		OrderInt( rmPairs.first, rmPairs.second);
		// add all except those specified in the pairs
		vector<CfgLineage> listLinsCur;
		for(int jj=0; jj<(int)listLinsPrev.size(); ++jj )
		{
			//
			if( jj != rmPairs.first && jj != rmPairs.second)
			{
				cfgCurr.AddLin( listLinsPrev[jj] );
				listLinsCur.push_back( listLinsPrev[jj] );
			}
		}
		// finally add the new one
		CfgLineage clin;
		CfgLineage::AssignLineageId(clin);
		int idCur = idToUseNext++;
		for(int tr =0; tr<GeneTreeInfo :: Instance().GetNumGeneTrees(); ++tr)
		{
			int cid =-1;
			if( GeneTreeInfo::Instance().IsLeafIdIn(tr,idCur) == false  )
			{
				cid = GeneTreeInfo::Instance().AddDummyLeafId(tr, idCur);
			}
			else
			{
				cid = GeneTreeInfo::Instance().GetNodeIdForLeaf(tr, idCur);
			}
			CfgLineageSrc clinSrc(cid);
			//clin.AddSrc(clinSrc, true);
			clin.AddSrc(clinSrc);
		}
		// if this lin really new? If not, use the original copy
		CfgLineage linCopy;
		if( cfg1stAfterReduction.FindMatchingLin(clin, linCopy) == true )
		{
			clin = linCopy;
		}

		cfgCurr.AddLin( clin);
		listLinsCur.push_back( clin );

		// save to the results list 
		listPreprocessCfgs.push_back( cfgCurr );

		// update prev list
		listLinsPrev = listLinsCur;
	}
}

void CfgExplorer :: DumpStats()
{
	cout << "**************************************************************\n";
	cout << "Number of processed configurations: " << numProcessedCfgs << endl;
#if 0
	cout << "Number of bypassed configurations: " << numBeatenCfgs << endl;
	cout << "Number of useless coalescents: " << numUselessCoals << endl;
	cout << "Number of coalescents back to earlier lineage: " << numUselessCoalsDesc << endl;
	cout << "Number of useless reticulations: " << numUselessRets << endl;
	cout << "Number of configurations pruned by weak infeasibility rule:  " << numInfeasible << endl;
	cout << "Number of configurations pruned by strong infeasibility rule: " << numStrongInfeasible << endl;
	cout << "Number of configurations pruned by stronger infeasibility rule:" << numEvenStrongInfeasible << endl;
	cout << "Number of dropped (and if greater than 0, we may miss optimal solution): " << numDroppedCfgs << endl;
	cout << "Number of reduced configurations: " << numCfgLinSrcCleaned << endl;
	cout << "Number of early terminated configurations: " << numEarlyTerminateCfgs << endl;
	cout << "Number of reduced configurations by preferred configurations: " << numCfgSaveByPreferCoal << endl;

	for( map<int, set<CfgConfiguration> > :: iterator itt = cfgsProcessed.begin(); itt != cfgsProcessed.end(); ++itt)
	{
		cout <<  "[" << itt->first << "]:" << "Sise of processed configuration: " << itt->second.size() << endl;
	}
	cout << "Size of beaten configuration: " << cfgsBeatenBefore.size() << endl;
#endif
	cout << "**************************************************************\n";
}

void CfgExplorer :: FilterFoundCfgs(const set<CfgConfiguration> &setCfgsCandidates, set<CfgConfiguration> &setCfgsToExploreNext )
{
	// for now, do nothing
	setCfgsToExploreNext = setCfgsCandidates;
#if 0
	// only put configs that are not beaten by any other configs
	for( set<CfgConfiguration> :: iterator itt= setCfgsCandidates.begin(); itt != setCfgsCandidates.end(); ++itt )
	{
		// try other configs
		bool fBeaten = false;
		for( set<CfgConfiguration> :: iterator itt2= setCfgsCandidates.begin(); itt2 != setCfgsCandidates.end(); ++itt2 )
		{
			if( itt2 == itt )
			{
				continue;
			}
			if(itt->IsBeatenBy(*itt2) == true )
			{
				fBeaten = true;
				break;
			}
		}
		if( fBeaten == false )
		{
			setCfgsToExploreNext.insert( *itt );
		}
	}
cout << "The numbers of candidates before and  filtering: " << setCfgsCandidates.size() << ", " << setCfgsToExploreNext.size() << endl;
#endif
}

bool CfgExplorer :: CfgBeatenByPrevious(const CfgConfiguration& cfgTest)
{
	// do nothing for now
	return false;

//#if 0
//cout << "In CfgExplorer :: CfgBeatenByPrevious: cfgTest = ";
//cfgTest.Dump();
	if( cfgsProcessed.find( cfgTest.GetNumLineageTypes() ) != cfgsProcessed.end()
		&& cfgsProcessed[cfgTest.GetNumLineageTypes()].find(cfgTest) !=  cfgsProcessed[cfgTest.GetNumLineageTypes()].end() )
	{
		// seen before
//cout << "THIS CFG HAS BEEN FOUND BEFORE\n";
//cfgTest.Dump();
		return true;
	}

	// 
	int numTotLins = cfgTest.GetTotNumLineages();
	int numLinTypes = cfgTest.GetNumLineageTypes();
	if( cfgsBeatenBefore.find( cfgTest) != cfgsBeatenBefore.end() )
	{
		// this cfg has been beaten before, so same answer
		return true;
	}

	//for( map<int, set<CfgConfiguration> > :: iterator it = cfgsProcessed.begin(); it != cfgsProcessed.end(); ++it)
	//{
		//if( it->first < numTotLins)
		//{
		//	continue;
		//}
//#if 0
	if( cfgsProcessed.find(numLinTypes) != cfgsProcessed.end()  )
	{

		for( set<CfgConfiguration> :: iterator it2 = cfgsProcessed[numLinTypes].begin(); it2 != cfgsProcessed[numLinTypes].end(); ++it2 )
		{
#if 0
			if( numTotLins > it2->GetTotNumLineages() )
			{
				// for now, only test those with at least same number of lin types
				continue;
			}
#endif
	//cout << "Compare with a previous cfg: ";
	//it->Dump();
			if( cfgTest.IsBeatenBy(*it2) == true)
			{
//cout << "BBBBBBBBBBBBBBBBBBBBBBBeaten by an existing config!\n";
//cout << "Beaten cfg: ";
//cfgTest.Dump();
//cout << "The one beating it: ";
//it2->Dump();
//cout << "CCCCCCCCCCCCCCCCCCCCCCCC\n";
				cfgsBeatenBefore.insert( cfgTest );
				numBeatenCfgs++;
				return true;
			}
		}
	//}
	}
//#endif
	// add it
	if( cfgsProcessed.find( numTotLins) == cfgsProcessed.end() )
	{
		set<CfgConfiguration> scfgs;
		cfgsProcessed.insert( map<int, set<CfgConfiguration> > :: value_type(numLinTypes, scfgs) );
	}
	cfgsProcessed[numLinTypes].insert( cfgTest );
//#endif

	return false;
}


///////////////////////////////////////////////////////////////////////////////////////

ProcLineagesDepot  ProcLineagesDepot :: instance;


void ProcLineagesDepot :: AddProcCfg( CfgConfiguration &cfg, const set<int> &auxInfo )
{
return;
	//set<int> sint;
	//cfg.GetCoveredNodes( sint );
	setProcNodesList.insert( auxInfo);
}

bool ProcLineagesDepot :: IsCfgProcessed( CfgConfiguration &cfg, const set<int> &auxInfo )
{
return false;
	//set<int> sint;
	//cfg.GetCoveredNodes( sint );
	// this is a fast approximated way of determining whether continue or not
	return  setProcNodesList.find( auxInfo ) != setProcNodesList.end();
}


///////////////////////////////////////////////////////////////////////////////////////
#ifdef RET_EVT_IMP

ReticulateSetLinSrcDepot ReticulateSetLinSrcDepot :: instance;
int ReticulateSetLinSrcDepot :: idReticulateSetNext = 1;

bool ReticulateSetLinSrcDepot :: GetProcessedEvtSet( int retSetId, set<CfgRetEvt> &evtSet )
{
	// if res id < 0, return empty set
	evtSet.clear();
	if( retSetId < 0 )
	{
		return true;
	}

	bool res = false;
	if( mapRetIdToEvtSet.find( retSetId) != mapRetIdToEvtSet.end() )
	{
		evtSet = mapRetIdToEvtSet[retSetId];
		res = true;
	}
//cout << "GetProcessedEvtSet: evtid = " << retSetId << ", evtSet = ";
//DumpIntSet( evtSet ); 
	return res;
}

int ReticulateSetLinSrcDepot :: GetProcessedEvtSetId( const set<CfgRetEvt> &evtSet )
{
	int res = -1;
	if( evtSet.size() == 0)
	{
		return res;
	}

	if( mapEvtSetToRetId.find( evtSet) != mapEvtSetToRetId.end() )
	{
		res = mapEvtSetToRetId[evtSet];
	}
//cout << "GetProcessedEvtSetId: id = " << res << " for event set ";
//DumpIntSet( evtSet );
	return res;
}

bool ReticulateSetLinSrcDepot :: AreEvtSetsDisjoint( int retSetId1, int retSetId2, set<CfgRetEvt> *pevtsetUnion )
{
	if( retSetId1 < 0 || retSetId2 < 0)
	{
		// setup union if needed
		if( pevtsetUnion != NULL )
		{
			if( retSetId1 < 0 )
			{
				// get the second set
				GetProcessedEvtSet( retSetId2, *pevtsetUnion );
			}
			if( retSetId2 < 0 )
			{
				// get the second set
				GetProcessedEvtSet( retSetId1, *pevtsetUnion );
			}
		}
		return true;
	}

	//
	set<CfgRetEvt> evtSet1, evtSet2;
	bool f1 = GetProcessedEvtSet( retSetId1, evtSet1 );
	bool f2 = GetProcessedEvtSet( retSetId2, evtSet2 );
//cout << "---AreEvtSetsDisjoint: retSetId1 = " << retSetId1 << ", evtset1 = ";
//DumpIntSet( evtSet1);
//cout << "---AreEvtSetsDisjoint: retSetId2 = " << retSetId2 << ", evtset2 = ";
//DumpIntSet( evtSet2);
	YW_ASSERT_INFO( f1 == true && f2 == true, "Evt id is new" );
	if( pevtsetUnion != NULL)
	{
		*pevtsetUnion = evtSet1;
		UnionSets( *pevtsetUnion, evtSet2 );
	}
	set<CfgRetEvt> setEvtInt;
	JoinSets( evtSet1, evtSet2, setEvtInt );
//cout << "evtid1 = " << retSetId1 << ", evtid2 = " << retSetId2 << ", uion = ";
//DumpIntSet( evtsetUnion);
	return setEvtInt.size() == 0;
}


int ReticulateSetLinSrcDepot :: CreateEvtSet( const set<CfgRetEvt> &evtSet)
{
	if( evtSet.size() == 0)
	{
		return -1;
	}
//cout << "CreateEvtSet: evtSet = ";
//DumpIntSet( evtSet );
	//
	int evtId = idReticulateSetNext++;
	mapRetIdToEvtSet.insert( map< int, set<CfgRetEvt> > :: value_type( evtId, evtSet ) );
	mapEvtSetToRetId.insert( map< set<CfgRetEvt>, int > :: value_type( evtSet, evtId ) );
//cout << "Event id = " << evtId << endl;
	return evtId;
}

int ReticulateSetLinSrcDepot :: GetExpandedEvtSetId(int evtIdOld, CfgRetEvt evtNew)
{
//cout << "GetExpandedEvtSetId: evtIdOld = " << evtIdOld << ", evtNew = " << evtNew << endl;
	//
	set<CfgRetEvt> evtSetOld;
	bool fCurEvtSet = GetProcessedEvtSet( evtIdOld, evtSetOld );
//cout << "Convereted ret evts = ";
//DumpIntSet( evtSetOld );
	YW_ASSERT_INFO( fCurEvtSet == true, "Fatal error: evtIdOld is wrong" );
	evtSetOld.insert( evtNew );
	int res = GetProcessedEvtSetId( evtSetOld );
	if( res < 0 )
	{
		// create a new one
		res = CreateEvtSet( evtSetOld );
	}
	return res;
}

bool ReticulateSetLinSrcDepot :: IsEvtSetSubsetOf(int evtsetIdContained, int evtsetIdContainer)
{
//cout << "IsEvtSetSubsetOf: idconaiined = " << evtsetIdContained << ", evtsetIdContainer = " << evtsetIdContainer << endl;
	// 
	set<CfgRetEvt> evtSetContained, evtSetContainer;
	bool f1 = GetProcessedEvtSet( evtsetIdContained, evtSetContained );
	bool f2 = GetProcessedEvtSet( evtsetIdContainer, evtSetContainer );
	YW_ASSERT_INFO( f1 == true && f2 == true, "Evt id is new" );
	if( evtSetContained.size() > evtSetContainer.size() )
	{
//cout << "Size: not contained" << endl;
		return false;
	}
	for( set<CfgRetEvt> :: iterator it = evtSetContained.begin(); it != evtSetContained.end(); ++it )
	{
		if( evtSetContainer.find(*it) == evtSetContainer.end() )
		{
//cout << "Item: not contained\n";
			return false;
		}
	}
	return true;
}

int ReticulateSetLinSrcDepot :: RetrieveRetEvtSetId( set<CfgRetEvt> &evtSet )
{
	if( evtSet.size() == 0)
	{
		return -1;
	}
	// if this set of evet is already in record, return the old id
	// otherwise crate a new id for it
	int res = GetProcessedEvtSetId( evtSet );
	if( res < 0)
	{
		res = CreateEvtSet( evtSet);
	}
//cout << "RetrieveRetEvtSetId: id = " << res << ", evtSet = ";
//DumpIntSet( evtSet );
	return res;
}

#endif
