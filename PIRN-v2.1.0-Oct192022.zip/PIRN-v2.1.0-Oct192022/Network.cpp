#include "Network.h"
#include "UnWeightedGraph.h"
#include <stack>
#include "SprILP.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const int MIN_IV_LENGTH_PF_TEST = 8;    // prefer each tree has at least this many splits
extern bool fAcyclic;



// a utility code to find smallest hitting set
int SlowHittingSetSolver( const vector< set<int> > &listSets, set<int> &setFound )
{
	// take a naive approach: find the list of elements
	// and then just try all subsets (starting from smaler) to see if alls sets are covered
	set<int> elems;
	for(int i=0; i<(int)listSets.size(); ++i)
	{
//cout << "Sets in SlowHittingSetSolver: ";
//DumpIntSet( listSets[i] );
		UnionSets( elems, listSets[i] );
	}
	vector<int> elemsvec;
	PopulateVecBySet( elemsvec, elems );
	//
	int res = 0;
	for(int num=1; num<= (int)elems.size(); ++num)
	{
		// 
		vector<int> posvec;
		GetFirstCombo(num, elems.size(), posvec);
		while(true)
		{
			// is this subset touching every set 
			set<int> itemsChosen;
			for( int ii=0; ii<(int)posvec.size(); ++ii )
			{
				itemsChosen.insert( elemsvec[ posvec[ii] ] );
			}
			bool fail = false;
			for( int jj=0; jj<(int)listSets.size(); ++jj  )
			{
				//
				set<int> sint;
				JoinSets( itemsChosen, listSets[jj], sint );
				if( sint.size() == 0 )
				{
					fail = true;
					break;
				}
			}

			if( fail == false )
			{
				res = num;
				setFound = itemsChosen;
				break;
			}

			// done if no more
			if( GetNextCombo(num, elems.size(), posvec ) == false )
			{
				break;
			}
		}
		if( res > 0 )
		{
			break;
		}
	}
//cout << "SlowHittingSetSolver: res = " << res << ", items = ";
//DumpIntSet(setFound);
	return res;
}



// test whether MAF is good: first a valid MAF, and then is acyclic
bool IsMAFGood( const MarginalTree &tree1, const vector<int> &cutEdges, const MarginalTree &tree2  )
{

    // first make sure the cut create a valid MAF

    vector< set<int> > ssLeavesByCuts;
    tree1.GetLeafSetsForCuts( cutEdges, ssLeavesByCuts );

    // 
    vector<vector<bool> > ancestralRelations( ssLeavesByCuts.size()  );
    for( int i=0; i<(int) ssLeavesByCuts.size(); ++i )
    {
        for(int j=0; j<(int)ssLeavesByCuts.size(); ++j)
        {
            ancestralRelations[i].push_back( false );;
        }
    }



    vector<int> listParentsTree1;
    for( int ii=0; ii<(int)ssLeavesByCuts.size(); ++ii )
    {
        int npp = tree1.GetMRCAForNodes( ssLeavesByCuts[ii] );
//        cout << "Parent = " << npp <<  " for leave sets ";
//        DumpIntSet( ssLeavesByCuts[ii] );
        listParentsTree1.push_back(npp);
    }
    for( int ii=0; ii<(int)listParentsTree1.size(); ++ii )
    {
        for(int jj=ii+1; jj<(int)listParentsTree1.size(); ++jj)
        {
            if( tree1.IsNodeUnder(listParentsTree1[ii], listParentsTree1[jj]  ) == true)
            {
                ancestralRelations[jj][ii] = true;
//cout << "Cluster " << jj << " is ancestral to cluster " << ii << endl ;
            }
            else if( tree1.IsNodeUnder(listParentsTree1[jj], listParentsTree1[ii]  ) == true)
            {
                ancestralRelations[ii][jj] = true;
//cout << "Cluster " << ii << " is ancestral to cluster " << jj << endl ;
            }

        }
    }

    vector<int> listParentsTree2;
    for( int ii=0; ii<(int)ssLeavesByCuts.size(); ++ii )
    {
        int npp = tree2.GetMRCAForNodes( ssLeavesByCuts[ii] );
//        cout << "Parent = " << npp <<  " for leave sets ";
//        DumpIntSet( ssLeavesByCuts[ii] );
        listParentsTree2.push_back(npp);

        // for debugging
        set<int> leavesUnder;
        tree2.GetLeavesUnder( npp, leavesUnder );
    }
    for( int ii=0; ii<(int)listParentsTree2.size(); ++ii )
    {
        for(int jj=ii+1; jj<(int)listParentsTree2.size(); ++jj)
        {
            if( tree2.IsNodeUnder(listParentsTree2[ii], listParentsTree2[jj]  ) == true)
            {
                ancestralRelations[jj][ii] = true;
//cout << "Cluster " << jj << " is ancestral to cluster " << ii << endl ;
            }
            else if( tree2.IsNodeUnder(listParentsTree2[jj], listParentsTree2[ii]  ) == true)
            {
                ancestralRelations[ii][jj] = true;
//cout << "Cluster " << ii << " is ancestral to cluster " << jj << endl ;
            }

        }
    }

    // now we create a graph with a node corresponding to a partition
    // and test for acyclic 
    DirectedGraph graphPartition;
    vector<int> nodesId;
    for( int i=0; i<(int)ssLeavesByCuts.size(); ++i  )
    {
        // is this cut good?
        nodesId.push_back( graphPartition.AddVertex(0) );
    }
    // now create edges
    for( int i=0; i<(int) ssLeavesByCuts.size(); ++i )
    {
        for(int j=0; j<(int)ssLeavesByCuts.size(); ++j)
        {
            if( ancestralRelations[i][j] == true )
            {
                // add an edge
                graphPartition.AddEdge( nodesId[i], nodesId[j], 0);

            }
        }
    }
graphPartition.OutputGML("graphPartition.gml");
    return graphPartition.IsAcyclic();
}


#if 0
// search for both directions new splits we can add to
static void AugmentPfTree( const BinaryMatrix &matInput, int coreLeft, int coreRight, PhylogenyTree &phTree,
                          vector<int> &listSitesNew)
{
cout << "coreLeft = " << coreLeft << ", coreRight = " << coreRight << endl;

    listSitesNew.clear();

    int totSitesNum = coreRight - coreLeft + 1;
    BinaryMatrix submat;
    matInput.SubMatrix(0, matInput.GetRowNum()-1, coreLeft, coreRight, submat );

    // if this segment is large enough, no need to search more
    if( totSitesNum >= MIN_IV_LENGTH_PF_TEST )
    {
        vector<int> rootSeq;
        for(int ii = 0; ii < totSitesNum; ++ii )
        {
            rootSeq.push_back( 0 );
        }
        phTree.SetRoot( rootSeq );
        bool ftree = phTree.ConsOnBinMatrix( submat );
        YW_ASSERT_INFO( ftree == true, "fail to build the tree" );

        return;
    }

    // now try to search for both directions what kind of new splits we can add into submat
    int curdist = 1;
    bool fMoveLeft = true;
    bool fNoMoreLeft = false, fNoMoreRight = false;
    while( totSitesNum < MIN_IV_LENGTH_PF_TEST && (fNoMoreLeft == false || fNoMoreRight == false)  )
    {
cout << "curdist = " << curdist << ", fMoveLeft = " << fMoveLeft << ", fNoMoreLeft = " << fNoMoreLeft << 
", fNoMoreRight = " << fNoMoreRight << endl;
        // 
        int siteNew = -1;
        if( fMoveLeft == true)
        {
            siteNew = coreLeft - curdist;
            if( siteNew < 0 )
            {
                // no more left
                fNoMoreLeft = true;
            }

            // switch if still possible
            if( fNoMoreRight == false )
            {
                fMoveLeft = false;
            }       

            // should move dist if we can no longer move right
            if( fNoMoreRight == true)
            {
                curdist ++;
            }
        }
        else
        {
            siteNew = coreLeft + curdist;
            if( siteNew >= matInput.GetColNum() )
            {
                // no more left
                fNoMoreRight = true;
                siteNew = -1;
            }

            // switch if still possible
            if( fNoMoreLeft == false )
            {
                fMoveLeft = true;
            }       

            // one more level
            curdist ++;
        }


        if( siteNew < 0 )
        {
            continue;
        }

        // now add this one more site
        BinaryMatrix singleSiteMat;
        matInput.SubMatrix(0, matInput.GetRowNum()-1, siteNew, siteNew, singleSiteMat );

        // append it
        submat.AppendMatrixByCol(singleSiteMat);

        // if it is not perfect phylogeny, drop it
        if( submat.IsPerfectPhylogeny() == false  )
        {
            // remove this site
            set<int> colSingle;
            colSingle.insert( submat.GetColNum()-1 );
            submat.RemoveColumns(colSingle);
        }
        else
        {
            // keep it
            totSitesNum ++;
            listSitesNew.push_back( siteNew );
        }

    }

    // finally build the tree
    vector<int> rootSeq;
    for(int ii = 0; ii < totSitesNum; ++ii )
    {
        rootSeq.push_back( 0 );
    }
cout << "Augmented matrix = ";
submat.Dump();
    phTree.SetRoot( rootSeq );
    bool ftree = phTree.ConsOnBinMatrix( submat );
    YW_ASSERT_INFO( ftree == true, "fail to build the tree" );
}
#endif

#if 0
void BuildMaxPhylogeny( const BinaryMatrix &matInput )
{
    // start from left end and scan to the right, to build phylogeny
    int lend, rend = 0;
    BinaryMatrix matPrev;
    int treeNum = 0;
    int lastIntPf = -1;
    for( lend = 0; lend < matInput.GetColNum(); ++lend )
    {
        // is (lend, rend) has perfect phylogeny?
        while( rend < matInput.GetColNum() )
        {
            BinaryMatrix submat;
            matInput.SubMatrix(0, matInput.GetRowNum()-1, lend, rend, submat );
            bool fPf = submat.IsPerfectPhylogeny();
             
            if( fPf == false || (fPf == true && rend == matInput.GetColNum()-1  )  )
            {
                // we take the previous submat
                PhylogenyTree treeFound;

                // set root ot all 0
                vector<int> rootSeq;
                int seqLen = matPrev.GetColNum();
                int curPfRight = rend-1;
                if( fPf == true )
                {
                    seqLen = rend - lend +1;
                    curPfRight = rend;
                }
                // quit if this is already outputed
                if( curPfRight == lastIntPf )
                {
                    break;
                }
                lastIntPf = curPfRight;

                // now find the tree
                vector<int> listNodesNew;
                AugmentPfTree( matInput, lend, curPfRight, treeFound, listNodesNew);
cout << "Working on interval: left = " << lend << ", right = " << curPfRight << endl;
cout << "This tree contains new nodes: ";
DumpIntVec( listNodesNew );

#if 0
                for(int ii = 0; ii < seqLen; ++ii )
                {
                    rootSeq.push_back( 0 );
                }
                treeFound.SetRoot( rootSeq );

                bool ftree;
                if( fPf == false )
                {
                    ftree = treeFound.ConsOnBinMatrix( matPrev );
cout << "Found a perfect phylogeny between " << lend << ", and " << rend -1 << endl;
                }
                else
                {
cout << "Found a perfect phylogeny between " << lend << ", and " << rend << endl;
                    ftree = treeFound.ConsOnBinMatrix( submat );
                    rend ++;
                }
                YW_ASSERT_INFO( ftree == true, "Must true" );
#endif

                // output the file
                treeNum++;
                char buf[100];
                sprintf(buf, "TreePf%d.gml", treeNum);
                treeFound.OutputGML(buf);
                break;
            }

            if( fPf == true)
            {
                // move on
                rend ++;
                matPrev = submat;
            }
        }
    }

}
#endif


///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// test code

static void DumpTreeAncestry(MarginalTree &mtree)
{
	stack<int> listNodes;
	for(int i=0; i<mtree.GetNumLeaves(); ++i)
	{
		listNodes.push(i);
	}
	while( listNodes.empty() == false )
	{
		int n = listNodes.top();
		listNodes.pop();
		int npar = mtree.GetParent(n);
		if( npar >= 0 )
		{
			//
			cout << "Node " << n << " has parent " << npar << endl;
			listNodes.push(npar);
		}
	}
}



static void OutputCki( ofstream &outFile, int tree, int i )
{
    outFile << "C," << tree << "," << i;  
} 
static void OutputMkij( ofstream &outFile, int tree, int i, int j )
{
	if( i > j )
	{
		int tmp = i;
		i=j;
		j=tmp;
	}
    outFile << "M," << tree << "," << i << "," << j;  
} 

static void OutputGijpq( ofstream &outFile, int i, int j, int p, int q )
{
    // only for two leaves i and j
	YW_ASSERT_INFO(i <j && p < q, "Fail");
    outFile << "G," << i << "," << j << "," << p << "," << q;  
} 

void OutputILPMaxGoodAgreeForestLeafPair(const char* fileName, const MarginalTree &treeOrig1, const MarginalTree &treeOrig2 )
{
    YW_ASSERT_INFO( treeOrig1.GetTotNodesNum() == treeOrig2.GetTotNodesNum(), "mismatch" );

//cout << "OutputILPMaxGoodAgreeForest: treeOrig1 = ";
//treeOrig1.Dump();
//cout << "OutputILPMaxGoodAgreeForest: tree2 = ";
//treeOrig2.Dump();
    MarginalTree  tree1Reduced = treeOrig1;
    MarginalTree  tree2Reduced = treeOrig2;

    // buildup the descendent info
    tree1Reduced.BuildDescendantInfo();
    tree2Reduced.BuildDescendantInfo();
//cout << "Output reduced trees...\n";
//treeOrig1.OutputGML("tree1.gml");
//treeOrig2.OutputGML("tree2.gml");
//cout <<"********tree1 = \n";
//DumpTreeAncestry(tree1Reduced);
//cout <<"********tree2 = \n";
//DumpTreeAncestry(tree2Reduced);

//    ReducePairTreesMAF(treeOrig1, treeOrig2, tree1Reduced, tree2Reduced);


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tree1Reduced.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, 1, i);
        if( i < tree1Reduced.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }

    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;




    // now enforce m,i
    OutputCki( outFile, 1,  tree1Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";


    const MarginalTree *ptrTrees[2];
    ptrTrees[0] = &tree1Reduced;
    ptrTrees[1] = &tree2Reduced;

    // start from the first tree
	// we save the path nodes
#if 0
	map< pair<int,int>, set<int> > mapLeafPairPathNodes[2];
    for(  int k=1; k<=2; ++k  )
    {
        const MarginalTree *pCurrTree = ptrTrees[k-1];

        for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
        {
            for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
            {
                // first we need to find MRCA of i,j. 
                // note that we actually want to exluce MRCA, but include i,j!
                set<int> listPathNodes;
                int n1=i, n2 = j;
                listPathNodes.insert(i);
                listPathNodes.insert(j);
                while( n1 != n2 )
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    if( n1 < n2  )
                    {
                        // move n1
                        n1 = pCurrTree->GetParent(n1);
                        nodeNew = n1;
                    }
                    else
                    {
                        // move n2
                        n2 = pCurrTree->GetParent(n2);
                        nodeNew = n2;
                    }
                    // save this when n1 != n2
                    if( n1 != n2 )
                    {
                        listPathNodes.insert( nodeNew );
                    }
                }
                // pop up the last item MRCA
                //listPathNodes.pop_back();
                //listPathNodes.erase(  n1  );
                

				// save it
				pair<int,int> ppp(i,j);
				mapLeafPairPathNodes[k-1].insert( map< pair<int,int>, set<int> > :: value_type(ppp, listPathNodes) );

            }
        }
    }
#endif

    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
    //set< pair<int,int> > listPairNodesConstraint[2];

    // start from the first tree
    //const MarginalTree *pCurrTree = ptrTrees[0];

    // start from the first tree
//    for(  int k=1; k<=2; ++k  )
    {
        const MarginalTree *pCurrTree = ptrTrees[0];

        for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
        {
            for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
            {
                // first we need to find MRCA of i,j. 
                // note that we actually want to exluce MRCA, but include i,j!
                set<int> listPathNodes;
                int n1=i, n2 = j;
                listPathNodes.insert(i);
                listPathNodes.insert(j);
                while( n1 != n2 )
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    if( n1 < n2  )
                    {
                        // move n1
                        n1 = pCurrTree->GetParent(n1);
                        nodeNew = n1;
                    }
                    else
                    {
                        // move n2
                        n2 = pCurrTree->GetParent(n2);
                        nodeNew = n2;
                    }
                    // save this when n1 != n2
                    if( n1 != n2 )
                    {
                        listPathNodes.insert( nodeNew );
                    }
                }
                // pop up the last item MRCA
                //listPathNodes.pop_back();
                listPathNodes.erase(  n1  );
                



                // now we start to enforce property
                OutputMkij( outFile, 1, i, j );
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    outFile << " + ";
                    OutputCki( outFile, 1, *it );
                    outFile << endl;
                }
                outFile << " >= 1\n";

                /*  do we need the following? yes */
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    OutputMkij( outFile, 1, i, j );
                    outFile << " + ";
                    OutputCki( outFile, 1, *it );
                    outFile << " <= 1\n";
                }


            }
        }
    }

#if 0
    for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
        {
            // first we need to find MRCA of i,j. 
            // note that we actually want to exluce MRCA, but include i,j!
            //vector<int> listPathNodes;
            int n1=i, n2 = j;
            //listPathNodes.push_back(i);
            //listPathNodes.push_back(j);
            while( n1 <= n2 )
            {
                // IMPORTANT: make sure n1 <= n2 (true upon entry)

                // enforce an property
                pair<int,int> pp(n1, n2);
                if( listPairNodesConstraint[0].find(pp) != listPairNodesConstraint[0].end()   )
                {
                    // we already reach what we need, stop
                    break;
                }
                listPairNodesConstraint[0].insert(pp);

                if( n1 == n2 )
                {
                    // for the last one, simply set to be 1 as always
                    OutputMkij( outFile, 1, n1, n1 );
                    outFile << " = 1\n";
                    break;
                }
                else
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    bool fMoven1 = true;
                    if( n1 < n2  )
                    {
                        // move n1
                        nodeNew = pCurrTree->GetParent(n1);
                        fMoven1 = true;
                    }
                    else
                    {
                        // move n2
                        nodeNew = pCurrTree->GetParent(n2);
                        fMoven1 = false;
                    }

                    int n1New, n2New, edgeCuti;
                    if( fMoven1 == true ) 
                    {
                        n1New = nodeNew;
                        n2New = n2;
                        edgeCuti = n1;
                    }
                    else
                    {
                        n1New = n1;
                        n2New = nodeNew;
                        edgeCuti = n2;
                    }
                    if( n1New > n2New )
                    {
                        OrderInt(n1New, n2New);
                    }

                    // here are constraints
                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " - ";
                    OutputMkij( outFile, 1, n1New, n2New );
                    outFile << " <= 0\n";

                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " + ";
                    OutputCki( outFile, 1,  edgeCuti);
                    outFile << " - ";
                    OutputMkij( outFile, 1, n1New, n2New );
                    outFile << " >= 0\n";

                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " + ";
                    OutputCki( outFile, 1,  edgeCuti);
                    outFile << " <= 1\n";

                     // now update n1 and n2
                    n1 = n1New;
                    n2 = n2New;
               }


                // save this when n1 != n2
                //if( n1 != n2 )
                //{
                //    listPathNodes.push_back( nodeNew );
                //}
            }
            // pop up the last item MRCA
            //listPathNodes.pop_back();

        }
    }
#endif



    // now try all possible triples of leaves i,j,k
    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1Reduced.GetMRCA( i, j );
                int mrcajk1 = tree1Reduced.GetMRCA( j, k );
                int mrcaik1 = tree1Reduced.GetMRCA( i, k );
                int mrcaij2 = tree2Reduced.GetMRCA( i, j );
                int mrcajk2 = tree2Reduced.GetMRCA( j, k );
                int mrcaik2 = tree2Reduced.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n ";

                // YW: now I believe only one of the following (say (i,j) and (j,k) are needed
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n";

//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n";

//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n";


            }
        }
    }

//#if  0
    // now we test for all pair of leaf pairs, to ensure there is no intersection in two trees
    // if the two pairs are left in one tree
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tree1Reduced.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tree1Reduced.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tree1Reduced.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
                    // also ignore when tree2 has disjoint (i,j) and (p,q), since they auto satisfy the partition
                    if( tree2Reduced.AreTwoPathsDisjoint( i, j, p, q ) == true  )
                    {
                        continue;
                    }

                    // now for this, make sure Mi,j + Mp,q <= 1
                    OutputMkij( outFile, 1, i, j );
                    outFile << " + ";
                    OutputMkij( outFile, 1, p, q );
                    outFile << " <= 1\n";

                }
            }
        }
    }
//#endif


    // now for acyclic property for hybridization property

//cout << "I AM HERE\n";
    // now enforce G,i,j,p,q
	// note none of p,q,i,j can be same
	int numGVars = 0;
	int numGVarsTwoWay = 0;

	//set< pair< pair<int,int>, pair<int,int> > > setZeroVars;
	map< pair<int,int>, set< pair<int,int> > > mapNonOverlapPaths;
	map< pair<pair<int,int>, pair<int,int> >, bool> mapPathAncestry;
    for( int i= 0; i< ptrTrees[0]->GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< ptrTrees[0]->GetNumLeaves() ; ++j  )
        {
			pair<int,int> ppij(i,j);
			//set<int> pathij1 = mapLeafPairPathNodes[0][ppij];
			//set<int> pathij2 = mapLeafPairPathNodes[1][ppij];
			// try (p,q)
//cout << "Testing " << i << ", " << j << endl;
			for( int p= i+1; p< ptrTrees[0]->GetNumLeaves() ; ++p  )
			{
				if( p == i || p == j)
				{
					continue;
				}
//cout << "p = " << p << endl;
				for( int q= p+1; q< ptrTrees[0]->GetNumLeaves() ; ++q  )
				{
//cout << "q = " << q << endl;
					if( q == i || q == j)
					{
						continue;
					}
//cout << "Pairs (" << i << ", " <<  j << "), (" << p << ", " << q << ")" << endl;
					// ensure i,j p,q are non-disjoint in T and T'
					pair<int,int> pppq(p,q);
					//set<int> pathpq1 = mapLeafPairPathNodes[0][pppq];
					//set<int> pathpq2 = mapLeafPairPathNodes[1][pppq];
					//set<int> jpath1, jpath2;
//cout << "pathij1 = ";
//DumpIntSet(pathij1);
//cout << "pathpq1 = ";
//DumpIntSet(pathpq1);
//cout << "pathij2 = ";
//DumpIntSet(pathij2);
//cout << "pathpq2 = ";
//DumpIntSet(pathpq2);
					//JoinSets( pathij1, pathpq1, jpath1 );
					//JoinSets( pathij2, pathpq2, jpath2 );
					//if( jpath1.size() == 0 && jpath2.size() == 0 )
					if( tree1Reduced.AreTwoPathsDisjoint(i,j,p,q) == true &&  tree2Reduced.AreTwoPathsDisjoint(i,j,p,q) == true )
					{
//set<int> pathij1, pathpq1;
//tree1Reduced.GetPath(i,j, pathij1);
//tree1Reduced.GetPath(p,q, pathpq1);
//cout << "Pathij = ";
//DumpIntSet( pathij1 );
//cout << "Pathpq = ";
//DumpIntSet( pathpq1 );

						// 
						bool fAncestral[2][2];

						// check which pair is higher
						for(int k=0; k<=1; ++k)
						{
							int mrcaij1 = ptrTrees[k]->GetMRCA(i,j);
							int mrcapq1 = ptrTrees[k]->GetMRCA(p,q);
							if( ptrTrees[k]->IsNodeUnder( mrcaij1, mrcapq1) == true)
							{
								// 110508: added another constraint:
								// if say p,i is connected (M,p,i = 1), then 
								// force it to be zero (that is, the pair of path
								// needs to be disjoint
//								OutputGijpq(outFile, p, q, i, j);
//								outFile << " + ";
//								OutputMkij(outFile, 1, i,p);
//								outFile << " - ";
//								OutputMkij(outFile, 1, i,j);
//								outFile << " - ";
//								OutputMkij( outFile, 1, p,q);
//								outFile << " >= -1\n";
								
#if 0
								//
								OutputGijpq(outFile, p, q, i, j);
								outFile << " - ";
								OutputMkij(outFile, 1, i,j);
								outFile << " <= 0\n";

								OutputGijpq(outFile, p, q, i, j);
								outFile << " - ";
								OutputMkij( outFile, 1, p,q);
								outFile << " <= 0\n";
								
								//
								OutputGijpq(outFile, p, q, i, j);
								outFile << " + ";
								OutputMkij(outFile, 1, i,p);
								outFile << " <= 1\n";
#endif


								// 
								fAncestral[k][0] = true;
//cout << "k = " << k << ", 0 : true\n";
								// add a record here for pair ancestry
								pair< pair<int,int>, pair<int,int> > ppppp( pppq, ppij  );
								mapPathAncestry.insert( map< pair<pair<int,int>, pair<int,int> >, bool> :: value_type( ppppp, true  ) ) ;
							}
							else
							{
								fAncestral[k][0] = false;
//cout << "k = " << k << ", 0 : false\n";
							}
							if( ptrTrees[k]->IsNodeUnder( mrcapq1, mrcaij1) == true)
							{
//								OutputGijpq(outFile, i, j, p, q);
//								outFile << " + ";
//								OutputMkij(outFile, 1, i,p);
//								outFile << " - ";
//								OutputMkij(outFile, 1, i,j);
//								outFile << " - ";
//								OutputMkij( outFile, 1, p,q);
//								outFile << " >= -1 \n";

#if 0
								//
								OutputGijpq(outFile, i, j, p, q);
								outFile << " - ";
								OutputMkij(outFile, 1, i,j);
								outFile << " <= 0\n";

								OutputGijpq(outFile, i, j, p, q);
								outFile << " - ";
								OutputMkij( outFile, 1, p,q);
								outFile << " <= 0\n";

								OutputGijpq(outFile, i, j, p, q);
								outFile << " + ";
								OutputMkij(outFile, 1, i,p);
								outFile << " <= 1\n";
#endif


								fAncestral[k][1] = true;
//cout << "k = " << k << ", 1 : true\n";

								// add a record here for pair ancestry
								pair< pair<int,int>, pair<int,int> > ppppp( ppij, pppq  );
								mapPathAncestry.insert( map< pair<pair<int,int>, pair<int,int> >, bool> :: value_type( ppppp, true  ) ) ;

							}
							else
							{
								fAncestral[k][1] = false;
//cout << "k = " << k << ", 1 : false\n";
							}
						}

						// note, we EXCLUDE any leaf pairs that are inconsistent in timing
						// there is no need to enforce extra triagular constraint for such kind
						// if no contradiction
						if( (fAncestral[0][0] == false && fAncestral[1][0] == false) 
							||  (fAncestral[0][1] == false && fAncestral[1][1] == false)    )
						{
cout << "This pair is GOOD: ";
cout << "Pairs (" << i << ", " <<  j << "), (" << p << ", " << q << ")" << endl;
							numGVars += 2;

							// Add constraints to them
							// but we still need to keep track of it
							if( mapNonOverlapPaths.find(pppq) == mapNonOverlapPaths.end() )
							{
								set< pair<int,int> > setInit;
								setInit.insert( ppij );
								mapNonOverlapPaths.insert(map< pair<int,int>, set< pair<int,int> > > :: value_type(pppq, setInit )  );
							}
							else
							{
								mapNonOverlapPaths[pppq].insert( ppij );
							}
							// another direction
							// ensure no cyclic ancestry between the two pairs
							if( mapNonOverlapPaths.find(ppij) == mapNonOverlapPaths.end() )
							{
								set< pair<int,int> > setInit;
								setInit.insert( pppq );
								mapNonOverlapPaths.insert(map< pair<int,int>, set< pair<int,int> > > :: value_type(ppij, setInit )  );
							}
							else
							{
								mapNonOverlapPaths[ppij].insert( pppq );
							}

							// 11/05: NO NEED TO CONSIER THIS
							// REASON: ANY PAIR OF LEAVES, IF THEY CAN BE ANCESTRAL TO EACH OTHER
							// THEN, THEY CANNOT CO-EXIST. THAT IS WHY...
							// ensure only one way works
							//OutputGijpq(outFile, i, j, p, q );
							//outFile << " + ";
							//OutputGijpq(outFile, p, q, i, j );
							//outFile << " <= 1\n";

							// decide which constraints to add:
							if( fAncestral[0][0] == true || fAncestral[1][0] == true )
							{
								// means (p,q) is (i,j)'s ancester
								// needs to be disjoint

								OutputGijpq(outFile, p, q, i, j);
								outFile << " + ";
								OutputMkij(outFile, 1, i,p);
								outFile << " - ";
								OutputMkij(outFile, 1, i,j);
								outFile << " - ";
								OutputMkij( outFile, 1, p,q);
								outFile << " >= -1\n";

								// enforce zero for the other direction
								OutputGijpq(outFile,  i, j, p, q);
								outFile << "=0\n";
								
#if 0
								//
								OutputGijpq(outFile, p, q, i, j);
								outFile << " - ";
								OutputMkij(outFile, 1, i,j);
								outFile << " <= 0\n";

								OutputGijpq(outFile, p, q, i, j);
								outFile << " - ";
								OutputMkij( outFile, 1, p,q);
								outFile << " <= 0\n";
								
								//
								OutputGijpq(outFile, p, q, i, j);
								outFile << " + ";
								OutputMkij(outFile, 1, i,p);
								outFile << " <= 1\n";
#endif
							}

							else if( fAncestral[0][1] == true || fAncestral[1][1] == true )
							{
								// ensure no cyclic ancestry between the two pairs

								OutputGijpq(outFile, i, j, p, q);
								outFile << " + ";
								OutputMkij(outFile, 1, i,p);
								outFile << " - ";
								OutputMkij(outFile, 1, i,j);
								outFile << " - ";
								OutputMkij( outFile, 1, p,q);
								outFile << " >= -1 \n";

								// enforce zero for the other direction
								OutputGijpq(outFile,  p, q, i, j);
								outFile << "=0\n";

#if 0
								//
								OutputGijpq(outFile, i, j, p, q);
								outFile << " - ";
								OutputMkij(outFile, 1, i,j);
								outFile << " <= 0\n";

								OutputGijpq(outFile, i, j, p, q);
								outFile << " - ";
								OutputMkij( outFile, 1, p,q);
								outFile << " <= 0\n";

								OutputGijpq(outFile, i, j, p, q);
								outFile << " + ";
								OutputMkij(outFile, 1, i,p);
								outFile << " <= 1\n";
#endif
							}
							else
							{
								numGVarsTwoWay ++;
cout << "This pair is unconstrained: ";
cout << "Pairs (" << i << ", " <<  j << "), (" << p << ", " << q << ")" << endl;

								// in this case, there is no clear relationship on both trees
								// but we still need to keep track of it

								OutputGijpq(outFile, p, q, i, j);
								outFile << " + ";
								OutputMkij(outFile, 1, i,p);
								outFile << " - ";
								OutputMkij(outFile, 1, i,j);
								outFile << " - ";
								OutputMkij( outFile, 1, p,q);
								outFile << " >= -1\n";

								// another direction
								// ensure no cyclic ancestry between the two pairs

								OutputGijpq(outFile, i, j, p, q);
								outFile << " + ";
								OutputMkij(outFile, 1, i,p);
								outFile << " - ";
								OutputMkij(outFile, 1, i,j);
								outFile << " - ";
								OutputMkij( outFile, 1, p,q);
								outFile << " >= -1 \n";

								// ensure only one way works
								OutputGijpq(outFile, p, q, i, j);
								outFile << " + ";
								OutputGijpq(outFile, i, j, p, q);
								outFile << " <= 1\n";
							}
						}
						else
						{
							// 11/05/08: when there is apparent contradiction
							// we only need to ensure there is no such pairs of leaf valid
							OutputMkij(outFile, 1, i,j);
							outFile << " + ";
							OutputMkij( outFile, 1, p, q);
							outFile << " <= 1 \n";
						}

					}

				}
			}
		}
	}

cout << "Number of good leaf pairs = " << numGVars << endl;
cout << "Number of two-way GVar = " << numGVarsTwoWay << endl;

	// enforce triangle property 
	int numTriangleCons = 0;
    for( int i= 0; i< ptrTrees[0]->GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< ptrTrees[0]->GetNumLeaves() ; ++j  )
        {
			pair<int,int> ppij(i,j);
			// try all non-overlapping path of ij
			for( set< pair<int,int> > :: iterator it = mapNonOverlapPaths[ppij].begin(); it != mapNonOverlapPaths[ppij].end(); ++it )
			{
				// find another pair
				pair<int,int> pppq = *it;

				pair< pair<int,int>, pair<int,int> > ppppp( pppq, ppij);
				//if( mapPathAncestry.find( ppppp ) != mapPathAncestry.end() )
				//{
					// we only consider the situation where ij is ancestral to pq
				//	continue;
				//}

				// 
				for( set< pair<int,int> > :: iterator it2 = mapNonOverlapPaths[pppq].begin(); it2 != mapNonOverlapPaths[pppq].end(); ++it2 )
				{
					pair<int,int> ppxy = *it2;

					pair< pair<int,int>, pair<int,int> > ppppp1( ppxy, ppij), ppppp2(ppxy, pppq);
					//if( mapPathAncestry.find( ppppp1 ) != mapPathAncestry.end()  || mapPathAncestry.find( ppppp2 ) != mapPathAncestry.end()   )
					//{
						// we only consider the situation where ij is ancestral to pq
					//	continue;
					//}


					// ensure ppxy is also disjoint with ij
					if( ppxy.first != i && ppxy.first != j && ppxy.second != i && ppxy.second != j && 
						mapNonOverlapPaths[ppij].find( ppxy ) != mapNonOverlapPaths[ppij].end()   )
					{
						// come up with triangle property
						// enforce triangle inequality here
						OutputGijpq(outFile, i, j, ppxy.first, ppxy.second);
						outFile << " - ";
						OutputGijpq(outFile, i, j, pppq.first, pppq.second);
						outFile << " - ";
						OutputGijpq(outFile, pppq.first, pppq.second, ppxy.first, ppxy.second);
						outFile << " >= -1\n";

						numTriangleCons++;

					}
				}
			}
		}
	}
cout << "Number of triangle constraints = " << numTriangleCons << endl;

    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tree1Reduced.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, 1, i );
        outFile << endl;
        //OutputCki( outFile, 2, i );
        //outFile << endl;
    }
    // mkij
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< tree1Reduced.GetNumLeaves() ; ++j  )
        {
            OutputMkij( outFile, 1, i, j );
            outFile << endl;
//            OutputMkij( outFile, 2, i, j );
//            outFile << endl;
        }
    }
    // G,i,j
	for(    map< pair<int,int>, set< pair<int,int> > > :: iterator it = mapNonOverlapPaths.begin(); it != mapNonOverlapPaths.end(); ++it  )
	{
		for( set< pair<int,int> > :: iterator it2 = it->second.begin(); it2 != it->second.end(); ++it2 )
		{
			OutputGijpq(outFile, it->first.first, it->first.second, it2->first, it2->second );
			outFile << endl;
		}
	}


#if 0
    for( int i= 0; i< ptrTrees[0]->GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< ptrTrees[0]->GetNumLeaves() ; ++j  )
        {
			pair<int,int> ppij(i,j);
			//set<int> pathij1 = mapLeafPairPathNodes[0][ppij];
			//set<int> pathij2 = mapLeafPairPathNodes[1][ppij];
			// try (p,q)
			for( int p= 0; p< ptrTrees[0]->GetNumLeaves() ; ++p  )
			{
				if( p == i || p == j)
				{
					continue;
				}
				for( int q= p+1; q< ptrTrees[0]->GetNumLeaves() ; ++q  )
				{
					if( q == i || q == j)
					{
						continue;
					}

					// ensure i,j p,q are non-disjoint in T and T'
					pair<int,int> pppq(p,q);
					//set<int> pathpq1 = mapLeafPairPathNodes[0][pppq];
					//set<int> pathpq2 = mapLeafPairPathNodes[1][pppq];
					//set<int> jpath1, jpath2;
					//JoinSets( pathij1, pathpq1, jpath1 );
					//JoinSets( pathij2, pathpq2, jpath2 );
					//if( jpath1.size() == 0 && jpath2.size() == 0 )
					if( tree1Reduced.AreTwoPathsDisjoint( i, j, p, q ) == true && tree2Reduced.AreTwoPathsDisjoint( i, j, p, q ) == true )
					{
						OutputGijpq(outFile, i, j, p, q);
						outFile << endl;
					}
				}
			}
		}
	}
#endif


    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();
cout << "Constrains finished\n";
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// base class for hybrid network, providing some basic functionalities like cycle finding


// NOTE: this implements Tarjan's algorithm in paper: finding all elementary circuits
// in directed graph
void GenericHybridNetwork :: FindLeafPairGraphCycles()
{
	vector< set<int> > listGraphNodeNggrs;
	ConsLeafPairGraph(listGraphNodeNggrs);
OutputGML( listGraphNodeNggrs, "LPGraph.gml" );

	// setup
	vector<bool> markedFlag;
	int numNodes = GetNumLeaves()*GetNumLeaves();
	for( int i=0; i<numNodes; ++i )
	{
		markedFlag.push_back( false );;
	}
	// two stacks
	vector<int> pointStack, markedStack;

	//
	for(int s=0; s<numNodes; ++s)
	{
//cout << "Visit s = ";
//DumpNode( s );
//cout << endl;
		RecurseCycle( listGraphNodeNggrs, s, s, pointStack, markedStack, markedFlag );
		while( markedStack.size() > 0 )
		{
			int u = markedStack[ markedStack.size()-1 ];
			markedFlag[u] = false;
			markedStack.pop_back();
//cout << "Pop ";
//DumpNode(  u );
//cout << " from marked stack\n";
		}
//cout << "Found cycles so far: ";
//DumpFoundCycles();
	}

//DumpFoundCycles();

}


// useful methods
void GenericHybridNetwork :: ConsLeafPairGraph( vector< set<int> > &listGraphNodeNggrs )
{
	listGraphNodeNggrs.clear();
	int numNodes = GetNumLeaves()*GetNumLeaves();
	listGraphNodeNggrs.resize(numNodes);
//cout << "pass0\n";	


//for(int t=0;t<(int)listTrees.size(); ++t)
//{
//char fname[100];
//sprintf(fname, "tree%d.gml", t);
//listTrees[t]->OutputGML(fname);
//}
	// first store MRCAs for leaf pairs
	vector<vector< int > > listMRCATrees( listTrees.size()  );
	for(int t=0; t<(int)listTrees.size(); ++t)
	{
//cout << "t = " << t << endl;
		listMRCATrees[t].resize(numNodes);
		for(int i=0; i<GetNumLeaves(); ++i)
		{
//cout << "i=" << i << endl;
			for(int j=i+1; j<GetNumLeaves(); ++j)
			{
//cout << "j = " << j << endl;
				int id = GetLeafPairInd( i, j );
				int mrca1 = listTrees[t]->GetMRCA(i, j);
				listMRCATrees[t][id] = mrca1;
			}
		}
	}
//cout << "pass1\n";	
	// also which nodes are descendents of the other (for both leaf and non-leaf nodes)
	int numTotNodes = GetNumTotNodes();
	vector< vector< vector<bool> > > ancestralMapTrees( listTrees.size() );    
	for(int t=0; t<(int)listTrees.size(); ++t)
	{
		ancestralMapTrees[t].resize( numTotNodes );
		for(int i=0; i<(int)ancestralMapTrees[t].size(); ++i)
		{
			ancestralMapTrees[t][i].resize( numTotNodes );
			for(int j=0; j<numTotNodes; ++j)
			{
				ancestralMapTrees[t][i][j] = false;
			}
		}
	}
//cout << "pass2\n";	
	for(int t=0; t<(int)listTrees.size(); ++t)
	{
		for(int i=0; i<(int)ancestralMapTrees[t].size(); ++i)
		{
			for(int j=0; j<(int)ancestralMapTrees[t].size(); ++j)
			{
				if( i== j )
				{
					continue;
				}

				// test whether they are ancestor to each other
				if( listTrees[t]->IsNodeUnder( i, j ) == true )
				{
					ancestralMapTrees[t][i][j] = true;
				}
				if( listTrees[t]->IsNodeUnder( j, i ) == true )
				{
					ancestralMapTrees[t][j][i] = true;
				}

			}
		}
	}
//cout << "pass3\n";	

	// try all pairs of leaves
	int numImpliedMPairs = 0;
	for(int i=0; i<GetNumLeaves(); ++i)
	{
		for(int j=i+1; j<GetNumLeaves(); ++j)
		{
			int idij = GetLeafPairInd(i,j);
			//int mrcaij1 = listMRCATree1[idij];
			//int mrcaij2 = listMRCATree2[idij];
			// another pair of leaves
			// for symetry, assume p > i
			for(int p=i+1; p<GetNumLeaves(); ++p)
			{
				for(int q=p+1; q<GetNumLeaves(); ++q)
				{
					if( p == i || p == j || q == i ||  q == j)
					{
						continue;
					}

					// test whether
					int idpq = GetLeafPairInd(p,q);
					//int mrcapq1 = listMRCATree1[idpq];
					//int mrcapq2 = listMRCATree2[idpq];
					//YW_ASSERT_INFO( idij != idpq, "WRONG" );

					if( AreTwoPairsFullyDisjoint(i,j,p,q) == true  )
					{
						//
						if( AreTwoPairsGood( i, j, p, q, listMRCATrees, ancestralMapTrees) == true)
						{
							// a good pair
							listGraphNodeNggrs[idpq].insert( idij );
						}
						if( AreTwoPairsGood( p, q, i, j, listMRCATrees, ancestralMapTrees) == true  )
						{
							// a good pair
							listGraphNodeNggrs[idij].insert( idpq );
						}

						// check implicit pairs
						if( AreTwoPairsForced( i, j, p, q, listMRCATrees, ancestralMapTrees ) == true )
						{
//cout << "Pairs (" << i << ", " << j << "), (" << p << ", " << q << ") is forced\n";
							++numImpliedMPairs;

							// add to list of forced pair
							pair<int,int> ppij(i,j), pppq(p,q);
							pair< pair<int,int>, pair<int,int> > ppppp(ppij, pppq);
							setForcedPathPairs.insert( ppppp );
//listGraphNodeNggrs[idij].insert( idpq );
//listGraphNodeNggrs[idpq].insert( idij );
						}

					}

				}
			}

		}
	}
//cout << "Number of implied pairs = " << numImpliedMPairs << endl;
 
#if 0
	// dump out nodes
	cout << "Found graph is: \n";
	for(int i=0; i<GetNumLeaves(); ++i)
	{
		for(int j=i+1; j<GetNumLeaves(); ++j)
		{
			int id = GetLeafPairInd( i, j );

			cout << "Leaf pair " << i << "," << j << ": ";
//#if 0
			for( set<int> :: iterator it = listGraphNodeNggrs[id].begin(); it != listGraphNodeNggrs[id].end(); ++it )
			{
				DumpNode(*it);
				//int leaf1, leaf2;
				//GetLeafPairFromId(*it, leaf1, leaf2);
				//cout << " (" << leaf1 << ", " << leaf2 << ")";
			}
			cout << endl;
			//DumpIntSet( listGraphNodeNggrs[id] );
//#endif
			cout << "number of neighbors = " << listGraphNodeNggrs[id].size() << endl;
		}
	}
#endif
}

int GenericHybridNetwork :: GetLeafPairInd(int i, int j)
{
	YW_ASSERT_INFO( i != j, "Can ont be the same" );
	// 
	if( i > j )
	{
		OrderInt(i,j);
	}
	return i*GetNumLeaves() + j;
//	return ConvertToLinear( i, j, GetNumLeaves()  );
}

void GenericHybridNetwork :: GetLeafPairFromId( int ind, int &leaf1, int &leaf2)
{
	leaf1 = ind / GetNumLeaves();
	leaf2 = ind % GetNumLeaves();
}

void GenericHybridNetwork :: GetCycle(int cycleId, vector< pair<int,int> > &cycleNodes)  
{ 
	for(int i=0; i<(int) listLeafPairCycles[cycleId].size(); ++i)
	{
		int leaf1, leaf2;
		GetLeafPairFromId( listLeafPairCycles[cycleId][i], leaf1, leaf2 );
		pair<int,int> pp(leaf1, leaf2);
		cycleNodes.push_back(pp); 
	}
}

bool GenericHybridNetwork :: RecurseCycle(vector< set<int> > &listGraphNodeNggrs, int s,
									  int v, vector<int> &pointStack, vector<int> &markedStack, vector<bool> &markedFlag)
{
//cout << "In RecurseCycle: s = ";
//DumpNode(s);
//cout << endl;
	// 
	// bool g;
	bool res = false;
	pointStack.push_back( v );
//cout << "After pushing ";
//DumpNode( v );
//cout << ", point stack = ";
//DumpListNode(pointStack);
	markedFlag[v] = true;
	markedStack.push_back(v);
//cout << "After pushing ";
//DumpNode( v );
//cout << ", marked stack = ";
//DumpListNode(markedStack);

	for( set<int> :: iterator it = listGraphNodeNggrs[v].begin(); it != listGraphNodeNggrs[v].end(); ++it )
	{
		int w = *it;
//cout << "Checking w = ";
//DumpNode( w );
//cout << endl;
		if( w < s )
		{
//cout << "Skip w = ";
//DumpNode( w );
			// delete this arc
			//listGraphNodeNggrs[v].erase( w );
		}
		else if( w == s )
		{
			// find a path
//cout << "****************Find a path: ";
//DumpListNode(pointStack);
			listLeafPairCycles.push_back( pointStack );
			//DumpIntVec(pointStack);
			res = true;
		}
		else if( markedFlag[w] == false )
		{
//cout << "w is unmarked, so continue...\n";
			bool g = RecurseCycle( listGraphNodeNggrs, s, w, pointStack, markedStack, markedFlag );
			if( g == true )
			{
//cout << "g is true, so set res to true\n";
				res = true;
			}
		}
	}

	//
	if( res == true )
	{
		while( markedStack.size() > 0 && markedStack[ markedStack.size()-1] != v )
		{
			int u = markedStack[ markedStack.size()-1];
			markedFlag[u] = false;
			markedStack.pop_back();
//cout << "Pop ";
//DumpNode( u );
//cout << ", from marked stack. Marked stack now = ";
//DumpListNode(markedStack);
		}
		YW_ASSERT_INFO( markedStack[ markedStack.size()-1] == v, "Stack operation error" );
		markedFlag[v] = false;
		markedStack.pop_back();
//DumpNode( v );
//cout << ", from marked stack. Marked stack now = ";
//DumpListNode(markedStack);
	}

	// finally delete v
	YW_ASSERT_INFO( pointStack[ pointStack.size()-1] == v, "Stack operation error2" );
	pointStack.pop_back();
//DumpNode( v );
//cout << ", from point stack. point stack now = ";
//DumpListNode(pointStack);

	return res;
}

void GenericHybridNetwork :: DumpNode(int id)
{
	int leaf1, leaf2;
	GetLeafPairFromId(id, leaf1, leaf2);
	cout << " (" << leaf1 << ", " << leaf2 << ")";

}

void GenericHybridNetwork :: DumpListNode( const vector<int> &listNids  )
{
	for(int i=0; i<(int)listNids.size(); ++i)
	{
		DumpNode( listNids[i] );
	}
	cout << endl;
}

void GenericHybridNetwork :: DumpFoundCycles()
{
	cout << "Number of cycles found = " << listLeafPairCycles.size() << endl;
return;
	for(int i=0; i<(int)listLeafPairCycles.size(); ++i)
	{
		cout << "Path: ";
		DumpListNode( listLeafPairCycles[i] );
	}
}

void GenericHybridNetwork :: OutputGML( const vector< set<int> > &listGraphNodeNggrs,  const char *fileName  )
{
	// only create node if it appears either as sink or as src
	set<int> nodesInGraph;
	for( int i=0; i<(int)listGraphNodeNggrs.size(); ++i )
	{
		//
		if(listGraphNodeNggrs[i].size() > 0  )
		{
//cout << "index " << i << ", list of ngbr = ";
//DumpIntSet( listGraphNodeNggrs[i] );
			// add it
			nodesInGraph.insert( i );
			UnionSets( nodesInGraph, listGraphNodeNggrs[i] );
		}
	}

	DirectedGraph digraph;


	// 
	map<int,int> mapNodesId;
	for( int i=0; i<(int)listGraphNodeNggrs.size(); ++i )
	{
		// 
		if( nodesInGraph.find( i ) != nodesInGraph.end() )
		{
			// create it
			int nid = digraph.AddVertex(i);
			mapNodesId.insert( map<int,int> :: value_type(i, nid) );

			// now change to an easy name
			int leaf1, leaf2;
			GetLeafPairFromId(i, leaf1, leaf2);
			char buf[100];
			sprintf( buf, "%d, %d", leaf1, leaf2 );
			digraph.SetVertexLabel( nid, buf );
//cout << "Create a vertex index " << i << " (" << leaf1 << ", " << leaf2  << ")" << " node id = " << nid << endl;
		}
	}
	// create arc
	for( int i=0; i<(int)listGraphNodeNggrs.size(); ++i )
	{
		if( listGraphNodeNggrs[i].size() > 0 )
		{
			int nsrcid = mapNodesId[i];
			for( set<int> :: iterator it = listGraphNodeNggrs[i].begin(); it != listGraphNodeNggrs[i].end(); ++it)
			{
				int destid = *it;
				YW_ASSERT_INFO( mapNodesId.find( destid ) != mapNodesId.end(), "Can not find the node"  );
				// add the arc
				digraph.AddEdge( nsrcid, mapNodesId[destid], -1  );
			}
		}
	}
	// output the graph
	digraph.OutputGML(fileName);

	// extra test
	if( digraph.IsAcyclic() == true )
	{
//		cout << "The graph of leaf pairs is ACYCLIC!\n";
	}
//cout << "Done output digraph\n";
	// also output a reduced graph here
	//DirectedGraph digraphRed = digraph;
	digraph.TrimTreeArcs();
	char fileNameRed[1000] = "tmp.gml";
	sprintf(fileNameRed,  "%s.reduced",  fileName );
	digraph.OutputGML(fileNameRed);
//cout << "Done output (reduced) digraph\n";
}



bool GenericHybridNetwork :: AreTwoPairsFullyDisjoint(int i, int j, int p, int q)
{
	// this two pairs do not intersect in any of the trees
	bool res = true;
	for(int t=0; t<(int)listTrees.size(); ++t)
	{
		if( listTrees[t]->AreTwoPathsDisjoint(i,j,p,q) == false )
		{
			res = false;
			break;
		}
	}

	return res;
}

bool GenericHybridNetwork :: AreTwoPairsGood(int i, int j, int p, int q, vector<vector< int > > &listMRCATrees, vector< vector< vector<bool> > > &ancestralMapTrees)
{
	// (i,j) vs (p,q) are good iff (i,j) is ancestral to (p,q) in some trees
	// and NONE of trees has the reverse relations
	bool res = false;

	// 
	for(int t=0; t<(int)listTrees.size(); ++t)
	{
		int idij = GetLeafPairInd(i,j);
		int idpq = GetLeafPairInd(p,q);
		int mrcaij1 = listMRCATrees[t][idij];
		int mrcapq1 = listMRCATrees[t][idpq];

		if( ancestralMapTrees[t][ mrcapq1 ][ mrcaij1 ] == true  )
		{
			res = false;
			break;
		}

		// 
		if( ancestralMapTrees[t][ mrcaij1 ][ mrcapq1 ] == true  )
		{
			res = true;
		}
	}

	return res;
}

bool GenericHybridNetwork :: AreTwoPairsForced(int i, int j, int p, int q, vector<vector< int > > &listMRCATrees, vector< vector< vector<bool> > > &ancestralMapTrees)
{
	bool f1 = false, f2 = false;
	for(int t=0; t<(int)listTrees.size(); ++t)
	{
		int idij = GetLeafPairInd(i,j);
		int idpq = GetLeafPairInd(p,q);
		int mrcaij1 = listMRCATrees[t][idij];
		int mrcapq1 = listMRCATrees[t][idpq];

		if( ancestralMapTrees[t][ mrcapq1 ][ mrcaij1 ] == true  )
		{
			f1 = true;
		}

		// 
		if( ancestralMapTrees[t][ mrcaij1 ][ mrcapq1 ] == true  )
		{
			f2 = true;
		}
	}

	if( f1 == true && f2 == true )
	{
		return true;
	}
	else
	{
		return false;
	}

}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// interface methods
HybridizeNetwork :: HybridizeNetwork(const MarginalTree &tp1, const MarginalTree &tp2 ) : tree1(tp1), tree2(tp2)
{
	vector<MarginalTree *> listTrees;
	listTrees.push_back( (MarginalTree *)&tree1);
	listTrees.push_back( (MarginalTree *)&tree2);
	SetTreeList( listTrees );
}

#if 0

// NOTE: this implements Tarjan's algorithm in paper: finding all elementary circuits
// in directed graph
void HybridizeNetwork :: FindLeafPairGraphCycles()
{
	vector< set<int> > listGraphNodeNggrs;
	ConsLeafPairGraph(listGraphNodeNggrs);
OutputGML( listGraphNodeNggrs, "LPGraph.gml" );

	// setup
	vector<bool> markedFlag;
	int numNodes = GetNumLeaves()*GetNumLeaves();
	for( int i=0; i<numNodes; ++i )
	{
		markedFlag.push_back( false );;
	}
	// two stacks
	vector<int> pointStack, markedStack;

	//
	for(int s=0; s<numNodes; ++s)
	{
//cout << "Visit s = ";
//DumpNode( s );
//cout << endl;
		RecurseCycle( listGraphNodeNggrs, s, s, pointStack, markedStack, markedFlag );
		while( markedStack.size() > 0 )
		{
			int u = markedStack[ markedStack.size()-1 ];
			markedFlag[u] = false;
			markedStack.pop_back();
//cout << "Pop ";
//DumpNode(  u );
//cout << " from marked stack\n";
		}
//cout << "Found cycles so far: ";
//DumpFoundCycles();
	}

//DumpFoundCycles();

}


// useful methods
void HybridizeNetwork :: ConsLeafPairGraph( vector< set<int> > &listGraphNodeNggrs )
{
	listGraphNodeNggrs.clear();
	int numNodes = GetNumLeaves()*GetNumLeaves();
	listGraphNodeNggrs.resize(numNodes);
//cout << "pass0\n";	

	// first store MRCAs for leaf pairs
	vector< int > listMRCATree1(numNodes), listMRCATree2( numNodes );
	for(int i=0; i<GetNumLeaves(); ++i)
	{
		for(int j=i+1; j<GetNumLeaves(); ++j)
		{
			int id = GetLeafPairInd( i, j );
			int mrca1 = tree1.GetMRCA(i, j);
			listMRCATree1[id] = mrca1;
			int mrca2 = tree2.GetMRCA(i, j);
			listMRCATree2[id] = mrca2;
		}
	}
//cout << "pass1\n";	
	// also which nodes are descendents of the other (for both leaf and non-leaf nodes)
	int numTotNodes = GetNumTotNodes();
	vector< vector<bool> > ancestralMapTree1( numTotNodes ), ancestralMapTree2(numTotNodes);
	for(int i=0; i<(int)ancestralMapTree1.size(); ++i)
	{
		ancestralMapTree1[i].resize( numTotNodes );
		ancestralMapTree2[i].resize( numTotNodes );
		for(int j=0; j<numTotNodes; ++j)
		{
			ancestralMapTree1[i][j] = false;
			ancestralMapTree2[i][j] = false;
		}
	}
//cout << "pass2\n";	
	for(int i=0; i<(int)ancestralMapTree1.size(); ++i)
	{
		for(int j=0; j<(int)ancestralMapTree1.size(); ++j)
		{
			if( i== j )
			{
				continue;
			}

			// test whether they are ancestor to each other
			if( tree1.IsNodeUnder( i, j ) == true )
			{
				ancestralMapTree1[i][j] = true;
			}
			if( tree1.IsNodeUnder( j, i ) == true )
			{
				ancestralMapTree1[j][i] = true;
			}
			if( tree2.IsNodeUnder( i, j ) == true )
			{
				ancestralMapTree2[i][j] = true;
			}
			if( tree2.IsNodeUnder( j, i ) == true )
			{
				ancestralMapTree2[j][i] = true;
			}
		}
	}
//cout << "pass3\n";	

	// try all pairs of leaves
	int numImpliedMPairs = 0;
	for(int i=0; i<GetNumLeaves(); ++i)
	{
		for(int j=i+1; j<GetNumLeaves(); ++j)
		{
			int idij = GetLeafPairInd(i,j);
			int mrcaij1 = listMRCATree1[idij];
			int mrcaij2 = listMRCATree2[idij];
			// another pair of leaves
			// for symetry, assume p > i
			for(int p=i+1; p<GetNumLeaves(); ++p)
			{
				for(int q=p+1; q<GetNumLeaves(); ++q)
				{
					if( p == i || p == j || q == i ||  q == j)
					{
						continue;
					}

					// test whether
					int idpq = GetLeafPairInd(p,q);
					int mrcapq1 = listMRCATree1[idpq];
					int mrcapq2 = listMRCATree2[idpq];
					YW_ASSERT_INFO( idij != idpq, "WRONG" );

					if( tree1.AreTwoPathsDisjoint(i,j,p,q) == true && tree2.AreTwoPathsDisjoint(i,j,p,q) == true )
					{
						//
						if( ( ancestralMapTree1[ mrcaij1 ][ mrcapq1 ] == true 
							&&
							ancestralMapTree2[ mrcapq2 ][ mrcaij2 ] == false ) ||
							( ancestralMapTree2[ mrcaij2 ][ mrcapq2 ] == true 
							&&
							ancestralMapTree1[ mrcapq1 ][ mrcaij1 ] == false
							)
							)
						{
							// a good pair
							listGraphNodeNggrs[idpq].insert( idij );
						}
						if( ( ancestralMapTree1[ mrcapq1 ][ mrcaij1 ] == true 
							&&  ancestralMapTree2[ mrcaij2 ][ mrcapq2 ] == false ) || 
							(ancestralMapTree2[ mrcapq2 ][ mrcaij2 ] == true 
							&&  ancestralMapTree1[ mrcaij1 ][ mrcapq1 ] == false )  )
						{
							// a good pair
							listGraphNodeNggrs[idij].insert( idpq );
						}

						// check implicit pairs
						if( ( ancestralMapTree1[ mrcaij1 ][ mrcapq1 ] == true || ancestralMapTree2[ mrcaij2 ][ mrcapq2 ] == true ) 
							&& ( ancestralMapTree1[ mrcapq1 ][ mrcaij1 ] == true || ancestralMapTree2[ mrcapq2 ][ mrcaij2 ] == true ) )
						{
//cout << "Pairs (" << i << ", " << j << "), (" << p << ", " << q << ") is forced\n";
							++numImpliedMPairs;

							// add to list of forced pair
							pair<int,int> ppij(i,j), pppq(p,q);
							pair< pair<int,int>, pair<int,int> > ppppp(ppij, pppq);
							setForcedPathPairs.insert( ppppp );
//listGraphNodeNggrs[idij].insert( idpq );
//listGraphNodeNggrs[idpq].insert( idij );
						}

					}

				}
			}

		}
	}
cout << "Number of implied pairs = " << numImpliedMPairs << endl;
 
#if 0
	// dump out nodes
	cout << "Found graph is: \n";
	for(int i=0; i<GetNumLeaves(); ++i)
	{
		for(int j=i+1; j<GetNumLeaves(); ++j)
		{
			int id = GetLeafPairInd( i, j );

			cout << "Leaf pair " << i << "," << j << ": ";
//#if 0
			for( set<int> :: iterator it = listGraphNodeNggrs[id].begin(); it != listGraphNodeNggrs[id].end(); ++it )
			{
				DumpNode(*it);
				//int leaf1, leaf2;
				//GetLeafPairFromId(*it, leaf1, leaf2);
				//cout << " (" << leaf1 << ", " << leaf2 << ")";
			}
			cout << endl;
			//DumpIntSet( listGraphNodeNggrs[id] );
//#endif
			cout << "number of neighbors = " << listGraphNodeNggrs[id].size() << endl;
		}
	}
#endif
}

int HybridizeNetwork :: GetLeafPairInd(int i, int j)
{
	YW_ASSERT_INFO( i != j, "Can ont be the same" );
	// 
	if( i > j )
	{
		OrderInt(i,j);
	}
	return i*GetNumLeaves() + j;
//	return ConvertToLinear( i, j, GetNumLeaves()  );
}

void HybridizeNetwork :: GetLeafPairFromId( int ind, int &leaf1, int &leaf2)
{
	leaf1 = ind / GetNumLeaves();
	leaf2 = ind % GetNumLeaves();
}

void HybridizeNetwork :: GetCycle(int cycleId, vector< pair<int,int> > &cycleNodes)  
{ 
	for(int i=0; i<(int) listLeafPairCycles[cycleId].size(); ++i)
	{
		int leaf1, leaf2;
		GetLeafPairFromId( listLeafPairCycles[cycleId][i], leaf1, leaf2 );
		pair<int,int> pp(leaf1, leaf2);
		cycleNodes.push_back(pp); 
	}
}

bool HybridizeNetwork :: RecurseCycle(vector< set<int> > &listGraphNodeNggrs, int s,
									  int v, vector<int> &pointStack, vector<int> &markedStack, vector<bool> &markedFlag)
{
//cout << "In RecurseCycle: s = ";
//DumpNode(s);
//cout << endl;
	// 
	// bool g;
	bool res = false;
	pointStack.push_back( v );
//cout << "After pushing ";
//DumpNode( v );
//cout << ", point stack = ";
//DumpListNode(pointStack);
	markedFlag[v] = true;
	markedStack.push_back(v);
//cout << "After pushing ";
//DumpNode( v );
//cout << ", marked stack = ";
//DumpListNode(markedStack);

	for( set<int> :: iterator it = listGraphNodeNggrs[v].begin(); it != listGraphNodeNggrs[v].end(); ++it )
	{
		int w = *it;
//cout << "Checking w = ";
//DumpNode( w );
//cout << endl;
		if( w < s )
		{
//cout << "Skip w = ";
//DumpNode( w );
			// delete this arc
			//listGraphNodeNggrs[v].erase( w );
		}
		else if( w == s )
		{
			// find a path
//cout << "****************Find a path: ";
//DumpListNode(pointStack);
			listLeafPairCycles.push_back( pointStack );
			//DumpIntVec(pointStack);
			res = true;
		}
		else if( markedFlag[w] == false )
		{
//cout << "w is unmarked, so continue...\n";
			bool g = RecurseCycle( listGraphNodeNggrs, s, w, pointStack, markedStack, markedFlag );
			if( g == true )
			{
//cout << "g is true, so set res to true\n";
				res = true;
			}
		}
	}

	//
	if( res == true )
	{
		while( markedStack.size() > 0 && markedStack[ markedStack.size()-1] != v )
		{
			int u = markedStack[ markedStack.size()-1];
			markedFlag[u] = false;
			markedStack.pop_back();
//cout << "Pop ";
//DumpNode( u );
//cout << ", from marked stack. Marked stack now = ";
//DumpListNode(markedStack);
		}
		YW_ASSERT_INFO( markedStack[ markedStack.size()-1] == v, "Stack operation error" );
		markedFlag[v] = false;
		markedStack.pop_back();
//DumpNode( v );
//cout << ", from marked stack. Marked stack now = ";
//DumpListNode(markedStack);
	}

	// finally delete v
	YW_ASSERT_INFO( pointStack[ pointStack.size()-1] == v, "Stack operation error2" );
	pointStack.pop_back();
//DumpNode( v );
//cout << ", from point stack. point stack now = ";
//DumpListNode(pointStack);

	return res;
}

void HybridizeNetwork :: DumpNode(int id)
{
	int leaf1, leaf2;
	GetLeafPairFromId(id, leaf1, leaf2);
	cout << " (" << leaf1 << ", " << leaf2 << ")";

}

void HybridizeNetwork :: DumpListNode( const vector<int> &listNids  )
{
	for(int i=0; i<(int)listNids.size(); ++i)
	{
		DumpNode( listNids[i] );
	}
	cout << endl;
}

void HybridizeNetwork :: DumpFoundCycles()
{
	cout << "Number of cycles found = " << listLeafPairCycles.size() << endl;
return;
	for(int i=0; i<(int)listLeafPairCycles.size(); ++i)
	{
		cout << "Path: ";
		DumpListNode( listLeafPairCycles[i] );
	}
}

void HybridizeNetwork :: OutputGML( const vector< set<int> > &listGraphNodeNggrs,  const char *fileName  )
{
	// only create node if it appears either as sink or as src
	set<int> nodesInGraph;
	for( int i=0; i<(int)listGraphNodeNggrs.size(); ++i )
	{
		//
		if(listGraphNodeNggrs[i].size() > 0  )
		{
//cout << "index " << i << ", list of ngbr = ";
//DumpIntSet( listGraphNodeNggrs[i] );
			// add it
			nodesInGraph.insert( i );
			UnionSets( nodesInGraph, listGraphNodeNggrs[i] );
		}
	}

	DirectedGraph digraph;


	// 
	map<int,int> mapNodesId;
	for( int i=0; i<(int)listGraphNodeNggrs.size(); ++i )
	{
		// 
		if( nodesInGraph.find( i ) != nodesInGraph.end() )
		{
			// create it
			int nid = digraph.AddVertex(i);
			mapNodesId.insert( map<int,int> :: value_type(i, nid) );

			// now change to an easy name
			int leaf1, leaf2;
			GetLeafPairFromId(i, leaf1, leaf2);
			char buf[100];
			sprintf( buf, "%d, %d", leaf1, leaf2 );
			digraph.SetVertexLabel( nid, buf );
//cout << "Create a vertex index " << i << " (" << leaf1 << ", " << leaf2  << ")" << " node id = " << nid << endl;
		}
	}
	// create arc
	for( int i=0; i<(int)listGraphNodeNggrs.size(); ++i )
	{
		if( listGraphNodeNggrs[i].size() > 0 )
		{
			int nsrcid = mapNodesId[i];
			for( set<int> :: iterator it = listGraphNodeNggrs[i].begin(); it != listGraphNodeNggrs[i].end(); ++it)
			{
				int destid = *it;
				YW_ASSERT_INFO( mapNodesId.find( destid ) != mapNodesId.end(), "Can not find the node"  );
				// add the arc
				digraph.AddEdge( nsrcid, mapNodesId[destid], -1  );
			}
		}
	}
	// output the graph
	digraph.OutputGML(fileName);

	// extra test
	if( digraph.IsAcyclic() == true )
	{
		cout << "The graph of leaf pairs is ACYCLIC!\n";
	}
cout << "Done output digraph\n";
	// also output a reduced graph here
	//DirectedGraph digraphRed = digraph;
	digraph.TrimTreeArcs();
	char fileNameRed[1000] = "tmp.gml";
	sprintf(fileNameRed,  "%s.reduced",  fileName );
	digraph.OutputGML(fileNameRed);
cout << "Done output (reduced) digraph\n";
}

#endif


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Three or more trees

// Class for inferring general hybrid network
GeneralHybridNetwork :: GeneralHybridNetwork(vector<MarginalTree *> &listTreeOrigParam) : listTreeOrig(listTreeOrigParam)
{
	SetTreeList( listTreeOrig );
}

int GeneralHybridNetwork :: CalcQuickUB()
{
	// calc quick UB for this
	vector< vector<int> > matPairDists(listTreeOrig.size());
	for(int i=0; i<(int) matPairDists.size(); ++i)
	{
		matPairDists[i].resize(listTreeOrig.size() );
	}
	for(int i=0; i<(int)matPairDists.size(); ++i)
	{
		matPairDists[i][i]=0;
	}
	// compute pairwise dist
	for(int i=0; i<(int)matPairDists.size(); ++i)
	{
		for(int j=i+1; j<(int)matPairDists.size(); ++j)
		{
cout << "Solve one pair\n";
			//
			ILPSolverSPR solver( *listTreeOrig[i], *listTreeOrig[j] );
			solver.SetAcyclic(  true );

			int dist = solver.ComputeAcyclicrSPR();
cout << "Hybrid distance between trees " << i << " and " << j << ": " << dist << endl;
			matPairDists[i][j] = dist;
			matPairDists[j][i] = dist;
		}
	}
	int res = CalcMinLinearOrder(matPairDists);
	return res;
}

int GeneralHybridNetwork :: CalcQuickLB()
{
	// YW: DO NOT WORK, UNFORTUNATELY!!!!!!!!!!!!
	// order the trees in some way, the number of edge-disjoint
	// novel triples (triples that do not appear in any previous ones)
	// this is similar to an independent set problem. Use simple heuristic to give a try
	// simple dynamic programming
	YW_ASSERT_INFO( listTreeOrig.size() <= 15, "Too many trees, can not handle this much yet. Stop." );

	int tblSize = 0x1 << listTreeOrig.size();
	vector<int> dpTableSubsets( tblSize );

	// init cell with single item to be 
	for(int pos=0; pos<= (int)listTreeOrig.size(); ++pos)
	{
		dpTableSubsets[pos] = 0;
	}

	int res = 0;

	// Now we move to next row
	for(unsigned int nr = 2; nr <= listTreeOrig.size(); ++nr)
	{
		// Now, we enumerate all combinations of nr rows
		// We do this by first get the position vector of each such cases
		vector<int> posvec;
		GetFirstCombo( nr, listTreeOrig.size(), posvec );
		while(true)
		{
//cout << "Now treat cell for: " ;
//DumpIntVec( posvec );
			// Create a vector, and set the index vector
			vector<int> subsetIndex;
			vector<int> subsetRows;

			GetIntVec(listTreeOrig.size(), posvec, subsetIndex );
			subsetRows = posvec;


			// Now we try to remove one row
			// Set to a large number
			int val = 0;			
			// We simply trim one row to see which one gives smaller value
			for( int i=0; i<(int)subsetRows.size(); ++i  )
			{
				vector<int> copy = subsetRows;
				vector<int> :: iterator it = copy.begin();
				for(int j=0; j<i; ++j)
				{
					it++;
				}
				copy.erase( it );
				vector<int> x;
				GetIntVec(listTreeOrig.size(), copy, x );
				int pos = ConvVecToInt(x);

				// find the minimum from this item to the other
				set<int> scopy;
				PopulateSetByVec( scopy, copy);
				int distMin = CalcISForestDist(scopy, subsetRows[i]  );


//cout << "pass 3" << endl;
//cout << "pass 4" << endl;
				int tmpVal = dpTableSubsets[pos] + distMin;
//cout << "Value = " << tmpVal << " for ";
//DumpIntVec( copy );
				if( val < tmpVal )
				{
					val = tmpVal;
				}
			}



			// FInally, save the new value
//cout << "Set value to " << val << endl;
			int pos = ConvVecToInt(subsetIndex);
			dpTableSubsets[pos] = val  ;

			// Record answer to the function
			if( nr == listTreeOrig.size() )
			{
				res = val;
			}

			// Get the next position
			if( GetNextCombo( nr, listTreeOrig.size(), posvec ) == false )
			{
				break;
			}
		}

	}


	// The result is the lowest-rightmost cell value
//	res = DPTable[nr-1]; 

	// Before quit, make sure to delete mem
	return res;

}

int GeneralHybridNetwork :: CalcISForestDist( const set<int> &setTreeIndices, int nextTree )
{
	// find a list of fully-incompatible triples at this next tree
	YW_ASSERT_INFO(setTreeIndices.find(nextTree) == setTreeIndices.end(), "Can not derive tree");
cout << "setTreeIndices: ";
DumpIntSet( setTreeIndices );
cout << "nextrree = " << nextTree << endl;

	// try all triples
	vector< pair<int, pair<int,int> > > listNovelTriples;
	for(int a=0; a<listTreeOrig[nextTree]->GetNumLeaves(); ++a)
	{
		for(int b=a+1; b<listTreeOrig[nextTree]->GetNumLeaves(); ++b)
		{
			for(int c=b+1; c<listTreeOrig[nextTree]->GetNumLeaves(); ++c)
			{
				int tripleabc = listTreeOrig[nextTree]->GetTriple(a,b,c);
				// is the triple same or different from previous triple
				bool fNovel = true;
				for(set<int>:: iterator it = setTreeIndices.begin(); it != setTreeIndices.end(); ++it)
				{
					int tnew = listTreeOrig[*it]->GetTriple(a,b,c);
					if( tnew == tripleabc)
					{
						fNovel = false;
						break;
					}
				}

				// 
				if( fNovel == true )
				{
//cout << "This triple is novel: " << a << ", " << b << ", " << c << endl; 
					// 
					pair<int,int> pbc(b, c);
					pair<int, pair<int,int> > pabc( a, pbc );
					listNovelTriples.push_back( pabc);
				}
				else
				{
//cout << "This triple is old: " << a << ", " << b << ", " << c << endl; 
				}
			}

		}

	}
cout << "Size of novel splits = " << listNovelTriples.size() << endl;


	// simply take the node with the smallest degree
	//int res = 0;

	vector< vector<bool> > matTripleIntsect(listNovelTriples.size());
	for(int i=0; i<(int)listNovelTriples.size(); ++i)
	{
		matTripleIntsect[i].resize(listNovelTriples.size());
	}
	for(int t1=0; t1<(int)listNovelTriples.size(); ++t1)
	{
		for(int t2=t1+1; t2<(int)listNovelTriples.size(); ++t2)
		{
			// if any leaves shared then of course intersect
			int fInt = false;
			set<int> s1;
			s1.insert(listNovelTriples[t1].first);
			s1.insert(listNovelTriples[t1].second.first);
			s1.insert(listNovelTriples[t1].second.second);
			if(  s1.find(listNovelTriples[t2].first) != s1.end() || 
				s1.find(listNovelTriples[t2].second.first) != s1.end()  ||
				s1.find(listNovelTriples[t2].second.second) != s1.end()  )
			{
				fInt = true;
			}
			else
			{


				// is this two triples intersect?
				if(   listTreeOrig[nextTree]->AreTwoPathsDisjoint( listNovelTriples[t1].first, listNovelTriples[t1].second.first, 
					listNovelTriples[t2].first, listNovelTriples[t2].second.first) == false   || 
					listTreeOrig[nextTree]->AreTwoPathsDisjoint( listNovelTriples[t1].first, listNovelTriples[t1].second.first, 
					listNovelTriples[t2].first, listNovelTriples[t2].second.second) == false   ||
					listTreeOrig[nextTree]->AreTwoPathsDisjoint( listNovelTriples[t1].first, listNovelTriples[t1].second.first, 
					listNovelTriples[t2].second.first, listNovelTriples[t2].second.second) == false
					||
					listTreeOrig[nextTree]->AreTwoPathsDisjoint( listNovelTriples[t1].first, listNovelTriples[t1].second.second, 
					listNovelTriples[t2].first, listNovelTriples[t2].second.first) == false   || 
					listTreeOrig[nextTree]->AreTwoPathsDisjoint( listNovelTriples[t1].first, listNovelTriples[t1].second.second, 
					listNovelTriples[t2].first, listNovelTriples[t2].second.second) == false   ||
					listTreeOrig[nextTree]->AreTwoPathsDisjoint( listNovelTriples[t1].first, listNovelTriples[t1].second.second, 
					listNovelTriples[t2].second.first, listNovelTriples[t2].second.second) == false
					)
				{
//cout << "This triple : " << listNovelTriples[t1].first << ", " << listNovelTriples[t1].second.first << ", " << listNovelTriples[t1].second.second << endl; 
//cout << "intersect " << listNovelTriples[t2].first << ", " << listNovelTriples[t2].second.first << ", " << listNovelTriples[t2].second.second << endl; 
					fInt = true;
				}

			}
			matTripleIntsect[t1][t2] = fInt;
			matTripleIntsect[t2][t1] = fInt;
if( fInt == false)
{
//cout << "This triple : " << listNovelTriples[t1].first << ", " << listNovelTriples[t1].second.first << ", " << listNovelTriples[t1].second.second << endl; 
//cout << "DISJOINT " << listNovelTriples[t2].first << ", " << listNovelTriples[t2].second.first << ", " << listNovelTriples[t2].second.second << endl; 

}

		}
	}

	// find the degree of each triple
	vector<int> listNodeDegrees( listNovelTriples.size() );
	for(int i=0; i<(int)listNovelTriples.size(); ++i)
	{
		for(int j=0; j<(int)listNovelTriples.size(); ++j)
		{
			if( i == j )
			{
				continue;
			}
			if( matTripleIntsect[i][j] == true )
			{
				listNodeDegrees[i] ++;
			}
		}
	}
	// now find the next lowest degree not already picked and is independent of current ones
	set<int> listISNodes;
	set<int> listCandidates;
	PopulateSetWithInterval(listCandidates, 0, listNovelTriples.size()-1 );
	while(  listCandidates.size() > 0  )
	{
//cout << "Current degree: ";
//DumpIntVec(listNodeDegrees);
		// 
		int item = -1;
		int mindeg = HAP_MAX_INT;
		for( set<int> :: iterator it = listCandidates.begin(); it != listCandidates.end(); ++it )
		{
			// is this triple disjoint with the one already selected?
			bool fDisjoint = true;
			for( set<int> :: iterator it2 = listISNodes.begin(); it2 != listISNodes.end(); ++it2 )
			{
				if(matTripleIntsect[*it][*it2] == true)
				{
					fDisjoint = false;
					break;
				}
			}

			// small and 
			YW_ASSERT_INFO( listNodeDegrees[*it] >= 0, "Can not be negative degree" );
			if( mindeg > listNodeDegrees[*it] && fDisjoint == true )
			{
				mindeg = listNodeDegrees[*it];
				item = *it;
			}
		}
		if(item <0)
		{
			// no more to work
			break;
		}

		// add it
		YW_ASSERT_INFO( listISNodes.find(item) == listISNodes.end(), "Not right" );
		listISNodes.insert(item);
		listCandidates.erase( item );
		// update degree for the remaining nodes in candidate
		for( set<int> :: iterator it = listCandidates.begin(); it != listCandidates.end(); ++it )
		{
			if(matTripleIntsect[*it][item] == true)
			{
				// 
				listNodeDegrees[*it] --;
			}
		}
	}
cout << "listISNodes: ";
DumpIntSet(listISNodes);
// ensure this is indeed an IS
for( set<int> :: iterator it = listISNodes.begin(); it != listISNodes.end(); ++it )
{
set<int> :: iterator it2 = it;
it2++;
for( ; it2 != listISNodes.end(); ++it2)
{
YW_ASSERT_INFO( matTripleIntsect[*it][*it2] == false, "SERIOUS ERROR: not an Indenpdent set at all" );
}
}
	return listISNodes.size();	// TBD
}


// utilities
int GeneralHybridNetwork :: CalcMinLinearOrder( const vector< vector<int> > &matPairDists )
{
	// simple dynamic programming
	YW_ASSERT_INFO( matPairDists.size() <= 15, "Too many trees, can not handle this much yet. Stop." );

	int tblSize = 0x1 << listTreeOrig.size();
	vector<int> dpTableSubsets( tblSize );

	// init cell with single item to be 
	for(int pos=0; pos<= (int)listTreeOrig.size(); ++pos)
	{
		dpTableSubsets[pos] = 0;
	}

	int res = 0;

	// Now we move to next row
	for(unsigned int nr = 2; nr <= listTreeOrig.size(); ++nr)
	{
		// Now, we enumerate all combinations of nr rows
		// We do this by first get the position vector of each such cases
		vector<int> posvec;
		GetFirstCombo( nr, listTreeOrig.size(), posvec );
		while(true)
		{
//cout << "Now treat cell for: " ;
//DumpIntVec( posvec );
			// Create a vector, and set the index vector
			vector<int> subsetIndex;
			vector<int> subsetRows;

			GetIntVec(listTreeOrig.size(), posvec, subsetIndex );
			subsetRows = posvec;


			// Now we try to remove one row
			// Set to a large number
			int val = HAP_MAX_INT;				// a large number. TBD
			// We simply trim one row to see which one gives smaller value
			for( int i=0; i<(int)subsetRows.size(); ++i  )
			{
				vector<int> copy = subsetRows;
				vector<int> :: iterator it = copy.begin();
				for(int j=0; j<i; ++j)
				{
					it++;
				}
				copy.erase( it );
				vector<int> x;
				GetIntVec(listTreeOrig.size(), copy, x );
				int pos = ConvVecToInt(x);

				// find the minimum from this item to the other
				int distMin = HAP_MAX_INT;
				for(int j=0; j<(int)copy.size(); ++j)
				{
					if( distMin > matPairDists[ subsetRows[i] ][ copy[j] ] )
					{
						distMin = matPairDists[ subsetRows[i] ][ copy[j] ];
					}
				}


//cout << "pass 3" << endl;
//cout << "pass 4" << endl;
				int tmpVal = dpTableSubsets[pos] + distMin;
//cout << "Value = " << tmpVal << " for ";
//DumpIntVec( copy );
				if( val > tmpVal )
				{
					val = tmpVal;
				}
			}



			// FInally, save the new value
//cout << "Set value to " << val << endl;
			int pos = ConvVecToInt(subsetIndex);
			dpTableSubsets[pos] = val  ;

			// Record answer to the function
			if( nr == listTreeOrig.size() )
			{
				res = val;
			}

			// Get the next position
			if( GetNextCombo( nr, listTreeOrig.size(), posvec ) == false )
			{
				break;
			}
		}

	}


	// The result is the lowest-rightmost cell value
//	res = DPTable[nr-1]; 

	// Before quit, make sure to delete mem
	return res;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Hybridize three trees
static void OutputTki( ofstream &outFile, int tree, int i )
{
    outFile << "T," << tree << "," << i;  
} 
static void OutputTk12i( ofstream &outFile, int tree1, int tree2, int i )
{
    outFile << "T2," << tree1 << "," << tree2 << "," << i;  
} 


static void OutputMLvCommonij( ofstream &outFile, int i, int j )
{
	if( i > j )
	{
		int tmp = i;
		i=j;
		j=tmp;
	}
    outFile << "ML," << i << "," << j;  
} 

static void OutputMTkij( ofstream &outFile, int tree, int i, int j )
{
    outFile << "MT," << tree << "," << i << "," << j;  
} 

static void OutputMPTkij( ofstream &outFile, int tree, int tprev, int i, int j )
{
    outFile << "MPT," << tree << ","  << tprev << "," << i << "," << j;  
} 


static void OutputMLvTreeij( ofstream &outFile, int tree, int i, int j )
{
	if( i > j )
	{
		int tmp = i;
		i=j;
		j=tmp;
	}
    outFile << "MT1," << tree << "," << i << "," << j;  
} 


static void OutputSi( ofstream &outFile, int i )
{
    outFile << "S," << i ;  
} 
static void OutputMLvTreeOrderedij( ofstream &outFile, int tree, int i, int j )
{
    outFile << "MTO," << tree << "," << i << "," << j;  
} 
static void OutputMLvT12Orderedij( ofstream &outFile, int t1, int t2, int i, int j )
{
    outFile << "MTO12," << t1 << "," << t2 << "," << i << "," << j;  
} 
// singleton a is attached to pair (c,d)
static void OutputMLvTreeOrderedacd( ofstream &outFile, int tree, int a, int c, int d )
{
    outFile << "MTO1," << tree << "," << a << "," << c << "," << d;  
} 
// pair(a,b) a is attached to singleton c
static void OutputMLvTreeOrderedabc( ofstream &outFile, int tree, int a, int b, int c )
{
    outFile << "MTO2," << tree << "," << a << "," << b << "," << c;  
} 
// pair (a,b) is attached to pair (c,d)
static void OutputMLvTreeOrderedabcd( ofstream &outFile, int tree, int a, int b, int c, int d )
{
    outFile << "MTO3," << tree << "," << a << "," << b << "," << c << "," << d;  
} 

// this only consider in T3 and only use one type of cuts (for T1 or T2)
static void OutputM2TConnectij( ofstream &outFile, int curtree, int reftree, int i, int j )
{
	if( i > j )
	{
		int tmp = i;
		i=j;
		j=tmp;
	}
    outFile << "M2T," << curtree << "," << reftree << "," << i << "," << j;  
} 

////////////////////////////////////////////////////////////////////////////////////////////////////////
// Four trees test
// indicate whether a leaf i's forest root (in C cuts) is node j
static void OutputRKij( ofstream &outFile, int tree, int i, int j )
{
    outFile << "R2," << tree << "," << i << "," << j;  
} 
// indicate whether leaf i's forest root is cut by T-cuts or not
static void OutputRKi( ofstream &outFile, int tree, int i )
{
    outFile << "R," << tree << "," << i;  
} 
static void OutputFk12i( ofstream &outFile, int tree1, int tree2, int i )
{
	// =1 mens branch bi of Tk1 is following tree Tk2
    outFile << "F," << tree1 << "," << tree2 << "," << i;  
} 
static void OutputAkij( ofstream &outFile, int tree1, int i, int j )
{
	// =1 mens branch bi of Tk1 is following tree Tk2
    outFile << "A," << tree1 << "," << i << "," << j;  
} 
static void OutputFLvk12i( ofstream &outFile, int tree1, int tree2, int i )
{
	// =1 mens the forest containing leave i Tk1 is following tree Tk2
    outFile << "FLV," << tree1 << "," << tree2 << "," << i;  
} 
static void OutputICk12iabcx( ofstream &outFile, int tree1, int tree2, int i, int a, int b, int c, int x )
{
	// IC,k,k2,i,a,b,c,x: whether Tk and Tk2 are incompatible regarding to cut at bi and
	// regarding to triples a,b,c (and another x as the other direction)
	vector<int> tmpvec;
	tmpvec.push_back(a);
	tmpvec.push_back(b);
	tmpvec.push_back(c);
	SortIntVec( tmpvec);

    outFile << "IC," << tree1 << "," << tree2 << "," << i << "," << tmpvec[0] << "," << tmpvec[1] << "," << tmpvec[2] << "," << x;  
}
static void Order3Int(int &a, int &b, int &c)
{
	vector<int> tmpvec;
	tmpvec.push_back(a);
	tmpvec.push_back(b);
	tmpvec.push_back(c);
	SortIntVec( tmpvec);
	a = tmpvec[0];
	b = tmpvec[1];
	c = tmpvec[2];
}


void OutputILPMaxGoodAgreeForestMultiTrees(const char* fileName, vector<MarginalTree *> &listTreeOrig)
{
	YW_ASSERT_INFO(listTreeOrig.size() >=3, "Wrong number of trees");
cout << "Inside OutputILPMaxGoodAgreeForestMultiTrees\n";
	for(int t=1; t< (int)listTreeOrig.size(); ++t)
	{
		YW_ASSERT_INFO( listTreeOrig[0]->GetTotNodesNum() == listTreeOrig[t]->GetTotNodesNum(), "mismatch" );
	}

//cout << "OutputILPMaxGoodAgreeForest: treeOrig1 = ";
//treeOrig1.Dump();
//cout << "OutputILPMaxGoodAgreeForest: tree2 = ";
//treeOrig2.Dump();

	vector<MarginalTree> listTreeUse;
	for(int t=0; t<(int)listTreeOrig.size(); ++t)
	{
		MarginalTree  tree1Reduced = *listTreeOrig[t];

		// buildup the descendent info
		tree1Reduced.BuildDescendantInfo();
		listTreeUse.push_back( tree1Reduced );
	}

	// collect all triples and their shape
	// in particular, for ordered triples i,j,k (i<j<k)
	// (i,j,k) = 1 if (i,j),k
	// (i,j,k) = 2 if i,(j,k)
	// (i,j,k) = 3 if(i,k),j
	int nLeaveNum = listTreeUse[0].GetNumLeaves();
//cout << "num leaves = " << nLeaveNum << endl;

    //vector MarginalTree *ptrTrees[4];
    //ptrTrees[0] = &tree1Reduced;
    //ptrTrees[1] = &tree2Reduced;
    //ptrTrees[2] = &tree3Reduced;
    //ptrTrees[3] = &tree4Reduced;

	// this keep track of the type of triples we have in the component
	vector< vector< vector<int> > >  treesTripleState[ listTreeUse.size() ];
	for(int t=0; t<(int)listTreeUse.size(); t++)
	{
		treesTripleState[t].resize( nLeaveNum );
		for(int i=0; i<nLeaveNum; ++i)
		{
			treesTripleState[t][i].resize( nLeaveNum );
			for(int j=0; j<nLeaveNum; ++j)
			{
				treesTripleState[t][i][j].resize( nLeaveNum );
				for(int k=0; k<nLeaveNum; ++k)
				{
					treesTripleState[t][i][j][k] = 0;
				}
			}
		}
	}
	for(int t=0; t< (int)listTreeUse.size(); t++)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				for(int k=j+1; k< listTreeUse[t].GetNumLeaves(); ++k)
				{
					// is these have different triples on T1 and T2?
					// we do this by getting MRCA for all pairs of MRCAs
					int mrcaij1 = listTreeUse[t].GetMRCA( i, j );
					int mrcajk1 = listTreeUse[t].GetMRCA( j, k );
					int mrcaik1 = listTreeUse[t].GetMRCA( i, k );

					// now just test exhustively
					if( mrcaij1 == mrcajk1 )
					{
						treesTripleState[t][i][j][k] = 3;
					}
					else if( mrcaij1 == mrcaik1 )
					{
						treesTripleState[t][i][j][k] = 2;
					}
					else 
					{
						treesTripleState[t][i][j][k] = 1;
					}

				}
			}
		}
	}

	// this keep track for each tree, which pair intersect with which in the first tree
	map< pair< pair<int,int>, pair<int,int> >, bool > mapNodePairPathIntersectInTrees[ listTreeUse.size() ];
	for(int t=0; t< (int)listTreeUse.size(); ++t)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				pair<int,int> pp1(i,j);
				for(int p=i+1; p< listTreeUse[t].GetNumLeaves(); ++p)
				{
					// make sure p <>i or j
					if(  p == j )
					{
						continue;
					}
					for(int q = p+1; q < listTreeUse[t].GetNumLeaves(); ++q)
					{
						// make sure q is unique twoo
						if(  q == j )
						{
							continue;
						}
						pair<int,int> pp2(p,q);
						pair< pair<int,int>, pair<int,int> > pp(pp1,pp2);

						// now we only worry about two disjoint path (i,j) and (p,q)
						bool fInt =  listTreeUse[t].AreTwoPathsDisjoint( i, j, p, q );
						if( fInt == true )
						{
							fInt = false;
						}
						else
						{
							fInt = true;
						}
//if( fInt == true )
//cout << "Tree " << t << ", [" << i << ", " << j << "] overlaps [" << p << ", " << q << "]\n";
//else
//cout << "Tree " << t << ", [" << i << ", " << j << "] disjoint [" << p << ", " << q << "]\n";
						mapNodePairPathIntersectInTrees[t].insert( map< pair< pair<int,int>, pair<int,int> >, bool > :: value_type(pp, fInt)  );
					}
				}
			}
		}
	}

    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // first the set of branch cuts (twice as much as what in one tree
	for(int t=1; t< (int)listTreeUse.size(); ++t)
	{
		for( int i = 0; i< listTreeUse[t].GetTotNodesNum()-1; ++i )
		{
			//if( t == 1 )
			//{
			//	outFile << "0.95 ";
			//}

			OutputTki(outFile, t, i);
			if( t < (int) listTreeUse.size()-1 || i < listTreeUse[t].GetTotNodesNum()-2 )
			{
				outFile << "\n+ ";
			}
		}
	}
#if 0
	// When condition is satisified, also find the smaller original cuts 
	double varRatio = 0.5/listTreeUse[0].GetTotNodesNum();
	for( int i = 0; i< listTreeUse[1].GetTotNodesNum()-1; ++i )
	{
		outFile << "\n+ " << varRatio << "  ";
		OutputTki(outFile, 1, i);
	}
#endif

#if 0
	// Also, minus everything we have one tree branch 
	for(int t=2; t<(int)listTreeUse.size(); ++t)
	{
		for( int i = 0; i< listTreeUse[t].GetTotNodesNum()-1; ++i )
		{
			outFile << "\n+ ";
			OutputTki(outFile, t, i);
		}
	}
#endif
    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;




    // now enforce m,i
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		//OutputCki( outFile, t,  listTreeUse[t].GetTotNodesNum()-1 );
		//outFile << " = 0 \n";
	}

	// enforce same number of edge cuts in two trees
	//for(int t=1; t<(int)listTreeUse.size(); ++t)
	//{
	//	for(int i=0; i<listTreeUse[0].GetTotNodesNum(); ++i)
	//	{
	//		OutputCki(outFile, 0, i);
	//		if( i < listTreeUse[0].GetTotNodesNum()-1 )
	//		{
	//			outFile << " + \n";
	//		}
	//	}
	//	for(int i=0; i<listTreeUse[t].GetTotNodesNum(); ++i)
	//	{
	//		outFile << "\n - ";
	//		OutputCki(outFile, t, i);
	//	}
	//	outFile << " = 0\n";
	//}

	// enforce connectivity through all pairs of node conectivity
    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
    set< pair<int,int> > listPairNodesConstraint[ listTreeUse.size() ];
	map< int, vector<int> > mapLeafAncestors[ listTreeUse.size() ];

    // for each tree, we constraint on the connectivity of each node to all ancestral nodes
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
        const MarginalTree *pCurrTree = &listTreeUse[t];

		for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
		{
			vector<int> lvAncestors;

			// first we need to find MRCA of i,j. 
			// note that we actually want to exluce MRCA, but include i,j!
			//vector<int> listPathNodes;
			int n1=i;
			// of course connected to itself
			OutputMkij( outFile, t, i, n1 );
			outFile << " = 1\n";

			//listPathNodes.push_back(i);
			//listPathNodes.push_back(j);
			while( n1 >= 0 )
			{
				// IMPORTANT: make sure n1 <= n2 (true upon entry)

				// enforce an property
				pair<int,int> pp(i, n1);
				if( listPairNodesConstraint[t].find(pp) != listPairNodesConstraint[t].end()   )
				{
					// we already reach what we need, stop
					//break;
					YW_ASSERT_INFO(false, "should not go here");
				}
				listPairNodesConstraint[t].insert(pp);
				lvAncestors.push_back(n1);

	
				// we alternatively move up, depend on which one is smaller
				int nodeNew;
				// move n1
				nodeNew = pCurrTree->GetParent(n1);

				int n1New, edgeCuti;
				n1New = nodeNew;
				edgeCuti = n1;

				if( n1New >= 0)
				{
					// here are constraints: if the (shorter) orig pair is already 0, then the new must also be 0
					OutputMkij( outFile, t, i, n1 );
					outFile << " - ";
					OutputMkij( outFile, t, i, n1New );
					outFile << " >= 0\n";
					// if orig is 1, and cut = 0, then new connect = 1
					OutputMkij( outFile, t, i, n1New );
					outFile << " + ";
//					OutputCki( outFile, t,  edgeCuti);
					// 020109: YW: temp trial: change frm Cki to Tki
					OutputTki( outFile, t,  edgeCuti);
					outFile << " - ";
					OutputMkij( outFile, t, i, n1 );
					outFile << " >= 0\n";
					// if edge cut is 1, then M = 0
					OutputMkij( outFile, t, i, n1New );
					outFile << " + ";
					OutputTki( outFile, t,  edgeCuti);
					outFile << " <= 1\n";
				}
				 // now update n1 and n2
				n1 = n1New;
			}
//cout << "For tree t= " << t << ", leaf " << i << ", ancestor list = ";
//DumpIntVec( lvAncestors );
			mapLeafAncestors[t].insert(map< int, vector<int> > :: value_type(i, lvAncestors) );
		}

	}

#if 0
	//
	for(int tcurr = 1; tcurr < (int)listTreeUse.size(); ++tcurr)
	{
		// is leaves are really connected or not

		// enforce for each previous tree
		const MarginalTree *pCurrTree = &listTreeUse[tcurr];

		for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
			{
				// first we need to find MRCA of i,j. 
				// note that we actually want to exluce MRCA, but include i,j!
				set<int> listPathNodes;
				int n1=i, n2 = j;
				listPathNodes.insert(i);
				listPathNodes.insert(j);
				while( n1 != n2 )
				{
					// we alternatively move up, depend on which one is smaller
					int nodeNew;
					if( n1 < n2  )
					{
						// move n1
						n1 = pCurrTree->GetParent(n1);
						nodeNew = n1;
					}
					else
					{
						// move n2
						n2 = pCurrTree->GetParent(n2);
						nodeNew = n2;
					}
					// save this when n1 != n2
					if( n1 != n2 )
					{
						listPathNodes.insert( nodeNew );
					}
				}
				// pop up the last item MRCA
				//listPathNodes.pop_back();
				listPathNodes.erase(  n1  );
            
				// create constraint for the current tree to see if they are really connected or not
                OutputMLvTreeij( outFile, tcurr, i, j );
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    outFile << " + ";
                    OutputTki( outFile, tcurr, *it );
                    outFile << endl;
                }
                outFile << " >= 1\n";

                /*  do we need the following? yes */
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    OutputMLvTreeij( outFile, tcurr, i, j );
                    outFile << " + ";
                    OutputTki( outFile, tcurr, *it );
                    outFile << " <= 1\n";
                }

			}
		}
	}
#endif

	// now use it to enforce pair of nodes
	// enforce connectivity
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
        const MarginalTree *pCurrTree = &listTreeUse[t];

        for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
        {
            for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
            {
				// get MRCA of two leaves
				//int mrca = pCurrTree->GetMRCA(i, j);
				//// two leaves are connected if both connects to MRCA
                //OutputMLvCommonij( outFile, i, j );
                //outFile << " - ";
				//OutputMkij( outFile, t, i, mrca );
                //outFile << " - ";
				//OutputMkij( outFile, t, j, mrca );
				//outFile << ">=-1\n";

                //OutputMLvCommonij( outFile, i, j );
                //outFile << " - ";
				//OutputMkij( outFile, t, i, mrca );
				//outFile << "<=0\n";

                //OutputMLvCommonij( outFile, i, j );
                //outFile << " - ";
				//OutputMkij( outFile, t, j, mrca );
				//outFile << "<=0\n";
			}
		}
	}


//#if 0
	// First ensure C,2,i and C,3,i cut into 3MAF
	// YW: question is whether we can still just refer to T0 and if they match with T0 then they should certainly
	// match each other
	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		//int t1 = 0, t2 = 2;
		//if( t == 2 )
		//{
		//	t1 = 0; 
		//	t2 = 1;
		//}
		// ensure all left-over triples are compatible
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				for(int k=j+1; k< listTreeUse[t].GetNumLeaves(); ++k)
				{
					// enforce branch cut if one triple does not match
					// YW: now I believe only one of the following (say (i,j) and (j,k) are needed
					if( treesTripleState[t][i][j][k] != treesTripleState[0][i][j][k] )
					//	treesTripleState[t][i][j][k] != treesTripleState[t2][i][j][k]  )
					{
						//OutputMLvCommonij(outFile, i, j);
						////OutputMkij( outFile, t, i, j );
						//outFile << " + ";
						//OutputMLvCommonij( outFile, i, k);
						////OutputMkij( outFile, t, i, k );
						//outFile << " <= 1\n";
					}

				}
			}
		}
	}

#if 0
	// now ensure the cut component has no overlap by considering all pairwise cut-off against T0
	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				pair<int,int> pp1(i,j);
				for(int p=i+1; p< listTreeUse[t].GetNumLeaves(); ++p)
				{
					// make sure p <>i or j
					if(  p == j )
					{
						continue;
					}
					for(int q = p+1; q < listTreeUse[t].GetNumLeaves(); ++q)
					{
						// make sure q is unique twoo
						if(  q == j )
						{
							continue;
						}
						pair<int,int> pp2(p,q);
						pair< pair<int,int>, pair<int,int> > pp(pp1,pp2);

						// 
						if( mapNodePairPathIntersectInTrees[t][pp] == false &&
							mapNodePairPathIntersectInTrees[0][pp] == true)
						{
							//
							OutputMLvCommonij( outFile, i, j);
							//OutputMkij( outFile, t, i, j );
							outFile << " + ";
							OutputMLvCommonij( outFile, p, q);
							//OutputMkij( outFile, t, p, q );
							outFile << " <= 1\n";
						}

					}
				}
			}
		}
	
	}
#endif
//#endif



//#if 0
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
		{
			// only cut edges can be count
			//OutputCki( outFile, tcurr, i );
			//outFile << "- ";
			//OutputTki( outFile, tcurr, i);
			//outFile << ">= 0\n";
		}
	}

	// fowarding of one forest must be the same for all leaves under the same f-tree
	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		// get left and right desc
		for(int tprev = 0; tprev < t; ++tprev)
		{
			for( int i= 0; i< listTreeUse[t].GetNumLeaves(); ++i  )
			{
				for( int j= i+1; j< listTreeUse[t].GetNumLeaves(); ++j  )
				{
					// if ML,i,j = 1 then Flv,t,t1,i = Flv,t,t1,j. That is, F1 + 1 >= F2 + ML and the other way
					//OutputFLvk12i( outFile, t, tprev, i);
					//outFile << " - ";
					//OutputFLvk12i( outFile, t, tprev, j);
					//outFile << " - ";
					//// YW: 020209: stronger constraints: if no T-cuts separate the pair, they have same forwarding
					//OutputMLvCommonij( outFile, i, j);
					//outFile << " >= -1\n";

					//OutputFLvk12i( outFile, t, tprev, j);
					//outFile << " - ";
					//OutputFLvk12i( outFile, t, tprev, i);
					//outFile << " - ";
					//OutputMLvCommonij( outFile, i, j);
					//outFile << " >= -1\n";

				}
			}
		}
	}
	// if a forest is not cut, then it must follow some previous tree
	// each leaf's forest got cut at least once. Otherwise, there should be no such f-tree
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[0].GetNumLeaves(); ++i )
		{
			OutputRKi( outFile, tcurr, i);
			for(int tprev=0; tprev<tcurr; ++tprev)
			{
				outFile << " + \n";
				OutputFLvk12i( outFile, tcurr, tprev, i);
			}
			outFile << ">= 1\n";
		}
	}
#if 0
	// each branch can only follow at most one previous tree
	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		// get left and right desc
		for( int i= 0; i< listTreeUse[t].GetNumLeaves(); ++i  )
		{
			for(int tprev = 0; tprev < t; ++tprev)
			{
				OutputFLvk12i( outFile, t, tprev, i);
				if( tprev < t-1)
				{
					outFile << " + ";
				}
			}
			outFile << " <=1\n";
		}
	}
#endif
#if 0
	// each leaf's forest got cut at least once. Otherwise, there should be no such f-tree
	for( int i = 0; i< listTreeUse[0].GetNumLeaves(); ++i )
	{
		for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
		{
			OutputRKi( outFile, tcurr, i);
			if( tcurr <(int)listTreeUse.size()-1 )
			{
				outFile << " + ";
			}
		}
		outFile << ">= 1\n";
	}
#endif	
	// ensure if Rki =1 then its corresponding f-tree root has a T-cut
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
		{
			int pi = i;
			while( pi>= 0)
			{
				// if Rki=1 and Rki,pi = 1, then T,k,pi = 1
				OutputRKi( outFile, tcurr, i);
				outFile << " + ";
				OutputRKij(outFile, tcurr, i, pi );
				outFile << " - ";
				OutputTki( outFile, tcurr, pi );
				outFile << " <=1\n";

				// similary, if Tki=1 in this case, then Rki=1
				OutputRKi( outFile, tcurr, i);
				outFile << " - ";
				OutputRKij(outFile, tcurr, i, pi );
				outFile << " - ";
				OutputTki( outFile, tcurr, pi );
				outFile << " >=-1\n";


				// 
				pi = listTreeUse[tcurr].GetParent(pi);
			}
		}
	}
	// if any forwarding is 1, then t-cut for this tree is dis-allowed?
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
		{
			for(int tprev=0; tprev <tcurr; ++tprev)
			{
				OutputRKi(outFile, tcurr, i);
				outFile << " + ";
				OutputFLvk12i( outFile, tcurr, tprev, i);
				outFile << "<= 1\n";
			}
		}
	}

	// if Rki=1, then none of the forwarding is allowed?
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
		{
			OutputRKi(outFile, tcurr, i);
			for(int tprev=0; tprev <tcurr; ++tprev)
			{
				outFile << " + ";
				OutputFLvk12i( outFile, tcurr, tprev, i);
			}
			outFile << ">= 1\n";

		}
	}

	// enforce transitive
	for( int i = 0; i< listTreeUse[0].GetNumLeaves(); ++i )
	{
		for(int tcurr=2; tcurr<(int)listTreeUse.size(); ++tcurr)
		{
			for(int t2=0; t2<tcurr; ++t2 )
			{
				for(int t3 = 0; t3 <t2; ++t3)
				{
					OutputFLvk12i( outFile, tcurr, t2, i);
					outFile << " + ";
					OutputFLvk12i( outFile, t2, t3, i);
					outFile << " - ";
					OutputFLvk12i( outFile, tcurr, t3, i);
					outFile << "<= 1\n";

					// also, if F13=1 and F23=1 then F12=1
					OutputFLvk12i( outFile, tcurr, t3, i);
					outFile << " + ";
					OutputFLvk12i( outFile, t2, t3, i);
					outFile << " - ";
					OutputFLvk12i( outFile, tcurr, t2, i);
					outFile << "<= 1\n";
					
				}
			}
		}
	}

//#endif

//#if 0
	// for each forest created by C cuts, at least one must be cut by T-cuts
	// R2,k,i,j = 1 if leaf i's forest root is node j, 0 otherwise in tree k
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves(); ++i  )
		{
			// Lvki = 1 iff for some j, Lvkij = 1 and Tk,j=1 if not root
			// if j is root, then by default it is satisified
			// Lvki =0 iff for some j, Lvkij=1 and Tk,j = 0
			// has been done already, see above
			//if( t > 0 )
			//{
			//	for(int ianc =0; ianc < (int)mapLeafAncestors[t][i].size()-1; ++ianc)
			//	{
			//		OutputRKi(outFile, t, i);
			///		outFile << " - ";
			//		OutputRKij(outFile, t, i, mapLeafAncestors[t][i][ianc] );
			//		outFile << " - ";
			//		OutputTki(outFile, t, i);
			//		outFile <<  ">=-1"  << endl;

					
			//		OutputRKi(outFile, t, i);
			//		outFile << " + ";
			//		OutputRKij(outFile, t, i, mapLeafAncestors[t][i][ianc] );
			//		outFile << " - ";
			//		OutputTki(outFile, t, i);
			//		outFile <<  "<=1"  << endl;
			//	}
			//}

			
			for(int ianc =0; ianc < (int)mapLeafAncestors[t][i].size(); ++ianc)
			{
				// Lv,ki,i,j = 1 iff nodes i and j are connected and C,k,j = 1 (if j is not root)
				// if j is root, then the C condition is dropped
				OutputRKij(outFile, t, i, mapLeafAncestors[t][i][ianc] );
				outFile << " - ";
				OutputMkij(outFile, t, i, mapLeafAncestors[t][i][ianc] );
				if( ianc < (int)mapLeafAncestors[t][i].size()-1 )
				{
					outFile << " - ";
					OutputTki(outFile, t, mapLeafAncestors[t][i][ianc]  );
					outFile << " >= -1" <<  endl;
				}
				else
				{
					outFile << " >= 0\n";
				}

				//OutputRKij(outFile, t, i, mapLeafAncestors[t][i][ianc] );
				//outFile << " - ";
				//OutputMkij(outFile, t, i, mapLeafAncestors[t][i][ianc] );
				//outFile << " <= 0\n";

				if( ianc < (int)mapLeafAncestors[t][i].size()-1 )
				{
					OutputRKij(outFile, t, i, mapLeafAncestors[t][i][ianc] );
					outFile << " - ";
					OutputTki(outFile, t, mapLeafAncestors[t][i][ianc]  );
					outFile << " <= 0" <<  endl;
				}

			}
		}
	}
//#endif

	// for each internal node, ensure not all its two descendents are cut
	// this way, each way of connection is fixed to be one direction
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		for( int i= listTreeUse[t].GetNumLeaves(); i< listTreeUse[t].GetTotNodesNum(); ++i  )
		{
			// get left and right desc
			int ld = listTreeUse[t].GetLeftDescendant(i);
			int rd = listTreeUse[t].GetRightDescendant(i);
			OutputTki(outFile, t, ld);
			outFile << " + ";
			OutputTki(outFile, t, rd);
			outFile << " <= 1\n";
		}
	}

	// consider all possible triples a,b,c. Test whether this triple can belong to a common
	// subtree by merging two f-trees
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev <tcurr; ++tprev)
		{
			for(int a=0; a<listTreeUse[tcurr].GetNumLeaves(); ++a)
			{
				for(int b=a+1; b<listTreeUse[tcurr].GetNumLeaves(); ++b)
				{
					for(int c=b+1; c<listTreeUse[tcurr].GetNumLeaves(); ++c)
					{
						// triples a,b,c: if same in two positions, skip it
						if( treesTripleState[tcurr][a][b][c] == treesTripleState[tprev][a][b][c] )
						{
							// skip
							continue;
						}

						// convert to type 1
						int xa=a, xb=b, xc=c;
						if(  treesTripleState[tcurr][a][b][c] == 2 )
						{
							// 
							xa = b;
							xb = c;
							xc = a;
						}
						else if( treesTripleState[tcurr][a][b][c] == 3 )
						{
							xa = a;
							xb = c;
							xc = b;
						}

						// first possiblity, xa or xb is single and xc is attached to the other
						int mrcaab = listTreeUse[tcurr].GetMRCA(xa,xb);
						int ldmrca = listTreeUse[tcurr].GetLeftDescendant(mrcaab);
						int rdmrca = listTreeUse[tcurr].GetRightDescendant(mrcaab);
						if( listTreeUse[tcurr].IsNodeUnder(xa, ldmrca) == false )
						{
							int tmp = ldmrca;
							ldmrca = rdmrca;
							rdmrca = tmp;
						}

						// in this case, we want the other pair be connected: OutputMLvCommonij==1
						// and ldmrca is root of xa: OutputRKij = 1, then, OutputFLvk12i = 0
						//OutputFLvk12i(outFile, tcurr, tprev, xa);
						//outFile << " + ";
						//OutputMLvCommonij(outFile, xb, xc);
						//outFile << " + ";
						//OutputRKij(outFile, tcurr, xa, ldmrca);
						//outFile << "<= 2\n";

						//OutputFLvk12i(outFile, tcurr, tprev, xb);
						//outFile << " + ";
						//OutputMLvCommonij(outFile, xa, xc);
						//outFile << " + ";
						//OutputRKij(outFile, tcurr, xb, rdmrca);
						//outFile << "<= 2\n";

						// for the third type, need to find the root of xa and xb, which is MRCA of both
						int mrcatot = listTreeUse[tcurr].GetMRCA(mrcaab,xc);
						int ances = mrcatot;
						while( ances >= 0)
						{
							// figure ot which node connect xc to the main branch
							int xldmrca = listTreeUse[tcurr].GetLeftDescendant(mrcatot);
							int xrdmrca = listTreeUse[tcurr].GetRightDescendant(mrcatot);
							int xduse = xldmrca;
							int xduseab = xrdmrca;
							if(listTreeUse[tcurr].IsNodeUnder(xc, xduse) == false )
							{
								xduse = xrdmrca;
								xduseab = xldmrca;
							}

							// root for xa and xa and xb are connected
							//OutputFLvk12i(outFile, tcurr, tprev, xc);
							//outFile << " + ";
							//OutputMLvCommonij(outFile, xa, xb);
							//outFile << " + ";
							//OutputRKij(outFile, tcurr, xa, ances);
							//outFile << " + ";
							//OutputRKij(outFile, tcurr, xc, xduse);
							//outFile << "<= 3\n";

							// or it could be xc is rooted at ances as well, and subtree with xa and xb is connected to xc
							//OutputFLvk12i(outFile, tcurr, tprev, xa);
							//outFile << " + ";
							//OutputMLvCommonij(outFile, xa, xb);
							//outFile << " + ";
							//OutputRKij(outFile, tcurr, xc, ances);
							//outFile << " + ";
							//OutputRKij(outFile, tcurr, xa, xduseab);
							//outFile << "<= 3\n";

							// move up
							ances = listTreeUse[tcurr].GetParent(ances);
						}

//#if 0
						//
						// now consider a triple containing three parts
						// root is mrcatot and up
						ances = mrcatot;
						while( ances >= 0)
						{
							// figure ot which node connect xc to the main branch
							int xldmrca = listTreeUse[tcurr].GetLeftDescendant(mrcatot);
							int xrdmrca = listTreeUse[tcurr].GetRightDescendant(mrcatot);
							int xdusec = xldmrca;
							int xduseab = xrdmrca;
							if(listTreeUse[tcurr].IsNodeUnder(xc, xdusec) == false )
							{
								xdusec = xrdmrca;
								xduseab = xldmrca;
							}

							// root for xa and xa and xb are connected
							// case 1: b and c connects to a
							OutputFLvk12i(outFile, tcurr, tprev, xb);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, xc);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xa, ances);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xb, rdmrca);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xc, xdusec);
							outFile << "<= 4\n";

							// case 2: a and c connects to b
							OutputFLvk12i(outFile, tcurr, tprev, xa);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, xc);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xb, ances);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xa, ldmrca);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xc, xdusec);
							outFile << "<= 4\n";

							// case 3: a and b connects to c (and a connects to c directly)
							OutputFLvk12i(outFile, tcurr, tprev, xa);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, xb);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xc, ances);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xa, xduseab);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xb, rdmrca);
							outFile << "<= 4\n";

							// case 4: a and b connects to c (and b connects to c directly)
							OutputFLvk12i(outFile, tcurr, tprev, xa);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, xb);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xc, ances);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xb, xduseab);
							outFile << " + ";
							OutputRKij(outFile, tcurr, xa, ldmrca);
							outFile << "<= 4\n";


							// move up
							ances = listTreeUse[tcurr].GetParent(ances);
						}
//#endif

					}

				}
			}
		}
	}
#if 0
	// enforce pairwise ancestry info
	// 
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i= 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i  )
		{
			for( int j= 0; j< listTreeUse[tcurr].GetNumLeaves(); ++j  )
			{
				if( i == j)
				{
					continue;
				}
				int mrca = listTreeUse[tcurr].GetMRCA(i,j);
				int ldm = listTreeUse[tcurr].GetLeftDescendant( mrca );
				int rdm = listTreeUse[tcurr].GetRightDescendant( mrca );
				int lduse = ldm;
				if(listTreeUse[tcurr].IsNodeUnder(i, lduse) == false )
				{
					lduse = rdm;
				}
				int na = mrca;
				while( na >= 0)
				{
					OutputAkij(outFile, tcurr, i, j);
					outFile << " - ";
					OutputRKij(outFile, tcurr, j, na);
					outFile << " - ";
					OutputRKij(outFile, tcurr, i, lduse);
					outFile << " + ";
					OutputRKi(outFile, tcurr, i);
					outFile << ">= -1" << endl; 

					//
					na = listTreeUse[tcurr].GetParent( na );
				}

				// how to enforce the other direction? TBD!!!!!!!!!!!!!!!

			}
		}
	}
#endif
	// enforce consistency of pairwise ancestry between two trees
	// A1 + F <= A2+1, and A2+F<=A1+1
	// Question: how to handle the first tree????
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i= 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i  )
			{
				for( int j= 0; j< listTreeUse[tcurr].GetNumLeaves(); ++j  )
				{
					if( i == j)
					{
						continue;
					}
//cout << "Wrete out one ancestry info.\n";
					// can not follow, if f-trees have different ancestry relations
					// 
					int mrca = listTreeUse[tcurr].GetMRCA(i,j);
					int ldm = listTreeUse[tcurr].GetLeftDescendant( mrca );
					int rdm = listTreeUse[tcurr].GetRightDescendant( mrca );
					int lduse = ldm;
					if(listTreeUse[tcurr].IsNodeUnder(i, lduse) == false )
					{
						lduse = rdm;
					}
					int mrca2 = listTreeUse[tprev].GetMRCA(i,j);
					int ldm2 = listTreeUse[tprev].GetLeftDescendant( mrca2 );
					int rdm2 = listTreeUse[tprev].GetRightDescendant( mrca2 );
					int lduse2 = ldm2;
					if(listTreeUse[tprev].IsNodeUnder(j, lduse2) == false )
					{
						lduse2 = rdm2;
					}

					// try the ancestor nodes
					int na = mrca;
					while( na >= 0)
					{
						// first, if pb is on mrca2 and up, then clearly F=0
						int nb = mrca2;
						while( nb >= 0)
						{
							OutputFLvk12i( outFile, tcurr, tprev, i);
							outFile << " + ";
							OutputRKij(outFile, tcurr, j, na);
							outFile << " + ";
							OutputRKij(outFile, tcurr, i, lduse);
							//outFile << " + ";
							//OutputRKi(outFile, tcurr, i);
							outFile << " + ";
							OutputRKij(outFile, tprev, i, nb);
							outFile << "<= 3" << endl; 

							//
							nb = listTreeUse[tprev].GetParent( nb );
						}



						// or if pa is below mrca2
						nb = i;
						while( nb != mrca2 )
						{
							if(  listTreeUse[tprev].GetParent( nb ) == mrca2 )
							{
								break;
							}

							// if rooting is correct for both, then we have a problem!

							OutputFLvk12i( outFile, tcurr, tprev, i);
							outFile << " + ";
							OutputRKij(outFile, tcurr, j, na);
							outFile << " + ";
							OutputRKij(outFile, tcurr, i, lduse);
							//outFile << " + ";
							//OutputRKi(outFile, tcurr, i);
							outFile << " + ";
							OutputRKij(outFile, tprev, i, nb);
							outFile << "<= 3" << endl; 

							//
							nb = listTreeUse[tprev].GetParent( nb );
						}

						//
						na = listTreeUse[tcurr].GetParent( na );
					}


				}
			}
		}
	}
//#if 0
	// moreover, if the attachment relation is different, then dis-allow forwarding
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i= 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i  )
			{
				for( int j= 0; j< listTreeUse[tcurr].GetNumLeaves(); ++j  )
				{
					if( i == j)
					{
						continue;
					}
					for( int k= 0; k< listTreeUse[tcurr].GetNumLeaves(); ++k  )
					{
						if( k == i || k == j)
						{
							continue;
						}

						// now if j and k are in different component (as told by M variable)
						// and also, i is connected to j in T but i to k in T2, then forwarding is disabled
						int mrca = listTreeUse[tcurr].GetMRCA(i,j);
						int ldm = listTreeUse[tcurr].GetLeftDescendant( mrca );
						int rdm = listTreeUse[tcurr].GetRightDescendant( mrca );
						int lduse = ldm;
						if(listTreeUse[tcurr].IsNodeUnder(i, lduse) == false )
						{
							lduse = rdm;
						}
						int mrca2 = listTreeUse[tprev].GetMRCA(i,k);
						int ldm2 = listTreeUse[tprev].GetLeftDescendant( mrca2 );
						int rdm2 = listTreeUse[tprev].GetRightDescendant( mrca2 );
						int lduse2 = ldm2;
						if(listTreeUse[tprev].IsNodeUnder(i, lduse2) == false )
						{
							lduse2 = rdm2;
						}

						// try the ancestor nodes
						int na = mrca;
						while( na >= 0)
						{
							int nb = mrca2;
							while( nb >= 0)
							{
								// if rooting is correct for both, then we have a problem!

								//OutputFLvk12i( outFile, tcurr, tprev, i);
								//outFile << " + ";
								//OutputRKij(outFile, tcurr, j, na);
								//outFile << " + ";
								//OutputRKij(outFile, tcurr, i, lduse);
								//outFile << " + ";
								//OutputRKij(outFile, tprev, k, nb);
								//outFile << " + ";
								//OutputRKij(outFile, tprev, i, lduse2);
								//outFile << " - ";
								//OutputMLvCommonij( outFile, j, k);
								//outFile << "<= 4" << endl; 

								//
								nb = listTreeUse[tprev].GetParent( nb );
							}

							//
							na = listTreeUse[tcurr].GetParent( na );
						}




					}
				}
			}
		}
	}
//#endif

	// one more condition: if to make a follow Tk2 and b is on the path
	// then a and b should follow the same tree
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i= 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i  )
			{
				for( int j= 0; j< listTreeUse[tcurr].GetNumLeaves(); ++j  )
				{
					if( i == j)
					{
						continue;
					}
//cout << "Wrete out one ancestry info.\n";
					// can not follow, if f-trees have different ancestry relations
					// 
					int mrca = listTreeUse[tprev].GetMRCA(i,j);
					int ldm = listTreeUse[tprev].GetLeftDescendant( mrca );
					int rdm = listTreeUse[tprev].GetRightDescendant( mrca );
					int lduse = ldm;
					if(listTreeUse[tcurr].IsNodeUnder(j, lduse) == false )
					{
						lduse = rdm;
					}

					// try the ancestor nodes
					int na = mrca;
					while( na >= 0)
					{
						// first, if pb is on mrca2 and up, then clearly F=0
						OutputFLvk12i( outFile, tcurr, tprev, j);
						outFile << " - ";
						OutputFLvk12i( outFile, tcurr, tprev, i);
						outFile << " - ";
						OutputRKij(outFile, tprev, i, na);
						outFile << " - ";
						OutputRKij(outFile, tprev, j, lduse);
						//outFile << " + ";
						//OutputRKi(outFile, tcurr, i);
						if( tprev > 0 )
						{
							outFile << " + ";
							OutputTki(outFile, tprev, lduse);
							outFile << ">= -3" << endl; 
						}
						else
						{
							outFile << ">= -2" << endl; 
						}
						//
						na = listTreeUse[tprev].GetParent( na );
					}


				}
			}
		}
	}

#if 0
	// for any pair of leaves, a and b, and also leaves (c,d)
	// if (a,b) intersects (c,d), and we want to 
	// connect (a,b) by following, then (c,d) can not be free of cuts (what cuts: C or T?) Not sure!!!
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev <tcurr; ++tprev)
		{
			for(int a=0; a<listTreeUse[tcurr].GetNumLeaves(); ++a)
			{
				for(int b=0; b<listTreeUse[tcurr].GetNumLeaves(); ++b)
				{
					if( a == b )
					{
						continue;
					}
				}
			}
		}
	}
#endif

    // variables
    outFile << "\nBinary " << endl;
	// each tree (including the first one)
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		//for( int i = 0; i< listTreeUse[t].GetTotNodesNum(); ++i )
		//{
		//	OutputCki( outFile, t, i );
		//	outFile << endl;
		//}
		// mkij
        // output m,k,i,js
        for( set<pair<int,int> > :: iterator it = listPairNodesConstraint[t].begin(); 
            it != listPairNodesConstraint[t].end(); ++it )
        {
            pair<int,int> pp = *it;
            OutputMkij( outFile, t, pp.first, pp.second );
            outFile << endl;
        }
	}
	// R,k,i,j = 1 if leaf i's forest root is node j, 0 otherwise in tree k
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves(); ++i  )
		{
			if( t > 0 )
			{
				OutputRKi(outFile, t, i);
				outFile << endl;
			}
			for(int ianc =0; ianc < (int)mapLeafAncestors[t][i].size(); ++ianc)
			{
				// 
				OutputRKij(outFile, t, i, mapLeafAncestors[t][i][ianc] );
				outFile << endl;
			}
		}
	}


	for( int i= 0; i< listTreeUse[0].GetNumLeaves(); ++i  )
	{
		for( int j= i+1; j< listTreeUse[0].GetNumLeaves(); ++j  )
		{
			//OutputMLvCommonij( outFile, i, j );
			//outFile << endl;
			//for(int t=1; t<(int)listTreeUse.size(); ++t)
			//{
				// whether the pair of leaves are really cut
			//	OutputMLvTreeij(outFile, t, i, j);
			//	outFile << endl;
			//}
		}
	}
	// T values and related
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
		{
			OutputTki( outFile, tcurr, i );
			outFile << endl;
		}
	}
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
		{
			// following variable
			for(int tprev=0; tprev<tcurr; ++tprev)
			{
				OutputFLvk12i( outFile, tcurr, tprev, i);
				outFile << endl;
			}
		}
	}
#if 0
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i= 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i  )
		{
			for( int j= 0; j< listTreeUse[tcurr].GetNumLeaves(); ++j  )
			{
				if( i == j)
				{
					continue;
				}
				OutputAkij(outFile, tcurr, i, j);
				outFile << endl;
			}
		}
	}
#endif

    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();
cout << "Constrains finished\n";
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
// hybridize multiple trees but not neccessarily optimally
 
void OutputILPHybridUBMultiTrees(const char* fileName, vector<MarginalTree *> &listTreeOrig)
{
	YW_ASSERT_INFO(listTreeOrig.size() >=3, "Wrong number of trees");
cout << "Inside OutputILPHybridUBMultiTrees\n";
	for(int t=1; t< (int)listTreeOrig.size(); ++t)
	{
		YW_ASSERT_INFO( listTreeOrig[0]->GetTotNodesNum() == listTreeOrig[t]->GetTotNodesNum(), "mismatch" );
	}

//cout << "OutputILPMaxGoodAgreeForest: treeOrig1 = ";
//treeOrig1.Dump();
//cout << "OutputILPMaxGoodAgreeForest: tree2 = ";
//treeOrig2.Dump();

	vector<MarginalTree> listTreeUse;
	for(int t=0; t<(int)listTreeOrig.size(); ++t)
	{
		MarginalTree  tree1Reduced = *listTreeOrig[t];

		// buildup the descendent info
		tree1Reduced.BuildDescendantInfo();
		listTreeUse.push_back( tree1Reduced );
	}

	// collect all triples and their shape
	// in particular, for ordered triples i,j,k (i<j<k)
	// (i,j,k) = 1 if (i,j),k
	// (i,j,k) = 2 if i,(j,k)
	// (i,j,k) = 3 if(i,k),j
	int nLeaveNum = listTreeUse[0].GetNumLeaves();
//cout << "num leaves = " << nLeaveNum << endl;

    //vector MarginalTree *ptrTrees[4];
    //ptrTrees[0] = &tree1Reduced;
    //ptrTrees[1] = &tree2Reduced;
    //ptrTrees[2] = &tree3Reduced;
    //ptrTrees[3] = &tree4Reduced;

	// this keep track of the type of triples we have in the component
	vector< vector< vector<int> > >  treesTripleState[ listTreeUse.size() ];
	for(int t=0; t<(int)listTreeUse.size(); t++)
	{
		treesTripleState[t].resize( nLeaveNum );
		for(int i=0; i<nLeaveNum; ++i)
		{
			treesTripleState[t][i].resize( nLeaveNum );
			for(int j=0; j<nLeaveNum; ++j)
			{
				treesTripleState[t][i][j].resize( nLeaveNum );
				for(int k=0; k<nLeaveNum; ++k)
				{
					treesTripleState[t][i][j][k] = 0;
				}
			}
		}
	}
	for(int t=0; t< (int)listTreeUse.size(); t++)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				for(int k=j+1; k< listTreeUse[t].GetNumLeaves(); ++k)
				{
					// is these have different triples on T1 and T2?
					// we do this by getting MRCA for all pairs of MRCAs
					int mrcaij1 = listTreeUse[t].GetMRCA( i, j );
					int mrcajk1 = listTreeUse[t].GetMRCA( j, k );
					int mrcaik1 = listTreeUse[t].GetMRCA( i, k );

					// now just test exhustively
					if( mrcaij1 == mrcajk1 )
					{
						treesTripleState[t][i][j][k] = 3;
					}
					else if( mrcaij1 == mrcaik1 )
					{
						treesTripleState[t][i][j][k] = 2;
					}
					else 
					{
						treesTripleState[t][i][j][k] = 1;
					}

				}
			}
		}
	}

	// this keep track for each tree, which pair intersect with which in the first tree
	map< pair< pair<int,int>, pair<int,int> >, bool > mapNodePairPathIntersectInTrees[ listTreeUse.size() ];
	for(int t=0; t< (int)listTreeUse.size(); ++t)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				pair<int,int> pp1(i,j);
				for(int p=i+1; p< listTreeUse[t].GetNumLeaves(); ++p)
				{
					// make sure p <>i or j
					if(  p == j )
					{
						continue;
					}
					for(int q = p+1; q < listTreeUse[t].GetNumLeaves(); ++q)
					{
						// make sure q is unique twoo
						if(  q == j )
						{
							continue;
						}
						pair<int,int> pp2(p,q);
						pair< pair<int,int>, pair<int,int> > pp(pp1,pp2);

						// now we only worry about two disjoint path (i,j) and (p,q)
						bool fInt =  listTreeUse[t].AreTwoPathsDisjoint( i, j, p, q );
						if( fInt == true )
						{
							fInt = false;
						}
						else
						{
							fInt = true;
						}
//if( fInt == true )
//cout << "Tree " << t << ", [" << i << ", " << j << "] overlaps [" << p << ", " << q << "]\n";
//else
//cout << "Tree " << t << ", [" << i << ", " << j << "] disjoint [" << p << ", " << q << "]\n";
						mapNodePairPathIntersectInTrees[t].insert( map< pair< pair<int,int>, pair<int,int> >, bool > :: value_type(pp, fInt)  );
					}
				}
			}
		}
	}

    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // first the set of branch cuts (twice as much as what in one tree
	for(int t=1; t< (int)listTreeUse.size(); ++t)
	{
		for( int i = 0; i< listTreeUse[t].GetTotNodesNum()-1; ++i )
		{
			//if( t == 1 )
			//{
			//	OutputCki(outFile, t, i);
			//	outFile << "+\n ";
			//}
			//else
			{

				OutputTki(outFile, t, i);
				if( t < (int) listTreeUse.size()-1 || i < listTreeUse[t].GetTotNodesNum()-2 )
				{
					outFile << "\n+ ";
				}
			}
		}
	}



    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;


    // now enforce m,i
	//for(int t=1; t<(int)listTreeUse.size(); ++t)
	//{
	//	OutputCki( outFile, t,  listTreeUse[t].GetTotNodesNum()-1 );
	//	outFile << " = 0 \n";
	//}

	// enforce same number of edge cuts in two trees
	//for(int t=2; t<(int)listTreeUse.size(); ++t)
	//{
	//	for(int i=0; i<listTreeUse[1].GetTotNodesNum(); ++i)
	//	{
	//		OutputCki(outFile, 1, i);
	//		if( i < listTreeUse[1].GetTotNodesNum()-1 )
	//		{
	//			outFile << " + \n";
	//		}
	//	}
	//	for(int i=0; i<listTreeUse[t].GetTotNodesNum(); ++i)
	//	{
	//		outFile << "\n - ";
	//		OutputCki(outFile, t, i);
	//	}
	//	outFile << " = 0\n";
	//}

	// enforce connectivity through all pairs of node conectivity
    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
//    set< pair<int,int> > listPairNodesConstraint[ listTreeUse.size() ];
//	map< int, vector<int> > mapLeafAncestors[ listTreeUse.size() ];



	// now use it to enforce pair of nodes
	// enforce connectivity
	map<pair<int,int>, set<int> > mapListPairNodesPath[listTreeUse.size()];
	for(int tcurr = 1; tcurr < (int)listTreeUse.size(); ++tcurr)
	{
		// is leaves are really connected or not

		// enforce for each previous tree
		const MarginalTree *pCurrTree = &listTreeUse[tcurr];

		for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
			{
				// first we need to find MRCA of i,j. 
				// note that we actually want to exluce MRCA, but include i,j!
				set<int> listPathNodes;
				int n1=i, n2 = j;
				listPathNodes.insert(i);
				listPathNodes.insert(j);
				while( n1 != n2 )
				{
					// we alternatively move up, depend on which one is smaller
					int nodeNew;
					if( n1 < n2  )
					{
						// move n1
						n1 = pCurrTree->GetParent(n1);
						nodeNew = n1;
					}
					else
					{
						// move n2
						n2 = pCurrTree->GetParent(n2);
						nodeNew = n2;
					}
					// save this when n1 != n2
					if( n1 != n2 )
					{
						listPathNodes.insert( nodeNew );
					}
				}
				// pop up the last item MRCA
				//listPathNodes.pop_back();
				listPathNodes.erase(  n1  );

				// save it
				pair<int,int> pp(i,j), pp2(j,i);
				mapListPairNodesPath[tcurr].insert( map<pair<int,int>, set<int> > :: value_type(pp, listPathNodes)  );
				mapListPairNodesPath[tcurr].insert( map<pair<int,int>, set<int> > :: value_type(pp2, listPathNodes)  );
            
				// create constraint for the current tree to see if they are really connected or not
//#if 0
                OutputMLvTreeij( outFile, tcurr, i, j );
                //OutputMLvCommonij( outFile, i, j );
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    outFile << " + ";
                    OutputTki( outFile, tcurr, *it );
                    outFile << endl;
                }
                outFile << " >= 1\n";
//#endif
//#if 0
                /*  do we need the following? yes */
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    OutputMLvTreeij( outFile, tcurr, i, j );
                //    OutputMLvCommonij( outFile, i, j );
                    outFile << " + ";
                    OutputTki( outFile, tcurr, *it );
                    outFile << " <= 1\n";
                }
//#endif
			}
		}
	}


	//for(int t=0; t<(int)listTreeUse.size(); ++t)
	//{
    //    const MarginalTree *pCurrTree = &listTreeUse[t];

    //    for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
    //    {
    //        for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
    //        {
	//			// get MRCA of two leaves
	//			//int mrca = pCurrTree->GetMRCA(i, j);
	//			//// two leaves are connected if both connects to MRCA
    //            OutputMLvCommonij( outFile, i, j );
    //            outFile << " - ";
	//			OutputMkij( outFile, t, i, mrca );
    //            outFile << " - ";
	//			OutputMkij( outFile, t, j, mrca );
	//			outFile << ">=-1\n";

    //            OutputMLvCommonij( outFile, i, j );
    //            outFile << " - ";
	//			OutputMkij( outFile, t, i, mrca );
	//			outFile << "<=0\n";

    //            OutputMLvCommonij( outFile, i, j );
    //            outFile << " - ";
	//			OutputMkij( outFile, t, j, mrca );
	//			outFile << "<=0\n";
	//		}
	//	}
	//}

#if 0
	///////////////////////////////////////////////////////////////////////////////
	// new idea: introduce cuts so that for novel triples
	// we must cut them
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
		{
			for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
			{
				for( int k = j+1; k< listTreeUse[tcurr].GetNumLeaves(); ++k )
				{
					// see if this triple is incomptible with that of any previous tree
					bool fcont = true;
					for( int tprev = 0; tprev < tcurr; ++tprev )
					{
						if( treesTripleState[tcurr][i][j][k] == treesTripleState[tprev][i][j][k] )
						{
							fcont = false;
						}
					}
					if( fcont == false )
					{
						continue;
					}

					// get all branches along the triple in T
					//pair<int,int> ppij(i,j), ppik(i,k);
					//set<int> listEdgesTot = mapListPairNodesPath[tcurr][ppij];
					//UnionSets(listEdgesTot, mapListPairNodesPath[tcurr][ppik] );
					// 


					// must cut off novel triples
					OutputMLvTreeij(outFile, tcurr, i, j);
					outFile << " + ";
					OutputMLvTreeij(outFile, tcurr, i, k);
					outFile << " <= 1\n ";

				}


			}
		}
	}

	// for two pairs of leaves (i,j) and (p,q), if they disjoint in Ti,
	// and in all previous trees, they intersect, then they can NOT be connected
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
		{
			for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
			{
				for( int p = 0; p< listTreeUse[tcurr].GetNumLeaves(); ++p )
				{
					if( p == i || p == j )
					{
						continue;
					}
					for( int q = p+1; q< listTreeUse[tcurr].GetNumLeaves(); ++q )
					{
						//
						if( q == i || q == j )
						{
							continue;
						}

						// is (i,j) (p,q) disjoint in T and T2?
		                if( listTreeUse[tcurr].AreTwoPathsDisjoint( i, j, p, q ) == false  )
						{
							continue;
						}

						bool fcont = true;
						for( int tprev = 0; tprev < tcurr; ++tprev )
						{
							if( listTreeUse[tprev].AreTwoPathsDisjoint( i, j, p, q ) == true )
							{
								fcont = false;
							}
						}
						if( fcont == false )
						{
							continue;
						}


						// then not all i,j,p,q can be in the same component if 
						// no cuts in between these paths
						OutputMLvTreeij(outFile, tcurr, i, j);
						outFile << " + ";
						OutputMLvTreeij(outFile, tcurr, p, q);
						outFile << " <= 1\n";
					}

				}
			}
		}
	}
#endif

#if 0
	// for incompatible triple, either one of leave is not mapped or there is some t-cuts
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					for( int p = 0; p< listTreeUse[tcurr].GetNumLeaves(); ++p )
					{
						if( p == i || p == j )
						{
							continue;
						}
						for( int q = p+1; q< listTreeUse[tcurr].GetNumLeaves(); ++q )
						{
							//
							if( q == i || q == j )
							{
								continue;
							}

							// is (i,j) (p,q) disjoint in T and T2?
		                    if( listTreeUse[tcurr].AreTwoPathsDisjoint( i, j, p, q ) == false  )
							{
								continue;
							}
		                    if( listTreeUse[tprev].AreTwoPathsDisjoint( i, j, p, q ) == true  )
							{
								continue;
							}

							// then not all i,j,p,q can be in the same component if 
							// no cuts in between these paths
							OutputFLvk12i(outFile, tcurr, tprev, i);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, j);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, p);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, q);
							outFile << " + ";
							OutputMLvTreeij(outFile, tcurr, i, j);
							outFile << " + ";
							OutputMLvTreeij(outFile, tcurr, p, q);

							//pair<int,int> ppij(i,j), pppq(p,q);
							//for( set<int> :: iterator it = mapListPairNodesPath[tcurr][ppij].begin(); it != mapListPairNodesPath[tcurr][ppij].end(); ++it )
							//{
							//	outFile << " -\n";
							//	OutputTki( outFile, tcurr, *it);
							//}
							//for( set<int> :: iterator it = mapListPairNodesPath[tcurr][pppq].begin(); it != mapListPairNodesPath[tcurr][pppq].end(); ++it )
							//{
							//	outFile << " -\n";
							//	OutputTki( outFile, tcurr, *it);
							//}

							outFile << " <= 5\n";
						}

					}
				}
			}
		}
	}
#endif

#if 0
	// YW: 021409. A new thought: for any previous tree
	// if pairs are not disjoint, then it must contain cuts in Ti or it is not connected in Tj
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					for( int p = 0; p< listTreeUse[tcurr].GetNumLeaves(); ++p )
					{
						if( p == i || p == j )
						{
							continue;
						}
						for( int q = p+1; q< listTreeUse[tcurr].GetNumLeaves(); ++q )
						{
							//
							if( q == i || q == j )
							{
								continue;
							}

							// is (i,j) (p,q) disjoint in T and T2?
		                    if( listTreeUse[tcurr].AreTwoPathsDisjoint( i, j, p, q ) == false  )
							{
								continue;
							}
		                    if( listTreeUse[tprev].AreTwoPathsDisjoint( i, j, p, q ) == true  )
							{
								continue;
							}

							// Mlj
							if( tprev >= 1 )
							{
								OutputMLvTreeij(outFile, tcurr, i, j);
								outFile << " + ";
								OutputMLvTreeij(outFile, tcurr, p, q);
								outFile << " + ";
								OutputMLvTreeij(outFile, tprev, i, j);
								outFile << " + ";
								OutputMLvTreeij(outFile, tprev, p, q);
								outFile << " <= 3\n";
							}
							else
							{
								OutputMLvTreeij(outFile, tcurr, i, j);
								outFile << " + ";
								OutputMLvTreeij(outFile, tcurr, p, q);
								outFile << " <= 1\n";
							}
						}

					}
				}
			}
		}
	}
#endif

	// for incompatible triple, either one of leave is not mapped or there is some t-cuts
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					for( int k = j+1; k< listTreeUse[tcurr].GetNumLeaves(); ++k )
					{
						// see if this triple is incomptible with that of a previous tree
						if( treesTripleState[tcurr][i][j][k] == treesTripleState[tprev][i][j][k] )
						{
							continue;
						}

						// get all branches along the triple in T
						pair<int,int> ppij(i,j), ppik(i,k);
						set<int> listEdgesTot = mapListPairNodesPath[tcurr][ppij];
						UnionSets(listEdgesTot, mapListPairNodesPath[tcurr][ppik] );
						// 


						// 
						OutputFLvk12i(outFile, tcurr, tprev, i);
						outFile << " + ";
						OutputFLvk12i(outFile, tcurr, tprev, j);
						outFile << " + ";
						OutputFLvk12i(outFile, tcurr, tprev, k);
						outFile << " + ";
						OutputMLvTreeij(outFile, tcurr, i, j);
						outFile << " + ";
						OutputMLvTreeij(outFile, tcurr, i, k);

						//for( set<int> :: iterator it = listEdgesTot.begin(); it != listEdgesTot.end(); ++it )
						//{
						//	outFile << " -\n";
						//	OutputTki( outFile, tcurr, *it);
						//}
						outFile << " <= 4\n ";

					}


				}
			}
		}
	}

	// enforce no overlapping property
	// for incompatible triple, either one of leave is not mapped or there is some t-cuts
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					for( int p = 0; p< listTreeUse[tcurr].GetNumLeaves(); ++p )
					{
						if( p == i || p == j )
						{
							continue;
						}
						for( int q = p+1; q< listTreeUse[tcurr].GetNumLeaves(); ++q )
						{
							//
							if( q == i || q == j )
							{
								continue;
							}

							// is (i,j) (p,q) disjoint in T and T2?
		                    if( listTreeUse[tcurr].AreTwoPathsDisjoint( i, j, p, q ) == false  )
							{
								continue;
							}
		                    if( listTreeUse[tprev].AreTwoPathsDisjoint( i, j, p, q ) == true  )
							{
								continue;
							}

							// then not all i,j,p,q can be in the same component if 
							// no cuts in between these paths
							OutputFLvk12i(outFile, tcurr, tprev, i);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, j);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, p);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, q);
							outFile << " + ";
							OutputMLvTreeij(outFile, tcurr, i, j);
							outFile << " + ";
							OutputMLvTreeij(outFile, tcurr, p, q);

							//pair<int,int> ppij(i,j), pppq(p,q);
							//for( set<int> :: iterator it = mapListPairNodesPath[tcurr][ppij].begin(); it != mapListPairNodesPath[tcurr][ppij].end(); ++it )
							//{
							//	outFile << " -\n";
							//	OutputTki( outFile, tcurr, *it);
							//}
							//for( set<int> :: iterator it = mapListPairNodesPath[tcurr][pppq].begin(); it != mapListPairNodesPath[tcurr][pppq].end(); ++it )
							//{
							//	outFile << " -\n";
							//	OutputTki( outFile, tcurr, *it);
							//}

							outFile << " <= 5\n";
						}

					}
				}
			}
		}
	}


	// for any forwarding, if a in Ti follows Tj and in Tj, a and b are not cut
	// then b should follow Tj as well
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					// first, if tprev = 0, we use tree T1 instead
					//int tprevuse = tprev;
					//if( tprevuse == 0 )
					//{
						//tprevuse = 1;
					//}

					// MLv,k,i,j = 1 and F,k2,i =1 and F,k2,j = 1, then Mlv,k2,i,j=1
					//??? is this really true???
					//OutputFLvk12i(outFile, tcurr, tprev, i);
					//outFile << " + ";
					//OutputMLvTreeij(outFile, tprevuse, i, j);
					//outFile << " - ";
					//OutputFLvk12i(outFile, tcurr, tprev, j);
					//outFile << " <= 1\n";

					// MLv,k,i,j = 1 and F,k2,i =1 and Mlv,k2,i,j = 1, then F,k2,j=1
					OutputMLvTreeij(outFile, tcurr, i, j);
					outFile << " + ";
					OutputFLvk12i(outFile, tcurr, tprev, i);
					if( tprev > 0 )
					{
						outFile << " + ";
						OutputMLvTreeij(outFile, tprev, i, j);
					}
					outFile << " - ";
					OutputFLvk12i(outFile, tcurr, tprev, j);
					if( tprev > 0 )
					{
						outFile << " <= 2\n";
					}
					else
					{
						outFile << " <= 1\n";
					}
				}
			}
		}
	}

	// for each tree, if a pair of leaves has different following, then there must be a cut in between
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = 0; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					if(j == i )
					{
						continue;
					}

					// first, if tprev = 0, we use tree T1 instead
					//int tprevuse = tprev;
					//if( tprevuse == 0 )
					//{
					//	//tprevuse = 1;
					//}

					// if F,k,k2,i = 1 and F,k,k2,j =0 then Mlv,k,i,j=0
					OutputFLvk12i(outFile, tcurr, tprev, i);
					outFile << " + ";
					OutputMLvTreeij(outFile, tcurr, i, j);
					outFile << " - ";
					OutputFLvk12i(outFile, tcurr, tprev, j);
					outFile << " <= 1\n";

				}
			}
		}
	}

	// 021909: ensure when following from T0 for (i,j), and there is a pair (p,q) follows another tree, 
	// then dis-allow it if they intersect in T0
	for(int tcurr=2; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=1; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					for( int p = 0; p< listTreeUse[tcurr].GetNumLeaves(); ++p )
					{
						if( p == i || p == j )
						{
							continue;
						}
						for( int q = p+1; q< listTreeUse[tcurr].GetNumLeaves(); ++q )
						{
							//
							if( q == i || q == j )
							{
								continue;
							}

							// is (i,j) (p,q) disjoint in T and T2?
		                    if( listTreeUse[tcurr].AreTwoPathsDisjoint( i, j, p, q ) == false  )
							{
								continue;
							}
		                    if( listTreeUse[0].AreTwoPathsDisjoint( i, j, p, q ) == true  )
							{
								continue;
							}

							// then if (i,j) and (p,q) are connected in current tree
							// and (i,j) follows T0, and (p,q) follows prev, then
							// this should be disabled
							OutputFLvk12i(outFile, tcurr, 0, i);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, 0, j);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, p);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, q);
							outFile << " + ";
							OutputMLvTreeij(outFile, tcurr, i, j);
							outFile << " + ";
							OutputMLvTreeij(outFile, tcurr, p, q);
							outFile << " <= 5\n";
						}

					}
				}
			}
		}
	}





#if 0
	// First ensure C,2,i and C,3,i cut into 3MAF
	// YW: question is whether we can still just refer to T0 and if they match with T0 then they should certainly
	// match each other
	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		// ensure all left-over triples are compatible
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				for(int k=j+1; k< listTreeUse[t].GetNumLeaves(); ++k)
				{
					// enforce branch cut if one triple does not match
					// YW: now I believe only one of the following (say (i,j) and (j,k) are needed
					if( treesTripleState[t][i][j][k] != treesTripleState[0][i][j][k] )
					//	treesTripleState[t][i][j][k] != treesTripleState[t2][i][j][k]  )
					{
						OutputMLvCommonij(outFile, i, j);
						//OutputMkij( outFile, t, i, j );
						outFile << " + ";
						OutputMLvCommonij( outFile, i, k);
						//OutputMkij( outFile, t, i, k );
						outFile << " <= 1\n";
					}

				}
			}
		}
	}
#endif

#if 0


//#if 0
	//for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	//{
	//	for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
	//	{
	//		// only cut edges can be count
	//		OutputCki( outFile, tcurr, i );
	//		outFile << "- ";
	//		OutputTki( outFile, tcurr, i);
	//		outFile << ">= 0\n";
	//	}
	//}

//#if 0
	// now enforce forwarding: the following says 
	// if there is no T-cuts between two nodes, the two must be assigned to the same previous tree
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					OutputFLvk12i(outFile, tcurr, tprev, i);
					// if there is no T-cuts, mapping must be the same????
					pair<int,int> pp(i,j);
					//for( set<int> :: iterator it = mapListPairNodesPath[tcurr][pp].begin(); it != mapListPairNodesPath[tcurr][pp].end(); ++it )
					//{
					//	outFile << " + \n";
					//	// 
					//	OutputTki(outFile, tcurr, *it);
					//}
					outFile << " - ";
					OutputMLvTreeij(outFile, tcurr, i, j);
					outFile << " - ";
					OutputFLvk12i(outFile, tcurr, tprev, j);
					outFile << " >=-1\n";

					OutputFLvk12i(outFile, tcurr, tprev, j);
					// if there is no T-cuts, mapping must be the same????
					//for( set<int> :: iterator it = mapListPairNodesPath[tcurr][pp].begin(); it != mapListPairNodesPath[tcurr][pp].end(); ++it )
					//{
					//	outFile << " + \n";
					//	// 
					//	OutputTki(outFile, tcurr, *it);
					//}
					outFile << " - ";
					OutputMLvTreeij(outFile, tcurr, i, j);
					outFile << " - ";
					OutputFLvk12i(outFile, tcurr, tprev, i);
					outFile << " >=-1\n";

				}
			}
		}
	}
//#endif

	// enforce no overlapping property
	// for incompatible triple, either one of leave is not mapped or there is some t-cuts
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					for( int p = 0; p< listTreeUse[tcurr].GetNumLeaves(); ++p )
					{
						if( p == i || p == j )
						{
							continue;
						}
						for( int q = p+1; q< listTreeUse[tcurr].GetNumLeaves(); ++q )
						{
							//
							if( q == i || q == j )
							{
								continue;
							}

							// is (i,j) (p,q) disjoint in T and T2?
		                    if( listTreeUse[tcurr].AreTwoPathsDisjoint( i, j, p, q ) == false  )
							{
								continue;
							}
		                    if( listTreeUse[tprev].AreTwoPathsDisjoint( i, j, p, q ) == true  )
							{
								continue;
							}

							// then not all i,j,p,q can be in the same component if 
							// no cuts in between these paths
							OutputFLvk12i(outFile, tcurr, tprev, i);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, j);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, p);
							outFile << " + ";
							OutputFLvk12i(outFile, tcurr, tprev, q);
							outFile << " + ";
							OutputMLvTreeij(outFile, tcurr, i, j);
							outFile << " + ";
							OutputMLvTreeij(outFile, tcurr, p, q);

							//pair<int,int> ppij(i,j), pppq(p,q);
							//for( set<int> :: iterator it = mapListPairNodesPath[tcurr][ppij].begin(); it != mapListPairNodesPath[tcurr][ppij].end(); ++it )
							//{
							//	outFile << " -\n";
							//	OutputTki( outFile, tcurr, *it);
							//}
							//for( set<int> :: iterator it = mapListPairNodesPath[tcurr][pppq].begin(); it != mapListPairNodesPath[tcurr][pppq].end(); ++it )
							//{
							//	outFile << " -\n";
							//	OutputTki( outFile, tcurr, *it);
							//}

							outFile << " <= 5\n";
						}

					}
				}
			}
		}
	}

	// for incompatible triple, either one of leave is not mapped or there is some t-cuts
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					for( int k = j+1; k< listTreeUse[tcurr].GetNumLeaves(); ++k )
					{
						// see if this triple is incomptible with that of a previous tree
						if( treesTripleState[tcurr][i][j][k] == treesTripleState[tprev][i][j][k] )
						{
							continue;
						}

						// get all branches along the triple in T
						pair<int,int> ppij(i,j), ppik(i,k);
						set<int> listEdgesTot = mapListPairNodesPath[tcurr][ppij];
						UnionSets(listEdgesTot, mapListPairNodesPath[tcurr][ppik] );
						// 


						// 
						OutputFLvk12i(outFile, tcurr, tprev, i);
						outFile << " + ";
						OutputFLvk12i(outFile, tcurr, tprev, j);
						outFile << " + ";
						OutputFLvk12i(outFile, tcurr, tprev, k);
						outFile << " + ";
						OutputMLvTreeij(outFile, tcurr, i, j);
						outFile << " + ";
						OutputMLvTreeij(outFile, tcurr, i, k);

						//for( set<int> :: iterator it = listEdgesTot.begin(); it != listEdgesTot.end(); ++it )
						//{
						//	outFile << " -\n";
						//	OutputTki( outFile, tcurr, *it);
						//}
						outFile << " <= 4\n ";

					}


				}
			}
		}
	}

	// need to ensure consistency
	// that is, if F12i=1 and in T2, i,j is not cut off, then F12j=1
	for(int tcurr=2; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					// first, if tprev = 0, we use tree T1 instead
					int tprevuse = tprev;
					if( tprevuse == 0 )
					{
						tprevuse = 1;
					}

					// 
					OutputFLvk12i(outFile, tcurr, tprev, i);
					//pair<int,int> ppij(i,j);
					//for( set<int> :: iterator it = mapListPairNodesPath[tprevuse][ppij].begin(); it != mapListPairNodesPath[tprevuse][ppij].end(); ++it )
					//{
					//	outFile << " -\n";
					//	OutputTki( outFile, tprevuse, *it);
					//}
					outFile << " + ";
					OutputMLvTreeij(outFile, tprevuse, i, j);

					outFile << " - \n";
					OutputFLvk12i(outFile, tcurr, tprev, j);
					outFile << " <= 1\n";

				}
			}
		}
	}


	// moreover, if no cut between i and j in current tree, and both i and j follows the same tree
	// then, there is no cuts in that tree
	for(int tcurr=2; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int tprev=0; tprev<tcurr; ++tprev)
		{
			for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
			{
				for( int j = i+1; j< listTreeUse[tcurr].GetNumLeaves(); ++j )
				{
					// first, if tprev = 0, we use tree T1 instead
					int tprevuse = tprev;
					if( tprevuse == 0 )
					{
						tprevuse = 1;
					}

					// MLv,k,i,j = 1 and F,k2,i =1 and F,k2,j = 1, then Mlv,k2,i,j=1
					OutputFLvk12i(outFile, tcurr, tprev, i);
					outFile << " + ";
					OutputMLvTreeij(outFile, tcurr, i, j);
					outFile << " + ";
					OutputFLvk12i(outFile, tcurr, tprev, j);
					outFile << " - ";
					OutputMLvTreeij(outFile, tprevuse, i, j);
					outFile << " <= 2\n";

				}
			}
		}
	}
#endif

//#if 0
	// each node has to follow one of the previous tree
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
		{
			// following variable: leave i is mapped to one of the previous tree
			for(int tprev=0; tprev<tcurr; ++tprev)
			{
				OutputFLvk12i( outFile, tcurr, tprev, i);
				if( tprev < tcurr-1)
				{
					outFile << " + \n";
				}
			}
			// YW: need not be equal to 1
			outFile << "=1"   << endl;
		}
	}
//#endif

    // variables
    outFile << "\nBinary " << endl;
	// each tree (including the first one)
	//for(int t=1; t<(int)listTreeUse.size(); ++t)
	//{
	//	for( int i = 0; i< listTreeUse[t].GetTotNodesNum(); ++i )
	//	{
	//		OutputCki( outFile, t, i );
	//		outFile << endl;
	//	}
	//}

	for( int i= 0; i< listTreeUse[0].GetNumLeaves(); ++i  )
	{
		for( int j= i+1; j< listTreeUse[0].GetNumLeaves(); ++j  )
		{
	//		OutputMLvCommonij( outFile, i, j );
	//		outFile << endl;
			for(int t=1; t<(int)listTreeUse.size(); ++t)
			{
				// whether the pair of leaves are really cut
				OutputMLvTreeij(outFile, t, i, j);
				outFile << endl;
			}
		}
	}
	// T values and related
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
		{
			OutputTki( outFile, tcurr, i );
			outFile << endl;
		}
	}
//#if 0
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetNumLeaves(); ++i )
		{
			// following variable: leave i is mapped to one of the previous tree
			for(int tprev=0; tprev<tcurr; ++tprev)
			{
				OutputFLvk12i( outFile, tcurr, tprev, i);
				outFile << endl;
			}
		}
	}
//#endif

    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();
cout << "Constrains finished\n";
}

void OutputLeafCost( ofstream &outFile, int a)
{
	outFile << "LC," << a;
}

void OutputCherryCost( ofstream &outFile, int a, int b )
{
	outFile << "CC," << a << "," << b;
}


static int CalcNumVertReps( const vector< set<int> > &listLeaves  )
{
//#if 0
	// find the non-connected components
	UndirectedGraph graph;
	for( int sid = 0; sid < (int) listLeaves.size(); ++sid )
	{
//cout << "Adding a vertex: " << sid << endl;
		int vid = graph.AddVertex(sid);
		YW_ASSERT_INFO( vid == sid, "wrong" );
	}
//cout << "Number of graph vertice = " << graph.GetNumVertices() << endl;
	// add edges
	for(int s1=0; s1<(int)listLeaves.size(); ++s1)
	{
		for(int s2=s1+1; s2<(int)listLeaves.size(); ++s2)
		{
			set<int> sint;
			JoinSets(listLeaves[s1], listLeaves[s2], sint);
			if( sint.size() > 0 )
			{
//cout << "add edge: " << s1 << ", " << s2 << endl;
				graph.AddEdge(s1,s2,0);
			}
		}
	}
	// find components
	set< set<int> > listCompVerts;
	graph.FindComponents( listCompVerts);
//cout << "Number of components = " << listCompVerts.size() << endl;
//#endif

	// do the computation for each component separately and then add up
	int res = 0;

	for( set< set<int> > :: iterator it = listCompVerts.begin(); it != listCompVerts.end(); ++it  )
	{
		YW_ASSERT_INFO( it->size() > 0, "Can not be empty set" );
		if( it->size() == 1)
		{
			res ++;
		}
		else
		{
			vector< set<int> > listSetUse;
			for( set<int> :: iterator itt = it->begin(); itt != it->end(); ++itt )
			{
				listSetUse.push_back(  listLeaves[ *itt ]  );
			}

			set<int> itemhits;
			int resstep = SlowHittingSetSolver(listSetUse, itemhits);
			res += resstep;
		}
	}
//cout << "final result = " << res << endl;

	return res;
}



// computes the leaf cost for each leaf node about how expensive it will be to connect to other
// parts of the tree. Note we can compute for pair of leaves as well, but wait.... unitl we get this right
// so how does this work? 
// we take an approximate approach: for each leaf, find the set of its sibling leaves for each tree
// then we take the number of connected components (minus one) as a rough estimate of the cost to connect the node
static void CalcLeafCostLBMultiTrees(vector<MarginalTree *> &listTreeOrig, vector<int> &listCosts )
{
	// 
	listCosts.clear();
	for(int a=0; a<(int)listTreeOrig[0]->GetNumLeaves(); ++a)
	{
		// 
		vector< set<int> > listSibs;
		for(int t=0; t<(int)listTreeOrig.size(); ++t)
		{
			//int par = listTreeOrig[t]->GetParent( a );
			//int ppar = listTreeOrig[t]->GetParent( par );
			//if( ppar >= 0)
			//{
			//	par = ppar;
			//}
			int sib = listTreeOrig[t]->GetSibling(a);
			// 
			set<int> listLeaves;
			listTreeOrig[t]->GetLeavesUnder(sib, listLeaves);
//			listTreeOrig[t]->GetLeavesUnder(par, listLeaves);
			listLeaves.erase(a);
			listSibs.push_back( listLeaves );
//cout << "A new sib vertex = ";
//DumpIntSet( listLeaves );
		}
		
#if 0
		// find the non-connected components
		UndirectedGraph graph;
		for( int sid = 0; sid < (int) listSibs.size(); ++sid )
		{
//cout << "Adding a vertex: " << sid << endl;
			int vid = graph.AddVertex(sid);
			YW_ASSERT_INFO( vid == sid, "wrong" );
		}
//cout << "Number of graph vertice = " << graph.GetNumVertices() << endl;
		// add edges
		for(int s1=0; s1<(int)listSibs.size(); ++s1)
		{
			for(int s2=s1+1; s2<(int)listSibs.size(); ++s2)
			{
				set<int> sint;
				JoinSets(listSibs[s1], listSibs[s2], sint);
				if( sint.size() > 0 )
				{
//cout << "add edge: " << s1 << ", " << s2 << endl;
					graph.AddEdge(s1,s2,0);
				}
			}
		}
		// find components
		set< set<int> > listCompVerts;
		graph.FindComponents( listCompVerts);
cout << "Number of components = " << listCompVerts.size() << endl;
#endif
		//
		int cost = CalcNumVertReps(listSibs)-2;
		if( cost < 0 )
		{
			cost = 0;
		}
		listCosts.push_back( cost );
	}
}


static void CalcCherryCostLBMultiTrees(vector<MarginalTree *> &listTreeOrig, vector<vector<int> > &listCosts )
{
cout << "Finding all cherry condition...\n";
	// 
	listCosts.clear();
	listCosts.resize(listTreeOrig[0]->GetNumLeaves());
	for(int a=0; a<(int)listTreeOrig[0]->GetNumLeaves(); ++a)
	{

		listCosts[a].resize(listTreeOrig[0]->GetNumLeaves());
		for(int b=a+1; b<(int) listTreeOrig[0]->GetNumLeaves(); ++b)
		{
//cout << "a = " << a << ", b = " << b << endl;
			// 
			vector< set<int> > listSibs;
			for(int t=0; t<(int)listTreeOrig.size(); ++t)
			{
				//int par = listTreeOrig[t]->GetParent( a );
				//int ppar = listTreeOrig[t]->GetParent( par );
				//if( ppar >= 0)
				//{
				//	par = ppar;
				//}
				int node = listTreeOrig[t]->GetMRCA(a,b);
				
				int sib;
				if( listTreeOrig[t]->GetParent(node) >= 0 )
				{
					sib = listTreeOrig[t]->GetSibling(node);
				}
				else
				{
					sib = node;
				}
				
				// 
				set<int> listLeaves;
				listTreeOrig[t]->GetLeavesUnder(sib, listLeaves);
	//			listTreeOrig[t]->GetLeavesUnder(par, listLeaves);
				listLeaves.erase(a);
				listLeaves.erase(b);
				listSibs.push_back( listLeaves );
//	cout << "A new sib vertex = ";
//	DumpIntSet( listLeaves );
			}
			
#if 0
			// find the non-connected components
			UndirectedGraph graph;
			for( int sid = 0; sid < (int) listSibs.size(); ++sid )
			{
//	cout << "Adding a vertex: " << sid << endl;
				int vid = graph.AddVertex(sid);
				YW_ASSERT_INFO( vid == sid, "wrong" );
			}
//	cout << "Number of graph vertice = " << graph.GetNumVertices() << endl;
			// add edges
			for(int s1=0; s1<(int)listSibs.size(); ++s1)
			{
				for(int s2=s1+1; s2<(int)listSibs.size(); ++s2)
				{
					set<int> sint;
					JoinSets(listSibs[s1], listSibs[s2], sint);
					if( sint.size() > 0 )
					{
//	cout << "add edge: " << s1 << ", " << s2 << endl;
						graph.AddEdge(s1,s2,0);
					}
				}
			}
			// find components
			set< set<int> > listCompVerts;
			graph.FindComponents( listCompVerts);
	cout << "Number of components = " << listCompVerts.size() << endl;
#endif
			//
			int cost = CalcNumVertReps(listSibs)-2;
			if( cost < 0 )
			{
				cost = 0;
			}
			listCosts[a][b] =  cost ;
		}
	}
}



// output a formulation for lower bound on the min hybrid number
void OutputILPHybridLBMultiTrees(const char* fileName, vector<MarginalTree *> &listTreeOrig)
{
	YW_ASSERT_INFO(listTreeOrig.size() >=3, "Wrong number of trees");
cout << "Inside OutputILPHybridLBMultiTrees\n";
	for(int t=1; t< (int)listTreeOrig.size(); ++t)
	{
		YW_ASSERT_INFO( listTreeOrig[0]->GetTotNodesNum() == listTreeOrig[t]->GetTotNodesNum(), "mismatch" );
	}

//cout << "OutputILPMaxGoodAgreeForest: treeOrig1 = ";
//treeOrig1.Dump();
//cout << "OutputILPMaxGoodAgreeForest: tree2 = ";
//treeOrig2.Dump();

	// calculate leaf penalty
	vector<int> listLeafCost;
	CalcLeafCostLBMultiTrees(listTreeOrig, listLeafCost);
	vector< vector<int> > listPairCost;
	CalcCherryCostLBMultiTrees( listTreeOrig, listPairCost );


	vector<MarginalTree> listTreeUse;
	vector<MarginalTree *> listTreePtrUse;
	for(int t=0; t<(int)listTreeOrig.size(); ++t)
	{
		MarginalTree  tree1Reduced = *listTreeOrig[t];

		// buildup the descendent info
		tree1Reduced.BuildDescendantInfo();
		listTreeUse.push_back( tree1Reduced );
	}
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		listTreePtrUse.push_back( &listTreeUse[t] );
	}

	// collect all triples and their shape
	// in particular, for ordered triples i,j,k (i<j<k)
	// (i,j,k) = 1 if (i,j),k
	// (i,j,k) = 2 if i,(j,k)
	// (i,j,k) = 3 if(i,k),j
	int nLeaveNum = listTreeUse[0].GetNumLeaves();
//cout << "num leaves = " << nLeaveNum << endl;

	// this keep track of the type of triples we have in the component
	vector< vector< vector<int> > >  treesTripleState[ listTreeUse.size() ];
	for(int t=0; t<(int)listTreeUse.size(); t++)
	{
		treesTripleState[t].resize( nLeaveNum );
		for(int i=0; i<nLeaveNum; ++i)
		{
			treesTripleState[t][i].resize( nLeaveNum );
			for(int j=0; j<nLeaveNum; ++j)
			{
				treesTripleState[t][i][j].resize( nLeaveNum );
				for(int k=0; k<nLeaveNum; ++k)
				{
					treesTripleState[t][i][j][k] = 0;
				}
			}
		}
	}
	for(int t=0; t< (int)listTreeUse.size(); t++)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				for(int k=j+1; k< listTreeUse[t].GetNumLeaves(); ++k)
				{
					// is these have different triples on T1 and T2?
					// we do this by getting MRCA for all pairs of MRCAs
					int mrcaij1 = listTreeUse[t].GetMRCA( i, j );
					int mrcajk1 = listTreeUse[t].GetMRCA( j, k );
					int mrcaik1 = listTreeUse[t].GetMRCA( i, k );

					// now just test exhustively
					if( mrcaij1 == mrcajk1 )
					{
						treesTripleState[t][i][j][k] = 3;
					}
					else if( mrcaij1 == mrcaik1 )
					{
						treesTripleState[t][i][j][k] = 2;
					}
					else 
					{
						treesTripleState[t][i][j][k] = 1;
					}

				}
			}
		}
	}

	// this keep track for each tree, which pair intersect with which in the first tree
	map< pair< pair<int,int>, pair<int,int> >, bool > mapNodePairPathIntersectInTrees[ listTreeUse.size() ];
	for(int t=0; t< (int)listTreeUse.size(); ++t)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				pair<int,int> pp1(i,j);
				for(int p=i+1; p< listTreeUse[t].GetNumLeaves(); ++p)
				{
					// make sure p <>i or j
					if(  p == j )
					{
						continue;
					}
					for(int q = p+1; q < listTreeUse[t].GetNumLeaves(); ++q)
					{
						// make sure q is unique twoo
						if(  q == j )
						{
							continue;
						}
						pair<int,int> pp2(p,q);
						pair< pair<int,int>, pair<int,int> > pp(pp1,pp2);

						// now we only worry about two disjoint path (i,j) and (p,q)
						bool fInt =  listTreeUse[t].AreTwoPathsDisjoint( i, j, p, q );
						if( fInt == true )
						{
							fInt = false;
						}
						else
						{
							fInt = true;
						}
//if( fInt == true )
//cout << "Tree " << t << ", [" << i << ", " << j << "] overlaps [" << p << ", " << q << "]\n";
//else
//cout << "Tree " << t << ", [" << i << ", " << j << "] disjoint [" << p << ", " << q << "]\n";
						mapNodePairPathIntersectInTrees[t].insert( map< pair< pair<int,int>, pair<int,int> >, bool > :: value_type(pp, fInt)  );
					}
				}
			}
		}
	}
//cout << "here\n";
	// YW: 2/10/09: added to support acyclic property
	// moreover, see what kinds of acyclic 
	GeneralHybridNetwork hybridNet( listTreePtrUse );
	if( fAcyclic == true )
	{
		hybridNet.FindLeafPairGraphCycles();
		cout << "Number of forced pairs = " << hybridNet.GetNumForcedPathPairs() << endl;
		cout << "Number of cycles = " << hybridNet.GetNumInferredCycles() << endl;
	}


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";



    // first the set of branch cuts (twice as much as what in one tree
	//for(int t=1; t< (int)listTreeUse.size(); ++t)
	{
		for( int i = 0; i< listTreeUse[1].GetTotNodesNum()-1; ++i )
		{
	//		if( t == 1 )
			{
				OutputCki(outFile, 0, i);
				if( i< listTreeUse[1].GetTotNodesNum()-2 )
				{
					outFile << "+\n ";
				}
			}
//			else
//			{
		//		outFile << " +\n";
		//		OutputTki(outFile, t, i);
			//	if( t < (int) listTreeUse.size()-1 || i < listTreeUse[t].GetTotNodesNum()-2 )
			//	{
			//		outFile << "\n+ ";
			//	}
//			}
		}
	}

#if 0
	// add additional penalty for leaves
	for(int a = 0; a< listTreeUse[0].GetNumLeaves(); ++a)
	{
		//
		outFile << " + " << listLeafCost[a]  << " ";
		OutputLeafCost( outFile, a);
	}
	outFile << endl;
	// add additional pentaly for cherry
	for(int a = 0; a< listTreeUse[0].GetNumLeaves(); ++a)
	{
		//
		for(int b = a+1; b< listTreeUse[0].GetNumLeaves(); ++b)
		{
			outFile << " + " << listPairCost[a][b]  << " ";
			OutputCherryCost( outFile, a, b);
		}
		outFile << endl;
	}
#endif


    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;

	// enforce same number of edge cuts in two trees
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		OutputCki(outFile, t, listTreeUse[t].GetTotNodesNum()-1);
		outFile << "=0\n";
	}

	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		for(int i=0; i<listTreeUse[1].GetTotNodesNum(); ++i)
		{
			OutputCki(outFile, 0, i);
			if( i < listTreeUse[1].GetTotNodesNum()-1 )
			{
				outFile << " + \n";
			}
		}

		for(int i=0; i<listTreeUse[t].GetTotNodesNum(); ++i)
		{
			outFile << "\n - ";
			OutputCki(outFile, t, i);
		}
		outFile << " = 0\n";
	}

#if 0
	for(int t=2; t<(int)listTreeUse.size(); ++t)
	{
		for(int i=0; i<listTreeUse[t].GetTotNodesNum(); ++i)
		{
			OutputCki(outFile, 1, i);
			outFile << " - ";
			OutputTki(outFile, 1, i);
			outFile << ">=0\n";
		}
	}
#endif

	// now use it to enforce pair of nodes
	// enforce connectivity
	map<pair<int,int>, set<int> > mapListPairNodesPath[listTreeUse.size()];
	for(int tcurr = 0; tcurr < (int)listTreeUse.size(); ++tcurr)
	{
		// is leaves are really connected or not

		// enforce for each previous tree
		const MarginalTree *pCurrTree = &listTreeUse[tcurr];

		for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
			{
				// first we need to find MRCA of i,j. 
				// note that we actually want to exluce MRCA, but include i,j!
				set<int> listPathNodes;
				int n1=i, n2 = j;
				listPathNodes.insert(i);
				listPathNodes.insert(j);
				while( n1 != n2 )
				{
					// we alternatively move up, depend on which one is smaller
					int nodeNew;
					if( n1 < n2  )
					{
						// move n1
						n1 = pCurrTree->GetParent(n1);
						nodeNew = n1;
					}
					else
					{
						// move n2
						n2 = pCurrTree->GetParent(n2);
						nodeNew = n2;
					}
					// save this when n1 != n2
					if( n1 != n2 )
					{
						listPathNodes.insert( nodeNew );
					}
				}
				// pop up the last item MRCA
				//listPathNodes.pop_back();
				listPathNodes.erase(  n1  );

				// save it
				pair<int,int> pp(i,j), pp2(j,i);
				mapListPairNodesPath[tcurr].insert( map<pair<int,int>, set<int> > :: value_type(pp, listPathNodes)  );
				mapListPairNodesPath[tcurr].insert( map<pair<int,int>, set<int> > :: value_type(pp2, listPathNodes)  );
            
				// create constraint for the current tree to see if they are really connected or not
//#if 0
                //OutputMLvTreeij( outFile, tcurr, i, j );
                OutputMLvCommonij( outFile, i, j );
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    outFile << " + ";
                    OutputCki( outFile, tcurr, *it );
                    outFile << endl;
                }
                outFile << " >= 1\n";
//#endif
				// no need for enforcing this I think
//#if 0
                /*  do we need the following? yes */
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    //OutputMLvTreeij( outFile, tcurr, i, j );
                    OutputMLvCommonij( outFile, i, j );
                    outFile << " + ";
                    OutputCki( outFile, tcurr, *it );
                    outFile << " <= 1\n";
                }
//#endif
			}
		}
	}
	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		// ensure all left-over triples are compatible
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				for(int k=j+1; k< listTreeUse[t].GetNumLeaves(); ++k)
				{
					// enforce branch cut if one triple does not match
					// YW: now I believe only one of the following (say (i,j) and (j,k) are needed
					if( treesTripleState[t][i][j][k] != treesTripleState[0][i][j][k] )
					//	treesTripleState[t][i][j][k] != treesTripleState[t2][i][j][k]  )
					{
						OutputMLvCommonij(outFile, i, j);
						//OutputMkij( outFile, t, i, j );
						outFile << " + ";
						OutputMLvCommonij( outFile, i, k);
						//OutputMkij( outFile, t, i, k );
						outFile << " <= 1\n";
					}

				}
			}
		}
	}
#if 0
	// try all triples
	for(int tcurr=2; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for(int a=0; a<listTreeOrig[tcurr]->GetNumLeaves(); ++a)
		{
			for(int b=a+1; b<listTreeOrig[tcurr]->GetNumLeaves(); ++b)
			{
				for(int c=b+1; c<listTreeOrig[tcurr]->GetNumLeaves(); ++c)
				{
					int tripleabc = listTreeOrig[tcurr]->GetTriple(a,b,c);
					// is the triple same or different from previous triple
					bool fNovel = true;
					for(int tprev = 0; tprev < tcurr; ++tprev)
					{
						int tnew = listTreeOrig[tprev]->GetTriple(a,b,c);
						if( tnew == tripleabc)
						{
							fNovel = false;
							break;
						}
					}

					// 
					if( fNovel == true )
					{
	//cout << "This triple is novel: " << a << ", " << b << ", " << c << endl; 

						// ensure at least one cut is there
						set<int> sLvsab, sLvsabc;
						listTreeOrig[tcurr]->GetPath( a, b, sLvsab );
						listTreeOrig[tcurr]->GetPath( b, c, sLvsabc );
						UnionSets( sLvsabc, sLvsab );

						// ensure at least one cut
						set<int> :: iterator it = sLvsabc.begin();
						OutputTki(outFile, tcurr, *it);
						++it;
						for( ; it != sLvsabc.end(); ++it )
						{
							outFile << " +\n";
							OutputTki(outFile, tcurr, *it);
						}
						outFile << " >=1\n";
					}
					else
					{
	//cout << "This triple is old: " << a << ", " << b << ", " << c << endl; 
					}
				}

			}
		}
	}
#endif


	// cycles:
	// now enforcing forced pair exclusion
	if( fAcyclic == true )
	{
		cout << "Output acyclic constraints...\n";
		set< pair<pair<int,int>, pair<int,int> > > & forcedPairs =  hybridNet.GetForcedPathPairsSet();
		for( set< pair<pair<int,int>, pair<int,int> > > :: iterator it= forcedPairs.begin(); it != forcedPairs.end(); ++it  )
		{
			OutputMLvCommonij(outFile, it->first.first, it->first.second);
			//OutputMkij( outFile, t, i, j );
			outFile << " + ";
			OutputMLvCommonij( outFile, it->second.first, it->second.second);
			//OutputMkij( outFile, t, i, k );
			outFile << " <= 1\n";
		}
	}

#if 0
	// ensure the leaf status: if it is not connected to any other leaf, then it is leaf
	for(int a = 0; a< listTreeUse[0].GetNumLeaves(); ++a)
	{
		//
		OutputLeafCost( outFile, a);
		for(int b=0; b< listTreeUse[0].GetNumLeaves(); ++b)
		{
			if( a == b)
				continue;

			// 
			outFile << " + \n";
			OutputMLvCommonij(outFile, a, b);
		}
		outFile << ">=1" <<  endl;
	}

	// ensure cherry status: the two needs to be conected and disconnect form the rest
	for(int a = 0; a< listTreeUse[0].GetNumLeaves(); ++a)
	{
		//
		for(int b = a+1; b< listTreeUse[0].GetNumLeaves(); ++b)
		{
			OutputCherryCost( outFile, a, b);
			for(int c=0; c< listTreeUse[0].GetNumLeaves(); ++c)
			{
				if( a == c || b == c)
					continue;

				// 
				outFile << " + \n";
				OutputMLvCommonij(outFile, a, c);
			}
			outFile << " - ";
			OutputMLvCommonij( outFile, a, b);
			outFile << ">=0" <<  endl;
		}
	}
#endif

    // variables
    outFile << "\nBinary " << endl;

	for( int i= 0; i< listTreeUse[0].GetNumLeaves(); ++i  )
	{
		for( int j= i+1; j< listTreeUse[0].GetNumLeaves(); ++j  )
		{
			OutputMLvCommonij( outFile, i, j );
			outFile << endl;
		}
	}
	// T values and related
	for(int tcurr=0; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
		{
			OutputCki( outFile, tcurr, i );
			outFile << endl;
		}
	}
#if 0
	// leave cost var
	for(int a = 0; a< listTreeUse[0].GetNumLeaves(); ++a)
	{
		//
		OutputLeafCost( outFile, a);
		outFile << endl;
	}
	// pair cost
	for(int a = 0; a< listTreeUse[0].GetNumLeaves(); ++a)
	{
		//
		for(int b = a+1; b< listTreeUse[0].GetNumLeaves(); ++b)
		{
			OutputCherryCost( outFile, a, b);
			outFile << endl;
		}
	}
#endif
	//for(int tcurr=2; tcurr<(int)listTreeUse.size(); ++tcurr)
	//{
	//	for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
	//	{
	//		OutputTki( outFile, tcurr, i );
	//		outFile << endl;
	//	}
	//}

    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();
cout << "Constrains finished\n";
}


////////////////////////////////////////////////////////////////////////////////////////////////////////

// Idea: For each branch b n Ti, if there exists either a node x (or a pair of nodes x and y)
// so x is connect to Lower(b) and there is a node z under Upper(b) but on the other side
// then we test whether they form the same relationship and if so, this branch cut is not needed
// should try all possible nodes
void OutputILPHybridLBStrongerMT(const char* fileName, vector<MarginalTree *> &listTreeOrig)
{
	//
	YW_ASSERT_INFO(listTreeOrig.size() >=3, "Wrong number of trees");
cout << "Inside OutputILPHybridLBStrongerMT\n";
	for(int t=1; t< (int)listTreeOrig.size(); ++t)
	{
		YW_ASSERT_INFO( listTreeOrig[0]->GetTotNodesNum() == listTreeOrig[t]->GetTotNodesNum(), "mismatch" );
	}

//cout << "OutputILPMaxGoodAgreeForest: treeOrig1 = ";
//treeOrig1.Dump();
//cout << "OutputILPMaxGoodAgreeForest: tree2 = ";
//treeOrig2.Dump();

	vector<MarginalTree> listTreeUse;
	for(int t=0; t<(int)listTreeOrig.size(); ++t)
	{
		MarginalTree  tree1Reduced = *listTreeOrig[t];

		// buildup the descendent info
		tree1Reduced.BuildDescendantInfo();
		listTreeUse.push_back( tree1Reduced );
	}

	// collect all triples and their shape
	// in particular, for ordered triples i,j,k (i<j<k)
	// (i,j,k) = 1 if (i,j),k
	// (i,j,k) = 2 if i,(j,k)
	// (i,j,k) = 3 if(i,k),j
	int nLeaveNum = listTreeUse[0].GetNumLeaves();
//cout << "num leaves = " << nLeaveNum << endl;

    //vector MarginalTree *ptrTrees[4];
    //ptrTrees[0] = &tree1Reduced;
    //ptrTrees[1] = &tree2Reduced;
    //ptrTrees[2] = &tree3Reduced;
    //ptrTrees[3] = &tree4Reduced;

	// this keep track of the type of triples we have in the component
	vector< vector< vector<int> > >  treesTripleState[ listTreeUse.size() ];
	for(int t=0; t<(int)listTreeUse.size(); t++)
	{
		treesTripleState[t].resize( nLeaveNum );
		for(int i=0; i<nLeaveNum; ++i)
		{
			treesTripleState[t][i].resize( nLeaveNum );
			for(int j=0; j<nLeaveNum; ++j)
			{
				treesTripleState[t][i][j].resize( nLeaveNum );
				for(int k=0; k<nLeaveNum; ++k)
				{
					treesTripleState[t][i][j][k] = 0;
				}
			}
		}
	}
	for(int t=0; t< (int)listTreeUse.size(); t++)
	{
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				for(int k=j+1; k< listTreeUse[t].GetNumLeaves(); ++k)
				{
					// is these have different triples on T1 and T2?
					// we do this by getting MRCA for all pairs of MRCAs
					int mrcaij1 = listTreeUse[t].GetMRCA( i, j );
					int mrcajk1 = listTreeUse[t].GetMRCA( j, k );
					int mrcaik1 = listTreeUse[t].GetMRCA( i, k );

					// now just test exhustively
					if( mrcaij1 == mrcajk1 )
					{
						treesTripleState[t][i][j][k] = 3;
					}
					else if( mrcaij1 == mrcaik1 )
					{
						treesTripleState[t][i][j][k] = 2;
					}
					else 
					{
						treesTripleState[t][i][j][k] = 1;
					}

				}
			}
		}
	}

    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // first the set of branch cuts (twice as much as what in one tree
	for(int t=1; t< (int)listTreeUse.size(); ++t)
	{
		for( int i = 0; i< listTreeUse[t].GetTotNodesNum()-1; ++i )
		{
			OutputTki(outFile, t, i);
			if( t < (int) listTreeUse.size()-1 || i < listTreeUse[t].GetTotNodesNum()-2 )
			{
				outFile << "\n+ ";
			}
		}
	}



    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;


    // now enforce m,i
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		OutputCki( outFile, t,  listTreeUse[t].GetTotNodesNum()-1 );
		outFile << " = 0 \n";
	}

	// each cut has at least one hybrid
	for(int t=1; t< (int)listTreeUse.size(); ++t)
	{
		for( int i = 0; i< listTreeUse[t].GetTotNodesNum()-1; ++i )
		{
			OutputTki(outFile, t, i);
			if( t < (int) listTreeUse.size()-1 || i < listTreeUse[t].GetTotNodesNum()-2 )
			{
				outFile << "\n+ ";
			}
		}
	}
	for(int i=0; i<listTreeUse[0].GetTotNodesNum(); ++i)
	{
		outFile << " - \n";
		OutputCki(outFile, 0, i);
	}
	outFile << " >= 0\n";

	// enforce same number of edge cuts in two trees
	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		for(int i=0; i<listTreeUse[0].GetTotNodesNum(); ++i)
		{
			OutputCki(outFile, 0, i);
			if( i < listTreeUse[1].GetTotNodesNum()-1 )
			{
				outFile << " + \n";
			}
		}
		for(int i=0; i<listTreeUse[t].GetTotNodesNum(); ++i)
		{
			outFile << "\n - ";
			OutputCki(outFile, t, i);
		}
		outFile << " = 0\n";
	}

	// enforce connectivity through all pairs of node conectivity
    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
    set< pair<int,int> > listPairNodesConstraint[ listTreeUse.size() ];
	map< int, vector<int> > mapLeafAncestors[ listTreeUse.size() ];

    // for each tree, we constraint on the connectivity of each node to all ancestral nodes
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
        const MarginalTree *pCurrTree = &listTreeUse[t];

		for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
		{
			vector<int> lvAncestors;

			// first we need to find MRCA of i,j. 
			// note that we actually want to exluce MRCA, but include i,j!
			//vector<int> listPathNodes;
			int n1=i;
			// of course connected to itself
			OutputMkij( outFile, t, i, n1 );
			outFile << " = 1\n";

			//listPathNodes.push_back(i);
			//listPathNodes.push_back(j);
			while( n1 >= 0 )
			{
				// IMPORTANT: make sure n1 <= n2 (true upon entry)

				// enforce an property
				pair<int,int> pp(i, n1);
				if( listPairNodesConstraint[t].find(pp) != listPairNodesConstraint[t].end()   )
				{
					// we already reach what we need, stop
					//break;
					YW_ASSERT_INFO(false, "should not go here");
				}
				listPairNodesConstraint[t].insert(pp);
				lvAncestors.push_back(n1);

	
				// we alternatively move up, depend on which one is smaller
				int nodeNew;
				// move n1
				nodeNew = pCurrTree->GetParent(n1);

				int n1New, edgeCuti;
				n1New = nodeNew;
				edgeCuti = n1;

				if( n1New >= 0)
				{
					// here are constraints: if the (shorter) orig pair is already 0, then the new must also be 0
					OutputMkij( outFile, t, i, n1 );
					outFile << " - ";
					OutputMkij( outFile, t, i, n1New );
					outFile << " >= 0\n";
					// if orig is 1, and cut = 0, then new connect = 1
					OutputMkij( outFile, t, i, n1New );
					outFile << " + ";
//					OutputCki( outFile, t,  edgeCuti);
					//
					OutputCki( outFile, t,  edgeCuti);
					outFile << " - ";
					OutputMkij( outFile, t, i, n1 );
					outFile << " >= 0\n";
					// if edge cut is 1, then M = 0
					OutputMkij( outFile, t, i, n1New );
					outFile << " + ";
					OutputCki( outFile, t,  edgeCuti);
					outFile << " <= 1\n";
				}
				 // now update n1 and n2
				n1 = n1New;
			}
//cout << "For tree t= " << t << ", leaf " << i << ", ancestor list = ";
//DumpIntVec( lvAncestors );
			mapLeafAncestors[t].insert(map< int, vector<int> > :: value_type(i, lvAncestors) );
		}
	}

	// ensure compatible triples
	for(int t=1; t<(int)listTreeUse.size(); ++t)
	{
		// ensure all left-over triples are compatible
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				for(int k=j+1; k< listTreeUse[t].GetNumLeaves(); ++k)
				{
					// enforce branch cut if one triple does not match
					// YW: now I believe only one of the following (say (i,j) and (j,k) are needed
					if( treesTripleState[t][i][j][k] != treesTripleState[0][i][j][k] )
					{
						// must ensure not both triples are realized
						//int mrca1ab = listTreeUse[t].GetMRCA( i, j );
						//int mrca1abc = listTreeUse[t].GetMRCA( k, mrca1ab );
						//int mrca0ab = listTreeUse[0].GetMRCA( i, j );
						//int mrca0abc = listTreeUse[0].GetMRCA( k, mrca0ab );

						OutputMLvCommonij( outFile, i, j );
						outFile << " + ";
						OutputMLvCommonij( outFile, i, k );
						outFile << " <=1\n";


						//OutputMkij(outFile, t, i, mrca1abc);
						//outFile << " + ";
						//OutputMkij(outFile, t, j, mrca1abc);
						//outFile << " + ";
						//OutputMkij(outFile, t, k, mrca1abc);
						//outFile << " + ";
						//OutputMkij(outFile, 0, i, mrca0abc);
						//outFile << " + ";
						//OutputMkij(outFile, 0, j, mrca0abc);
						//outFile << " + ";
						//OutputMkij(outFile, 0, k, mrca0abc);
						//outFile << " <= 5\n";
					}
				}
			}
		}
	}
	// ensure cutting status the same
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		// ensure all left-over triples are compatible
		for( int i= 0; i< listTreeUse[t].GetNumLeaves() ; ++i  )
		{
			for(int j=i+1; j< listTreeUse[t].GetNumLeaves(); ++j)
			{
				int mrca1ab = listTreeUse[t].GetMRCA( i, j );

				OutputMLvCommonij( outFile, i, j );
				outFile << " - ";
				OutputMkij(outFile, t, i, mrca1ab);
				outFile << " <= 0\n";

				OutputMLvCommonij( outFile, i, j );
				outFile << " - ";
				OutputMkij(outFile, t, j, mrca1ab);
				outFile << " <= 0\n";

				OutputMLvCommonij( outFile, i, j );
				outFile << " - ";
				OutputMkij(outFile, t, i, mrca1ab);
				outFile << " - ";
				OutputMkij(outFile, t, j, mrca1ab);
				outFile << " >= -1\n";


			}
		}
	}



	// now enforce which T mus be set to 0. First, if there is no C-cut, T has to be 0
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
		{
			OutputTki( outFile, tcurr, i );
			outFile << " - ";
			OutputCki( outFile, tcurr, i );
			outFile << " <= 0" <<  endl;
		}
	}
	// do not allow two sibling been C-cut at the same time
	// now enforce which T mus be set to 0. First, if there is no C-cut, T has to be 0
	for(int tcurr=0; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
		{
			if( listTreeUse[tcurr].IsLeaf( i ) == false )
			{
				int child1 = listTreeUse[tcurr].GetLeftDescendant( i );
				int child2 = listTreeUse[tcurr].GetRightDescendant( i );

				OutputCki( outFile, tcurr, child1 );
				outFile << " + ";
				OutputCki( outFile, tcurr, child2 );
				outFile << " <= 1" <<  endl;
			}
		}
	}

	// enforce Mlv vars
	set< pair<int,int> > setNgbrSingletonPairs[listTreeUse.size()];
	for( int i= 0; i< listTreeUse[0].GetNumLeaves(); ++i  )
	{
		for( int j= 0; j< listTreeUse[0].GetNumLeaves(); ++j  )
		{
			if( i == j )
			{
				continue;
			}

			for(int t=0; t<(int)listTreeUse.size(); ++t)
			{
				// MlvTree,t,i,j = 1 iff j is connected to MRCAt(i,j)
				// and i is connected to the descend of MRCAt(i,j) on the path to i, but not to the MRCA
				int mrca = listTreeUse[t].GetMRCA( i, j );
				int child1 = listTreeUse[t].GetLeftDescendant( mrca );
				int child2 = listTreeUse[t].GetRightDescendant( mrca );
				int child = child1;
				if( listTreeUse[t].IsNodeUnder( i, child1  ) == false)
				{
					child = child2;
					YW_ASSERT_INFO( listTreeUse[t].IsNodeUnder( i, child  ) == true, "FALSE" );
				}
				OutputMLvTreeOrderedij(outFile, t, i, j);
				outFile << " - ";
				OutputMkij(outFile, t, i, child);
				outFile << "<= 0" <<  endl;

				OutputMLvTreeOrderedij(outFile, t, i, j);
				outFile << " - ";
				OutputMkij(outFile, t, j, mrca);
				outFile << "<= 0" <<  endl;

				OutputMLvTreeOrderedij(outFile, t, i, j);
				outFile << " - ";
				OutputCki(outFile, t, child);
				outFile << "<= 0" <<  endl;


				OutputMLvTreeOrderedij(outFile, t, i, j);
				outFile << " - ";
				OutputMkij(outFile, t, i, child);
				outFile << " - ";
				OutputMkij(outFile, t, j, mrca);
				outFile << " - ";
				OutputCki(outFile, t, child);
				outFile << ">= -2" <<  endl;

				// save it
				pair<int,int> pp(i,j);
				setNgbrSingletonPairs[t].insert(pp);

			}
		}
	}

	// each C-cut must be turned to a T-cut
	// if none of the following occurs: for any 
	// we should try all possible attachment way
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		// try all pssoble  attachment. First, consider singleton
		for( set< pair<int,int> > :: iterator it = setNgbrSingletonPairs[tcurr].begin();
			it != setNgbrSingletonPairs[tcurr].end(); ++it )
		{
			int mrca = listTreeUse[tcurr].GetMRCA(it->first, it->second);
			int child1 = listTreeUse[tcurr].GetLeftDescendant( mrca );
			int child2 = listTreeUse[tcurr].GetRightDescendant( mrca );
			int child = child1;
			if( listTreeUse[tcurr].IsNodeUnder( it->first, child1  ) == false)
			{
				child = child2;
				YW_ASSERT_INFO( listTreeUse[tcurr].IsNodeUnder( it->first, child  ) == true, "FALSE" );
			}

			OutputTki(outFile, tcurr, child);

			for(int tprev = 0; tprev < tcurr; ++tprev)
			{
				if( setNgbrSingletonPairs[tprev].find(*it) != setNgbrSingletonPairs[tprev].end()  )
				{
					outFile << " + ";
					OutputMLvTreeOrderedij(outFile, tprev, it->first, it->second );
				}
			}
			outFile << " - ";
			OutputMLvTreeOrderedij(outFile, tcurr, it->first, it->second);
			outFile << " >=  0\n";
		}
	}


    // variables
    outFile << "\nBinary " << endl;
	// each tree (including the first one)
	for(int t=0; t<(int)listTreeUse.size(); ++t)
	{
		for( int i = 0; i< listTreeUse[t].GetTotNodesNum(); ++i )
		{
			OutputCki( outFile, t, i );
			outFile << endl;
		}
		// mkij
        // output m,k,i,js
        for( set<pair<int,int> > :: iterator it = listPairNodesConstraint[t].begin(); 
            it != listPairNodesConstraint[t].end(); ++it )
        {
            pair<int,int> pp = *it;
            OutputMkij( outFile, t, pp.first, pp.second );
            outFile << endl;
        }
	}
	// common leaf status
	for( int i= 0; i< listTreeUse[0].GetNumLeaves(); ++i  )
	{
		for( int j= i+1; j< listTreeUse[0].GetNumLeaves(); ++j  )
		{
			OutputMLvCommonij( outFile, i, j );
			outFile << endl;
		}
	}
	// cut status indicator
	for( int t= 1; t< (int)listTreeUse.size(); ++t  )
	{
		for( set< pair<int,int> > :: iterator it =  setNgbrSingletonPairs[t].begin(); it != setNgbrSingletonPairs[t].end(); ++it)
		{
			// MlvTree,t,i,j = 1 iff i, j in Tt is similarly connected as a previous tree
			OutputMLvTreeOrderedij(outFile, t, it->first, it->second);
			outFile << endl;
		}
	}

	// T values and related
	for(int tcurr=1; tcurr<(int)listTreeUse.size(); ++tcurr)
	{
		for( int i = 0; i< listTreeUse[tcurr].GetTotNodesNum(); ++i )
		{
			OutputTki( outFile, tcurr, i );
			outFile << endl;
		}
	}

    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();
cout << "Constrains finished\n";
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
// output a file for lower bound computation
////////////////////////////////////////////////////////////////////////////////////////////////////////
static void OutputXij( ofstream &outFile, int row, int col )
{
    outFile << "X," << row << "," << col;  
} 
static void OutputMijk( ofstream &outFile, int r1, int r2, int col )
{
    outFile << "M," << r1 << "," << r2 << "," << col;  
} 

void OutputILPVecLBMT(const char* fileName, int numHybrids, vector< vector<int> > &listTreeDists)
{
    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";
	OutputXij(outFile, 0, 0);

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;

	// fix the first row to be all-0
	for(int j=0; j<numHybrids; ++j)
	{
		OutputXij( outFile, 0, j );
		outFile  << "=0" <<  endl;
	}

	// varialbes: M = 1 if two positions matches 
	for( int i = 0; i<(int)listTreeDists.size(); ++i )
	{
		for( int j = i+1; j<(int)listTreeDists.size(); ++j )
		{
			for(int k=0; k<numHybrids; ++k)
			{
				OutputMijk( outFile, i, j, k );
				outFile << " + ";
				OutputXij(outFile, i, k);
				outFile << " + ";
				OutputXij( outFile, j, k);
				outFile << ">=1"  << endl;

				OutputMijk( outFile, i, j, k );
				outFile << " - ";
				OutputXij(outFile, i, k);
				outFile << " - ";
				OutputXij( outFile, j, k);
				outFile << ">=-1"  << endl;
			}
		}
	}

	// pairwise constraints
	for( int i = 0; i<(int)listTreeDists.size(); ++i )
	{
		for( int j = i+1; j<(int)listTreeDists.size(); ++j )
		{
			for(int k=0; k<numHybrids; ++k)
			{
				OutputMijk( outFile, i, j, k );
				if( k < numHybrids-1 )
				{
					outFile << " + ";
				}
			}
			outFile << " <= " << numHybrids - listTreeDists[i][j] << endl;;
		}
	}

    outFile << "\nBinary " << endl;
	// each tree (including the first one)
	for( int i = 0; i<(int)listTreeDists.size(); ++i )
	{
		for(int j=0; j<numHybrids; ++j)
		{
			OutputXij( outFile, i, j );
			outFile  <<  endl;
		}
	}

	for( int i = 0; i<(int)listTreeDists.size(); ++i )
	{
		for( int j = i+1; j<(int)listTreeDists.size(); ++j )
		{
			for(int k=0; k<numHybrids; ++k)
			{
				OutputMijk( outFile, i, j, k );
				outFile << endl;
			}
		}
	}
}


