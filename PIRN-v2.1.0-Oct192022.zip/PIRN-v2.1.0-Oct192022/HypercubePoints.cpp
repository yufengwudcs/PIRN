#include "HypercubePoints.h"
#include "Utils3.h"

/////////////////////////////////////////////////////////////////////////////////
//

HPPEntry :: HPPEntry()
{
}

void HPPEntry :: AddPairInfo( const pair<int,int> &pp, int count )
{
	if( mapNumDiffBits.find( pp ) == mapNumDiffBits.end() )
	{
		mapNumDiffBits.insert( map< pair<int,int>, int>  :: value_type(pp, count) );
	}
	else
	{
		mapNumDiffBits[pp] += count;
	}
}

// initialize by looking at a single bit
void HPPEntry :: FindCandiateAtSingleBit(int numPoints, vector<HPPEntry> &listCandidates)
{
	// 
	for( int nr = 0; nr <numPoints-1; ++nr)
	{
		// Now, we enumerate all combinations of nr rows
		// We do this by first get the position vector of each such cases
		vector<int> posvec;
		GetFirstCombo( nr, numPoints-1, posvec );
		while(true)
		{
			// Create a vector, and set the index vector
			set<int> set0, set1;
			for( int i=0;i<(int)posvec.size(); ++i )
			{
				set0.insert( posvec[i] );
			}
			set0.insert(numPoints-1);
			PopulateSetWithInterval( set1, 0, numPoints-1 );
			SubtractSets( set1, set0 );

			// 
			HPPEntry hppEntry;
			for( set<int> :: iterator ittg1 = set0.begin(); ittg1 != set0.end(); ++ittg1 )
			{
				for( set<int> :: iterator ittg2 = set1.begin(); ittg2 != set1.end(); ++ittg2 )
				{
					pair<int,int> pp(*ittg1, *ittg2);
					OrderInt(pp.first, pp.second);

					//
					hppEntry.AddPairInfo( pp, 1 );
				}
			}
//cout << "Create one candidate:  ";
//hppEntry.Dump();
			listCandidates.push_back( hppEntry );

			// Get the next position
			if( GetNextCombo( nr, numPoints-1, posvec ) == false )
			{
				break;
			}
		}

	}
}

// merge the count of two records
void HPPEntry :: MergeWith( const HPPEntry &entryToMerge )
{
//cout << "MergeWith: entry to merge: ";
//const_cast<HPPEntry &>(entryToMerge).Dump();
//cout << "current entry: ";
//Dump();
	// mapNumDiffBits
	for( map< pair<int,int>, int> :: iterator it =  const_cast<HPPEntry &>(entryToMerge).mapNumDiffBits.begin(); 
		it != const_cast<HPPEntry &>(entryToMerge).mapNumDiffBits.end(); ++it )
	{
		this->AddPairInfo( it->first, it->second );
	}
//cout << "After merge: ";
//Dump();
}

void HPPEntry :: ApplyBound(map< pair<int, int>, int > &mapDistPairwise)
{
	for( map< pair<int,int>, int> :: iterator it =  this->mapNumDiffBits.begin(); it != this->mapNumDiffBits.end(); ++it )
	{
		int distNew = -1;
		if( mapDistPairwise.find( it->first) == mapDistPairwise.end()  )
		{
			distNew = 0;
		}
		else if(mapDistPairwise[it->first] < it->second )
		{
			distNew = mapDistPairwise[it->first];
		}
		if( distNew >= 0)
		{
			this->mapNumDiffBits[it->first] = distNew;
		}
	}
}


// is the distance satisfying the min requirements?
bool HPPEntry :: IsCompatible(  map< pair<int, int>, int > &mapDistPairwise ) 
{
	//for( map< pair<int,int>, int> :: iterator it =  this->mapNumDiffBits.begin(); it != this->mapNumDiffBits.end(); ++it )
	//{
	//	if( mapDistPairwise.find(it->first) != mapDistPairwise.end() && mapDistPairwise [it->first] > it->second  )
	//	{
	//		return false;
	//	}
	//}
	for( map< pair<int,int>, int> :: iterator it =  mapDistPairwise.begin(); it != mapDistPairwise.end(); ++it )
	{
		if(  this->mapNumDiffBits.find(it->first) == mapDistPairwise.end() ||  this->mapNumDiffBits[it->first] < it->second  )
		{
			return false;
		}
	}
cout << "-------------------This entry is good: ";
this->Dump();
	return true;
}

void HPPEntry :: Dump()
{
	for( map< pair<int,int>, int> :: iterator it =  this->mapNumDiffBits.begin(); it != this->mapNumDiffBits.end(); ++it )
	{
		cout << "[" << it->first.first << ", " << it->first.second << "]: " << it->second << "   ";
	}
	cout << endl;
}


/////////////////////////////////////////////////////////////////////////////////
//

HypercubePointsPlacement :: HypercubePointsPlacement( int numPt, const map< pair<int, int>, int > &mapDist ) 
 : numPoints(numPt), mapDistPairwise(mapDist), szLastBuildHPP(0)
{
}

HypercubePointsPlacement :: HypercubePointsPlacement( const vector< vector<int> > &vecDistPairwise )
{
	// create a corresponding map
	this->numPoints = vecDistPairwise.size();
	for(int i=0; i<(int)vecDistPairwise.size(); ++i)
	{
		for(int j=i+1; j<(int)vecDistPairwise.size(); ++j)
		{
			pair<int,int> pp(i,j);
			mapDistPairwise.insert( map<pair<int,int>,int> :: value_type(pp, vecDistPairwise[i][j] ) );
		}
	}
	szLastBuildHPP = 0;
}

// test whether it works for some m-dimensional 
bool HypercubePointsPlacement :: IsFeasibleFor(int dimHC)
{
cout << "***** IsFeasibleFor: dimHC = " << dimHC << endl;
	// 
	if( dimHC <= 0 )
	{
		return false;
	}
	int numPoints = GetNumPoints();
	set< HPPEntry > setCurrHPPEntries = this->setLastBuiltHPPEntries;

	// pre-build one-bit entry
	vector<HPPEntry> listOneBitCandidates;
	HPPEntry :: FindCandiateAtSingleBit(numPoints, listOneBitCandidates);

	// try in the increasing order of sizes
	int szStart = 1;
	if( szStart < this->szLastBuildHPP+1 )
	{
		szStart = this->szLastBuildHPP+1;
	}
cout << "szStart = " << szStart << endl;
	for(int sz=szStart; sz<= dimHC; ++sz)
	{
		// create a list of candidates at a single bit
//cout << "Number of candidate entries = " << listOneBitCandidates.size() << endl;

		// 
		if(setCurrHPPEntries.size() == 0)
		{
			for(int ii=0; ii<(int)listOneBitCandidates.size(); ++ii)
			{
				setCurrHPPEntries.insert( listOneBitCandidates[ii] );
			}
		}
		else
		{
			set< HPPEntry > setNewHPPEntries;
			for( set< HPPEntry > :: iterator itt = setCurrHPPEntries.begin(); itt != setCurrHPPEntries.end(); ++itt )
			{
				for(int ii=0; ii<(int)listOneBitCandidates.size(); ++ii)
				{
					HPPEntry hppEntry = *itt;
					hppEntry.MergeWith( listOneBitCandidates[ii] );
					hppEntry.ApplyBound(mapDistPairwise);
//cout << "After merge: ";
//hppEntry.Dump();
					setNewHPPEntries.insert( hppEntry );
				}
			}
			// set the new list of candidates
			setCurrHPPEntries = setNewHPPEntries;
		}
cout << "Partial hypercube size = " << sz << ", number of kept entries = " << setCurrHPPEntries.size() << endl;
	}

	// remember what we have done so far
	if( dimHC > this->szLastBuildHPP )
	{
		this->szLastBuildHPP = dimHC;
		this->setLastBuiltHPPEntries = setCurrHPPEntries;
	}

	// check to see if one record is good
	for( set< HPPEntry > :: iterator itt = setCurrHPPEntries.begin(); itt != setCurrHPPEntries.end(); ++itt )
	{
		// 
		if( const_cast<HPPEntry &>(*itt).IsCompatible( mapDistPairwise ) == true )
		{
			return true;
		}
	}

	return false;
}

