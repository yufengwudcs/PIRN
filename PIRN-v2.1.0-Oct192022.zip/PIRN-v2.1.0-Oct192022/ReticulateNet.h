#ifndef RETICULATE_NETWORK_H
#define  RETICULATE_NETWORK_H

#include <map>
#include <vector>
#include <set>
using namespace std;

#include "MarginalTree.h"
#include "PhylogenyTreeBasic.h"

// define the interface for a general network
typedef int RN_NODE_ID;
typedef int RN_RETICULATE_ID;



class ReticulateNetwork
{
public:
	// editing
	virtual RN_NODE_ID CreateNode() = 0;
	virtual void AddTreeEdge( const RN_NODE_ID &idAncestor, const RN_NODE_ID &idDescendent ) = 0;
	virtual RN_RETICULATE_ID AddReticulateEdges(const RN_NODE_ID &idAncLeft, 
		const RN_NODE_ID &idAncRight, const RN_NODE_ID &idDescendent) = 0;
	virtual void UpdateEdge( const RN_NODE_ID &idAncLeft, 
		const RN_NODE_ID &idAncRight, const RN_NODE_ID &idDescendent ) = 0;
	virtual void SetLeafId(const RN_NODE_ID &nid, int leafId) = 0;
	virtual void Init() = 0;

	// querying
	int GetTotNumNodes() {return GetNumReticulateNodes() + GetNumTreeEdges() + 1;}
	virtual int GetNumLeaves() const = 0;
	virtual int GetNumReticulateNodes() const = 0;
	virtual int GetNumTreeEdges()  const = 0;		// exclude the root, which does not belong to either tree or Ret
	//virtual void GetTreeEdge(int etid, RN_NODE_ID &idAnc, RN_NODE_ID &idDesc) const = 0;
	virtual int GetNumReticulateEdges() const = 0;		// exclude the root, which does not belong to either tree or Ret
	//virtual void GetReticulateEdge(int erid, RN_NODE_ID &idAncLeft, RN_NODE_ID &idAncRight, RN_NODE_ID &idDesc) const = 0;
	virtual bool IsTreeEdge(const RN_NODE_ID &idAnc, const RN_NODE_ID &idDesc)  = 0;
	virtual bool IsReticulateEdge(const RN_NODE_ID &idAnc, const RN_NODE_ID &idDesc, bool &fLeft)  = 0;
	virtual void GetDirectParents(const RN_NODE_ID &idnode, vector<RN_NODE_ID> &listNodesPar)  = 0;
	virtual void GetAllAncestors(const RN_NODE_ID &idnode, set<RN_NODE_ID> &listNodesAnces)  = 0;	// get all direct or indirect ancestors
	virtual RN_RETICULATE_ID GetReticulateId(const RN_NODE_ID &idDesc)  = 0;		// return -1 if not a reticulate node
	virtual void GetLeafNodes( vector<int> &listLeafIds )  = 0;
	virtual void GetAllNodes(set<RN_NODE_ID> &setNodes) = 0;
	virtual void GetReticulateNodes(set<RN_NODE_ID> &setNodes) = 0;
	virtual RN_NODE_ID GetNodeIdFromLeafId(int leafId) = 0;
	virtual RN_NODE_ID GetRoot() = 0;
	virtual void GetImmDescendents(const RN_NODE_ID &nodeid, vector<RN_NODE_ID> &listDescs) = 0;
	virtual bool IsNodeLeaf(const RN_NODE_ID &nodeid) = 0;
	virtual bool IsNodeReticulate(const RN_NODE_ID &nodeid) = 0;
	virtual int GetLeafId(const RN_NODE_ID &nodeid) = 0;
	virtual void RetrieveATree(const vector<int> &choicesRNs, map<RN_NODE_ID,RN_NODE_ID >& mapEdges ) = 0;
	virtual void RetriveEmbeddedTree( map<RN_NODE_ID,RN_NODE_ID> &mapRNChoices, PhylogenyTreeBasic *treeEmbedded) = 0;
	virtual void RetriveAllEmbeddedTrees( vector<PhylogenyTreeBasic *> &listEmbeddedTrees ) = 0;
	virtual void OutputGML(const char *filename) = 0;
	virtual RN_NODE_ID GetLeafRoot() = 0;
	virtual RN_NODE_ID GetLeafRootSib() = 0;
	virtual bool IsAcyclic() = 0;
	virtual void FindDisjointAncesTwinPaths( vector< pair<int,int> > &listEnclosedPaths, vector< pair<int,int> > &listEnclosingPaths ) = 0;
	virtual bool IsSibling(int nid1, int nid2) = 0;
	virtual void ConvToMTree( map<RN_NODE_ID,RN_NODE_ID >& mapEdges, MarginalTree &mTree ) = 0;
};


// a specific implementation
class ReticulateNetworkImp : public ReticulateNetwork
{
public:
	ReticulateNetworkImp();
	virtual ~ReticulateNetworkImp() {}

	// editing
	void InitWithMTree( MarginalTree &mTree  );
	virtual RN_NODE_ID CreateNode() ;
	virtual void AddTreeEdge( const RN_NODE_ID &idAncestor, const RN_NODE_ID &idDescendent );
	virtual RN_RETICULATE_ID AddReticulateEdges(const RN_NODE_ID &idAncLeft, 
		const RN_NODE_ID &idAncRight, const RN_NODE_ID &idDescendent);
	virtual void UpdateEdge( const RN_NODE_ID &idAncLeft, 
		const RN_NODE_ID &idAncRight, const RN_NODE_ID &idDescendent );
	virtual void SetLeafId(const RN_NODE_ID &nid, int leafId);
	virtual void Init();

	// querying
	virtual int GetNumLeaves() const;
	virtual int GetNumReticulateNodes() const;
	virtual int GetNumTreeEdges() const;		// exclude the root, which does not belong to either tree or Ret
	//virtual void GetTreeEdge(int etid, RN_NODE_ID &idAnc, RN_NODE_ID &idDesc)  const;
	virtual int GetNumReticulateEdges() const;		// exclude the root, which does not belong to either tree or Ret
	//virtual void GetReticulateEdge(int erid, RN_NODE_ID &idAncLeft, RN_NODE_ID &idAncRight, RN_NODE_ID &idDesc)  const;
	virtual bool IsTreeEdge(const RN_NODE_ID &idAnc, const RN_NODE_ID &idDesc)  ;
	virtual bool IsReticulateEdge(const RN_NODE_ID &idAnc, const RN_NODE_ID &idDesc, bool &fLeft)  ;
	virtual void GetDirectParents(const RN_NODE_ID &idnode, vector<RN_NODE_ID> &listNodesPar)  ;
	virtual void GetAllAncestors(const RN_NODE_ID &idnode, set<RN_NODE_ID> &listNodesAnces)  ;	// get all direct or indirect ancestors
	virtual RN_RETICULATE_ID GetReticulateId(const RN_NODE_ID &idDesc)  ;		// return -1 if not a reticulate node
	virtual void GetLeafNodes( vector<int> &listLeafIds ) ;
	virtual void GetAllNodes(set<RN_NODE_ID> &setNodes) { setNodes = setNetNodes; }
	virtual void GetReticulateNodes(set<RN_NODE_ID> &setNodes);
	virtual RN_NODE_ID GetNodeIdFromLeafId(int leafId) ;
	virtual RN_NODE_ID GetRoot();
	virtual void GetImmDescendents(const RN_NODE_ID &nodeid, vector<RN_NODE_ID> &listDescs);
	virtual bool IsNodeLeaf(const RN_NODE_ID &nodeid);
	virtual bool IsNodeReticulate(const RN_NODE_ID &nodeid);
	virtual int GetLeafId(const RN_NODE_ID &nodeid);
	virtual void RetrieveATree(const vector<int> &choicesRNs, map<RN_NODE_ID,RN_NODE_ID >& mapEdges );
	virtual void RetriveEmbeddedTree( map<RN_NODE_ID,RN_NODE_ID> &mapRNChoices, PhylogenyTreeBasic *treeEmbedded);
	virtual void RetriveAllEmbeddedTrees( vector<PhylogenyTreeBasic *> &listEmbeddedTrees );
	virtual void OutputGML(const char *filename);
	virtual RN_NODE_ID GetLeafRoot();
	virtual RN_NODE_ID GetLeafRootSib();
	virtual bool IsAcyclic();
	virtual void FindDisjointAncesTwinPaths( vector< pair<int,int> > &listEnclosedPaths, vector< pair<int,int> > &listEnclosingPaths );
	virtual bool IsSibling(RN_NODE_ID nid1, RN_NODE_ID nid2);
	virtual void ConvToMTree( map<RN_NODE_ID,RN_NODE_ID >& mapEdges, MarginalTree &mTree );

	// more about outputting format
	void OutputGMLOrigTaxa(const char *filename);
	void SetOrigTreeInfo(int numTaxaUser, const vector< pair<int,int> > &listRemovedPairs, const vector< int > &listSurvivePos, TaxaMapper *pMapperTMapInfo);

private:
	void FindAcyclicOrder( vector<int> &listNodesOrder );
	bool IsImmParent(RN_NODE_ID nid1, RN_NODE_ID nidpar);
	bool IsNodeUnder( map<RN_NODE_ID,RN_NODE_ID >& mapEdges, RN_NODE_ID nodeid, RN_NODE_ID nodepar );

	int nidNext;
	int reticulateIdNext;
	map<RN_NODE_ID, RN_NODE_ID> mapTreeEdges;	// first: descendent, second: parent
	map<RN_NODE_ID, pair<RN_NODE_ID,RN_NODE_ID> > mapReticulateEdges;	// first: descendent, second: parent left and right
	map<RN_NODE_ID, int> mapRNIdToLeafId;
	map<int, RN_NODE_ID> mapLeafIdToRNId;
	map<RN_NODE_ID, RN_RETICULATE_ID> mapRNIdToReticulateId;
	map<RN_RETICULATE_ID, RN_NODE_ID> mapReticulateIdToRNId;
	set<RN_NODE_ID> setNetNodes;

	// related to the original user input trees
	map<RN_NODE_ID,int> mapIdUsedTo2ndTaxaId;
	int numTaxaUser;
	vector< pair<int,int> > listRemovedPairs;
	vector< int > listSurvivePos;
	TaxaMapper *pMapperTMapInfo;
};


#endif
