#include "Utils.h"
#include "Utils2.h"
#include "Utils3.h"
#include "ReticulateILP.h"
#include "ILPSolver.h"
#include "SprILP.h"
#include "HypercubePoints.h"
#include <cmath>

///////////////////////////////////////////////////////////////////////////////////////////////////////
// utility for inserting a tree in an optimal way into a given network
SWInsTreeILP :: SWInsTreeILP(ReticulateNetwork &rn, MarginalTree &tI) : reticulateNet(rn), treeIns(tI)
{
	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	// useful properties of network
	this->numNodesInN = reticulateNet.GetTotNumNodes();
	set<RN_NODE_ID> setNodes;
	reticulateNet.GetAllNodes( setNodes );
	YW_ASSERT_INFO( (int)setNodes.size() == numNodesInN, "Mismatch in set size" );
	// convert to vector
	//vector<RN_NODE_ID> vecNodes;
	PopulateVecBySet( this->vecRNNodes, setNodes );

	// let idNewNodeStart be one more than the largest one
	RN_NODE_ID nMaxNid = 0;
	for(int i=0; i<(int)this->vecRNNodes.size(); ++i)
	{
		if( vecRNNodes[i] > nMaxNid )
		{
			nMaxNid = vecRNNodes[i];
		}
	}
	idNewNodeStart = nMaxNid + 1;



	// collect possible ancestors
	//vector< vector<RN_NODE_ID> > vecRNAncesNodes; 
	//map<RN_NODE_ID, set<RN_NODE_ID> > mapAncesNodesSet; 
    for( int i= 0; i< (int)vecRNNodes.size() ; ++i  )
	{
		set<RN_NODE_ID> listNodesAnces;
		reticulateNet.GetAllAncestors(vecRNNodes[i], listNodesAnces);
		vector<RN_NODE_ID> vecNodesAnces;
		PopulateVecBySet( vecNodesAnces, listNodesAnces );
//cout << "For node " << vecRNNodes[i] << ", ancestor nodes = ";
//DumpIntVec(vecNodesAnces);
		vecRNAncesNodes.push_back( vecNodesAnces );
		mapRNAncesNodesSet.insert( map<RN_NODE_ID, set<RN_NODE_ID> > :: value_type( vecRNNodes[i], listNodesAnces) );
	}
	this->numReticulateNodes = reticulateNet.GetNumReticulateNodes();
	//vector<int> listLeafIds;
	reticulateNet.GetLeafNodes( this->listRNLeafIds ) ;
//cout << "List of leaf ids = ";
//DumpIntVec(listRNLeafIds);

	// collect info from tree
	//map< pair<int,int>, set<int> > mapPathNodesLeafPairsInT;
    for( int i= 0; i< treeIns.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< treeIns.GetNumLeaves(); ++j)
        {
            // first we need to find MRCA of i,j. 
            // note that we actually want to exluce MRCA, but include i,j!
            set<int> listPathNodes;
            int n1=i, n2 = j;
            listPathNodes.insert(i);
            listPathNodes.insert(j);
            while( n1 != n2 )
            {
                // we alternatively move up, depend on which one is smaller
                int nodeNew;
                if( n1 < n2  )
                {
                    // move n1
                    n1 = treeIns.GetParent(n1);
                    nodeNew = n1;
                }
                else
                {
                    // move n2
                    n2 = treeIns.GetParent(n2);
                    nodeNew = n2;
                }
                // save this when n1 != n2
                if( n1 != n2 )
                {
                    listPathNodes.insert( nodeNew );
                }
            }
            // pop up the last item MRCA
            //listPathNodes.pop_back();
            listPathNodes.erase(  n1  );
            pair<int,int> pp(i,j);
			mapPathNodesLeafPairsInT.insert( map< pair<int,int>, set<int> > :: value_type(pp, listPathNodes)  );
//cout << "For leaves " << i << ", " << j << ", list of path nodes = ";
//DumpIntSet(listPathNodes);
        }
    }

	// how many AVars are there up to (before) a certain index?
	int indexAvar = 0;
	for(int i=0;i<(int)vecRNNodes.size(); ++i)
	{
		pair<int,int> pp(vecRNNodes[i],vecRNNodes[i]);
		mapAVarIndex.insert( map<pair<int,int>, int> :: value_type(pp, indexAvar++) );

		for( int j=0; j<(int)vecRNAncesNodes[i].size(); ++j )
		{
			//
			pair<int,int> pp(vecRNNodes[i],vecRNAncesNodes[i][j]);
			mapAVarIndex.insert( map<pair<int,int>, int> :: value_type(pp, indexAvar++) );

		}
	}

}

int SWInsTreeILP :: Calculate( SW_INS_TREE_RES &result )
{
	// Return the cost of adding this tree
	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	// formulate the problem first
	this->numCVars = treeIns.GetTotNodesNum();
	this->numRVars = this->numReticulateNodes;
	this->numAVars = this->vecRNNodes.size();
    for( int i= 0; i< (int)vecRNNodes.size() ; ++i  )
    {
        for( int j= 0; j< (int)vecRNAncesNodes[i].size() ; ++j  )
        {
			numAVars ++;
        }
    }
	int numTotVarsNum = numCVars + numRVars + numAVars;

	// now create the constraint list
	vector<ILP_CONSTRAINT> listConstraints;
	ConsILPConstraints( listConstraints );


	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	// call ILP solver
    ILPSolver *pILPSolver;
#ifdef LPSOLVER_CPLEX
	pILPSolver = new CPlexILPSolver;
#endif

#ifdef LPSOLVER_GLPK
	pILPSolver = new GLPKILPSolver;
#endif

	// Now, we first create a LP problem
	pILPSolver->CreateProblem( listConstraints.size(), numTotVarsNum, true );    // we want to minimize

	///////////////////////////////////////////////////////////////////////////////////////////////
    // setup variables (coluns)
    //int c = 0;
    // first part is the Ci
	for(int ni = 0; ni < this->numCVars; ++ni )
	{
        int realVarId = GetCVarPos( ni );
	    char objName[1280];
		objName[0] = 'C'; 
		sprintf(&objName[1], ",%d", ni );
        // the var can be any of the integer value
        // How do we assign coefficient to it
        double coeff = 1.0;
		pILPSolver->SetupVar( realVarId, objName, coeff, true);	
	}

	for(int ni = 0; ni < this->numRVars; ++ni )
	{
        int realVarId = GetRVarPos( ni, this->numCVars );
	    char objName[1280];
		objName[0] = 'R'; 
		sprintf(&objName[1], ",%d", ni );
        // the var can be any of the integer value
        // How do we assign coefficient to it
        double coeff = 0.0;
		pILPSolver->SetupVar( realVarId, objName, coeff, true);	
	}

	// ancestral relationship vars
    for( map<pair<int,int>, int> :: iterator it = mapAVarIndex.begin(); it != mapAVarIndex.end(); ++it )
    {
        int realVarId = GetAVarPos(it->first.first, it->first.second, this->numCVars + this->numRVars );
	    char objName[1280];
		objName[0] = 'A'; 
		sprintf(&objName[1], "%d,%d", it->first.first, it->first.second );
		pILPSolver->SetupVar( realVarId, objName, 0.0, true);	
    }


    //setup constraints
    int rcons = 0;
    for( int i = 0; i < (int) listConstraints.size(); ++i)
    {
		HAP_ILP_SENSE bdType = HAP_ILP_LB;
		if( listConstraints[i].fLB == false )
		{
			bdType = HAP_ILP_UB;
		}
        pILPSolver->AddConstraint( rcons++, listConstraints[i].nonzeroPos, listConstraints[i].coefficients, 
			listConstraints[i].rhsBound, bdType);
    }


    //solve and retrive the result
	ILPSolution solILP(0, numTotVarsNum-1);
	solILP.Init( numTotVarsNum, numTotVarsNum, NULL);
	bool f = pILPSolver->Solve( solILP );
	if( f == false)
	{
		cout << "Fail to solve interger program." << endl;
		exit(-1); 
	}
//cout << "The objective = " << solILP.optObjective << endl; 
    int res = (int)(solILP.optObjective + 0.01) ;


    // also keep track of which edges are cut
    FindSolInILP( solILP, result );   

    // free up ILP
    delete pILPSolver;

	return res;
}

void SWInsTreeILP :: UpdateNetwork(SW_INS_TREE_RES &resultIns )
{
//cout << "Entering UpdateNetwork...\n";
	// find list of update actions based on the results
	map<RN_NODE_ID,RN_NODE_ID > mapEdges;
	reticulateNet.RetrieveATree(resultIns.choicesRNs, mapEdges );

	// here are the edges
//cout << "The displayed tree in N contains the following edges\n";
//DumpTreeMap(mapEdges);

	// first, find the re-attachment nodes
	vector< RN_NODE_ID > listMAFSubtreeRoots;
	vector< set<RN_NODE_ID> > listCompleteSTs;

//	RN_NODE_ID rootId = reticulateNet.GetRoot();
//	RN_NODE_ID leafNode = -1;
//cout << "UpdateNetwork: rootid = " << rootId << endl;
//	int indexRootCluster = -1;
	vector< set<RN_NODE_ID> > listMAFLeafNodes;
	for( int i=0; i<(int) resultIns.resMAFParts.size(); ++i )
	{
		set<RN_NODE_ID> nodesLvs;
		for( set<int> :: iterator itt = resultIns.resMAFParts[i].begin(); itt != resultIns.resMAFParts[i].end(); ++itt  )
		{
			nodesLvs.insert( reticulateNet.GetNodeIdFromLeafId( *itt ) );
		}
		listMAFLeafNodes.push_back( nodesLvs );

		// find the subtree root
		RN_NODE_ID ridsr = FindMRCA( mapEdges, nodesLvs);
		listMAFSubtreeRoots.push_back(ridsr);

		set<RN_NODE_ID> nodesInSubtree;
		FindNodesInSubtree(mapEdges, nodesLvs, nodesInSubtree);
		listCompleteSTs.push_back( nodesInSubtree  );
//cout << "Tree " << i << ": complete subtree = ";
//DumpIntSet(nodesInSubtree);
	}

//	YW_ASSERT_INFO( indexRootCluster >= 0, "Root must appear in the cluster roots" );
//cout << "indexRootCluster = " << indexRootCluster << endl;

	// find the order of derivation
	vector<int> vecOrderAttachSTrees;
	FindTreeAttachOrder( listCompleteSTs, vecOrderAttachSTrees );
//cout << "**In UpdateNetwork, the order of tree attachment: ";
//DumpIntVec( vecOrderAttachSTrees);

	//set<RN_NODE_ID> stsDone;
	//stsDone.insert(listMAFSubtreeRoots[indexRootCluster]);
	//set<RN_NODE_ID> baseSubtree = listCompleteSTs[indexRootCluster];
	map<RN_NODE_ID,RN_NODE_ID > mapEdgesCurrTree;
	// build the subtree
	ExtractSubtree( resultIns, listCompleteSTs[vecOrderAttachSTrees[0] ], mapEdgesCurrTree );

	// if map is empty, we simply add a single tree edge into it
	if(mapEdgesCurrTree.size() == 0)
	{
		RN_NODE_ID rootId = reticulateNet.GetRoot();
		RN_NODE_ID leafNode =  reticulateNet.GetLeafRoot();
		RN_NODE_ID leafNodeSib =  reticulateNet.GetLeafRootSib();

		//vector<RN_NODE_ID> vecRootDescs;
		//reticulateNet.GetImmDescendents( rootId, vecRootDescs);
		//if( reticulateNet.IsNodeLeaf(vecRootDescs[0]) )
		//{
		//	leafNode = vecRootDescs[0];
		//}
		//else
		//{
		//	leafNode = vecRootDescs[1];
		//}
		//YW_ASSERT_INFO( reticulateNet.IsNodeLeaf(leafNode) == true, "The network is not in right format: must have a leaf node attached to root" );
		mapEdgesCurrTree.insert( map<RN_NODE_ID,RN_NODE_ID > :: value_type( leafNode, rootId ) );
		mapEdgesCurrTree.insert( map<RN_NODE_ID,RN_NODE_ID > :: value_type( leafNodeSib, rootId ) );
	}

	set<int> baseTreeLvs = resultIns.resMAFParts[vecOrderAttachSTrees[0] ];


	for( int i=1; i<(int)vecOrderAttachSTrees.size(); ++i )
	{
//cout << "Adding subtree " << vecOrderAttachSTrees[i] << endl;
		int index = vecOrderAttachSTrees[i];

		RN_NODE_ID ridattach = FindSibInTN( mapEdgesCurrTree, resultIns.resMAFParts[index], baseTreeLvs );

//cout << "Choose subtree " << index << " to attach (with node " << ridattach << ")\n";

		// update the trees
		UnionSets( baseTreeLvs, resultIns.resMAFParts[index] );

		// update current tree
		SW_TREE_UPDATE swTreeUpdates;
		UpdateCurrTree( resultIns, mapEdgesCurrTree, listCompleteSTs[index], ridattach, swTreeUpdates );
		// finally convert to nextwork update
		ConvTreeUpdateToNW( swTreeUpdates, resultIns );
	}


}


RN_NODE_ID SWInsTreeILP :: FindMRCA(map<RN_NODE_ID,RN_NODE_ID > &mapEdges, const set<RN_NODE_ID> &setLeaves)
{
	set<RN_NODE_ID> nodesInSubtree;
	return FindNodesInSubtree(mapEdges, setLeaves, nodesInSubtree);
#if 0
	// we do it in rounds: each round, we move backwards one time
	YW_ASSERT_INFO(setLeaves.size() > 0, "Can ont allow empty leaf sets");
	set<RN_NODE_ID> curNodes = setLeaves;
	while( curNodes.size() > 1 )
	{
//cout << "curNodes = ";
//DumpIntSet( curNodes );
		set<RN_NODE_ID> nextNodes;
		for( set<RN_NODE_ID>:: iterator it = curNodes.begin(); it != curNodes.end(); ++it )
		{
			// 
			//YW_ASSERT_INFO(mapEdges.find( *it) != mapEdges.end(), "Fatal error: the node is not in the edges");
			if(mapEdges.find( *it) != mapEdges.end())
			{
				nextNodes.insert( mapEdges[*it]  );
			}
			else
			{
				// otherwise keep the same node (actually very likely to be the root already, but let us pretend not knowning)
				nextNodes.insert( *it  );
			}
		}
		// move on to the next
		curNodes = nextNodes;
	}
	YW_ASSERT_INFO(curNodes.size() ==1, "Strange error here");
	return *(curNodes.begin());
#endif
}


RN_NODE_ID SWInsTreeILP :: FindNodesInSubtree(map<RN_NODE_ID,RN_NODE_ID > &mapEdges, const set<RN_NODE_ID> &setLeaves, set<RN_NODE_ID> &nodesInSubtree)
{
//cout << "In FindNodesInSubtree: tree map = ";
//DumpTreeMap(mapEdges);
//cout << "setLeaves: ";
//DumpIntSet( setLeaves );
	// find nodes in the subtree, return the root of the subtree
	YW_ASSERT_INFO(setLeaves.size() > 0, "Can ont allow empty leaf sets");

	// take a simple approach: try all nodes in tree to see if it is ancestral to each, and 
	// is the lowest one

	// get all the nodes
	set<RN_NODE_ID> setANs;
	for( map<RN_NODE_ID,RN_NODE_ID > :: iterator it = mapEdges.begin(); it != mapEdges.end(); ++it)
	{
		setANs.insert( it->first);
		setANs.insert( it->second);
	}

	RN_NODE_ID res = -1;
	for( set<RN_NODE_ID > :: iterator it = setANs.begin(); it != setANs.end(); ++it)
	{
		bool fAnces = true;
		for( set<RN_NODE_ID> :: iterator itt =  setLeaves.begin(); itt != setLeaves.end(); ++itt )
		{
			if( IsNodeAncestralInTTo(mapEdges, *itt, *it) == false )
			{
				fAnces = false;
				break;
			}
		}
		if( fAnces == true && ( res < 0 ||   IsNodeAncestralInTTo(mapEdges, res, *it) == false  ) )
		{
			res = *it;
		}
	}
	// now get all the nodes under res
	for( set<RN_NODE_ID> :: iterator itt =  setLeaves.begin(); itt != setLeaves.end(); ++itt )
	{
		RN_NODE_ID curn = *itt;
		while( curn != res )
		{
			nodesInSubtree.insert( curn );
			curn = mapEdges[curn];
		}
	}
	// make sure root id is in
	nodesInSubtree.insert( res );
	return res;
}


bool SWInsTreeILP :: AreTwoSTIntersectOnPathToRootInT( const set<RN_NODE_ID> &setNodeIds1, const set<RN_NODE_ID> &setNodeIds2 )
{
	// find whether subtree T1 intersects with subtree T2 on its (T1)'s way to root in MarginalTree treeIns
	// CAUTION: INS(T1, T2) = false does not imply INS(T2, T1) = false
	set<int> leafIdSet1, leafIdSet2;
	for( set<RN_NODE_ID> :: iterator it = setNodeIds1.begin(); it != setNodeIds1.end(); ++it )
	{
		int leafId1 = reticulateNet.GetLeafId( *it );
		if(leafId1 >= 0)
		{
			leafIdSet1.insert(leafId1);
		}
	}
	for( set<RN_NODE_ID> :: iterator it = setNodeIds2.begin(); it != setNodeIds2.end(); ++it )
	{
		int leafId2 = reticulateNet.GetLeafId( *it );
		if(leafId2 >= 0)
		{
			leafIdSet2.insert(leafId2);
		}
	}
//cout << "AreTwoSTIntersectOnPathToRootInT: Leaf set T1: ";
//DumpIntSet( leafIdSet1 );
//cout << "AreTwoSTIntersectOnPathToRootInT: Leaf set T2: ";
//DumpIntSet( leafIdSet2 );
	YW_ASSERT_INFO(leafIdSet1.size() >= 0 && leafIdSet2.size() >= 0, "Bogus MAF: no leaf in a tree.");
	int mrcast1, mrcast2;
	mrcast1 = treeIns.GetMRCAForNodes( leafIdSet1 );
	mrcast2 = treeIns.GetMRCAForNodes( leafIdSet2 );

	// now get the list of nodes on mrcast1 to root
	int curn = mrcast1;
	set<int> setAllAnces1;
	while(curn >= 0)
	{
		setAllAnces1.insert(curn);
		curn = treeIns.GetParent(curn);
	}

	if(  setAllAnces1.find( mrcast2 ) != setAllAnces1.end() )
	{
		// yes, intersect
		return true;
	}
	else
	{
		return false;
	}
}


RN_NODE_ID SWInsTreeILP :: FindSibInTN( map<RN_NODE_ID,RN_NODE_ID > &mapEdgesCurrTree,  
									   const set<int> &lvLabels, const set<int> &baseTreeLvs )
{
//cout << "In FindSibInTN: lvLabels = ";
//DumpIntSet(lvLabels);
//cout << "In FindSibInTN: baseTreeLvs = ";
//DumpIntSet(baseTreeLvs);
//cout << "current tree = ";
//DumpTreeMap( mapEdgesCurrTree );
	// find in T_N, where the subtree should connect to 
	// note, the passed-in are all in leaf labels (not node ids)
	// For this, first find the sibling in T (the leaf labels)
	// Note we are building a second tree from existing N nodes
	// so mapEdgesCurrTree refers to the second tree we are building
	set<int> lvsSib;
	int lvsMRCA = treeIns.GetMRCAForNodes( lvLabels );
	// use a SLOW approach: get the parent, see if it intersects with the base tree
	int curNode = lvsMRCA;
	while(true)
	{
		// 
		curNode = treeIns.GetParent(curNode);
		// get leaves
		set<int> lvsNew;
		treeIns.GetLeavesUnder(curNode, lvsNew);
//cout << "curNode = " << curNode << ", lvsBelow = ";
//DumpIntSet( lvsNew );
		set<int> sint;
		JoinSets(baseTreeLvs, lvsNew, sint);
		if( sint.size() > 0 )
		{
			lvsSib = sint;
			break;
		}
	}
	YW_ASSERT_INFO( lvsSib.size() > 0, "Fail to find intersection" );
//cout << "lvsSib = ";
//DumpIntSet( lvsSib );

	// now from this set of leaves, find the root in T_N
	set<RN_NODE_ID> setLeaves;
	for( set<int> :: iterator it = lvsSib.begin(); it != lvsSib.end(); ++it )
	{
		setLeaves.insert(reticulateNet.GetNodeIdFromLeafId( *it )  );
	}
//cout << "setLeaves = ";
//DumpIntSet( setLeaves );
//cout << "Before FindMRCA: treemap = ";
//DumpTreeMap( mapEdgesCurrTree );
	RN_NODE_ID rid = FindMRCA( mapEdgesCurrTree, setLeaves);
//cout << "rid = " << rid << endl;


	// problem: if this node is the leaf root
	RN_NODE_ID leafRootId = reticulateNet.GetLeafRoot();
	if( rid == leafRootId)
	{
		//RN_NODE_ID rootId = reticulateNet.GetRoot();
		//vector<RN_NODE_ID> vecRootDescs;
		//reticulateNet.GetImmDescendents( rootId, vecRootDescs);
		//RN_NODE_ID leafNodeSibId;
		//if( leafRootId ==   vecRootDescs[0] )
		//{
		//	leafNodeSibId = vecRootDescs[1];
		//}
		//else
		//{
		//	leafNodeSibId = vecRootDescs[0];
		//}	

		// change to sibid
		//rid = leafNodeSibId;
		rid = reticulateNet.GetLeafRootSib();
	}

	return rid;
}

RN_NODE_ID SWInsTreeILP :: ExtractSubtree( SW_INS_TREE_RES &resultIns, const set<RN_NODE_ID> &subtree, 
		map<RN_NODE_ID,RN_NODE_ID > &mapEdgesSubtree )
{
	// simply call the next
	map<RN_NODE_ID,RN_NODE_ID> mapEdgesFullTree;
	reticulateNet.RetrieveATree(resultIns.choicesRNs, mapEdgesFullTree);
	return ExtractSubtree(mapEdgesFullTree, subtree, mapEdgesSubtree);
}

RN_NODE_ID SWInsTreeILP :: ExtractSubtree( map<RN_NODE_ID,RN_NODE_ID > &mapEdgesFullTree, const set<RN_NODE_ID> &subtree, 
		map<RN_NODE_ID,RN_NODE_ID > &mapEdgesSubtree )
{
//cout << "ExtractSubtree: ";
//cout << "subtree = ";
//DumpIntSet( subtree );
	// extract the subtree to store int he map.
	// return root id for the subtree
	mapEdgesSubtree.clear();
	// simply loop trhough all the nodes in subtree and create an edge for each (except the root)
	RN_NODE_ID rid = -1;
	stack<RN_NODE_ID> stackNodes;
	for( set<RN_NODE_ID> :: iterator it = subtree.begin(); it != subtree.end(); ++it )
	{
		//stackNodes.push( *it );
	//}

	//while( stackNodes.eempty() == false )
	//{
		// 
		RN_NODE_ID curn = *it;
		if( mapEdgesFullTree.find( curn ) != mapEdgesFullTree.end() )
		{
			if( subtree.find( mapEdgesFullTree[curn] ) != subtree.end() )
			{
				mapEdgesSubtree.insert( 	map<RN_NODE_ID,RN_NODE_ID > :: value_type(*it, mapEdgesFullTree[*it] ) );
			}
			else
			{
				rid = *it;
			}
		}
	}
	return rid;
}

void SWInsTreeILP :: UpdateCurrTree( SW_INS_TREE_RES &resultIns, map<RN_NODE_ID,RN_NODE_ID > &mapEdgesCurrTree, 
	const set<RN_NODE_ID> &subtreeToAttach, 
	const RN_NODE_ID &ridattach, SW_TREE_UPDATE &updateTreeStatus )
{
//cout << "In updatecurtree: choiceRN = ";
//DumpIntVec( resultIns.choicesRNs );
	map<RN_NODE_ID,RN_NODE_ID> mapEdgesFullTree;
	reticulateNet.RetrieveATree(resultIns.choicesRNs, mapEdgesFullTree);
	UpdateCurrTree(mapEdgesFullTree, mapEdgesCurrTree, subtreeToAttach, ridattach, updateTreeStatus);
}


void SWInsTreeILP :: UpdateCurrTree( map<RN_NODE_ID,RN_NODE_ID > &mapEdgesFullTree, map<RN_NODE_ID,RN_NODE_ID > &mapEdgesCurrTree, 
	const set<RN_NODE_ID> &subtreeToAttach, 
	const RN_NODE_ID &ridattach, SW_TREE_UPDATE &updateTNStatus )
{
	map<RN_NODE_ID,RN_NODE_ID > mapSubtree;
	RN_NODE_ID ridsubtree = ExtractSubtree(mapEdgesFullTree, subtreeToAttach, mapSubtree);
	// add to current tree
	RN_NODE_ID idpar = CreateNewNode();
//cout << "In UpdateCurrTree: subtree root = " << ridsubtree << ", and its sibling: " << ridattach << ", idpar = " << idpar << endl;

//cout << "Currente tree: ";
//DumpTreeMap(mapEdgesCurrTree);
	// keep track of what changes we have made
	// the way of dividing into new or update is: the new ones has new node
	// as source or destination, while update has a new destination
	YW_ASSERT_INFO( mapEdgesCurrTree.find( ridattach ) != mapEdgesCurrTree.end()
		&& mapEdgesCurrTree.find( ridsubtree ) != mapEdgesFullTree.end(), "Not good"  );
	SW_TREE_UPDATE_RECORD stur;
	stur.subtreeRoot = ridsubtree;
	stur.sibling = ridattach;
	stur.parNew = idpar;
	// YW: 060509: here we can not rely on either the current tree or the full tree
	// because the structure of the network is changing. So we need to get the information
	// from the current network (together with the reticulate choice). URGENT: to get back soon
//	stur.parOrigsr = mapEdgesFullTree[ridsubtree];
//	stur.parOrigsib = mapEdgesCurrTree[ridattach];
	updateTNStatus.listNewConnections.push_back(stur);
	//pair<RN_NODE_ID, RN_NODE_ID> pp2( ridattach, idpar );
	//updateTNStatus.listUpdatedConnections.push_back(pp2);
	//YW_ASSERT_INFO( mapEdgesCurrTree.find( ridattach ) != mapEdgesCurrTree.end(), "Not good"  );
	//pair<RN_NODE_ID, RN_NODE_ID> pp3( idpar, mapEdgesCurrTree[ridattach] );
	//updateTNStatus.listNewConnections.push_back(pp3);

	// now update current tree
	mapEdgesCurrTree.insert( map<RN_NODE_ID,RN_NODE_ID> :: value_type(  idpar,    mapEdgesCurrTree[ridattach] ) );
	mapEdgesCurrTree.insert( map<RN_NODE_ID,RN_NODE_ID> :: value_type(  ridsubtree, idpar    ) );
	mapEdgesCurrTree[ridattach] = idpar;

	// add the rest of edges in the subtree
	for( map<RN_NODE_ID,RN_NODE_ID > :: iterator it = mapSubtree.begin(); it != mapSubtree.end(); ++it )
	{
		mapEdgesCurrTree.insert( *it );
	}
//cout << "mapsubtree = ";
//DumpTreeMap(mapSubtree);
//cout << "After UpdateCurTree: ";
//DumpTreeMap(mapEdgesCurrTree);
//exit(1);
}



void SWInsTreeILP :: ConvTreeUpdateToNW( const SW_TREE_UPDATE &swTreeUpdates, SW_INS_TREE_RES &resultIns )
{
//cout << "-------------------------------------------\n";
//cout << "In ConvTreeUpdateToNW: \n";

	// maintain a list of newly reticulated nodes during update
//	set<RN_NODE_ID> setNewRNs;

	// 
	for( int i = 0; i<(int) swTreeUpdates.listNewConnections.size(); ++i )
	{
//cout << "subtree root = " << swTreeUpdates.listNewConnections[i].subtreeRoot << endl;
//cout << "parNew = " << swTreeUpdates.listNewConnections[i].parNew << endl;
//cout << "sibling = " << swTreeUpdates.listNewConnections[i].sibling << endl;

//#if 0
		// first, subtree root will become a reticulate, no matter whether it is a tree node or not before
		// if it is already, then we need to split the
		// need to find which edge the original one involving is: tree or reticulate?
		//RN_NODE_ID rnsrNew = -1;

		if( reticulateNet.GetReticulateId( swTreeUpdates.listNewConnections[i].subtreeRoot ) < 0  )
		{
			// it was a tree node before, so change it to reticulate node
			SW_NW_UPDATE_RECORD snur;
			snur.descendNode = swTreeUpdates.listNewConnections[i].subtreeRoot;
			//snur.par1Node = swTreeUpdates.listNewConnections[i].parOrigsr;
			// YW: 060609: remove the need for origsr, instead using the network directly
			vector<RN_NODE_ID> listNodesPar;
			reticulateNet.GetDirectParents(swTreeUpdates.listNewConnections[i].subtreeRoot, listNodesPar);
			YW_ASSERT_INFO( listNodesPar.size() == 1, "Not a tree edge as assumed" );
			snur.par1Node = listNodesPar[0];

			snur.par2Node = swTreeUpdates.listNewConnections[i].parNew;
			snur.fUpdate = true;
			UpdateNetworkStep( snur, resultIns, 1);		// YW: 062309, change to be 1???

			// update insertion record: pick the side that follow the original (not the NEW)
			//resultIns.choicesRNs.push_back(0);

//			updateNet.listUpdatedNodes.push_back(snur);
		}
		else
		{
			// need to add a new node (split it as follows)
			// first figure out which parold this srroot inherit from
			// then create a new reticulate node with one parent from 
			// the orig one and one from the new par (with choice taken to the old one)
			// and then update the original ret node (i.e. the srroot)'s parent to this new node
			// but first, find the original par 
			vector<RN_NODE_ID> listNodesPar;
			reticulateNet.GetDirectParents(swTreeUpdates.listNewConnections[i].subtreeRoot, listNodesPar);
//cout << "ConvTreeUpdateToNW: For root = " << swTreeUpdates.listNewConnections[i].subtreeRoot << ", its imm par = ";
//DumpIntVec(listNodesPar);
			YW_ASSERT_INFO( listNodesPar.size() == 2, "Not a tree edge as assumed" );
			// get the choice here
			RN_RETICULATE_ID ridsr = reticulateNet.GetReticulateId(swTreeUpdates.listNewConnections[i].subtreeRoot);
			YW_ASSERT_INFO( ridsr >=0, "Fail to retrieve the reticulate id" );
			YW_ASSERT_INFO( ridsr < (int)resultIns.choicesRNs.size(), "Out of bound: resultIns.choicesRNs" );
			int choiceatsr = resultIns.choicesRNs[ ridsr ];
			//YW_ASSERT_INFO( choiceatsr < (int) resultIns.choicesRNs.size(), "choiceatsr: out of range"); 
			YW_ASSERT_INFO( 0 <= choiceatsr && 1 >= choiceatsr, 
				"Non binary value at resultIns.choicesRNs1.0" );
			//YW_ASSERT_INFO( 0 <= resultIns.choicesRNs[choiceatsr] && 1 >= resultIns.choicesRNs[choiceatsr], 
			//	"Non binary value at resultIns.choicesRNs1.0" );

			RN_NODE_ID rnsrNew = CreateNewNode();
			SW_NW_UPDATE_RECORD snur1;
			snur1.descendNode = rnsrNew;
			snur1.par1Node = listNodesPar[ choiceatsr ];
			snur1.par2Node = swTreeUpdates.listNewConnections[i].parNew;
			snur1.fUpdate = false;
			UpdateNetworkStep( snur1, resultIns, 1);		// YW: 062309, change to be 1???

			SW_NW_UPDATE_RECORD snur2;
			snur2.descendNode = swTreeUpdates.listNewConnections[i].subtreeRoot;
			if( choiceatsr == 0 )
			{
				snur2.par1Node = rnsrNew;
				snur2.par2Node = listNodesPar[1];
			}
			else
			{
				snur2.par1Node = listNodesPar[0];
				snur2.par2Node = rnsrNew;
			}
			snur2.fUpdate = true;
//			updateNet.listUpdatedNodes.push_back(snur);
			UpdateNetworkStep( snur2, resultIns, -1);


#if 0
			rnsrNew = CreateNewNode();
			SW_NW_UPDATE_RECORD snur;
			snur.descendNode = rnsrNew;
			snur.par1Node = swTreeUpdates.listNewConnections[i].subtreeRoot;
			snur.par2Node = swTreeUpdates.listNewConnections[i].parNew;
			snur.fUpdate = false;
//			updateNet.listUpdatedNodes.push_back(snur);
			UpdateNetworkStep( snur, resultIns, 1);		// YW: 062309, change to be 1???

			// also need to update the immediate descendents of the original root
			vector<RN_NODE_ID> listImmDescs;
			reticulateNet.GetImmDescendents(swTreeUpdates.listNewConnections[i].subtreeRoot, listImmDescs);
			for(int jj=0; jj<(int)listImmDescs.size(); ++jj)
			{
				SW_NW_UPDATE_RECORD snur;
				MaintainURNewPar( listImmDescs[jj], swTreeUpdates.listNewConnections[i].subtreeRoot, rnsrNew, snur );
//				updateNet.listUpdatedNodes.push_back(snur);
				UpdateNetworkStep( snur, resultIns, -1);		// no changes to RN choices
			}
#endif
		}

		// get the orig par for sibling
		RN_NODE_ID sibParOld = -1;
		vector<RN_NODE_ID> listNodesParSib;
		reticulateNet.GetDirectParents(swTreeUpdates.listNewConnections[i].sibling, listNodesParSib);

		// now update the other link
//cout << "ConvTreeUpdateToNW: sibling = " << swTreeUpdates.listNewConnections[i].sibling << endl;
		if( reticulateNet.GetReticulateId( swTreeUpdates.listNewConnections[i].sibling ) < 0 )
		{
			// it was a tree node before, so change it to reticulate node
			SW_NW_UPDATE_RECORD snur;
			snur.descendNode = swTreeUpdates.listNewConnections[i].sibling;
			snur.par1Node = swTreeUpdates.listNewConnections[i].parNew;
			snur.par2Node = -1;		// since it is tree edge
			snur.fUpdate = true;
//			updateNet.listUpdatedNodes.push_back(snur);
			UpdateNetworkStep( snur, resultIns, -1);		// adding no new RN

			// sibpar old is simply its parent
			YW_ASSERT_INFO( listNodesParSib.size() == 1, "Wrong size of par list" );
			sibParOld = listNodesParSib[0];
		}
		else
		{
			// YW: 060709: remove the need for origsr, instead using the network directly
			// get the choice here
			RN_RETICULATE_ID ridsib = reticulateNet.GetReticulateId(swTreeUpdates.listNewConnections[i].sibling);
			YW_ASSERT_INFO( ridsib >=0, "Fail to retrieve the reticulate id" );
			YW_ASSERT_INFO( ridsib < (int)resultIns.choicesRNs.size(), "Out of bound: resultIns.choicesRNs" );
			int choiceatsr = resultIns.choicesRNs[ ridsib ];
			YW_ASSERT_INFO( 0 <= resultIns.choicesRNs[choiceatsr] && 1 >= resultIns.choicesRNs[choiceatsr], 
				"Non binary value at resultIns.choicesRNs" );


			SW_NW_UPDATE_RECORD snur;
			MaintainURNewPar( swTreeUpdates.listNewConnections[i].sibling, listNodesParSib[choiceatsr], 
				swTreeUpdates.listNewConnections[i].parNew, snur );
//			updateNet.listUpdatedNodes.push_back(snur);
			UpdateNetworkStep( snur, resultIns, -1);	// make no changes of the choice here

			//
			// sibpar old is simply its parent
			YW_ASSERT_INFO( listNodesParSib.size() == 2, "Wrong size of par list" );
			sibParOld = listNodesParSib[choiceatsr];
		}

		// finally, add a (tree) edge leading to the new node
		SW_NW_UPDATE_RECORD snur;
		snur.descendNode = swTreeUpdates.listNewConnections[i].parNew;
		snur.par1Node = sibParOld;
		snur.par2Node = -1;
		snur.fUpdate = false;
//		updateNet.listUpdatedNodes.push_back(snur);
		UpdateNetworkStep( snur, resultIns, -1);		// make no choice change here
//#endif
		// the subtree root will become a new RN
//		setNewRNs.insert(swTreeUpdates.listNewConnections[i].subtreeRoot);
//if( i == 1 )
//{
//break;		// YW: FIRST STEP TRIAL
//}
	}
}

void SWInsTreeILP :: MaintainURNewPar( const RN_NODE_ID &nodeChild, const RN_NODE_ID &nodeParOld, 
									  const RN_NODE_ID &nodeParNew, SW_NW_UPDATE_RECORD &record )
{
//cout << "In MaintainURNewPar: nodeChild = " << nodeChild << ", nodeParOld = " << nodeParOld << ", nodeParNew = " << nodeParNew << endl;
	// is this node a reticulate node?
	RN_NODE_ID par1 = -1, par2 = -1;
	if( reticulateNet.GetReticulateId( nodeChild ) >= 0  )
	{
		//
		vector<RN_NODE_ID> listNodesPar;
		reticulateNet.GetDirectParents(nodeChild, listNodesPar);
if(listNodesPar.size() != 2)
{
cout << "Wrong1\n";
}
if(listNodesPar[0] == listNodesPar[1])
{
cout << "Wrong2\n";
}
if( !( listNodesPar[0] == nodeParOld || listNodesPar[1] == nodeParOld ))
{
cout << "Wrong nodeParOld: par1 = " << listNodesPar[0]  << ", par2 = " << listNodesPar[1] << endl;
}
		YW_ASSERT_INFO( listNodesPar.size() == 2 && listNodesPar[0] != listNodesPar[1] &&
			( listNodesPar[0] == nodeParOld || listNodesPar[1] == nodeParOld ), 
			"Not a good retciulate node" );
		if( nodeParOld == listNodesPar[0] )
		{
			par1 = nodeParNew;
			par2 = listNodesPar[1];
		}
		else
		{
			par1 = listNodesPar[0];
			par2 = nodeParNew;
		}
	}
	else
	{
		par1 = nodeParNew;
		par2 = -1;
	}
//YW_ASSERT_INFO( par1 >=0 && par2 >=0, "Fail to update a reticulate node" );
	// 
	record.descendNode = nodeChild;
	record.par1Node = par1;
	record.par2Node = par2;
	record.fUpdate = true;
}

void SWInsTreeILP :: DumpTreeMap(map<RN_NODE_ID,RN_NODE_ID > &mapTree)
{
	cout << "The tree map contains the following edges\n";
	for( map<RN_NODE_ID,RN_NODE_ID > :: iterator it = mapTree.begin(); it != mapTree.end(); ++it )
	{
		cout << "(" << it->first << ", " << it->second << ")" << endl;
	}
}

bool SWInsTreeILP :: IsNodeAncestralInTTo( map<RN_NODE_ID,RN_NODE_ID > &mapEdges, const RN_NODE_ID &descn, const RN_NODE_ID &ancesn )
{
	//bool fres = false;
	RN_NODE_ID curn = descn;
	while( true )
	{
		if( curn == ancesn )
		{
			return true;
		}
		if( mapEdges.find( curn ) == mapEdges.end() )
		{
			break;
		}
		else
		{
			curn = mapEdges[curn];
		}
	}
	return false;
}

void SWInsTreeILP :: UpdateNetworkStep(const SW_NW_UPDATE_RECORD &updateRec,  SW_INS_TREE_RES &resultIns, int rnChoice)
{
//static int nStepCount = 1;
	reticulateNet.UpdateEdge( updateRec.par1Node, updateRec.par2Node, updateRec.descendNode);
//char buf[100];
//sprintf(buf, "tmpnet%d.gml", nStepCount++ );
//reticulateNet.OutputGML( buf );

	// also update choice at any new RN
	YW_ASSERT_INFO(rnChoice <= 1, "UpdateNetworkStep: rnChoice is out of range");
	if( rnChoice >= 0)
	{
		resultIns.choicesRNs.push_back( rnChoice );
	}
}


void SWInsTreeILP :: FindTreeAttachOrder( const vector<set<RN_NODE_ID> > &listCompleteTNs, vector<int> &vecOrder )
{
	vecOrder.clear();

	// find the proper order of attachment
	// the first will be where the root (or leaf root) is contained
	// to find this, we only need to find where the leaf root (the single leaf dangling out of the root)
	// the tree containing this leaf node is the one
	//RN_NODE_ID rootId = reticulateNet.GetRoot();

	// search for a cluster with a single leaf, whose 
	int indexRootCluster = -1;
	//vector<RN_NODE_ID> vecRootDescs;
	//reticulateNet.GetImmDescendents( rootId, vecRootDescs);
	RN_NODE_ID leafNode = reticulateNet.GetLeafRoot();
	//if( reticulateNet.IsNodeLeaf(vecRootDescs[0]) )
	//{
	//	leafNode = vecRootDescs[0];
	//}
	//else
	//{
	//	leafNode = vecRootDescs[1];
	//}
	YW_ASSERT_INFO( reticulateNet.IsNodeLeaf(leafNode) == true, "The network is not in right format: must have a leaf node attached to root" );
	for(int ii=0;ii<(int)listCompleteTNs.size(); ++ii)
	{
		if( listCompleteTNs[ii].find( leafNode) != listCompleteTNs[ii].end() )
		{
			indexRootCluster = ii;
			break;
		}
	}
	YW_ASSERT_INFO(indexRootCluster >=0, "Fail to find the root");

	// now, add the rest: try to find the one not intersecting with others
	vecOrder.push_back(indexRootCluster);
	set<int> indicesDone;
	indicesDone.insert(indexRootCluster);
	while(true)
	{
//cout << "In FindTreeAttachOrder, vecOrder: ";
//DumpIntVec( vecOrder );
		bool fUpdate = false;
		for(int i=0; i<(int)listCompleteTNs.size(); ++i)
		{
			if( indicesDone.find( i ) != indicesDone.end() )
			{
				continue;
			}

			// is this one intersecting other not-done tree
			bool fAdd = true;
			for(int j=0; j<(int)listCompleteTNs.size(); ++j)
			{
				if( j != i && indicesDone.find( j ) == indicesDone.end()  )
				{
//cout << "FindTreeAttachOrder: Checking i = " << i << ", j = " << j << endl;
					// is Tj intersecting with Ti, can not add
					if( AreTwoSTIntersectOnPathToRootInT( listCompleteTNs[i], listCompleteTNs[j] ) == true )
					{
//cout << "-----------Subtree T" << i << " intersect with subtree T" << j << " on it is way to root\n";;
						fAdd = false;
						break;
					}
				}
			}

			if( fAdd == true)
			{
				vecOrder.push_back(i);
				indicesDone.insert( i );
				fUpdate = true;
				break;
			}
		}

		if( fUpdate == false)
		{
			break;
		}
	}

	YW_ASSERT_INFO(vecOrder.size() == listCompleteTNs.size(), "Did not add all the subtrees");

	// see if we can do better in ensuring acyclic order of both sides
	vector<int> vecNew;
	if( FindTreeAttachOrderTwoTree(listCompleteTNs, vecNew) == true)
	{
//cout << "Found a better derivation order: ";
//DumpIntVec( vecNew );
		vecOrder = vecNew;
	}

}

bool SWInsTreeILP :: FindTreeAttachOrderTwoTree( const vector<set<RN_NODE_ID> > &listCompleteTNs, vector<int> &vecOrder )
{
	// try to see if it is possible to get the acyclic order for both T and N
	vecOrder.clear();

	// search for a cluster with a single leaf, whose 
	int indexRootCluster = -1;
	//vector<RN_NODE_ID> vecRootDescs;
	//reticulateNet.GetImmDescendents( rootId, vecRootDescs);
	RN_NODE_ID leafNode = reticulateNet.GetLeafRoot();
	//if( reticulateNet.IsNodeLeaf(vecRootDescs[0]) )
	//{
	//	leafNode = vecRootDescs[0];
	//}
	//else
	//{
	//	leafNode = vecRootDescs[1];
	//}
	YW_ASSERT_INFO( reticulateNet.IsNodeLeaf(leafNode) == true, "The network is not in right format: must have a leaf node attached to root" );
	for(int ii=0;ii<(int)listCompleteTNs.size(); ++ii)
	{
		if( listCompleteTNs[ii].find( leafNode) != listCompleteTNs[ii].end() )
		{
			indexRootCluster = ii;
			break;
		}
	}
	YW_ASSERT_INFO(indexRootCluster >=0, "Fail to find the root");

	// now, add the rest: try to find the one not intersecting with others
	vecOrder.push_back(indexRootCluster);
	set<int> indicesDone;
	indicesDone.insert(indexRootCluster);
	while(true)
	{
//cout << "In FindTreeAttachOrder, vecOrder: ";
//DumpIntVec( vecOrder );
		bool fUpdate = false;
		for(int i=0; i<(int)listCompleteTNs.size(); ++i)
		{
			if( indicesDone.find( i ) != indicesDone.end() )
			{
				continue;
			}

			// is this one intersecting other not-done tree
			bool fAdd = true;
			for(int j=0; j<(int)listCompleteTNs.size(); ++j)
			{
				if( j != i && indicesDone.find( j ) == indicesDone.end()  )
				{
//cout << "FindTreeAttachOrder: Checking i = " << i << ", j = " << j << endl;
					// is Tj intersecting with Ti, can not add
					if( AreTwoSTIntersectOnPathToRootInT( listCompleteTNs[i], listCompleteTNs[j] ) == true )
					{
//cout << "-----------Subtree T" << i << " intersect with subtree T" << j << " on it is way to root\n";;
						fAdd = false;
						break;
					}

					// then see if Tj is ancestral to Ti in N
					if( IsSubTreeAncestralToInN(listCompleteTNs[j], listCompleteTNs[i]) == true )
					{
						//
						fAdd = false;
						break;
					}
				}
			}

			if( fAdd == true)
			{
				vecOrder.push_back(i);
				indicesDone.insert( i );
				fUpdate = true;
				break;
			}
		}

		if( fUpdate == false)
		{
			break;
		}
	}

	if(vecOrder.size() < listCompleteTNs.size() )
	{
		return false;
	}
	else
	{
		return true;
	}

}

bool SWInsTreeILP :: IsSubTreeAncestralToInN( const set<RN_NODE_ID> &setNodeIds1, const set<RN_NODE_ID> &setNodeIds2 )
{
	// find whether subtree T1 is ancestral to subtree T2 (i.e. T1's root is on the path from root of T2 onto root)
	// CAUTION: INS(T1, T2) = false does not imply INS(T2, T1) = false
	// 
	set<RN_NODE_ID> nodesMRCA2;
	//set<RN_NODE_ID> *setNodeIds[2];
	//setNodeIds[0] = &setNodeIds1;
	//setNodeIds[1] = &setNodeIds2;
	//for(int k=0; k<2; ++k)
	//{
	for( set<RN_NODE_ID> :: iterator it = setNodeIds2.begin(); it != setNodeIds2.end(); ++it )
	{
		set<RN_NODE_ID> ancesNodes;
		reticulateNet.GetAllAncestors( *it, ancesNodes );
		if(nodesMRCA2.size()  == 0)
		{
			nodesMRCA2 = ancesNodes;
		}
		else
		{
			// take a join
			set<RN_NODE_ID> sint;
			JoinSets( ancesNodes, nodesMRCA2, sint);
			nodesMRCA2 = sint;
		}
	}
	//}
	// If ancestral, should exist a node in T1 that is in the MRCA list
	set<RN_NODE_ID> sint;
	JoinSets(nodesMRCA2, setNodeIds1, sint);
	if( sint.size() > 0 )
	{
		return true;
	}
	else
	{
		return false;
	}

//cout << "AreTwoSTIntersectOnPathToRootInT: Leaf set T1: ";

}

////////////////////////////////////////////////////////////////////////////////////
int SWInsTreeILP :: GetCVarPos(int c)
{
	return c;
}
int SWInsTreeILP :: GetRVarPos(int r, int numCVars)
{
	return r + numCVars;
}
int SWInsTreeILP :: GetAVarPos(int v, int pv, int numCRVars)
{
	// CAUTION: these are node ID, not index
	pair<int,int> pp(v, pv);
	return numCRVars + mapAVarIndex[pp];
}
void SWInsTreeILP :: FindSolInILP( ILPSolution &solILP, SW_INS_TREE_RES &result )
{
	// the first comes CVars
	result.choicesRNs.clear();
	for( int i=0; i<this->numRVars; ++i )
	{
		int pos = GetRVarPos(i, this->numCVars);
		if( solILP.pSolution[pos] >= 0.9 )
		{
			result.choicesRNs.push_back(1);
		}
		else
		{
			result.choicesRNs.push_back(0);
		}
	}
//cout << "Reticulate variable settings: ";
//DumpIntVec( result.choicesRNs );
	// get cut edges and then find the MAFs
	vector<int> cutEdges;
	for( int i=0; i<this->numCVars; ++i )
	{
		int pos = GetCVarPos(i);
		if( solILP.pSolution[pos] >= 0.9 )
		{
			cutEdges.push_back(i);
		}
	}
//cout << "Cut edges: ";
//DumpIntVec( cutEdges );

	// now find the MAF 
	treeIns.GetLeafSetsForCuts( cutEdges, result.resMAFParts );
//cout << "The MAF leaf sets\n";
//for(int i=0; i<(int)result.resMAFParts.size(); ++i)
//{
//DumpIntSet( result.resMAFParts[i] );
//}

}



void SWInsTreeILP :: ConsILPConstraints( vector<ILP_CONSTRAINT> &listConstraints )
{
	int numCRVars = numCVars + numRVars;

	// first some trivial facts
	// A,a,a = 1
    for( int i= 0; i< (int)vecRNNodes.size() ; ++i  )
    {
		ILP_CONSTRAINT ilpc;
		ilpc.nonzeroPos.push_back( GetAVarPos( vecRNNodes[i], vecRNNodes[i], numCRVars)  );
		ilpc.coefficients.push_back(1.0);
		ilpc.rhsBound = 1.0;
		ilpc.fLB = true;
		listConstraints.push_back(ilpc);

		ilpc.fLB = false;
		listConstraints.push_back(ilpc);
    }


	// A,x,root = 1
	RN_NODE_ID rootId = reticulateNet.GetRoot();
//cout << "Root of the network is: " << rootId << endl;
    for( int i= 0; i< (int)vecRNNodes.size() ; ++i  )
    {
		ILP_CONSTRAINT ilpc;
		ilpc.nonzeroPos.push_back( GetAVarPos( vecRNNodes[i], rootId, numCRVars)  );
		ilpc.coefficients.push_back(1.0);
		ilpc.rhsBound = 1.0;
		ilpc.fLB = true;
		listConstraints.push_back(ilpc);

		ilpc.fLB = false;
		listConstraints.push_back(ilpc);
    }

	// YW: do not use the following due to some complexity caused by updated network. 6/5/09
#if 0
	// also, the one not in the root leaf is also root to all other nodes (except of course the leaf node)
	//vector<RN_NODE_ID> vecRootDescs;
	//reticulateNet.GetImmDescendents(rootId, vecRootDescs);
	//YW_ASSERT_INFO(vecRootDescs.size() == 2, "Network is either not binary or just contain a root");
	//RN_NODE_ID leafRoot = vecRootDescs[0];
	//RN_NODE_ID rootNodeReal = vecRootDescs[1];
	//if(reticulateNet.IsNodeLeaf(leafRoot) == false)
	//{
	//	leafRoot = vecRootDescs[1];
	//	rootNodeReal = vecRootDescs[0];
	//	YW_ASSERT_INFO( reticulateNet.IsNodeLeaf(leafRoot) == true, "Network in bad format: no root leaf." );
	//}

    for( int i= 0; i< (int)vecRNNodes.size() ; ++i  )
    {
		if( vecRNNodes[i] != leafRoot && vecRNNodes[i] != rootId)
		{
			ILP_CONSTRAINT ilpc;
			ilpc.nonzeroPos.push_back( GetAVarPos( vecRNNodes[i], rootNodeReal, numCRVars)  );
			ilpc.coefficients.push_back(1.0);
			ilpc.rhsBound = 1.0;
			ilpc.fLB = true;
			listConstraints.push_back(ilpc);

			ilpc.fLB = false;
			listConstraints.push_back(ilpc);

		}
    }
#endif

	// ???
    for( int i= 0; i< (int)vecRNNodes.size() ; ++i  )
    {
		int v = vecRNNodes[i];
        for( int j= 0; j< (int)vecRNAncesNodes[i].size() ; ++j  )
        {
			int pv = vecRNAncesNodes[i][j];
			// is [v,pv] an tree edge?
			vector<RN_NODE_ID> listNodesParOfv;
			reticulateNet.GetDirectParents(v, listNodesParOfv);

			// if this is a tree edge, then we are done
			if( listNodesParOfv.size() == 1 )
			{
				// A,v,pv = A,par(v),pv in this case
				ILP_CONSTRAINT ilpc;
				ilpc.nonzeroPos.push_back( GetAVarPos( v, pv, numCRVars)  );
				ilpc.coefficients.push_back(1.0);
				ilpc.nonzeroPos.push_back( GetAVarPos( listNodesParOfv[0], pv, numCRVars)  );
				ilpc.coefficients.push_back(-1.0);
				ilpc.rhsBound = 0.0;
				ilpc.fLB = true;
				listConstraints.push_back(ilpc);

				ilpc.fLB = false;
				listConstraints.push_back(ilpc);

 			}
			else
			{
				// this is a reticulate nodes, then it is the same as R,i
				int rid = reticulateNet.GetReticulateId( v );
				YW_ASSERT_INFO( rid >= 0, "Fail to get reticulate id" );

				bool fLeftUnderpv =  (pv == listNodesParOfv[0]) || IsNodeDescendentOf(listNodesParOfv[0], pv, mapRNAncesNodesSet);
				bool fRightUnderpv = (pv == listNodesParOfv[1]) || IsNodeDescendentOf(listNodesParOfv[1], pv, mapRNAncesNodesSet);

				// if parleft can possibly be desc of pv, 
				if(fLeftUnderpv == true)
				{
					ILP_CONSTRAINT ilpc;
					ilpc.nonzeroPos.push_back( GetAVarPos( v, pv, numCRVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.nonzeroPos.push_back( GetRVarPos( rid, numCVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.nonzeroPos.push_back( GetAVarPos( listNodesParOfv[0], pv, numCRVars)  );
					ilpc.coefficients.push_back(-1.0);
					ilpc.rhsBound = 0.0;
					ilpc.fLB = true;
					listConstraints.push_back(ilpc);
				}

				if( fRightUnderpv == true)
				{
					ILP_CONSTRAINT ilpc;
					ilpc.nonzeroPos.push_back( GetAVarPos( v, pv, numCRVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.nonzeroPos.push_back( GetRVarPos( rid, numCVars)  );
					ilpc.coefficients.push_back(-1.0);
					ilpc.nonzeroPos.push_back( GetAVarPos( listNodesParOfv[1], pv, numCRVars)  );
					ilpc.coefficients.push_back(-1.0);
					ilpc.rhsBound = -1.0;
					ilpc.fLB = true;
					listConstraints.push_back(ilpc);
				}

				// then finally if neither works, we set to 0
				if( fLeftUnderpv == true)
				{
					ILP_CONSTRAINT ilpc;
					ilpc.nonzeroPos.push_back( GetAVarPos( v, pv, numCRVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.nonzeroPos.push_back( GetRVarPos( rid, numCVars)  );
					ilpc.coefficients.push_back(-1.0);
					ilpc.nonzeroPos.push_back( GetAVarPos( listNodesParOfv[0], pv, numCRVars)  );
					ilpc.coefficients.push_back(-1.0);
					ilpc.rhsBound = 0.0;
					ilpc.fLB = false;
					listConstraints.push_back(ilpc);
				}
				else
				{
					ILP_CONSTRAINT ilpc;
					ilpc.nonzeroPos.push_back( GetAVarPos( v, pv, numCRVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.nonzeroPos.push_back( GetRVarPos( rid, numCVars)  );
					ilpc.coefficients.push_back(-1.0);
					ilpc.rhsBound = 0.0;
					ilpc.fLB = false;
					listConstraints.push_back(ilpc);
				}

				if( fRightUnderpv == true)
				{
					ILP_CONSTRAINT ilpc;
					ilpc.nonzeroPos.push_back( GetAVarPos( v, pv, numCRVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.nonzeroPos.push_back( GetRVarPos( rid, numCVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.nonzeroPos.push_back( GetAVarPos( listNodesParOfv[1], pv, numCRVars)  );
					ilpc.coefficients.push_back(-1.0);
					ilpc.rhsBound = 1.0;
					ilpc.fLB = false;
					listConstraints.push_back(ilpc);
				}
				else
				{
					ILP_CONSTRAINT ilpc;
					ilpc.nonzeroPos.push_back( GetAVarPos( v, pv, numCRVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.nonzeroPos.push_back( GetRVarPos( rid, numCVars)  );
					ilpc.coefficients.push_back(1.0);
					ilpc.rhsBound = 1.0;
					ilpc.fLB = false;
					listConstraints.push_back(ilpc);
				}
			}
       }
    }

//#if 0
	// now enforce triple condition
    // now try all possible triples of leaves i,j,k
	YW_ASSERT_INFO( treeIns.GetNumLeaves() == (int)listRNLeafIds.size(), "Size mismatch" );
    for( int i= 0; i< treeIns.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< treeIns.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< treeIns.GetNumLeaves(); ++k)
            {
				int la = listRNLeafIds[i], lb = listRNLeafIds[j], lc = listRNLeafIds[k];

				// skip the leaf root, because it will never involve in any incompaiblity
				//if( la == leafRoot || lb == leafRoot || lc == leafRoot)
				//{
				//	continue;
				//}

//cout << "la = " << la << ", lb = " << lb << ", lc = " << lc << endl;
//cout << "Triple (" << la << ", " << lb << ", " << lc << ")" << endl;

				// here is the set of path edges in T, which we want to cut
				pair<int,int> pp(i,j);
				set<int> tripleEdges = mapPathNodesLeafPairsInT[pp];
				pp.first = j;
				pp.second = k;
				UnionSets(tripleEdges, mapPathNodesLeafPairsInT[pp]);

                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int tripleijk = treeIns.GetTriple( la, lb, lc );

				// now try all possible ancestor of a1,b1,c1 and a2,b2,c2
				int a[2],b[2],c[2];
				if( tripleijk == 1 )
				{
					a[0]=lb;
					b[0]=lc;
					c[0]=la;
					a[1]=la;
					b[1]=lc;
					c[1]=lb;
				}
				else if(tripleijk == 2)
				{
					a[0]=la;
					b[0]=lb;
					c[0]=lc;
					a[1]=la;
					b[1]=lc;
					c[1]=lb;
				}
				else
				{
					a[0]=la;
					b[0]=lb;
					c[0]=lc;
					a[1]=lb;
					b[1]=lc;
					c[1]=la;
				}

				// if ((a1,b1),c1), enforce constraint
				for(int index=0; index<2; ++index)
				{
					// convert from leaf id to node id
					RN_NODE_ID node1, node2, node3;
					node1 = reticulateNet.GetNodeIdFromLeafId( a[index] );
					node2 = reticulateNet.GetNodeIdFromLeafId( b[index] );
					node3 = reticulateNet.GetNodeIdFromLeafId( c[index] );
//cout << "node1 = " << node1 << ", node2 = " << node2 << ", node3 = " << node3 << endl;

					// get the possible x, which is intersection of par a1, b1 (but not c1)
					// y: join of all three
					set<int> tmpset1 = mapRNAncesNodesSet[node1];
					set<int> tmpset2 = mapRNAncesNodesSet[node2];
					set<int> choicesx;
					JoinSets(tmpset1, tmpset2, choicesx);

					// get rid of root and its immediate descendent
					choicesx.erase( rootId );
					//choicesx.erase( rootNodeReal );


					// try them all
					vector<int> vecChoicex;
					PopulateVecBySet( vecChoicex, choicesx );

					for(int iii=0; iii<(int)vecChoicex.size(); ++iii)
					{
						ILP_CONSTRAINT ilpc;
						if(IsNodeDescendentOf(node3, vecChoicex[iii], mapRNAncesNodesSet) == true)
						{
							ilpc.nonzeroPos.push_back( GetAVarPos(node3, vecChoicex[iii], numCRVars)  );
							ilpc.coefficients.push_back(1.0);
						}
						ilpc.nonzeroPos.push_back( GetAVarPos( node1, vecChoicex[iii], numCRVars)  );
						ilpc.coefficients.push_back(-1.0);
						ilpc.nonzeroPos.push_back( GetAVarPos( node2, vecChoicex[iii], numCRVars)  );
						ilpc.coefficients.push_back(-1.0);

						for(set<int> :: iterator itttt= tripleEdges.begin(); itttt != tripleEdges.end(); ++itttt)
						{
							ilpc.nonzeroPos.push_back( GetCVarPos(*itttt )  );
							ilpc.coefficients.push_back(1.0);
						}
							
						ilpc.rhsBound = -1.0;
						ilpc.fLB = true;
						listConstraints.push_back(ilpc);
							
					}

				}
			}
		}
	}
//#endif

//#if 0
	// now the twin path constraints
    // if the two pairs are left in one tree
	int numTwinPathsProc = 0;
    for( int i= 0; i< treeIns.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< treeIns.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< treeIns.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < treeIns.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( treeIns.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
					numTwinPathsProc++;
//cout << "(" << i << "," << j << ") disjoins (" << p << "," << q << ")\n";

					// here is the set of path edges in T, which we want to cut
					pair<int,int> pp(i,j);
					set<int> twinEdges = mapPathNodesLeafPairsInT[pp];
					pp.first = p;
					pp.second = q;
					UnionSets(twinEdges, mapPathNodesLeafPairsInT[pp]);
//cout << "In T, twin path edges = ";
//DumpIntSet(twinEdges);
					// Check whether (a,b) and (c,d) intersect in T_N
					int la = listRNLeafIds[i], lb = listRNLeafIds[j], lc = listRNLeafIds[p], ld = listRNLeafIds[q];
//cout << "la = " << la << ", lb = " << lb << ", lc = " << lc  << ", ld = " << ld << endl;


					// Now we think of two pairs of leaves: (a,b) and (c,d)
					// suppose there are disjoint in T. Now consider T_N
					// we need to add edge cuts if in T_N, the two pairs
					// intersect
					// to make them intersect, we need to have a node x, st.
					// A,a,x=1, A,c,x=1, A,b,x=0, 
					// Note for un-ordered (a,b),(c,d), we need 
					// to have all possible ways covered:
					// A,b,x=1, A,c,x=1, A,a,x=1 and
					// A,a,x=1, A,d,x=1, A,b,x=0, 
					// A,b,x=1, A,d,x=1, A,a,x=0, 
					// For one of them (the first), we have:
					// SUM(C_i) + 1 + A,b,x >= A,a,x + A,c,x 

					int a[4],b[4],c[4],d[4];
					a[0]=la;
					b[0]=lb;
					c[0]=lc;
					d[0]=ld;

					a[1]=lb;
					b[1]=la;
					c[1]=lc;
					d[1]=ld;

					a[2]=la;
					b[2]=lb;
					c[2]=ld;
					d[2]=lc;

					a[3]=lb;
					b[3]=la;
					c[3]=ld;
					d[3]=lc;

					// find possible x
					for(int index=0; index<4; ++index)
					{
						// convert from leaf id to node id
						RN_NODE_ID node1, node2, node3, node4;
						node1 = reticulateNet.GetNodeIdFromLeafId( a[index] );
						node2 = reticulateNet.GetNodeIdFromLeafId( b[index] );
						node3 = reticulateNet.GetNodeIdFromLeafId( c[index] );
						node4 = reticulateNet.GetNodeIdFromLeafId( d[index] );
//cout << "node1 = " << node1 << ", node2 = " << node2 << ", node3 = " << node3  << ", node4 = " << node4  << endl;

						// get the possible x, which is intersection of par a1, b1 (but not c1)
						// y: join of all three
						set<int> tmpset1 = mapRNAncesNodesSet[node1];
						set<int> tmpset2 = mapRNAncesNodesSet[node3];
						set<int> choicesx;
						JoinSets(tmpset1, tmpset2, choicesx);
						// again, root can not be x: we assume x is lower one
						choicesx.erase(rootId);

						// try them all
						vector<int> vecChoicex;
						PopulateVecBySet( vecChoicex, choicesx );
						for(int iii=0; iii<(int)vecChoicex.size(); ++iii)
						{

							ILP_CONSTRAINT ilpc;
							
							if(IsNodeDescendentOf(node2, vecChoicex[iii], mapRNAncesNodesSet) == true)
							{
								ilpc.nonzeroPos.push_back( GetAVarPos(node2, vecChoicex[iii], numCRVars)  );
								ilpc.coefficients.push_back(1.0);
							}
							if(IsNodeDescendentOf(node4, vecChoicex[iii], mapRNAncesNodesSet) == true)
							{
								ilpc.nonzeroPos.push_back( GetAVarPos(node4, vecChoicex[iii], numCRVars)  );
								ilpc.coefficients.push_back(1.0);
							}

							ilpc.nonzeroPos.push_back( GetAVarPos( node1, vecChoicex[iii], numCRVars)  );
							ilpc.coefficients.push_back(-1.0);
							ilpc.nonzeroPos.push_back( GetAVarPos( node3, vecChoicex[iii], numCRVars)  );
							ilpc.coefficients.push_back(-1.0);

							for(set<int> :: iterator itttt= twinEdges.begin(); itttt != twinEdges.end(); ++itttt)
							{
								ilpc.nonzeroPos.push_back( GetCVarPos(*itttt )  );
								ilpc.coefficients.push_back(1.0);
							}
								
							ilpc.rhsBound = -1.0;
							ilpc.fLB = true;
							listConstraints.push_back(ilpc);							
														

						}
					}
				}
			}
		}
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// now (simplified) timing constraints
#if 0
	vector< pair<int,int> > listEnclosedPaths;
	vector< pair<int,int> > listEnclosingPaths;
	reticulateNet.FindDisjointAncesTwinPaths( listEnclosedPaths, listEnclosingPaths );
//cout << "listEnclosedPaths:\n";
//for(int i=0;i<(int)listEnclosedPaths.size();++i)
//{
//cout << listEnclosedPaths[i].first << ", " << listEnclosedPaths[i].second << endl;
//}
//for(int i=0;i<(int)listEnclosingPaths.size();++i)
//{
//cout << listEnclosingPaths[i].first << ", " << listEnclosingPaths[i].second << endl;
//}

	// try all found enclosing constraints
	for(int i=0;i<(int)listEnclosedPaths.size();++i)
	{
		int x = listEnclosedPaths[i].first;
		int y = listEnclosedPaths[i].second;
		int z = listEnclosingPaths[i].first;
		int w = listEnclosingPaths[i].second;
        if( treeIns.AreTwoPathsDisjoint( x, y, z, w ) == false  )
        {
            continue;
        }	
		// also
		int mrcaxy = treeIns.GetMRCA( x, y );
		int mrcazw = treeIns.GetMRCA( z, w );
		if( treeIns.IsNodeUnder( mrcazw, mrcaxy) == false)
		{
			// need to inverse order
			continue;
		}
		pair<int,int> pp(x,y);
		set<int> twinEdges = mapPathNodesLeafPairsInT[pp];
		pp.first = z;
		pp.second = w;
		UnionSets(twinEdges, mapPathNodesLeafPairsInT[pp]);
		// now constraints
		ILP_CONSTRAINT ilpc;
		
		for(set<int> :: iterator itttt= twinEdges.begin(); itttt != twinEdges.end(); ++itttt)
		{
			ilpc.nonzeroPos.push_back( GetCVarPos(*itttt )  );
			ilpc.coefficients.push_back(1.0);
		}
			
		ilpc.rhsBound = 1.0;
		ilpc.fLB = true;
		listConstraints.push_back(ilpc);	
	}
#endif


//#if 0
	int numTwinPathsTCs = 0;
    for( int i= 0; i< treeIns.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< treeIns.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< treeIns.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < treeIns.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }
//cout << "i = " << i << ", j = " << j << ", p = " << p << ", q = " << q << endl;
                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( treeIns.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }

					// here is the set of path edges in T, which we want to cut
					pair<int,int> pp(i,j);
					set<int> twinEdges = mapPathNodesLeafPairsInT[pp];
					pp.first = p;
					pp.second = q;
					UnionSets(twinEdges, mapPathNodesLeafPairsInT[pp]);
//cout << "In timing constraints generation, twin path edges = ";
//DumpIntSet(twinEdges);

					// Check whether (a,b) and (c,d) intersect in T_N
					//int la = listRNLeafIds[i], lb = listRNLeafIds[j], lc = listRNLeafIds[p], ld = listRNLeafIds[q];

					int a[4], b[4], c[4], d[4];
					a[0] = i;
					b[0] = j;
					c[0] = p;
					d[0] = q;

					a[1] = j;
					b[1] = i;
					c[1] = p;
					d[1] = q;

					a[2] = p;
					b[2] = q;
					c[2] = i;
					d[2] = j;

					a[3] = q;
					b[3] = p;
					c[3] = i;
					d[3] = j;


					// check which pair is higher
					for(int k=0; k<4; ++k)
					{
//cout << "a[k] = " << a[k] << ", b[k] = " << b[k] << endl;
//cout << "c[k] = " << c[k] << ", d[k] = " << d[k] << endl;
						int mrcaab1 = treeIns.GetMRCA(a[k],b[k]);
						int mrcacd1 = treeIns.GetMRCA(c[k],d[k]);
//cout << "mrcaab = " << mrcaab1 << ", mrcacd1 = " << mrcacd1 << endl;
						if( treeIns.IsNodeUnder( mrcaab1, mrcacd1) == false)
						{
							continue;
						}

						// now consider T_N
						RN_NODE_ID node1, node2, node3, node4;
						node1 = reticulateNet.GetNodeIdFromLeafId( listRNLeafIds[a[k] ] );
						node2 = reticulateNet.GetNodeIdFromLeafId( listRNLeafIds[b[k] ] );
						node3 = reticulateNet.GetNodeIdFromLeafId( listRNLeafIds[c[k] ] );
						node4 = reticulateNet.GetNodeIdFromLeafId( listRNLeafIds[d[k] ] );
//cout << "node1 = " << node1 << ", node2 = " << node2 << ", node3 = " << node3  << ", node4 = " << node4  << endl;

						// get the possible x, which is intersection of par a1, b1 (but not c1)
						// y: join of all three
						set<int> tmpset1 = mapRNAncesNodesSet[node1];
						set<int> tmpset2 = mapRNAncesNodesSet[node3];
						set<int> tmpset3 = mapRNAncesNodesSet[node4];
						set<int> choicesx, tmpjoin;
						JoinSets(tmpset1, tmpset2, tmpjoin);
						JoinSets(tmpset3, tmpjoin, choicesx);

						// try them all
						vector<int> vecChoicex;
						PopulateVecBySet( vecChoicex, choicesx );
						for(int iii=0; iii<(int)vecChoicex.size(); ++iii)
						{

							ILP_CONSTRAINT ilpc;
							
							if(IsNodeDescendentOf(node2, vecChoicex[iii], mapRNAncesNodesSet) == true)
							{
								ilpc.nonzeroPos.push_back( GetAVarPos(node2, vecChoicex[iii], numCRVars)  );
								ilpc.coefficients.push_back(1.0);
							}

							ilpc.nonzeroPos.push_back( GetAVarPos( node1, vecChoicex[iii], numCRVars)  );
							ilpc.coefficients.push_back(-1.0);
							ilpc.nonzeroPos.push_back( GetAVarPos( node3, vecChoicex[iii], numCRVars)  );
							ilpc.coefficients.push_back(-1.0);
							ilpc.nonzeroPos.push_back( GetAVarPos( node4, vecChoicex[iii], numCRVars)  );
							ilpc.coefficients.push_back(-1.0);

							for(set<int> :: iterator itttt= twinEdges.begin(); itttt != twinEdges.end(); ++itttt)
							{
								ilpc.nonzeroPos.push_back( GetCVarPos(*itttt )  );
								ilpc.coefficients.push_back(1.0);
							}
								
							ilpc.rhsBound = -2.0;
							ilpc.fLB = true;
							listConstraints.push_back(ilpc);	
							
						}

					}

					numTwinPathsTCs++;
				}
			}
		}
	}
//#endif

#if 0
    for( int i= 0; i< treeIns.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< treeIns.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< treeIns.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < treeIns.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }
//cout << "i = " << i << ", j = " << j << ", p = " << p << ", q = " << q << endl;
                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( treeIns.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
					// here is the set of path edges in T, which we want to cut
					pair<int,int> pp(i,j);
					set<int> twinEdges = mapPathNodesLeafPairsInT[pp];
					pp.first = p;
					pp.second = q;
					UnionSets(twinEdges, mapPathNodesLeafPairsInT[pp]);
//cout << "In timing constraints generation, twin path edges = ";
//DumpIntSet(twinEdges);

					// Check whether (a,b) and (c,d) intersect in T_N
					//int la = listRNLeafIds[i], lb = listRNLeafIds[j], lc = listRNLeafIds[p], ld = listRNLeafIds[q];

					// find whether (a,b) can be ancestral to (c,d) in N (or the other way around)
					int a[2], b[2], c[2], d[2];
					a[0] = i;
					b[0] = j;
					c[0] = p;
					d[0] = q;

					a[1] = p;
					b[1] = q;
					c[1] = i;
					d[1] = j;

					// check which pair is higher
					for(int k=0; k<2; ++k)
					{
//cout << "a[k] = " << a[k] << ", b[k] = " << b[k] << endl;
//cout << "c[k] = " << c[k] << ", d[k] = " << d[k] << endl;
						int mrcaab1 = treeIns.GetMRCA(a[k],b[k]);
						int mrcacd1 = treeIns.GetMRCA(c[k],d[k]);
//cout << "mrcaab = " << mrcaab1 << ", mrcacd1 = " << mrcacd1 << endl;
						if( treeIns.IsNodeUnder( mrcaab1, mrcacd1) == false)
						{
							continue;
						}

						// now consider T_N
						RN_NODE_ID node1, node2, node3, node4;
						node1 = reticulateNet.GetNodeIdFromLeafId( listRNLeafIds[a[k] ]  );
						node2 = reticulateNet.GetNodeIdFromLeafId( listRNLeafIds[b[k] ]  );
						node3 = reticulateNet.GetNodeIdFromLeafId( listRNLeafIds[c[k] ] );
						node4 = reticulateNet.GetNodeIdFromLeafId( listRNLeafIds[d[k] ] );
//cout << "node1 = " << node1 << ", node2 = " << node2 << ", node3 = " << node3  << ", node4 = " << node4  << endl;

						// get the possible x, which is intersection of par a1, b1 (but not c1)
						// y: join of all three
						set<int> tmpset1 = mapRNAncesNodesSet[node1];
						set<int> tmpset2 = mapRNAncesNodesSet[node2];
						set<int> tmpset3 = mapRNAncesNodesSet[node3];
						set<int> tmpset4 = mapRNAncesNodesSet[node4];
						set<int> choicesx, choicesy;
						JoinSets(tmpset1, tmpset2, choicesx);
						JoinSets(tmpset3, tmpset4, choicesy);
						//set<int> mrcacd;
						SubtractSets(choicesy, choicesx);

						// try them all
						if( choicesy.size() > 0 )
						{
							ILP_CONSTRAINT ilpc;

							// 
							for(set<int> :: iterator itttt= twinEdges.begin(); itttt != twinEdges.end(); ++itttt)
							{
								ilpc.nonzeroPos.push_back( GetCVarPos(*itttt )  );
								ilpc.coefficients.push_back(1.0);
							}
								
							ilpc.rhsBound = 1.0;
							ilpc.fLB = true;
							listConstraints.push_back(ilpc);	

						}
					}


					//numTwinPathsTCs++;
				}
			}
		}
	}
#endif
}


///////////////////////////////////////////////////////////////////////////////////////////////////////
// SW Network builder

extern void CreateSimpleNet1(ReticulateNetwork &network );
extern void CreateATree(MarginalTree &tr);
//extern void CreateRetNet2(ReticulateNetwork &network );
//extern void CreateATree2(MarginalTree &tr);
extern void CreateRetNetBug1(ReticulateNetwork &network );
extern void CreateATreeBug1(MarginalTree &tr);

// how many trees to try randomly
const int SWNB_TREE_RUN = 10;

SWNetworkBuilder :: SWNetworkBuilder(vector<MarginalTree> &listTrs) : listMargTrees(listTrs), knownLB(0), numTreesRun(SWNB_TREE_RUN),
numTaxaUser(0), pMapperTMapInfo(NULL)
{
}

void SWNetworkBuilder :: SetOrigTreeInfo(int ntu, const vector< pair<int,int> > &lrp, const vector< int > &lsp, TaxaMapper *pmtm)
{
	// 
	numTaxaUser = ntu;
	listRemovedPairs = lrp;
	listSurvivePos = lsp;
	pMapperTMapInfo = pmtm;
}

void SWNetworkBuilder :: CalcBest()
{
	// for now, just try one order
	vector<int> vecOrder;
	//for(int i=0; i<(int)listMargTrees.size(); ++i)
	//{
	//	vecOrder.push_back( i );
	//}
	GetRandVector( vecOrder, 0, (int)listMargTrees.size()-1 );
//cout << "************************************CalcBest *************************\nvecOrder = ";
//DumpIntVec( vecOrder );
	ReticulateNetworkImp resNet;
	resNet.SetOrigTreeInfo(	numTaxaUser, listRemovedPairs, listSurvivePos, pMapperTMapInfo );
	int costTot = CalcCostForOrder( vecOrder, resNet, HAP_MAX_INT );
	cout << "The lowest number of hybridization events found so far is " << costTot << endl;
	if( costTot == knownLB)
	{
		cout << "This is the OPTIMAL solution.\n";
	}
	else
	{
		cout << "This may not be the optimal solution.\n";
	}
}

// 
void SWNetworkBuilder :: CalcExhaustive()
{
	set<int> setRef;
	PopulateSetWithInterval( setRef, 0, (int)listMargTrees.size()-1 );
	vector<int> reference;
	PopulateVecBySet( reference, setRef );

	// best
	//ReticulateNetworkImp resBestNet;
	int costMin = HAP_MAX_INT;
	const char *fname = "rnbest.gml";

	YW_ASSERT_INFO( listMargTrees.size() >=2, "Can not have just one tree" );

	vector<int> vecOrder;
	InitPermutation( vecOrder, reference);
	while(true)
	{
	// for now, just try one order
	//for(int i=0; i<(int)listMargTrees.size(); ++i)
	//{
	//	vecOrder.push_back( i );
	//}
//cout << "************************************CalcExhaustive *************************\nvecOrder = ";
//DumpIntVec( vecOrder );

		// for a little speedup, assume a,b,c... is the same as b,a,c....
		if( vecOrder[0] < vecOrder[1] )
		{
			ReticulateNetworkImp resNet;
			int CostStep = CalcCostForOrder( vecOrder, resNet, costMin );
//cout << "coststep = " << CostStep << endl;
			if( CostStep < costMin )
			{
				costMin = CostStep;
cout << "Current best reticulation found: " << costMin << endl;
			//resBestNet = resNet;
//cout << "resNet: num of reticulate nodes = " << resNet.GetNumReticulateEdges() << endl;;
//resNet.OutputGML(fname);

				// when reaching the known LB, done
				YW_ASSERT_INFO(knownLB <= CostStep, "SERIOUS BUG: LB is HIGHER than found upper bound");
				if( costMin ==  knownLB)
				{
					// abort since we have reached the known lower bound
					break;
				}
			}
		}
		// get next
		if( GetNextPermutation(vecOrder, reference) == false )
		{
			break;
		}
	}
	cout << "The minimum number of hybridization events = " << costMin << endl;
	if( costMin == knownLB)
	{
		cout << "This is the OPTIMAL solution.\n";
	}
	else
	{
		cout << "This may not be the optimal solution.\n";
	}
//	cout << "Output best reticulate network found as " << fname  << endl;
//	resBestNet.OutputGML(fname);
}

void SWNetworkBuilder :: CalcOneOrder( const vector<int> &vecOrder)
{
//cout << "************************************CalcOneOrder *************************\nvecOrder = ";
//DumpIntVec( vecOrder );
	ReticulateNetworkImp resNet;
	int costTot = CalcCostForOrder( vecOrder, resNet, HAP_MAX_INT );
	cout << "The lowest number of hybridization events found so far is " << costTot << endl;
}

void SWNetworkBuilder :: Test()
{
	// initialize network and a test tree
	ReticulateNetworkImp testNet;
	CreateRetNetBug1( testNet );
	//CreateRetNet2( testNet );
	//CreateRetNet3( testNet );
cout << "The number of Leaves in the net: " << testNet.GetNumLeaves() << endl;
cout << "The number of reticulate nodes in the net: " << testNet.GetNumReticulateNodes() << endl;
cout << "The number of tree edges in the net: " << testNet.GetNumTreeEdges() << endl;
cout << "The number of reticulate edges in the net: " << testNet.GetNumReticulateEdges() << endl;

	MarginalTree tr;
	CreateATreeBug1(tr);
	//CreateATree2(tr);
	//CreateATree3(tr);
	//const int NUM_LEAVES = 16;
	//CreateATreeRandom( tr, NUM_LEAVES);

	// ensure the starting network is not cyclic
	YW_ASSERT_INFO( testNet.IsAcyclic() == true, "The starting network is already cyclic" );

	SWInsTreeILP swit( testNet, tr );
	SW_INS_TREE_RES res;
	int cder = swit.Calculate(res);
cout << "Cost of adding the tree = " << cder << endl;

	// dump out the displayed tree from testNet
	//map<RN_NODE_ID,RN_NODE_ID > mapEdges;
	//testNet.RetrieveATree(res.choicesRNs, mapEdges );
	// here are the edges
	//cout << "The displayed tree in N contains the following edges\n";
	//for( map<RN_NODE_ID,RN_NODE_ID > :: iterator it = mapEdges.begin(); it != mapEdges.end(); ++it )
	//{
	//	cout << "(" << it->first << ", " << it->second << ")" << endl;
	//}
	//SW_NETWORK_UPDATE updateNetRec;
	//swit.FindNetworkUpdates( res, updateNetRec);

	// now updae the net with the network
testNet.OutputGML("net0.gml");
	swit.UpdateNetwork( res );
testNet.OutputGML("net1.gml");

	// if acyclic?
	if( testNet.IsAcyclic() == false)
	{
		// 
		cout << "The resulting network is NOT acyclic.\n";
	}
	else
	{
		cout << "The resulting network IS acyclic.\n";
	}
}

//void SWNetworkBuilder :: UpdateNetwork( ReticulateNetwork &testNet, const SW_NETWORK_UPDATE &updateNetRec )
//{
//cout << "Number of updates: " <<  updateNetRec.listUpdatedNodes.size() << endl;
//	// update network according to the update records
//	for(int i=0; i<(int) updateNetRec.listUpdatedNodes.size(); ++i)
//	{
//cout << "Performing update " << i;
//cout << ": par1Node = " << updateNetRec.listUpdatedNodes[i].par1Node 
//<< ", par2Node = " << updateNetRec.listUpdatedNodes[i].par2Node << ", descend = " << updateNetRec.listUpdatedNodes[i].descendNode << endl;
//
//		// 
//		testNet.UpdateEdge( updateNetRec.listUpdatedNodes[i].par1Node, updateNetRec.listUpdatedNodes[i].par2Node,
//			updateNetRec.listUpdatedNodes[i]. descendNode);
//	}
//}

int SWNetworkBuilder :: CalcCostForOrder( const vector<int> &deriveOrder, ReticulateNetwork &resNet, int curBestCost  )
{
	// 
	ReticulateNetworkImp netWorking;
	netWorking.SetOrigTreeInfo(	numTaxaUser, listRemovedPairs, listSurvivePos, pMapperTMapInfo );
	int resCost = 0;

	// init with a single tree
	netWorking.InitWithMTree( listMargTrees[deriveOrder[0]] );
//netWorking.OutputGML("net0.gml");
//cout << "***************************************************\n";
//cout << "The initial net has " << netWorking.GetNumReticulateNodes() << " reticulate nodes\n";
//cout << "***************************************************\n";
	for(int i=1; i<(int) deriveOrder.size(); ++i)
	{
//cout << "Now adding tree " << i << "...\n";
		SWInsTreeILP swit( netWorking, listMargTrees[deriveOrder[i]] );
		SW_INS_TREE_RES resStep;
		int cder = swit.Calculate(resStep);
//cout << "Cost of adding tree " << i << " = " << cder << endl;
		resCost += cder; 
//		SW_NETWORK_UPDATE updateNetRec;
		ReticulateNetworkImp netCopy = netWorking;

		if( cder > 0 )
		{
			swit.UpdateNetwork( resStep);
		}

		// do not continue if the network contains cycle at this point
		if( netWorking.IsAcyclic() == false)
		{
cout << "Cycles founded. Now trying to recover...\n";
			// try to recover
			vector<int> indexPrevTrees;
			for(int pppp=0; pppp<i; ++pppp)
			{
				indexPrevTrees.push_back( deriveOrder[pppp] );
			}
			int cost2 = HeuAddTreeToNet(netCopy, listMargTrees[deriveOrder[i]], indexPrevTrees  );

//netWorking.OutputGML("cycle.gml");
			if( resCost < 0 )
			{
				resCost = HAP_MAX_INT;
//YW_ASSERT_INFO(false, "Check it");
				break;
			}
			else
			{
				resCost -= cder;
				resCost += cost2;
				netWorking = netCopy;
			}
		}

		// stop if can not be optimal
		if( resCost >= curBestCost)
		{
			// no hope of beating the best, stop
			resCost = HAP_MAX_INT;
			break;
		}


		// now updae the net with the network
		//UpdateNetwork( netWorking, updateNetRec );
char buf[100];
sprintf(buf, "net%d.gml", i);
netWorking.OutputGML(buf);
	}

	resNet = netWorking;

	if( netWorking.IsAcyclic() == false)
	{
		cout << "WARNING: the reticulate network contains CYCLES. Skip the solution (with " << resCost << " reticulate nodes.\n";

netWorking.OutputGML("cycle.gml");
//		YW_ASSERT_INFO(false, "Check it");
		// 
		return HAP_MAX_INT;
	}
	if( resCost < curBestCost )
	{
		const char *fname = "rnbest.gml";
		netWorking.OutputGML(fname);
//exit(1);
	}

#if 0
	// check if this network really contains all the trees
	// if so for each tree, the network should have ZERO cost of adding it
	// ensure it really works!!!
	for(int i=0; i<(int) deriveOrder.size(); ++i)
	{
//cout << "Rechecking tree " << i << endl;
		SWInsTreeILP swit( netWorking, listMargTrees[deriveOrder[i]] );
		SW_INS_TREE_RES resStep;
		int cder = swit.Calculate(resStep);
		YW_ASSERT_INFO( cder == 0, "FATAL ERROR: Constructed network does not contain one input tree" );
	}
#endif

//exit(1);	// temp

//	cout << "resNet: num of reticulate nodes = " << resNet.GetNumReticulateEdges() << endl;;
	return resCost;
}

int SWNetworkBuilder :: HeuAddTreeToNet( ReticulateNetwork &curNet, MarginalTree &treeToAdd, const vector<int> &indexPrevTrees )
{
	// add the tree to the network which has to be acyclic
	// return the cost of adding the tree after trying certain number of times (pre-set)
	// return -1 if all these number of failed to add the tree (final failure)
	// in which case the network is not changed
	//ReticulateNetworkImp netInWork = resNet;


	// ensure we have the input trees 
	set< vector<int> >  setChoicesRN;
	bool fInitTrees = GetInputRNChoices(curNet, indexPrevTrees, setChoicesRN);
	YW_ASSERT_INFO(fInitTrees == true, "Fail to retrive the trees");

	int numTreesToTry = numTreesRun;
	if(numTreesToTry <= 0)
	{
		// we will try at least one tree
		numTreesToTry = 1;
	}

	// first generate the random trees
	int numRNs = curNet.GetNumReticulateNodes();
	int numTreesNet = 0x1 << numRNs;
//cout << "numTreesNet: " << numTreesNet << endl;
	if( numTreesNet <= numTreesToTry  )
	{
		// collect all
		for(int nt = 0; nt < numTreesNet; ++nt)
		{
			vector<int> vecChoice;
			GetHyperCubeSeq(nt, vecChoice, numRNs);
			setChoicesRN.insert( vecChoice );
		}
	}
	else
	{
		// generate random choices at RNs
		for(int i=0; i<numTreesToTry; ++i)
		{
			// random number
			int nt = (int)(numTreesNet*GetRandFraction());
			vector<int> vecChoice;
			GetHyperCubeSeq(nt, vecChoice, numRNs);
			setChoicesRN.insert( vecChoice );
		}
	}
	// if nothing, then easy
	if( setChoicesRN.size() == 0 )
	{
		// add a dummy choice
		vector<int> emptyChoice;
		setChoicesRN.insert(emptyChoice);
	}


//cout << "Selected RN choices: \n";
//for(set< vector<int> > :: iterator it = setChoicesRN.begin(); it != setChoicesRN.end(); ++it)
//{
//DumpSequence( *it );
//}

	// for each RN choice, try it
	int resCost = -1;
	SW_INS_TREE_RES resSITR;
	for(set< vector<int> > :: iterator it = setChoicesRN.begin(); it != setChoicesRN.end(); ++it)
	{
//cout << "setChoicesRN: ";
//DumpSequence(*it);
		// extract the tree based on this RN
		MarginalTree mTree;

		map<RN_NODE_ID,RN_NODE_ID > mapEdges;
		curNet.RetrieveATree( *it, mapEdges );
//cout << "num of edges: " << mapEdges.size() << endl;
		curNet.ConvToMTree( mapEdges, mTree );

//cout << "mTree = ";
//mTree.Dump();

		// 
	    ILPSolverSPR solver( mTree, treeToAdd );
		solver.SetAcyclic(  true );		// want to focus on acyclic ones
		int distSPR = solver.ComputeILP();
		vector<int> edgesRes;
		solver.GetCutEdges( edgesRes ); 
		vector< set<int> > ssLeavesByCuts;
		mTree.GetLeafSetsForCuts( edgesRes, ssLeavesByCuts );

		// form solution
		SW_INS_TREE_RES sitr;
		sitr.choicesRNs = *it;			
		sitr.resMAFParts = ssLeavesByCuts;
		
		// try to add it
		ReticulateNetworkImp netInWork = (ReticulateNetworkImp &)curNet;
		SWInsTreeILP swit( netInWork, treeToAdd );
		swit.UpdateNetwork(sitr);

		// is it legal?
		if( netInWork.IsAcyclic() == true  && (resCost < 0 || resCost > distSPR) )
		{
//cout << "Curr best step cost: " << distSPR << endl;
			resCost = distSPR;
			resSITR = sitr;
		}
	}
	if( resCost >= 0 )
	{
		SWInsTreeILP swit( curNet, treeToAdd );
		swit.UpdateNetwork(resSITR);
	}
	return resCost;

}

void SWNetworkBuilder :: CalcHeu(const vector<int> &listNodeOrder)
{
cout << "In CalcHeu: derivation order = ";
DumpIntVec(listNodeOrder);
	// grow a network heuristicly. we start with a fixed order: 0, 1, 2, ...
	// and add to the network. Each time we add the network heuristicly
	int costRes = 0;
	const char *fname = "rnheu.gml";

	YW_ASSERT_INFO( listMargTrees.size() >=2, "Can not have just one tree" );

	ReticulateNetworkImp resNet;
	resNet.SetOrigTreeInfo(	numTaxaUser, listRemovedPairs, listSurvivePos, pMapperTMapInfo );
	resNet.InitWithMTree( listMargTrees[  listNodeOrder[0] ] );
	for(int i=1; i<(int)listNodeOrder.size(); ++i)
	{
//cout << "HEU: adding tree " << i << endl;
//resNet.OutputGML("tmp.net");
		vector<int> indexPrevTrees;
		for(int pppp=0; pppp<i; ++pppp)
		{
			indexPrevTrees.push_back( listNodeOrder[pppp] );
		}

		int costStep = HeuAddTreeToNet( resNet, listMargTrees[ listNodeOrder[i] ], indexPrevTrees );
		YW_ASSERT_INFO( costStep >= 0, "FATAL ERROR: Fail to expand the tree." );
		costRes += costStep;
//cout << "coststep = " << costStep << endl;

	}

	// double check
	// check if this network really contains all the trees
	// if so for each tree, the network should have ZERO cost of adding it
	// ensure it really works!!!
	YW_ASSERT_INFO( resNet.IsAcyclic() == true, "FATAL ERROR: resulting network has CYCLEs." );
#if 0
	for(int i=0; i<(int) listMargTrees.size(); ++i)
	{
//cout << "Rechecking tree " << i << endl;
		SWInsTreeILP swit( resNet, listMargTrees[i] );
		SW_INS_TREE_RES resStep;
		int cder = swit.Calculate(resStep);
		YW_ASSERT_INFO( cder == 0, "FATAL ERROR: Constructed network does not contain one input tree" );
	}
#endif
	cout << "The minimum number of hybridization (HEU) = " << costRes << endl;
	if( costRes == knownLB)
	{
		cout << "This is the OPTIMAL solution.\n";
	}
	else
	{
		cout << "This may not be the optimal solution.\n";
	}
	cout << "Output best reticulate network (HEU) as " << fname  << endl;
resNet.OutputGML(fname);
}

int SWNetworkBuilder :: FindMSTOrder( const vector< vector<int> > &resDists, vector<int> &listNodeOrder )
{
	// the starting point is the one adjacent to a shortest edge
	// return the cost of MST
	int nodeStart = -1;
	int minLen = HAP_MAX_INT;
	for(int i=0; i<(int)resDists.size(); ++i)
	{
		for(int j=i+1; j<(int)resDists.size(); ++j)
		{
			if( resDists[i][j] < minLen  )
			{
				nodeStart = i;
				minLen = resDists[i][j];
			}
		}
	}
	YW_ASSERT_INFO( nodeStart >= 0, "DO NOT MAKE SENSE" );

	listNodeOrder.clear();
	// start with arbitary node, say 0
	listNodeOrder.push_back(nodeStart);
	set<int> nodesDone;
	nodesDone.insert(nodeStart);
	set<int> nodesTodo;
	PopulateSetWithInterval(nodesTodo, 0, resDists.size()-1);
	nodesTodo.erase(nodeStart);

	int resMST = 0;
	while(nodesTodo.size() > 0 )
	{
		// find which one in the cut has the smallest edge
		int distBest = HAP_MAX_INT;
		int nodeNext = -1;
		for( set<int> :: iterator it = nodesTodo.begin(); it != nodesTodo.end(); ++it )
		{
			//int nidtodo = *it;
			for(set<int> :: iterator it2 = nodesDone.begin(); it2 != nodesDone.end(); ++it2)
			{
				if( distBest > resDists[*it][*it2] )
				{
					distBest = resDists[*it][*it2];
					nodeNext = *it;
				}
			}
		}
		YW_ASSERT_INFO( nodeNext >= 0, "Fail to find the next MST node" );
		resMST += distBest;
		nodesTodo.erase(nodeNext);
		nodesDone.insert(nodeNext);
		listNodeOrder.push_back( nodeNext );
	}
	return resMST;
}

bool SWNetworkBuilder :: GetInputRNChoices(ReticulateNetwork &curNet, const vector<int> &indexPrevTrees, set< vector<int> >  &setChoicesRN)
{
	// get the RN choices for the lis tof input trees
	// return false if any one input tree is not in the list
	for(int i=0; i<(int) indexPrevTrees.size(); ++i)
	{
//cout << "Rechecking tree " << i << endl;
		SWInsTreeILP swit( curNet, listMargTrees[  indexPrevTrees[i]  ] );
		SW_INS_TREE_RES resStep;
		int cder = swit.Calculate(resStep);
		if( cder > 0 )
		{
			// "FATAL ERROR: Constructed network does not contain one input tree" );
			return false;
		}
//cout << "GetInputRNChoices: for tree " << indexPrevTrees[i] << ", RN choices: ";
//DumpSequence( resStep.choicesRNs );
		setChoicesRN.insert( resStep.choicesRNs );
	}
	return true;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// SW Network lower bound

ReticualteNetLB :: ReticualteNetLB(vector<MarginalTree> &listTreesPar) : listMargTrees(listTreesPar)
{
	YW_ASSERT_INFO(listTreesPar.size() >= 2, "Must have at least two trees to compute a lower bound");

	// init
	InitPairDists();
}

ReticualteNetLB :: ReticualteNetLB(vector<MarginalTree> &listTreesPar, const vector< vector<int> > &distPairwisePar) : listMargTrees(listTreesPar), distPairwise(distPairwisePar)
{
    // just take the given distance
}

int ReticualteNetLB :: Calculate()
{

	if( listMargTrees.size() == 3 )
	{
		return CalcLB3Trees();
	}
	int res = 0;
	// start from the largest value in dist matrix
	for(int t1=0; t1<(int)distPairwise.size(); ++t1  )
	{
		for(int t2=t1+1; t2<(int)distPairwise.size(); ++t2)
		{
			if( distPairwise[t1][t2] > res )
			{
				res = distPairwise[t1][t2];
			}
		}
	}
	// if no non-zero values exist, done: these trees are all the same
	if( res == 0 )
	{
		return 0;
	}

#if 0
	//*********************** test code 08062010
	HypercubePointsPlacement hppSolver(distPairwise);
	for(int dimH = res; ; dimH ++)
	{
		if( hppSolver.IsFeasibleFor( dimH) == true )
		{
			res = dimH;
			break;
		}
	}
cout << "***** RH bound (FOUND by HYPERCUBE points) is " << res << endl;
//exit(1);
#endif

	while(true)
	{
		if( IsHCFeasible( res ) == true )
		{
			break;
		}
		else
		{
			res ++;
		}
cout << "...Current LB = " << res << endl;
	}

	if( listMargTrees.size() == 3 )
	{
		YW_ASSERT_INFO( CalcLB3Trees() == res, "Lower bound is wrong" );
	}

	return res;	// TBD
}

int ReticualteNetLB :: CalcLB3Trees()
{
	// have an analytical bound here
	YW_ASSERT_INFO( listMargTrees.size() == 3, "This only works for three trees" );
	YW_ASSERT_INFO( distPairwise.size() == 3, "Must initialize pairwise distances" );
	int res = distPairwise[0][1] + distPairwise[0][2] + distPairwise[1][2];
	if( (res % 2 ) == 1 )
	{
		res++;
	}
	return res/2;
}


void ReticualteNetLB :: InitPairDists()
{
	distPairwise.clear();
	distPairwise.resize(listMargTrees.size());
	for(int i=0; i<(int)distPairwise.size(); ++i)
	{
		distPairwise[i].resize( listMargTrees.size() );
	}
	// 
	for(int i=0; i<(int)listMargTrees.size(); ++i)
	{
		for(int j=i+1; j<(int)listMargTrees.size(); ++j)
		{
	        ILPSolverSPR solver( listMargTrees[i], listMargTrees[j] );
			solver.SetAcyclic(  true );		// want to focus on acyclic ones
			int distSPR = solver.ComputeILP();
			cout << "The reticulation distance between T" << i << " and T" << j << ": " << distSPR << endl;
			distPairwise[i][j] = distSPR;
			distPairwise[j][i] = distSPR;
		}
	}
}

bool ReticualteNetLB :: IsHCFeasible( int szHC )
{
	// Now, we first create a LP problem
	int numXVars = distPairwise.size() * szHC;
	int numMVars = distPairwise.size() *( distPairwise.size()-1 )*szHC/2;
	int numTotVarsNum = numXVars + numMVars;


	// figure out constraints
	vector<ILP_CONSTRAINT> listConstraints;

	// fix the first row to be all-0
	for(int j=0; j<szHC; ++j)
	{
		ILP_CONSTRAINT ilpc;
		ilpc.nonzeroPos.push_back( GetXVarPos( 0, j, szHC )  );
		ilpc.coefficients.push_back(1.0);
		ilpc.rhsBound = 0.0;
		ilpc.fLB = false;
		listConstraints.push_back(ilpc);
	}

	// varialbes: M = 1 if two positions matches 
	for( int i = 0; i<(int)distPairwise.size(); ++i )
	{
		for( int j = i+1; j<(int)distPairwise.size(); ++j )
		{
			for(int k=0; k<szHC; ++k)
			{
				ILP_CONSTRAINT ilpc1;
				int mvarpos =  GetMVarPos( numXVars, szHC, i, j, k );
				YW_ASSERT_INFO( mvarpos < numTotVarsNum, "Variable out of bounds in ILP" );
				ilpc1.nonzeroPos.push_back(  mvarpos );
				ilpc1.coefficients.push_back(1.0);
				ilpc1.nonzeroPos.push_back( GetXVarPos( i, k, szHC )  );
				ilpc1.coefficients.push_back(1.0);
				ilpc1.nonzeroPos.push_back( GetXVarPos( j, k, szHC )  );
				ilpc1.coefficients.push_back(1.0);
				ilpc1.rhsBound = 1.0;
				ilpc1.fLB = true;
				listConstraints.push_back(ilpc1);


				ILP_CONSTRAINT ilpc2;
				ilpc2.nonzeroPos.push_back( mvarpos );
				ilpc2.coefficients.push_back(1.0);
				ilpc2.nonzeroPos.push_back( GetXVarPos( i, k, szHC )  );
				ilpc2.coefficients.push_back(-1.0);
				ilpc2.nonzeroPos.push_back( GetXVarPos( j, k, szHC )  );
				ilpc2.coefficients.push_back(-1.0);
				ilpc2.rhsBound = -1.0;
				ilpc2.fLB = true;
				listConstraints.push_back(ilpc2);
			}
		}
	}

	// pairwise constraints
	for( int i = 0; i<(int)distPairwise.size(); ++i )
	{
		for( int j = i+1; j<(int)distPairwise.size(); ++j )
		{
			ILP_CONSTRAINT ilpc;
			for(int k=0; k<szHC; ++k)
			{
				ilpc.nonzeroPos.push_back( GetMVarPos(numXVars, szHC, i, j, k )  );
				ilpc.coefficients.push_back(1.0);
				ilpc.rhsBound = szHC - distPairwise[i][j] ;

			}
			ilpc.fLB = false;
			listConstraints.push_back(ilpc);
		}
	}



	///////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////
	// call ILP solver
    ILPSolver *pILPSolver;
#ifdef LPSOLVER_CPLEX
	pILPSolver = new CPlexILPSolver;
#endif

#ifdef LPSOLVER_GLPK
	pILPSolver = new GLPKILPSolver;
#endif


	pILPSolver->CreateProblem( listConstraints.size(), numTotVarsNum, true );    // we want to minimize

	///////////////////////////////////////////////////////////////////////////////////////////////
    // setup variables (coluns)
    //int c = 0;
    // first part is the Ci
	for( int i = 0; i<(int)distPairwise.size(); ++i )
	{
		for(int j=0; j<szHC; ++j)
		{
			int realVarId = GetXVarPos( i, j, szHC );
			char objName[1280];
			objName[0] = 'X'; 
			sprintf(&objName[1], ",%d,%d", i, j );
			// the var can be any of the integer value
			// How do we assign coefficient to it
			double coeff = 0.0;
			pILPSolver->SetupVar( realVarId, objName, coeff, true);	
		}
	}

	for( int i = 0; i<(int)distPairwise.size(); ++i )
	{
		for( int j = i+1; j<(int)distPairwise.size(); ++j )
		{
			for(int k=0; k<szHC; ++k)
			{

				int realVarId = GetMVarPos(numXVars, szHC, i, j, k );
				char objName[1280];
				objName[0] = 'M'; 
				sprintf(&objName[1], ",%d,%d,%d", i, j, k );
				// the var can be any of the integer value
				// How do we assign coefficient to it
				double coeff = 0.0;
				pILPSolver->SetupVar( realVarId, objName, coeff, true);	
			}
		}
	}

    //setup constraints
    int rcons = 0;
    for( int i = 0; i < (int) listConstraints.size(); ++i)
    {
		HAP_ILP_SENSE bdType = HAP_ILP_LB;
		if( listConstraints[i].fLB == false )
		{
			bdType = HAP_ILP_UB;
		}
        pILPSolver->AddConstraint( rcons++, listConstraints[i].nonzeroPos, listConstraints[i].coefficients, 
			listConstraints[i].rhsBound, bdType);
    }


    //solve and retrive the result
	ILPSolution solILP(0, numTotVarsNum-1);
	solILP.Init( numTotVarsNum, numTotVarsNum, NULL);
	bool f = pILPSolver->Solve( solILP );

    // free up ILP
    delete pILPSolver;

	if( f == false)
	{
		// Infeasible
		return false; 
	}


	// feasible
	return true;

}

int ReticualteNetLB :: GetXVarPos(int t1, int h, int szHC)
{
	// get position of xvars
	YW_ASSERT_INFO( t1 <(int)distPairwise.size(), "Parameter wrong in GetXVarPos" );
	//return ConvertToLinear(t1, t2, distPairwise.size() );
	return t1*szHC + h;
}

int ReticualteNetLB :: GetMVarPos( int numXVars, int szHC, int t1, int t2, int h )
{
	// get position of mvars
	return numXVars + ConvertToLinear(t1, t2, distPairwise.size() ) *szHC + h;
}

//*********************************************************************
// Cherry bound: a much faster lower bound


ReticulateCherryBound:: ReticulateCherryBound(vector<MarginalTree> &listMargTreesIn) : listMargTrees(listMargTreesIn)
{
}
int ReticulateCherryBound :: Calculate()
{
    // get all the cherries from all trees
    int minCherries = GetNumTaxa();
    set<pair<int,int> > setAllCherries;
    for(unsigned int i=0; i<listMargTrees.size(); ++i)
    {
        set<pair<int,int> > setCherries;
        GetCherryFor(listMargTrees[i], setCherries);
        if( setCherries.size() < minCherries )
        {
            minCherries = setCherries.size();
        }
        // add cherries
        UnionSetsGen(setAllCherries, setCherries);
    }
cout << "Number of distinct cherries: " << setAllCherries.size() << ", minimum number of cherries in single tree: " << minCherries << endl;
    
    // now compute the cherry bound
    double cb = (std::sqrt(8*(setAllCherries.size()-minCherries)+1) -1.0)/2;
    int cherryBound = std::ceil(cb);
    return cherryBound;
}

int ReticulateCherryBound :: CalculateComposite()
{
    // calculate a pairwise distance by cherry bound
    vector<vector<int> > distPairwiseCB(GetNumTrees());
    for(int i=0; i<GetNumTrees(); ++i)
    {
        for(int j=0; j<GetNumTrees(); ++j)
        {
            distPairwiseCB[i].push_back(0);
        }
    }
    // get all the cherries
    vector< set<pair<int,int> > > listSetCherries(GetNumTrees());
    for(int i=0; i<GetNumTrees(); ++i)
    {
        GetCherryFor(listMargTrees[i], listSetCherries[i]);
    }
    for(int i=0; i<GetNumTrees(); ++i)
    {
        for(int j=i+1; j<GetNumTrees(); ++j)
        {
            set<pair<int,int> > set12=listSetCherries[i], set21=listSetCherries[j];
            SubtractSetsGen(set12, listSetCherries[j]);
            SubtractSetsGen(set21, listSetCherries[i]);
            int c2 = std::max( set12.size(), set21.size() );
            double cb = (std::sqrt(8*c2+1) -1.0)/2;
            int cherryBound = std::ceil(cb);
cout << "Tree pairs: " << i << "," << j << ": " << cherryBound << endl;
            distPairwiseCB[i][j] = cherryBound;
            distPairwiseCB[j][i] = cherryBound;
        }
    }
    // calculate the composite bound
    ReticualteNetLB lber(listMargTrees, distPairwiseCB);
    int bdComposite = lber.Calculate();
    return bdComposite;
}

//
void ReticulateCherryBound :: GetCherryFor(const MarginalTree &tr, std::set<pair<int,int> > &setCherries) const
{
cout << "GetCherryFor: tree: " << tr.GetNewick() << endl;
    setCherries.clear();
    vector<pair<int,int> > listSibPairs;
    tr.FindSibLeafPairs( listSibPairs );
    for(unsigned int i=0; i<listSibPairs.size(); ++i)
    {
        int c1 = listSibPairs[i].first;
        int c2 = listSibPairs[i].second;
        int lbl1 = tr.GetLabel(c1);
        int lbl2 = tr.GetLabel(c2);
        OrderInt(lbl1, lbl2);
        pair<int,int> pp(lbl1, lbl2);
        setCherries.insert(pp);
cout << "Cherry: " << lbl1 << "," << lbl2 << endl;
    }
}

int ReticulateCherryBound :: GetNumTaxa() const
{
    YW_ASSERT_INFO(listMargTrees.size() > 0, "List of trees: empty");
    return listMargTrees[0].GetNumLeaves();
}
